<?php
namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Services\NotificationService;

class CheckOverstay extends BaseCommand
{
    protected $group='Parking'; protected $name='parking:check-overstay'; protected $description='Periksa tamu yang melewati batas durasi dan buat notifikasi.';
    public function run(array $params)
    {
        $hour=(int)date('G'); $limit=($hour>=5&&$hour<18)?3:6;
        $rows=db_connect()->table('visits v')->select('v.id,v.check_in,v.plate_no,vs.name,u.unit_no,c.name cluster_name')->join('visitors vs','vs.id=v.visitor_id')->join('units u','u.id=v.unit_id')->join('clusters c','c.id=u.cluster_id')->where('v.deleted_at',null)->where('v.status','inside')->where('v.check_in <',date('Y-m-d H:i:s',time()-$limit*3600))->get()->getResultArray();
        $service=new NotificationService(); $count=0;
        foreach($rows as $row){
            $exists=db_connect()->table('notifications')->where('deleted_at',null)->where(['visit_id'=>$row['id'],'type'=>'visitor_overstay'])->where('created_at >=',date('Y-m-d H:00:00'))->countAllResults();
            if(!$exists){$service->queue((int)$row['id'],'visitor_overstay','Tamu melebihi durasi',"{$row['name']} ({$row['plate_no']}) tujuan {$row['cluster_name']} {$row['unit_no']} masih berada di area.",'popup,email,whatsapp');$count++;}
        }
        CLI::write("{$count} notifikasi dibuat.",'green');
    }
}
