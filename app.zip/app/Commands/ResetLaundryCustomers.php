<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use CodeIgniter\Database\BaseConnection;
use RuntimeException;
use Throwable;

/**
 * Mengembalikan data Eksis Laundry ke kondisi sebelum customer pertama dibuat.
 *
 * Master/platform configuration sengaja tidak disentuh. Perintah ini hanya dapat
 * mengeksekusi penghapusan jika menerima frasa konfirmasi yang tepat.
 */
class ResetLaundryCustomers extends BaseCommand
{
    private const CONFIRMATION = 'HAPUS-SEMUA-CUSTOMER';

    protected $group = 'Eksis Laundry';
    protected $name = 'laundry:reset-customers';
    protected $description = 'Hapus permanen semua customer laundry dan seluruh data tenant terkait.';
    protected $usage = 'laundry:reset-customers [--confirm HAPUS-SEMUA-CUSTOMER] [--keep-files]';
    protected $options = [
        '--confirm' => 'Frasa wajib untuk menjalankan reset permanen.',
        '--keep-files' => 'Jangan hapus logo, foto user, dan bukti pembayaran tenant.',
    ];

    /**
     * Urutan child ke parent. Daftar ini sengaja eksplisit agar tabel konfigurasi
     * platform yang baru tidak ikut terhapus secara tidak sengaja.
     *
     * @var list<string>
     */
    private array $tenantTables = [
        'ex_product_branches',
        'ex_discount_branches',
        'ex_inventory_movements',
        'ex_order_payments',
        'ex_order_status_history',
        'ex_order_items',
        'ex_voucher_usages',
        'ex_license_devices',
        'ex_license_history',
        'ex_user_tokens',
        'ex_whatsapp_sessions',
        'ex_notifications',
        'ex_logs',
        'ex_payments',
        'ex_invoices',
        'ex_orders',
        'ex_inventory_items',
        'ex_assets',
        'ex_expenses',
        'ex_employees',
        'ex_discounts',
        'ex_products',
        'ex_customers',
        'ex_devices',
        'ex_users',
        'ex_branches',
        'ex_licenses',
        'ex_companies',
        'ex_otps',
    ];

    public function run(array $params)
    {
        $db = db_connect();
        $tables = array_values(array_filter(
            $this->tenantTables,
            static fn (string $table): bool => $db->tableExists($table)
        ));

        $this->showPreview($db, $tables);

        if ((string) CLI::getOption('confirm') !== self::CONFIRMATION) {
            CLI::newLine();
            CLI::write('PRATINJAU SAJA - belum ada data atau file yang dihapus.', 'yellow');
            CLI::write(
                'Untuk menjalankan: php spark laundry:reset-customers --confirm ' . self::CONFIRMATION,
                'yellow'
            );
            return EXIT_SUCCESS;
        }

        $originalForeignKeyChecks = (int) ($db->query('SELECT @@FOREIGN_KEY_CHECKS AS enabled')
            ->getRowArray()['enabled'] ?? 1);

        try {
            $db->query('SET FOREIGN_KEY_CHECKS = 0');
            $db->transBegin();

            foreach ($tables as $table) {
                // DELETE dipakai di dalam transaksi; berbeda dari TRUNCATE yang
                // melakukan implicit commit dan sulit dipulihkan saat gagal.
                $db->query('DELETE FROM `' . $table . '`');
            }

            // Pemakaian voucher merupakan data tenant. Master voucher dipertahankan,
            // tetapi penghitung hasil testing harus dikembalikan ke kondisi awal.
            if ($db->tableExists('ex_vouchers')) {
                $db->table('ex_vouchers')->set('qty_used', 0)->update();
                $db->table('ex_vouchers')->where('status', 'USED')->update(['status' => 'AVAILABLE']);
            }

            if ($db->transStatus() === false) {
                throw new RuntimeException('Transaksi database gagal.');
            }

            $db->transCommit();

            foreach ($tables as $table) {
                $db->query('ALTER TABLE `' . $table . '` AUTO_INCREMENT = 1');
            }

            if (! CLI::getOption('keep-files')) {
                $this->removeTenantUploads();
            }
        } catch (Throwable $e) {
            $db->transRollback();
            CLI::error('Reset gagal: ' . $e->getMessage());
            return EXIT_ERROR;
        } finally {
            $db->query('SET FOREIGN_KEY_CHECKS = ' . $originalForeignKeyChecks);
        }

        CLI::newLine();
        CLI::write('Reset selesai. Database sekarang belum memiliki customer laundry.', 'green');
        CLI::write('Konfigurasi platform dan akun administrator tetap dipertahankan.', 'green');
        return EXIT_SUCCESS;
    }

    /** @param list<string> $tables */
    private function showPreview(BaseConnection $db, array $tables): void
    {
        CLI::write('Database : ' . $db->getDatabase(), 'cyan');
        CLI::write('Data tenant yang akan dihapus permanen:', 'cyan');

        $total = 0;
        foreach ($tables as $table) {
            $count = $db->table($table)->countAllResults();
            $total += $count;
            CLI::write(sprintf('  %-30s %d baris', $table, $count));
        }

        CLI::write('  TOTAL                          ' . $total . ' baris', 'yellow');
        CLI::newLine();
        CLI::write('Tetap dipertahankan:', 'cyan');
        CLI::write('  paket, fitur, kategori produk global, rekening/QRIS, voucher master,');
        CLI::write('  panduan mobile, pengaturan aplikasi, email/WhatsApp, menu, role, dan admin.');
    }

    private function removeTenantUploads(): void
    {
        foreach (['companies', 'users', 'payments'] as $folder) {
            $path = FCPATH . 'uploads' . DIRECTORY_SEPARATOR . $folder;
            $this->removeDirectoryContents($path);
        }
    }

    private function removeDirectoryContents(string $directory): void
    {
        if (! is_dir($directory)) {
            return;
        }

        $realDirectory = realpath($directory);
        $uploadRoot = realpath(FCPATH . 'uploads');
        if ($realDirectory === false || $uploadRoot === false
            || ! str_starts_with($realDirectory . DIRECTORY_SEPARATOR, $uploadRoot . DIRECTORY_SEPARATOR)
        ) {
            throw new RuntimeException('Lokasi upload tenant tidak aman: ' . $directory);
        }

        $iterator = new \FilesystemIterator($realDirectory, \FilesystemIterator::SKIP_DOTS);
        foreach ($iterator as $item) {
            if ($item->isDir() && ! $item->isLink()) {
                $this->removeDirectoryTree($item->getPathname(), $uploadRoot);
                continue;
            }

            if (! unlink($item->getPathname())) {
                throw new RuntimeException('Gagal menghapus file: ' . $item->getPathname());
            }
        }
    }

    private function removeDirectoryTree(string $directory, string $uploadRoot): void
    {
        $realDirectory = realpath($directory);
        if ($realDirectory === false
            || ! str_starts_with($realDirectory . DIRECTORY_SEPARATOR, $uploadRoot . DIRECTORY_SEPARATOR)
        ) {
            throw new RuntimeException('Lokasi subfolder tenant tidak aman: ' . $directory);
        }

        foreach (new \FilesystemIterator($realDirectory, \FilesystemIterator::SKIP_DOTS) as $item) {
            if ($item->isDir() && ! $item->isLink()) {
                $this->removeDirectoryTree($item->getPathname(), $uploadRoot);
            } elseif (! unlink($item->getPathname())) {
                throw new RuntimeException('Gagal menghapus file: ' . $item->getPathname());
            }
        }

        if (! rmdir($realDirectory)) {
            throw new RuntimeException('Gagal menghapus folder: ' . $realDirectory);
        }
    }
}
