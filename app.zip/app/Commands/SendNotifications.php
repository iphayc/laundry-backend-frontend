<?php
namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\NotificationModel;

class SendNotifications extends BaseCommand
{
    protected $group='Parking'; protected $name='parking:send-notifications'; protected $description='Kirim antrean notifikasi email dan WhatsApp.';
    public function run(array $params)
    {
        $model=new NotificationModel(); $rows=$model->where('status','pending')->findAll(100); $wa=new \App\Services\WhatsAppService(); $ns=new \App\Services\NotificationService();
        foreach($rows as $row){$ok=true; if(str_contains($row['channel'],'email')){$to=(string)env('email.recipients',env('email.fromEmail'));$ok=$ns->email($to,$row['title'],$row['message'])&&$ok;} if(str_contains($row['channel'],'whatsapp')){$to=(string)env('whatsapp.alertRecipient','');if($to)$ok=$wa->send($to,$row['message'])['success']&&$ok;} $model->update($row['id'],['status'=>$ok?'sent':'failed','sent_at'=>$ok?date('Y-m-d H:i:s'):null]);}
        CLI::write(count($rows).' notifikasi diproses.','green');
    }
}
