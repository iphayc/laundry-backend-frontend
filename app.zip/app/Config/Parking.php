<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class Parking extends BaseConfig
{
    public string $gateApiKey;
    public int $dayStart = 5;
    public int $nightStart = 18;
    public int $dayLimitHours = 3;
    public int $nightLimitHours = 6;

    public function __construct()
    {
        parent::__construct();
        $this->gateApiKey = (string) env('gate.apiKey', '');
    }
}
