<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class WhatsApp extends BaseConfig
{
    public string $baseUrl;
    public string $phoneNumberId;
    public string $token;
    public string $defaultCountryCode;

    public function __construct()
    {
        parent::__construct();
        $this->baseUrl = rtrim((string) env('whatsapp.baseUrl', 'https://graph.facebook.com/v21.0'), '/');
        $this->phoneNumberId = (string) env('whatsapp.phoneNumberId', '');
        $this->token = (string) env('whatsapp.token', '');
        $this->defaultCountryCode = (string) env('whatsapp.defaultCountryCode', '62');
    }
}
