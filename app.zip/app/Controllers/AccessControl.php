<?php
namespace App\Controllers;
class AccessControl extends BaseController
{
    public function index()
    {
        $db=db_connect();$roles=$db->table('roles')->where('deleted_at',null)->get()->getResultArray();$selectedRole=(int)($this->request->getGet('role_id')?:($roles[0]['id']??0));$permissions=$db->table('permissions')->where('deleted_at',null)->orderBy('module')->get()->getResultArray();$permissionRows=$db->table('role_permissions')->where('role_id',$selectedRole)->get()->getResultArray();$permissionAccess=[];foreach($permissionRows as $access)$permissionAccess[(int)$access['permission_id']]=$access;$rawMenus=$db->table('menus')->where('deleted_at',null)->orderBy('sort_order')->get()->getResultArray();$menus=$this->flattenMenus($rawMenus);$accessRows=$db->table('role_menus')->where('role_id',$selectedRole)->get()->getResultArray();$menuAccess=[];foreach($accessRows as $access)$menuAccess[(int)$access['menu_id']]=$access;
        return view('access/index',['title'=>'Access Control','roles'=>$roles,'selectedRole'=>$selectedRole,'permissions'=>$permissions,'permissionAccess'=>$permissionAccess,'menus'=>$menus,'menuAccess'=>$menuAccess]);
    }
    public function save()
    {
        $role=(int)$this->request->getPost('role_id');
        if($role<=0)return redirect()->back()->with('warning','Pilih role yang akan diperbarui.');
        try {
            $ids=array_map('intval',(array)$this->request->getPost('permissions'));$permissionCrud=(array)$this->request->getPost('permission_crud');$menuIds=array_map('intval',(array)$this->request->getPost('menus'));$crud=(array)$this->request->getPost('crud');$db=db_connect();$db->transStart();$db->table('role_permissions')->where('role_id',$role)->delete();foreach($ids as $id){$rights=(array)($permissionCrud[$id]??[]);$db->table('role_permissions')->insert(['role_id'=>$role,'permission_id'=>$id,'can_create'=>isset($rights['create'])?1:0,'can_read'=>isset($rights['read'])?1:0,'can_update'=>isset($rights['update'])?1:0,'can_delete'=>isset($rights['delete'])?1:0]);}$db->table('role_menus')->where('role_id',$role)->delete();foreach($menuIds as $id){$rights=(array)($crud[$id]??[]);$db->table('role_menus')->insert(['role_id'=>$role,'menu_id'=>$id,'can_create'=>isset($rights['create'])?1:0,'can_read'=>isset($rights['read'])?1:0,'can_update'=>isset($rights['update'])?1:0,'can_delete'=>isset($rights['delete'])?1:0]);}$db->transComplete();
            if(!$db->transStatus())return redirect()->back()->with('error','Hak akses gagal disimpan karena transaksi database gagal.');
            return redirect()->to('/access-control?role_id='.$role)->with('success','Hak akses menu, permission, dan CRUD berhasil diperbarui.');
        } catch (\Throwable $e) {
            log_message('error','AccessControl save: '.$e->getMessage());
            return redirect()->back()->with('error','Terjadi error saat menyimpan hak akses.');
        }
    }

    private function flattenMenus(array $rows,?int $parentId=null,int $depth=0): array
    {
        $flat=[];
        foreach($rows as $row){$rowParent=$row['parent_id']===null?null:(int)$row['parent_id'];if($rowParent===$parentId){$row['depth']=$depth;$flat[]=$row;$flat=[...$flat,...$this->flattenMenus($rows,(int)$row['id'],$depth+1)];}}
        return $flat;
    }
}
