<?php
namespace App\Controllers;

use App\Models\UserModel;
use App\Services\PasswordPolicy;

class Account extends BaseController
{
    public function updateProfile()
    {
        $name=trim((string)$this->request->getPost('name'));
        $email=trim((string)$this->request->getPost('email'));
        $phone=trim((string)$this->request->getPost('phone'));
        if($name==='')return redirect()->back()->with('error','Nama wajib diisi.')->with('open_modal','profile-modal');
        if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))return redirect()->back()->with('error','Alamat email tidak valid.')->with('open_modal','profile-modal');
        $id=(int)session('user_id');$db=db_connect();$db->transStart();
        (new UserModel())->update($id,['name'=>$name,'email'=>$email?:null,'phone'=>$phone?:null]);
        $db->table('audit_logs')->insert(['user_id'=>$id,'action'=>'UPDATE_PROFILE','table_name'=>'users','record_id'=>(string)$id,'new_data'=>json_encode(['name'=>$name,'email'=>$email,'phone'=>$phone]),'ip_address'=>$this->request->getIPAddress(),'created_at'=>date('Y-m-d H:i:s')]);
        $db->transComplete();session()->set('user_name',$name);
        if(!$db->transStatus())return redirect()->back()->with('error','Profil gagal diperbarui karena transaksi database gagal.')->with('open_modal','profile-modal');
        return redirect()->back()->with('success','Profil berhasil diperbarui.');
    }

    public function changePassword()
    {
        $model=new UserModel();$id=(int)session('user_id');$user=$model->find($id);
        $current=(string)$this->request->getPost('current_password');$password=(string)$this->request->getPost('password');$confirmation=(string)$this->request->getPost('password_confirm');
        if(!$user||!password_verify($current,$user['password_hash']))return redirect()->back()->with('error','Password lama salah.')->with('open_modal','password-modal');
        if($error=(new PasswordPolicy())->validate($password))return redirect()->back()->with('error',$error)->with('open_modal','password-modal');
        if($password!==$confirmation)return redirect()->back()->with('error','Konfirmasi password baru tidak sama.')->with('open_modal','password-modal');
        if(!$model->update($id,['password_hash'=>password_hash($password,PASSWORD_DEFAULT)]))return redirect()->back()->with('error','Password gagal diubah.')->with('open_modal','password-modal');
        db_connect()->table('audit_logs')->insert(['user_id'=>$id,'action'=>'CHANGE_PASSWORD','table_name'=>'users','record_id'=>(string)$id,'ip_address'=>$this->request->getIPAddress(),'created_at'=>date('Y-m-d H:i:s')]);
        return redirect()->back()->with('success','Password berhasil diubah.');
    }
}
