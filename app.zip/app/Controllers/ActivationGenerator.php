<?php

namespace App\Controllers;

use App\Models\IssuedApplicationLicenseModel;
use App\Services\LicenseService;
use App\Services\NotificationService;
use CodeIgniter\Exceptions\PageNotFoundException;

class ActivationGenerator extends BaseController
{
    private LicenseService $license;

    public function index()
    {
        $this->assertGeneratorAvailable();

        if (! $this->administrator()) {
            return redirect()->to('/dashboard')
                ->with('error', 'Form pembuat kode aktivasi hanya tersedia untuk Administrator pemilik.');
        }

        return view('activation_generator/index', [
            'title' => 'Pembuat Kode Aktivasi',
        ]);
    }

    public function data()
    {
        $this->assertGeneratorAvailable();

        if (! $this->administrator()) {
            return $this->response->setStatusCode(403)->setJSON([
                'data' => [],
                'message' => 'Akses ditolak.',
            ]);
        }

        $rows = db_connect()
            ->table('issued_application_licenses l')
            ->select('l.id, l.registered_email, l.machine_id, l.active, l.registered_at, l.last_generated_at, u.name AS creator_name')
            ->join('users u', 'u.id = l.created_by', 'left')
            ->where('l.deleted_at', null)
            ->orderBy('l.registered_at', 'DESC')
            ->get()
            ->getResultArray();

        return $this->response->setJSON(['data' => $rows]);
    }

    public function generate()
    {
        $this->assertGeneratorAvailable();

        if (! $this->administrator()) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Akses ditolak.',
            ]);
        }

        $email = strtolower(trim((string) $this->request->getPost('email')));
        $machineId = strtolower(trim((string) $this->request->getPost('machine_id')));

        if (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Alamat email pemohon tidak valid.',
            ]);
        }

        if ($machineId === '' || mb_strlen($machineId) > 255) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Machine ID wajib diisi dan maksimal 255 karakter.',
            ]);
        }

        $generatedCode = $this->license->activationCode($email, $machineId);
        $machineHash = $this->license->machineFingerprint($machineId);
        $model = new IssuedApplicationLicenseModel();
        $existing = $model
            ->where('registered_email', $email)
            ->where('machine_id_hash', $machineHash)
            ->first();
        $now = date('Y-m-d H:i:s');
        $licenseData = [
            'registered_email' => $email,
            'machine_id' => $machineId,
            'machine_id_hash' => $machineHash,
            'license_code_hash' => password_hash($generatedCode, PASSWORD_DEFAULT),
            'active' => 1,
            'registered_at' => $existing['registered_at'] ?? $now,
            'last_generated_at' => $now,
            'created_by' => (int) session('user_id'),
        ];

        $saved = $existing
            ? $model->update($existing['id'], $licenseData)
            : $model->insert($licenseData);

        if (! $saved) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Kode berhasil dihitung, tetapi data registrasi gagal disimpan.',
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => $existing
                ? 'Kode aktivasi berhasil dibuat ulang dan data registrasi diperbarui.'
                : 'Kode aktivasi berhasil dibuat dan data registrasi disimpan.',
            'code' => $generatedCode,
        ]);
    }

    public function detail(int $id)
    {
        $this->assertGeneratorAvailable();

        if (! $this->administrator()) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Akses ditolak.',
            ]);
        }

        $registration = $this->registrationById($id);
        if (! $registration) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Data registrasi tidak ditemukan.',
            ]);
        }

        $code = $this->license->activationCode(
            (string) $registration['registered_email'],
            (string) $registration['machine_id']
        );

        if (! password_verify($code, (string) $registration['license_code_hash'])) {
            return $this->response->setStatusCode(409)->setJSON([
                'success' => false,
                'message' => 'Hash kode aktivasi tidak sesuai. Silakan generate ulang lisensi.',
            ]);
        }

        unset($registration['license_code_hash']);

        return $this->response->setJSON([
            'success' => true,
            'data' => $registration + ['activation_code' => $code],
        ]);
    }

    public function sendEmail(int $id)
    {
        $this->assertGeneratorAvailable();

        if (! $this->administrator()) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Akses ditolak.',
            ]);
        }

        $registration = $this->registrationById($id);
        if (! $registration) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Data registrasi tidak ditemukan.',
            ]);
        }

        $email = (string) $registration['registered_email'];
        $machineId = (string) $registration['machine_id'];
        $code = $this->license->activationCode($email, $machineId);

        if (! password_verify($code, (string) $registration['license_code_hash'])) {
            return $this->response->setStatusCode(409)->setJSON([
                'success' => false,
                'message' => 'Hash kode aktivasi tidak sesuai. Silakan generate ulang lisensi.',
            ]);
        }

        $companyName = $this->companyProfile['residence_name'] ?? 'Parking Cluster & Gate VMS';
        $message = '<p>Permintaan kode aktivasi aplikasi telah diproses.</p>'
            . '<p><strong>Aplikasi:</strong> ' . esc($companyName) . '</p>'
            . '<p><strong>Email:</strong> ' . esc($email) . '</p>'
            . '<p><strong>Machine ID:</strong></p><p><code>' . esc($machineId) . '</code></p>'
            . '<p><strong>Kode Aktivasi:</strong></p><h2>' . esc($code) . '</h2>'
            . '<p>Kode ini hanya berlaku untuk kombinasi email dan Machine ID tersebut.</p>';
        $sent = (new NotificationService())->email(
            $email,
            'Kode Aktivasi ' . $companyName,
            $message
        );

        return $this->response
            ->setStatusCode($sent ? 200 : 502)
            ->setJSON([
                'success' => $sent,
                'message' => $sent
                    ? 'Kode aktivasi berhasil dikirim ke ' . $email . '.'
                    : 'Kode aktivasi gagal dikirim. Periksa Setting Email dan Log Email.',
            ]);
    }

    private function assertGeneratorAvailable(): void
    {
        $this->license = new LicenseService();
        $ownerMachineHash = strtolower(trim((string) env('license.generatorMachineHash', '')));

        if (! filter_var(env('license.generatorEnabled', false), FILTER_VALIDATE_BOOL)
            || $ownerMachineHash === ''
            || ! hash_equals($ownerMachineHash, $this->license->machineFingerprint())) {
            throw PageNotFoundException::forPageNotFound();
        }
    }

    private function administrator(): ?array
    {
        return db_connect()
            ->table('users u')
            ->select('u.id, u.username, r.name AS role_name')
            ->join('roles r', 'r.id = u.role_id')
            ->where('u.id', (int) session('user_id'))
            ->where('u.active', 1)
            ->where('u.deleted_at', null)
            ->where('r.deleted_at', null)
            ->where('r.name', 'Administrator')
            ->get()
            ->getRowArray() ?: null;
    }

    private function registrationById(int $id): ?array
    {
        return db_connect()
            ->table('issued_application_licenses l')
            ->select('l.id, l.registered_email, l.machine_id, l.machine_id_hash, l.license_code_hash, l.active, l.registered_at, l.last_generated_at, u.name AS creator_name')
            ->join('users u', 'u.id = l.created_by', 'left')
            ->where('l.id', $id)
            ->where('l.deleted_at', null)
            ->get()
            ->getRowArray() ?: null;
    }
}
