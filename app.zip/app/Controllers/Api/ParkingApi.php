<?php
namespace App\Controllers\Api;
use App\Services\GateService;
class ParkingApi extends SecuredApiController
{
    protected $format='json';
    public function health(){return $this->respond(['status'=>'ok','version'=>'1.0.0','time'=>date(DATE_ATOM)]);}
    public function tap(){if($response=$this->requireApiKey())return $response;return $this->respond((new GateService())->process($this->request->getJSON(true)??[]));}
    public function traffic(){if($response=$this->requireApiKey())return $response;return $this->respond(db_connect()->table('access_logs')->select("DATE(event_time) day, subject_type, result, COUNT(*) total")->where('deleted_at',null)->groupBy(['DATE(event_time)','subject_type','result'])->orderBy('day','DESC')->limit(100)->get()->getResultArray());}
    public function search(){if($response=$this->requireApiKey())return $response;$q=trim((string)$this->request->getGet('q'));if(strlen($q)<2||strlen($q)>80)return $this->failValidationErrors(['q'=>'Pencarian harus 2 sampai 80 karakter.']);$rows=db_connect()->table('access_logs')->where('deleted_at',null)->groupStart()->like('card_no',$q)->orLike('plate_no',$q)->orLike('reason',$q)->groupEnd()->orderBy('event_time','DESC')->limit(100)->get()->getResultArray();return $this->respond($rows);}
}
