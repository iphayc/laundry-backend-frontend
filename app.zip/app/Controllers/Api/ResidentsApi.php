<?php
namespace App\Controllers\Api;

class ResidentsApi extends SecuredApiController
{
    protected $modelName = 'App\Models\ResidentModel';
    protected $format = 'json';
    private const WRITABLE_FIELDS = [
        'unit_id', 'household_head_id', 'is_household_head', 'identity_no', 'name',
        'gender', 'birth_date', 'address', 'phone', 'email', 'identity_image',
        'suspended', 'suspension_note',
    ];

    public function index()
    {
        if ($response = $this->requireApiKey()) return $response;
        return $this->respond($this->model->orderBy('id', 'DESC')->findAll(500));
    }

    public function show($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        $row = ctype_digit((string) $id) ? $this->model->find((int) $id) : null;
        return $row ? $this->respond($row) : $this->failNotFound('Penghuni tidak ditemukan.');
    }

    public function create()
    {
        if ($response = $this->requireApiKey()) return $response;
        $data = $this->payload(self::WRITABLE_FIELDS);
        if ($errors = $this->payloadErrors()) return $this->failValidationErrors($errors);
        if ($errors = $this->validatePayload($data)) return $this->failValidationErrors($errors);
        $id = $this->model->insert($data, true);
        return $id ? $this->respondCreated(['id' => $id]) : $this->failValidationErrors($this->model->errors());
    }

    public function update($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        if (! ctype_digit((string) $id) || ! $this->model->find((int) $id)) {
            return $this->failNotFound('Penghuni tidak ditemukan.');
        }
        $data = $this->payload(self::WRITABLE_FIELDS);
        if ($errors = $this->payloadErrors()) return $this->failValidationErrors($errors);
        if ($errors = $this->validatePayload($data, (int) $id, true)) return $this->failValidationErrors($errors);
        return $this->model->update((int) $id, $data)
            ? $this->respond(['success' => true])
            : $this->failValidationErrors($this->model->errors());
    }

    public function delete($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        if (! ctype_digit((string) $id) || ! $this->model->find((int) $id)) {
            return $this->failNotFound('Penghuni tidak ditemukan.');
        }
        return $this->model->delete((int) $id)
            ? $this->respondDeleted(['success' => true])
            : $this->failServerError('Penghuni gagal diarsipkan.');
    }

    private function validatePayload(array $data, ?int $id = null, bool $partial = false): array
    {
        if ($data === []) return ['payload' => 'Tidak ada field yang dapat diproses.'];
        $rules = [
            'unit_id' => 'required|is_natural_no_zero',
            'household_head_id' => 'permit_empty|is_natural_no_zero',
            'is_household_head' => 'permit_empty|in_list[0,1]',
            'identity_no' => 'required|max_length[40]',
            'name' => 'required|min_length[2]|max_length[120]',
            'gender' => 'permit_empty|in_list[male,female]',
            'birth_date' => 'permit_empty|valid_date[Y-m-d]',
            'address' => 'permit_empty|max_length[2000]',
            'phone' => 'permit_empty|max_length[30]',
            'email' => 'permit_empty|valid_email|max_length[160]',
            'identity_image' => 'permit_empty|max_length[255]',
            'suspended' => 'permit_empty|in_list[0,1]',
            'suspension_note' => 'permit_empty|max_length[2000]',
        ];
        if ($partial) $rules = array_intersect_key($rules, $data);
        $validation = service('validation');
        $validation->reset()->setRules($rules);
        if (! $validation->run($data)) return $validation->getErrors();

        $db = db_connect();
        if (isset($data['unit_id']) && ! $db->table('units')->where('id', (int) $data['unit_id'])->where('active', 1)->where('deleted_at', null)->countAllResults()) {
            return ['unit_id' => 'Unit rumah tidak ditemukan atau tidak aktif.'];
        }
        if (! empty($data['household_head_id']) && ! $db->table('residents')->where('id', (int) $data['household_head_id'])->where('is_household_head', 1)->where('deleted_at', null)->countAllResults()) {
            return ['household_head_id' => 'Kepala rumah tangga tidak valid.'];
        }
        if (isset($data['identity_no'])) {
            $builder = $db->table('residents')->where('identity_no', $data['identity_no'])->where('deleted_at', null);
            if ($id) $builder->where('id !=', $id);
            if ($builder->countAllResults()) return ['identity_no' => 'Nomor identitas sudah digunakan.'];
        }
        return [];
    }
}
