<?php

namespace App\Controllers\Api;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;

abstract class SecuredApiController extends ResourceController
{
    private ?string $payloadError = null;

    protected function requireApiKey(): ?ResponseInterface
    {
        $expected = (string) config('Parking')->gateApiKey;
        if ($expected === '') {
            log_message('critical', 'API request rejected because gate.apiKey is empty.');
            return $this->failServerError('API belum dikonfigurasi.');
        }

        $provided = (string) $this->request->getHeaderLine('X-Gate-Key');
        if ($provided === '' || ! hash_equals($expected, $provided)) {
            return $this->failUnauthorized('API key tidak valid.');
        }

        return null;
    }

    protected function payload(array $allowedFields): array
    {
        $this->payloadError = null;
        if ($this->request->is('json')) {
            try {
                $input = json_decode((string) $this->request->getBody(), true, 32, JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                $this->payloadError = 'Body JSON tidak valid.';
                return [];
            }
        } else {
            $input = $this->request->getPost() ?: $this->request->getRawInput();
        }

        if (! is_array($input)) {
            $this->payloadError = 'Payload harus berupa object.';
            return [];
        }

        return array_intersect_key($input, array_flip($allowedFields));
    }

    protected function payloadErrors(): array
    {
        return $this->payloadError === null ? [] : ['payload' => $this->payloadError];
    }
}
