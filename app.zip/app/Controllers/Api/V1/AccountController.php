<?php

namespace App\Controllers\Api\V1;

class AccountController extends ApiController
{
    public function changePassword()
    {
        $authUser = $this->user();
        if (strtoupper((string) ($authUser['role'] ?? '')) !== 'OWNER') {
            return $this->failMessage('Reset password ini hanya tersedia untuk owner.', 403);
        }

        $data = $this->json();
        $oldPassword = (string) ($data['old_password'] ?? '');
        $newPassword = (string) ($data['new_password'] ?? '');
        $confirmation = (string) ($data['new_password_confirmation'] ?? '');

        if ($oldPassword === '') {
            return $this->failMessage('Password lama wajib diisi.', 422);
        }
        if (strlen($newPassword) < 8) {
            return $this->failMessage('Password baru minimal 8 karakter.', 422);
        }
        if ($newPassword !== $confirmation) {
            return $this->failMessage('Konfirmasi password baru tidak sama.', 422);
        }
        if (hash_equals($oldPassword, $newPassword)) {
            return $this->failMessage('Password baru harus berbeda dari password lama.', 422);
        }

        $db = db_connect();
        $owner = $db->table('ex_users')
            ->where('id', (int) ($authUser['id'] ?? 0))
            ->where('company_id', (int) ($authUser['company_id'] ?? 0))
            ->where('role', 'OWNER')
            ->where('is_active', 1)
            ->where('deleted_at', null)
            ->get()->getRowArray();

        if (!$owner || !password_verify($oldPassword, (string) $owner['password'])) {
            return $this->failMessage('Password lama tidak sesuai.', 422);
        }

        $now = date('Y-m-d H:i:s');
        $db->transStart();
        $db->table('ex_users')->where('id', $owner['id'])->update([
            'password' => password_hash($newPassword, PASSWORD_DEFAULT),
            'updated_at' => $now,
        ]);
        $db->table('ex_logs')->insert([
            'company_id' => $owner['company_id'],
            'user_id' => $owner['id'],
            'action' => 'CHANGE_OWN_PASSWORD',
            'module' => 'USER',
            'reference_id' => $owner['id'],
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => $now,
        ]);
        $db->transComplete();

        if (!$db->transStatus()) {
            return $this->failMessage('Password gagal diperbarui.', 500);
        }

        return $this->ok(null, 'Password berhasil diperbarui.');
    }
}
