<?php
namespace App\Controllers\Api\V1;
use CodeIgniter\RESTful\ResourceController;
abstract class ApiController extends ResourceController
{protected $format='json';protected function ok($data=null,string $message='Success',int $status=200){return $this->respond(['success'=>true,'message'=>$message,'data'=>$data],$status);}protected function failMessage(string $message,int $status=400,array $errors=[]){$body=['success'=>false,'message'=>$message];if($errors)$body['errors']=$errors;return $this->respond($body,$status);}protected function json():array{return (array)($this->request->getJSON(true)?:$this->request->getPost());}protected function user():array{return (array)($this->request->user??[]);}}
