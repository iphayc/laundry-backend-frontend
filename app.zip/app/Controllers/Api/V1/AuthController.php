<?php
namespace App\Controllers\Api\V1;
use App\Services\MobileAuthService;use App\Services\MobileLoginService;use App\Services\NotificationService;
class AuthController extends ApiController
{
 public function sendOtp(){return $this->sendOtpFor('REGISTER');}
 public function forgotPassword(){return $this->sendOtpFor('RESET_PASSWORD');}
 private function sendOtpFor(string $purpose){try{$data=$this->json();(new \App\Services\OtpService())->send((string)($data['email']??''),$purpose);return $this->ok(null,'Jika email valid, OTP telah dikirim.');}catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}catch(\Throwable $e){return $this->failMessage($e->getMessage(),429);}}
 public function register(){try{$data=$this->json();if(empty($data['terms_accepted']))return $this->failMessage('Anda wajib menyetujui syarat dan ketentuan.',422);$result=(new MobileAuthService())->register($data);$version=db_connect()->table('ex_app_settings')->where('setting_key','terms_version')->get()->getRow('setting_value')??'1.0';db_connect()->table('ex_companies')->where('id',$result['company_id'])->update(['terms_accepted_at'=>date('Y-m-d H:i:s'),'terms_version'=>$version,'terms_ip'=>$this->request->getIPAddress(),'updated_at'=>date('Y-m-d H:i:s')]);$this->sendRegistrationSuccess($data,$result);return $this->ok($result,'Registrasi berhasil',201);}catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}catch(\Throwable $e){log_message('error','API register: '.$e->getMessage());return $this->failMessage('Registrasi gagal.',500);}}
 private function sendRegistrationSuccess(array $data,array $result):void{$email=strtolower(trim((string)($data['email']??'')));$body='<div style="font-family:Arial;max-width:600px"><h2>Pendaftaran Eksis Laundry Berhasil</h2><p>Akun dan paket FREE Anda sudah aktif.</p><table cellpadding="8" style="border-collapse:collapse"><tr><td><b>Owner</b></td><td>'.esc($data['fullname']).'</td></tr><tr><td><b>No. HP</b></td><td>'.esc($data['phone']).'</td></tr><tr><td><b>Username</b></td><td>'.esc($data['username']).'</td></tr><tr><td><b>Password</b></td><td>'.esc($data['password']).'</td></tr><tr><td><b>Kode Customer</b></td><td>'.esc($result['company_code']).'</td></tr></table><p>Simpan informasi ini dengan aman dan segera ubah password bila diperlukan.</p></div>';try{(new NotificationService())->email($email,'Pendaftaran Eksis Laundry Berhasil',$body);}catch(\Throwable $e){log_message('error','Email registrasi berhasil gagal dikirim: '.$e->getMessage());}}
 public function deviceTransferRequest(){
  try{
   $data=$this->json();
   $result=(new MobileLoginService())->requestDeviceTransfer($data);
   return $this->ok($result,'OTP pindah perangkat telah dikirim ke email Owner.');
  }catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}
  catch(\Throwable $e){return $this->failMessage($e->getMessage(),429);}
 }
 public function deviceTransferConfirm(){
  try{
   $data=$this->json();
   return $this->ok((new MobileLoginService())->confirmDeviceTransfer($data),'Perangkat berhasil dipindahkan.');
  }catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}
  catch(\Throwable $e){return $this->failMessage($e->getMessage(),401);}
 }
 public function refresh(){try{$d=$this->json();return $this->ok((new MobileAuthService())->refresh((string)($d['refresh_token']??''),$d),'Token diperbarui');}catch(\Throwable $e){$message=$e->getMessage();if($message==='Refresh token tidak valid.')return $this->failMessage($message,401,['reason'=>'SESSION_REVOKED']);if(str_contains($message,'Versi aplikasi Anda sudah usang'))return $this->failMessage($message,426,['reason'=>'APP_VERSION_CHANGED']);log_message('error','Refresh session sementara gagal: '.$message);return $this->failMessage('Session belum dapat diperbarui karena gangguan server. Session tetap dipertahankan.',503,['reason'=>'TEMPORARY_ERROR']);}}
 public function logout(){(new MobileAuthService())->logout((string)($this->json()['refresh_token']??''));return $this->ok(null,'Logout berhasil');}
 public function resetPassword(){try{$data=$this->json();(new MobileAuthService())->resetPassword((string)($data['email']??''),(string)($data['otp']??''),(string)($data['password']??''));return $this->ok(null,'Password berhasil diperbarui. Silakan login kembali.');}catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}catch(\Throwable $e){return $this->failMessage('Password gagal diperbarui.',500);}}
}
