<?php

namespace App\Controllers\Api\V1;

use App\Services\EntitlementService;

class CompanyBranchController extends ApiController
{
    public function disable($id = null)
    {
        $owner = $this->user();
        if (($owner['role'] ?? '') !== 'OWNER') return $this->failMessage('Hanya owner yang dapat menonaktifkan cabang.', 403);
        $db = db_connect(); $companyId = (int) $owner['company_id'];
        $branch = $db->table('ex_branches')->where('id', (int) $id)->where('company_id', $companyId)->where('is_active', 1)->where('deleted_at', null)->get()->getRowArray();
        if (!$branch) return $this->failMessage('Cabang aktif tidak ditemukan.', 404);
        $mainId = (int) ($db->table('ex_branches')->select('id')->where('company_id', $companyId)->where('deleted_at', null)->orderBy('id')->get()->getRow('id') ?? 0);
        if ((int) $branch['id'] === $mainId) return $this->failMessage('Cabang utama harus selalu aktif dan tidak dapat dinonaktifkan.', 422);
        $license = (new EntitlementService())->current($companyId);
        $limit = max(1, (int) ($license['max_branches'] ?? 1));
        $active = $db->table('ex_branches')->where('company_id', $companyId)->where('is_active', 1)->where('deleted_at', null)->countAllResults();
        if ($active <= 1) return $this->failMessage('Cabang terakhir tidak dapat dinonaktifkan.', 422);
        $reason = $active > $limit ? 'PACKAGE_DOWNGRADE' : 'MANUAL';
        $now = date('Y-m-d H:i:s');
        $db->transStart();
        $db->table('ex_branches')->where('id', $branch['id'])->update(['is_active' => 0, 'disabled_reason' => $reason, 'updated_at' => $now]);
        $this->disableBranchAccess($companyId, (int) $branch['id'], $reason, $now);
        $db->table('ex_logs')->insert(['company_id' => $companyId, 'user_id' => $owner['id'], 'action' => $reason === 'PACKAGE_DOWNGRADE' ? 'LOCK_BRANCH_DOWNGRADE' : 'DISABLE_BRANCH', 'module' => 'BRANCH', 'reference_id' => $branch['id'], 'ip_address' => $this->request->getIPAddress(), 'created_at' => $now]);
        $db->transComplete();
        if (!$db->transStatus()) return $this->failMessage('Cabang gagal dinonaktifkan.', 500);
        (new EntitlementService())->restoreAfterUpgrade($companyId);
        return $this->ok(null, $reason === 'PACKAGE_DOWNGRADE' ? 'Cabang dikunci sebagai cabang nonaktif untuk paket ini. User dan device cabang telah dinonaktifkan.' : 'Cabang, user, dan device di dalamnya dinonaktifkan. Histori tetap tersimpan.');
    }

    public function activate($id = null)
    {
        $owner = $this->user();
        if (($owner['role'] ?? '') !== 'OWNER') return $this->failMessage('Hanya owner yang dapat mengaktifkan cabang.', 403);
        $db = db_connect(); $companyId = (int) $owner['company_id'];
        $branch = $db->table('ex_branches')->where('id', (int) $id)->where('company_id', $companyId)->where('is_active', 0)->where('deleted_at', null)->get()->getRowArray();
        if (!$branch) return $this->failMessage('Cabang nonaktif tidak ditemukan.', 404);
        $license = (new EntitlementService())->current($companyId);
        $limit = max(1, (int) ($license['max_branches'] ?? 1));
        $active = $db->table('ex_branches')->where('company_id', $companyId)->where('is_active', 1)->where('deleted_at', null)->countAllResults();
        if ($active >= $limit) return $this->failMessage('Cabang ini terkunci oleh batas paket. Upgrade paket terlebih dahulu untuk mengaktifkannya.', 422);
        $now = date('Y-m-d H:i:s');
        $db->table('ex_branches')->where('id', $branch['id'])->update(['is_active' => 1, 'disabled_reason' => null, 'updated_at' => $now]);
        $db->table('ex_logs')->insert(['company_id' => $companyId, 'user_id' => $owner['id'], 'action' => 'ACTIVATE_BRANCH', 'module' => 'BRANCH', 'reference_id' => $branch['id'], 'ip_address' => $this->request->getIPAddress(), 'created_at' => $now]);
        (new EntitlementService())->restoreAfterUpgrade($companyId);
        return $this->ok(null, 'Cabang berhasil diaktifkan. User dan device cabang dipulihkan otomatis sepanjang masih tersedia kuota paket.');
    }

    private function disableBranchAccess(int $companyId, int $branchId, string $reason, string $now): void
    {
        $db = db_connect();
        $users = $db->table('ex_users')->select('id')->where('company_id', $companyId)->where('branch_id', $branchId)->where('role !=', 'OWNER')->where('deleted_at', null)->get()->getResultArray();
        if ($users) {
            $ids = array_column($users, 'id');
            $db->table('ex_users')->whereIn('id', $ids)->update(['is_active' => 0, 'disabled_reason' => $reason, 'updated_at' => $now]);
            $db->table('ex_user_tokens')->whereIn('user_id', $ids)->where('revoked_at', null)->update(['revoked_at' => $now]);
        }
        $devices = $db->table('ex_devices')->select('id')->where('company_id', $companyId)->where('branch_id', $branchId)->where('status', 'ACTIVE')->where('deleted_at', null)->get()->getResultArray();
        if ($devices) {
            $ids = array_column($devices, 'id');
            $db->table('ex_devices')->whereIn('id', $ids)->update(['status' => 'DISABLED', 'disabled_reason' => $reason, 'updated_at' => $now]);
            $db->table('ex_user_tokens')->whereIn('device_id', $ids)->where('revoked_at', null)->update(['revoked_at' => $now]);
            $db->table('ex_license_devices')->whereIn('device_id', $ids)->where('revoked_at', null)->update(['revoked_at' => $now]);
        }
    }
}
