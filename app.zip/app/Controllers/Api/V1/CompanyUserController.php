<?php

namespace App\Controllers\Api\V1;

class CompanyUserController extends ApiController
{
    public function index()
    {
        $user = $this->user();
        $rows = db_connect()->table('ex_users u')
            ->select('u.id,u.branch_id,u.username,u.fullname,u.email,u.phone,u.role,u.photo,u.is_active,u.disabled_reason,u.created_at,b.name branch_name')
            ->join('ex_branches b', 'b.id=u.branch_id', 'left')
            ->where('u.company_id', $user['company_id'])->where('u.deleted_at', null)
            ->orderBy('u.id')->get()->getResultArray();
        foreach($rows as &$row)$row['photo_url']=$row['photo']?base_url($row['photo']):null;
        return $this->ok($rows);
    }

    public function create()
    {
        try {
            $user = $this->user();
            if (($user['role'] ?? '') !== 'OWNER') {
                return $this->failMessage('Hanya owner yang dapat menambah kasir.', 403);
            }
            $data = $this->json();
            $fullname = trim((string) ($data['fullname'] ?? ''));
            $username = strtolower(trim((string) ($data['username'] ?? '')));
            $email = strtolower(trim((string) ($data['email'] ?? '')));
            $password = (string) ($data['password'] ?? '');
            $branchId = (int) ($data['branch_id'] ?? 0);
            if ($fullname === '' || !preg_match('/^[a-z0-9._-]{3,50}$/', $username) || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $branchId < 1) {
                return $this->failMessage('Cabang, nama, username, email, dan password minimal 8 karakter wajib valid.', 422);
            }
            $license = (new \App\Services\EntitlementService())->current((int) $user['company_id']);
            if (!$license || $license['status'] !== 'ACTIVE') {
                return $this->failMessage('Lisensi tidak aktif.', 422);
            }
            $db = db_connect();
            $branch = $db->table('ex_branches')->where('id', $branchId)->where('company_id', $user['company_id'])->where('is_active', 1)->where('deleted_at', null)->get()->getRowArray();
            if (!$branch) {
                return $this->failMessage('Cabang tidak valid atau tidak aktif.', 422);
            }
            $totalLimit = max(1, (int) $license['max_branches'] * (int) $license['users_per_branch']);
            $branchLimit = max(1, (int) $license['users_per_branch']);
            $activeTotal = $db->table('ex_users')->where('company_id', $user['company_id'])->where('is_active', 1)->where('deleted_at', null)->countAllResults();
            $activeInBranch = $db->table('ex_users')->where('company_id', $user['company_id'])->where('branch_id', $branchId)->where('is_active', 1)->where('deleted_at', null)->countAllResults();
            if ($activeTotal >= $totalLimit) {
                return $this->failMessage('Batas total pengguna paket sudah tercapai ('.$totalLimit.' user).', 422);
            }
            if ($activeInBranch >= $branchLimit) {
                return $this->failMessage('Kuota pengguna cabang '.$branch['name'].' sudah penuh ('.$branchLimit.' user).', 422);
            }
            if ($db->table('ex_users')->where('email', $email)->where('deleted_at', null)->countAllResults() || $db->table('ex_users')->where('company_id', $user['company_id'])->where('username', $username)->where('deleted_at', null)->countAllResults()) {
                return $this->failMessage('Email atau username sudah digunakan.', 422);
            }
            $row = ['company_id' => $user['company_id'], 'branch_id' => $branchId, 'username' => $username, 'role' => 'CASHIER', 'fullname' => $fullname, 'email' => $email, 'phone' => trim((string) ($data['phone'] ?? '')) ?: null, 'password' => password_hash($password, PASSWORD_DEFAULT), 'is_active' => 1, 'created_at' => date('Y-m-d H:i:s')];
            $db->table('ex_users')->insert($row);
            unset($row['password']);
            return $this->ok(['id' => (int) $db->insertID(), 'branch_name' => $branch['name']] + $row, 'Kasir berhasil ditambahkan.', 201);
        } catch (\Throwable $e) {
            log_message('error', 'Tambah kasir: '.$e->getMessage());
            return $this->failMessage('Kasir gagal ditambahkan.', 500);
        }
    }

    public function disable($id = null)
    {
        $owner = $this->user();
        if (($owner['role'] ?? '') !== 'OWNER') {
            return $this->failMessage('Hanya owner yang dapat menonaktifkan kasir.', 403);
        }
        $db = db_connect();
        $cashier = $db->table('ex_users')->where('id', (int) $id)
            ->where('company_id', $owner['company_id'])->where('role', 'CASHIER')
            ->where('is_active', 1)->where('deleted_at', null)->get()->getRowArray();
        if (!$cashier) {
            return $this->failMessage('Kasir aktif tidak ditemukan.', 404);
        }
        $now = date('Y-m-d H:i:s');
        $db->transStart();
        $db->table('ex_users')->where('id', $cashier['id'])->update(['is_active' => 0, 'disabled_reason' => 'MANUAL', 'updated_at' => $now]);
        $db->table('ex_user_tokens')->where('user_id', $cashier['id'])->where('revoked_at', null)->update(['revoked_at' => $now]);
        $db->table('ex_logs')->insert(['company_id' => $owner['company_id'], 'user_id' => $owner['id'], 'action' => 'DISABLE_CASHIER', 'module' => 'USER', 'reference_id' => $cashier['id'], 'ip_address' => $this->request->getIPAddress(), 'created_at' => $now]);
        $db->transComplete();
        return $db->transStatus() ? $this->ok(null, 'Kasir dinonaktifkan. Histori transaksi tetap tersimpan.') : $this->failMessage('Kasir gagal dinonaktifkan.', 500);
    }

    public function activate($id = null)
    {
        $owner = $this->user();
        if (($owner['role'] ?? '') !== 'OWNER') {
            return $this->failMessage('Hanya owner yang dapat mengaktifkan kasir.', 403);
        }
        $db = db_connect();
        $companyId = (int) $owner['company_id'];
        $cashier = $db->table('ex_users')->where('id', (int) $id)
            ->where('company_id', $companyId)->where('role', 'CASHIER')
            ->where('is_active', 0)->where('deleted_at', null)->get()->getRowArray();
        if (!$cashier) {
            return $this->failMessage('Kasir nonaktif tidak ditemukan.', 404);
        }
        // Kasir yang dinonaktifkan otomatis oleh sistem (LICENSE_LIMIT /
        // PACKAGE_DOWNGRADE) tidak boleh diaktifkan manual oleh owner --
        // slot-nya akan pulih otomatis begitu kuota paket tersedia lagi.
        // Hanya kasir yang dinonaktifkan manual oleh owner yang boleh
        // diaktifkan kembali lewat endpoint ini.
        if (($cashier['disabled_reason'] ?? null) !== 'MANUAL') {
            return $this->failMessage('Kasir ini dinonaktifkan otomatis oleh sistem karena batas paket dan akan aktif kembali otomatis saat kuota tersedia.', 422);
        }
        $branch = $db->table('ex_branches')->where('id', $cashier['branch_id'])->where('company_id', $companyId)->where('is_active', 1)->where('deleted_at', null)->get()->getRowArray();
        if (!$branch) {
            return $this->failMessage('Cabang kasir ini sedang nonaktif. Aktifkan cabangnya terlebih dahulu.', 422);
        }
        $license = (new \App\Services\EntitlementService())->current($companyId);
        if (!$license || $license['status'] !== 'ACTIVE') {
            return $this->failMessage('Lisensi tidak aktif.', 422);
        }
        $totalLimit = max(1, (int) $license['max_branches'] * (int) $license['users_per_branch']);
        $branchLimit = max(1, (int) $license['users_per_branch']);
        $activeTotal = $db->table('ex_users')->where('company_id', $companyId)->where('is_active', 1)->where('deleted_at', null)->countAllResults();
        $activeInBranch = $db->table('ex_users')->where('company_id', $companyId)->where('branch_id', $cashier['branch_id'])->where('is_active', 1)->where('deleted_at', null)->countAllResults();
        if ($activeTotal >= $totalLimit) {
            return $this->failMessage('Kasir ini terkunci oleh batas paket ('.$totalLimit.' user). Upgrade paket terlebih dahulu untuk mengaktifkannya.', 422);
        }
        if ($activeInBranch >= $branchLimit) {
            return $this->failMessage('Kuota pengguna cabang '.$branch['name'].' sudah penuh ('.$branchLimit.' user). Upgrade paket terlebih dahulu untuk mengaktifkannya.', 422);
        }
        $now = date('Y-m-d H:i:s');
        $db->transStart();
        $db->table('ex_users')->where('id', $cashier['id'])->update(['is_active' => 1, 'disabled_reason' => null, 'updated_at' => $now]);
        $db->table('ex_logs')->insert(['company_id' => $companyId, 'user_id' => $owner['id'], 'action' => 'ACTIVATE_CASHIER', 'module' => 'USER', 'reference_id' => $cashier['id'], 'ip_address' => $this->request->getIPAddress(), 'created_at' => $now]);
        $db->transComplete();
        return $db->transStatus() ? $this->ok(null, 'Kasir berhasil diaktifkan.') : $this->failMessage('Kasir gagal diaktifkan.', 500);
    }

    public function resetPassword($id = null)
    {
        $owner = $this->user();
        if (($owner['role'] ?? '') !== 'OWNER') return $this->failMessage('Hanya owner yang dapat mereset password kasir.', 403);
        $password = (string) ($this->json()['password'] ?? '');
        if (strlen($password) < 8) return $this->failMessage('Password baru minimal 8 karakter.', 422);
        $db = db_connect();
        $cashier = $db->table('ex_users')->where('id', (int) $id)->where('company_id', $owner['company_id'])->where('role', 'CASHIER')->where('deleted_at', null)->get()->getRowArray();
        if (!$cashier) return $this->failMessage('Kasir tidak ditemukan.', 404);
        $now = date('Y-m-d H:i:s');
        $db->transStart();
        $db->table('ex_users')->where('id', $cashier['id'])->update(['password' => password_hash($password, PASSWORD_DEFAULT), 'updated_at' => $now]);
        $db->table('ex_user_tokens')->where('user_id', $cashier['id'])->where('revoked_at', null)->update(['revoked_at' => $now]);
        $db->table('ex_logs')->insert(['company_id' => $owner['company_id'], 'user_id' => $owner['id'], 'action' => 'RESET_CASHIER_PASSWORD', 'module' => 'USER', 'reference_id' => $cashier['id'], 'ip_address' => $this->request->getIPAddress(), 'created_at' => $now]);
        $db->transComplete();
        return $db->transStatus() ? $this->ok(null, 'Password kasir berhasil direset. Kasir harus login kembali.') : $this->failMessage('Password kasir gagal direset.', 500);
    }
}
