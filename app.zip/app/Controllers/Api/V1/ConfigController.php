<?php
namespace App\Controllers\Api\V1;
class ConfigController extends ApiController
{
 public function paymentAccounts(){$rows=db_connect()->table('ex_payment_accounts')->select('id,type,bank_name,account_number,account_name,qris_image,instructions')->where('is_active',1)->where('deleted_at',null)->orderBy('sort_order')->get()->getResultArray();foreach($rows as &$row)if($row['qris_image']){$public=FCPATH.ltrim($row['qris_image'],'/');$legacy=WRITEPATH.ltrim($row['qris_image'],'/');$file=is_file($public)?$public:(is_file($legacy)?$legacy:null);$row['qris_image']=$file?'data:'.(mime_content_type($file)?:'image/png').';base64,'.base64_encode((string)file_get_contents($file)):base_url($row['qris_image']);}unset($row);return $this->ok($rows);}
 public function app(){return $this->ok(array_column(db_connect()->table('ex_app_settings')->select('setting_key,setting_value')->where('is_public',1)->get()->getResultArray(),'setting_value','setting_key'));}
}
