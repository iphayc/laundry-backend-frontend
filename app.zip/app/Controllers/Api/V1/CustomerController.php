<?php
namespace App\Controllers\Api\V1;

class CustomerController extends ApiController
{
    private function branchId(array $user):int{return (int)($user['branch_id']??0);}

    private function accessible($db,int $id,array $user):bool
    {
        $query=$db->table('ex_customers c')->where('c.id',$id)->where('c.company_id',$user['company_id'])->where('c.is_active',1)->where('c.deleted_at',null);
        if(($user['role']??'')!=='OWNER'){
            $branchId=$this->branchId($user);if($branchId<1)return false;
            $query->groupStart()->where('c.branch_id',$branchId)->orWhere("EXISTS (SELECT 1 FROM ex_orders o WHERE o.customer_id=c.id AND o.company_id=c.company_id AND o.branch_id={$branchId} AND o.deleted_at IS NULL)",null,false)->groupEnd();
        }
        return $query->countAllResults()>0;
    }

    public function index()
    {
        $user=$this->user();$companyId=(int)$user['company_id'];$branchId=$this->branchId($user);$owner=($user['role']??'')==='OWNER';
        if(!$owner&&$branchId<1)return $this->ok([]);
        $selectedBranch=$owner?max(0,(int)$this->request->getGet('branch_id')):$branchId;
        if($selectedBranch>0){
            $valid=db_connect()->table('ex_branches')->where('id',$selectedBranch)->where('company_id',$companyId)->where('is_active',1)->where('deleted_at',null)->countAllResults();
            if(!$valid)return $this->failMessage('Cabang tidak valid atau tidak aktif.',422);
        }
        $scope=' AND o.company_id='.$companyId.($selectedBranch>0?' AND o.branch_id='.$selectedBranch:'');
        $query=db_connect()->table('ex_customers c')->select("c.*,b.name branch_name,
            (SELECT COUNT(*) FROM ex_orders o WHERE o.customer_id=c.id AND o.deleted_at IS NULL{$scope}) visit_count,
            (SELECT COALESCE(SUM(o.item_count),0) FROM ex_orders o WHERE o.customer_id=c.id AND o.deleted_at IS NULL{$scope}) total_items,
            (SELECT COALESCE(SUM(o.total),0) FROM ex_orders o WHERE o.customer_id=c.id AND o.deleted_at IS NULL{$scope}) total_spent",false)
            ->join('ex_branches b','b.id=c.branch_id','left')
            ->where('c.company_id',$companyId)->where('c.is_active',1)->where('c.deleted_at',null);
        if($selectedBranch>0)$query->groupStart()->where('c.branch_id',$selectedBranch)->orWhere("EXISTS (SELECT 1 FROM ex_orders scoped_order WHERE scoped_order.customer_id=c.id AND scoped_order.company_id=c.company_id AND scoped_order.branch_id={$selectedBranch} AND scoped_order.deleted_at IS NULL)",null,false)->groupEnd();
        $search=trim((string)$this->request->getGet('q'));
        if($search!=='')$query->groupStart()->like('c.name',$search)->orLike('c.phone',$search)->groupEnd();
        return $this->ok($query->orderBy('c.id','DESC')->get()->getResultArray());
    }

    public function create(){return $this->saveCustomer(null);}
    public function update($id=null){return $this->saveCustomer((int)$id);}

    private function saveCustomer(?int $id)
    {
        try{
            $user=$this->user();$data=$this->json();$name=trim((string)($data['name']??''));$email=trim((string)($data['email']??''));
            if($name==='')return $this->failMessage('Nama pelanggan wajib diisi.',422);
            if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))return $this->failMessage('Format email pelanggan tidak valid.',422);
            $db=db_connect();
            if($id&&!$this->accessible($db,$id,$user))return $this->failMessage('Pelanggan aktif tidak ditemukan pada cabang Anda.',404);
            $row=['name'=>$name,'phone'=>trim((string)($data['phone']??''))?:null,'email'=>$email?:null,'address'=>trim((string)($data['address']??''))?:null,'notes'=>trim((string)($data['notes']??''))?:null,'updated_at'=>date('Y-m-d H:i:s')];
            if($id){$db->table('ex_customers')->where('id',$id)->update($row);return $this->ok(['id'=>$id]+$row,'Pelanggan berhasil diperbarui.');}
            $branchId=$this->branchId($user);
            if($branchId<1)$branchId=(int)($db->table('ex_branches')->select('id')->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->orderBy('id')->get()->getRow('id')??0);
            $row+=['company_id'=>$user['company_id'],'branch_id'=>$branchId?:null,'is_active'=>1,'created_at'=>date('Y-m-d H:i:s')];
            $db->table('ex_customers')->insert($row);return $this->ok(['id'=>(int)$db->insertID()]+$row,'Pelanggan berhasil ditambahkan.',201);
        }catch(\Throwable $e){return $this->failMessage('Pelanggan gagal disimpan.',500);}
    }

    public function disable($id=null)
    {
        $user=$this->user();$db=db_connect();$id=(int)$id;
        if(!$this->accessible($db,$id,$user))return $this->failMessage('Pelanggan aktif tidak ditemukan pada cabang Anda.',404);
        $db->table('ex_customers')->where('id',$id)->update(['is_active'=>0,'updated_at'=>date('Y-m-d H:i:s')]);
        return $this->ok(null,'Pelanggan dinonaktifkan. Histori transaksi tetap tersimpan.');
    }
}
