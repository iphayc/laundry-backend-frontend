<?php

namespace App\Controllers\Api\V1;

use App\Services\EksisWhatsAppGatewayService;

class CustomerWhatsAppController extends ApiController
{
    /**
     * Membaca metode pengiriman WhatsApp dan status persetujuan Linked Device.
     */
    public function configuration()
    {
        $company = db_connect()
            ->table('ex_companies')
            ->select('whatsapp_delivery_method,whatsapp_linked_terms_at')
            ->where('id', $this->user()['company_id'])
            ->get()->getRowArray() ?: [];

        // return $this->ok([
        //     'method' => strtoupper((string) ($company['whatsapp_delivery_method'] ?? 'APP')),
        //     'terms_accepted' => !empty($company['whatsapp_linked_terms_at']),
        // ]);
        return $this->ok([
            'method' => strtoupper((string) ($company['whatsapp_delivery_method'] ?? 'APP')),
            'terms_accepted' => !empty($company['whatsapp_linked_terms_at']),
        ], 'Konfigurasi WhatsApp berhasil diambil.');
    }

    public function saveConfiguration()
    {
        $user = $this->user();
        $data = $this->json();
        $method = strtoupper((string) ($data['method'] ?? 'APP'));

        if (!in_array($method, ['APP', 'LINKED'], true)) {
            return $this->failMessage('Metode WhatsApp tidak valid.', 422);
        }

        $db = db_connect();
        $company = $db->table('ex_companies')
            ->where('id', $user['company_id'])
            ->get()->getRowArray() ?: [];

        $acceptedAt = $company['whatsapp_linked_terms_at'] ?? null;
        if (!empty($data['accept_terms'])) {
            $acceptedAt = date('Y-m-d H:i:s');
        }

        if ($method === 'LINKED' && !$acceptedAt) {
            return $this->failMessage(
                'Setujui syarat dan ketentuan WhatsApp Linked Device terlebih dahulu.',
                422
            );
        }

        $db->table('ex_companies')
            ->where('id', $user['company_id'])
            ->update([
                'whatsapp_delivery_method' => $method,
                'whatsapp_linked_terms_at' => $acceptedAt,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

        return $this->ok([
            'method' => $method,
            'terms_accepted' => (bool) $acceptedAt,
        ], 'Pengaturan pengiriman WhatsApp berhasil disimpan.');
    }

    /**
     * Membuat/mengambil session milik company yang sedang login lalu meminta QR.
     *
     * Mobile tidak pernah mengirim company_id, session_key, atau API key.
     * Semua identitas ditentukan oleh JWT dan database server.
     */
    public function connect()
    {
        try {
            $user = $this->user();
            $companyId = (int) $user['company_id'];

            $company = db_connect()->table('ex_companies')
                ->select('whatsapp_linked_terms_at')
                ->where('id', $companyId)
                ->get()->getRowArray();

            if (empty($company['whatsapp_linked_terms_at'])) {
                return $this->failMessage(
                    'Setujui syarat dan ketentuan WhatsApp Linked Device sebelum menghubungkan perangkat.',
                    422
                );
            }

            $session = $this->getActiveSession($companyId);

            // Jika ada session yang sudah terhubung, tidak perlu membuat QR baru.
            if ($session && strtoupper((string) $session['status']) === 'CONNECTED') {
                return $this->ok([
                    'connection' => 'connected',
                    'connected' => true,
                    'phone' => $session['phone'] ?: null,
                    'session_key' => $session['session_key'],
                    'qr' => null,
                    'updated_at' => $session['updated_at'] ?? date('Y-m-d H:i:s'),
                ], 'WhatsApp sudah terhubung.');
            }

            // Session baru dibuat hanya bila belum ada session aktif.
            if (!$session) {
                $session = $this->createSession($companyId);
            }

            $result = (new EksisWhatsAppGatewayService('CUSTOMER'))
                ->connect($session['session_key']);

            if (!$result['success']) {
                return $this->failMessage(
                    $result['message'] ?? 'QR WhatsApp tidak dapat dibuat.',
                    502
                );
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $state = $this->syncSessionStatus($session, $data, true);

            $qr = $this->extractQr($data);

            return $this->ok([
                'qr' => $qr,
                'connection' => $state['connection'],
                'connected' => $state['connected'],
                'phone' => $state['phone'],
                'session_key' => $session['session_key'],
                'updated_at' => $state['updated_at'],
            ], $qr
                ? 'QR WhatsApp siap. Silakan scan menggunakan WhatsApp.'
                : 'Status WhatsApp berhasil diperbarui.');
        } catch (\Throwable $e) {
            log_message('error', 'Customer WhatsApp connect: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 502);
        }
    }

    /**
     * Status hanya membaca session milik company.
     * Endpoint ini tidak membuat session dan tidak meminta QR.
     */
    public function status()
    {
        try {
            $companyId = (int) $this->user()['company_id'];
            $session = $this->getActiveSession($companyId);

            if (!$session) {
                return $this->ok([
                    'connection' => 'disconnected',
                    'connected' => false,
                    'phone' => null,
                    'session_key' => null,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }

            $result = (new EksisWhatsAppGatewayService('CUSTOMER'))
                ->status($session['session_key']);

            if (!$result['success']) {
                // Jika gateway tidak dapat dihubungi, jangan mengubah status
                // connected menjadi disconnected hanya karena timeout.
                return $this->ok([
                    'connection' => strtolower((string) $session['status']) === 'CONNECTED'
                        ? 'connected'
                        : 'connecting',
                    'connected' => strtoupper((string) $session['status']) === 'CONNECTED',
                    'phone' => $session['phone'] ?: null,
                    'session_key' => $session['session_key'],
                    'updated_at' => $session['updated_at'] ?? date('Y-m-d H:i:s'),
                    'gateway_available' => false,
                ]);
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $state = $this->syncSessionStatus($session, $data, false);

            return $this->ok([
                'connection' => $state['connection'],
                'connected' => $state['connected'],
                'phone' => $state['phone'],
                'session_key' => $session['session_key'],
                'updated_at' => $state['updated_at'],
                'gateway_available' => true,
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'Customer WhatsApp status: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 502);
        }
    }

    /**
     * QR endpoint dipertahankan untuk kompatibilitas.
     * Mobile baru sebaiknya menggunakan POST /connect.
     */
    public function qr()
    {
        return $this->connect();
    }

    public function logout()
    {
        try {
            $companyId = (int) $this->user()['company_id'];
            $session = $this->getActiveSession($companyId);

            if (!$session) {
                return $this->ok([
                    'connection' => 'disconnected',
                    'connected' => false,
                    'phone' => null,
                    'session_key' => null,
                    'updated_at' => date('Y-m-d H:i:s'),
                ], 'WhatsApp sudah tidak terhubung.');
            }

            $result = (new EksisWhatsAppGatewayService('CUSTOMER'))
                ->logout($session['session_key']);

            if (!$result['success']) {
                return $this->failMessage(
                    $result['message'] ?? 'Sesi WhatsApp tidak dapat dikeluarkan.',
                    502
                );
            }

            // Session lokal diarsipkan agar connect berikutnya membuat
            // session_key baru. Ini mencegah QR/session lama dipakai kembali.
            $now = date('Y-m-d H:i:s');
            db_connect()->table('ex_whatsapp_sessions')
                ->where('id', $session['id'])
                ->update([
                    'status' => 'DISCONNECTED',
                    'phone' => null,
                    'last_seen_at' => $now,
                    'updated_at' => $now,
                    'deleted_at' => $now,
                ]);

            return $this->ok([
                'connection' => 'disconnected',
                'connected' => false,
                'phone' => null,
                'session_key' => null,
                'updated_at' => $now,
            ], 'Sesi WhatsApp berhasil dikeluarkan.');
        } catch (\Throwable $e) {
            log_message('error', 'Customer WhatsApp logout: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 502);
        }
    }

    private function getActiveSession(int $companyId): ?array
    {
        $row = db_connect()->table('ex_whatsapp_sessions')
            ->where('company_id', $companyId)
            ->where('provider', 'CUSTOMER_GATEWAY')
            ->where('deleted_at', null)
            ->orderBy('id', 'DESC')
            ->get()->getRowArray();

        return $row ?: null;
    }

    private function createSession(int $companyId): array
    {
        $now = date('Y-m-d H:i:s');

        // Random suffix membuat session key tidak mudah ditebak.
        $suffix = bin2hex(random_bytes(16));
        $sessionKey = 'wa_company_'.$companyId.'_'.$suffix;

        $db = db_connect();
        $db->table('ex_whatsapp_sessions')->insert([
            'company_id' => $companyId,
            'session_key' => $sessionKey,
            'phone' => null,
            'provider' => 'CUSTOMER_GATEWAY',
            'status' => 'CONNECTING',
            'last_seen_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $id = (int) $db->insertID();

        return $db->table('ex_whatsapp_sessions')
            ->where('id', $id)
            ->get()->getRowArray();
    }

    /**
     * Sinkronisasi response Gateway ke ex_whatsapp_sessions.
     *
     * Gateway dapat mengembalikan:
     * connection, status, state, connected, number atau phone.
     */
    private function syncSessionStatus(array $session, array $gateway, bool $fromConnect): array
    {
        $connection = $this->normalizeConnection($gateway, $fromConnect);
        $phone = $this->extractPhone($gateway) ?: ($session['phone'] ?: null);
        $now = date('Y-m-d H:i:s');

        $record = [
            'status' => strtoupper($connection),
            'phone' => $phone,
            'last_seen_at' => $now,
            'updated_at' => $now,
        ];

        if ($connection === 'connected') {
            $record['last_connected_at'] = $session['last_connected_at'] ?: $now;
        }

        db_connect()->table('ex_whatsapp_sessions')
            ->where('id', $session['id'])
            ->update($record);

        return [
            'connection' => $connection,
            'connected' => $connection === 'connected',
            'phone' => $phone,
            'updated_at' => $now,
        ];
    }

    private function normalizeConnection(array $data, bool $fromConnect = false): string
    {
        $raw = $data['connection']
            ?? $data['status']
            ?? $data['state']
            ?? null;

        if (isset($data['connected'])) {
            if ((bool) $data['connected']) {
                return 'connected';
            }
            if ($raw === null && $fromConnect) {
                return 'connecting';
            }
        }

        $value = strtolower(trim((string) $raw));

        if (in_array($value, [
            'connected', 'online', 'ready', 'open', 'authenticated',
            'auth_success', 'success',
        ], true)) {
            return 'connected';
        }

        if (in_array($value, [
            'connecting', 'waiting_scan', 'qr_ready', 'qr',
            'authenticating', 'pairing', 'pending', 'initializing',
        ], true)) {
            return 'connecting';
        }

        if (in_array($value, [
            'disconnected', 'logged_out', 'logout', 'closed',
            'close', 'offline', 'unauthorized',
        ], true)) {
            return 'disconnected';
        }

        // Saat /connect menghasilkan QR, kita tahu session sedang menunggu scan.
        return $fromConnect ? 'connecting' : 'disconnected';
    }

    private function extractPhone(array $data): ?string
    {
        $phone = $data['number']
            ?? $data['phone']
            ?? $data['phone_number']
            ?? $data['wid']
            ?? null;

        if (is_array($phone)) {
            $phone = $phone['user'] ?? $phone['number'] ?? null;
        }

        $phone = preg_replace('/\D+/', '', (string) $phone);
        return $phone !== '' ? $phone : null;
    }

    private function extractQr(array $data): ?string
    {
        $qr = $data['qr']
            ?? $data['qr_code']
            ?? $data['qrcode']
            ?? null;

        if (is_array($qr)) {
            $qr = $qr['data'] ?? $qr['base64'] ?? null;
        }

        $qr = trim((string) $qr);
        if ($qr === '') {
            return null;
        }

        if (!preg_match('#^(data:image/|https?://)#i', $qr)) {
            return 'data:image/png;base64,'.$qr;
        }

        return $qr;
    }
}