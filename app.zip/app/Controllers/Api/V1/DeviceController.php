<?php
namespace App\Controllers\Api\V1;

class DeviceController extends ApiController
{
 public function index()
 {
  $u=$this->user();
  $db=db_connect();
  $active=$db->table('ex_devices d')
    ->select('d.id,d.device_uuid,d.device_name,d.platform,d.os_version,d.app_version,d.status,d.branch_id,b.name branch_name,d.last_sync_at,d.last_login_at,d.created_at')
    ->join('ex_branches b','b.id=d.branch_id','left')
    ->where('d.company_id',$u['company_id'])
    ->where('d.status','ACTIVE')
    ->where('d.deleted_at',null)
    ->orderBy('d.last_login_at','DESC')
    ->orderBy('d.id','DESC')
    ->get()->getResultArray();

  return $this->ok($active);
 }

 public function disable($id=null)
 {
  $u=$this->user();
  $db=db_connect();
  $device=$db->table('ex_devices')
    ->where('id',(int)$id)
    ->where('company_id',$u['company_id'])
    ->where('status','ACTIVE')
    ->where('deleted_at',null)
    ->get()->getRowArray();

  if(!$device)return $this->failMessage('Perangkat aktif tidak ditemukan.',404);

  $now=date('Y-m-d H:i:s');
  $db->transStart();
  $db->table('ex_devices')->where('id',$device['id'])->update([
    'status'=>'DISABLED',
    'disabled_reason'=>'MANUAL',
    'updated_at'=>$now
  ]);
  $db->table('ex_user_tokens')->where('device_id',$device['id'])->where('revoked_at',null)->update([
    'revoked_at'=>$now
  ]);
  $db->table('ex_logs')->insert([
    'company_id'=>$u['company_id'],
    'user_id'=>$u['id'],
    'action'=>'DISABLE_DEVICE',
    'module'=>'DEVICE',
    'reference_id'=>$device['id'],
    'ip_address'=>$this->request->getIPAddress(),
    'created_at'=>$now
  ]);
  $db->transComplete();

  return $db->transStatus()
    ? $this->ok(null,'Perangkat dinonaktifkan dan slot perangkat tersedia kembali.')
    : $this->failMessage('Perangkat gagal dinonaktifkan.',500);
 }
}
