<?php

namespace App\Controllers\Api\V1;

class ExpenseController extends ApiController
{
    public function index()
    {
        $u = $this->user();
        $b = $this->scope($u)->select('e.*,b.name branch_name,u.fullname created_by_name,emp.name employee_name,emp.nik employee_nik,emp.phone employee_phone,emp.email employee_email')
            ->join('ex_branches b', 'b.id=e.branch_id', 'left')
            ->join('ex_users u', 'u.id=e.created_by', 'left')
            ->join('ex_employees emp', 'emp.id=e.employee_id', 'left');
        return $this->ok($b->orderBy('e.expense_date', 'DESC')->orderBy('e.id', 'DESC')->limit(100)->get()->getResultArray());
    }

    public function create()
    {
        try {
            $u = $this->user();
            $d = $this->json();
            $category = (string) ($d['category'] ?? '');
            $qty = (float) ($d['qty'] ?? 0);
            $amount = (float) ($d['unit_amount'] ?? 0);
            if ($u['role'] !== 'OWNER' && !in_array($category, ['OPERATIONAL', 'OTHER'], true)) return $this->failMessage('Kasir hanya dapat mencatat pengeluaran Operasional dan Lain-lain.', 403);
            if (!in_array($category, ['SALARY', 'RENT', 'OPERATIONAL', 'OTHER'], true) || $qty <= 0 || $amount < 0) return $this->failMessage('Kategori, qty, dan nilai wajib valid.', 422);
            $db = db_connect();
            $fresh = $db->table('ex_users u')->select('u.branch_id,b.is_active branch_active')->join('ex_branches b', 'b.id=u.branch_id', 'left')->where('u.id', $u['id'])->where('u.is_active', 1)->get()->getRowArray();
            if (!$fresh || !(int) $fresh['branch_active']) return $this->failMessage('User atau cabang tidak aktif.', 403);
            $row = ['company_id' => $u['company_id'], 'branch_id' => $fresh['branch_id'], 'category' => $category, 'qty' => $qty, 'unit_amount' => $amount, 'total_amount' => round($qty * $amount, 2), 'notes' => trim((string) ($d['notes'] ?? '')) ?: null, 'expense_date' => date('Y-m-d'), 'created_by' => $u['id'], 'created_at' => date('Y-m-d H:i:s')];
            if ($category === 'SALARY') {
                if ($u['role'] !== 'OWNER') return $this->failMessage('Payroll hanya dapat diproses owner.', 403);
                $employeeId = (int)($d['employee_id'] ?? 0);
                $period = trim((string)($d['payroll_period'] ?? ''));
                $days = max(0, (float)($d['attendance_days'] ?? 0));
                $deduction = max(0, (float)($d['deduction'] ?? 0));
                $bonus = max(0, (float)($d['bonus'] ?? 0));
                $thr = max(0, (float)($d['thr'] ?? 0));
                if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $period)) return $this->failMessage('Periode payroll wajib menggunakan format bulan dan tahun yang valid.', 422);
                $employee = $db->table('ex_employees')->where('id',$employeeId)->where('company_id',$u['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
                if (!$employee) return $this->failMessage('Pegawai aktif tidak ditemukan.', 422);
                if ($db->table('ex_expenses')->where('company_id',$u['company_id'])->where('employee_id',$employeeId)->where('payroll_period',$period)->where('category','SALARY')->where('deleted_at',null)->countAllResults()) return $this->failMessage('Gaji pegawai untuk periode tersebut sudah diproses.', 422);
                $attendance = round((float)$employee['attendance_rate'] * $days,2);
                $mealRate = (float)$employee['meal_allowance'];
                $mealTotal = round($mealRate * $days,2);
                $received = round((float)$employee['salary']+(float)$employee['allowance']+$mealTotal+(float)$employee['transport_allowance']+$attendance-$deduction+$bonus+$thr,2);
                if ($received < 0) return $this->failMessage('Potongan tidak boleh melebihi seluruh pendapatan payroll.', 422);
                $row += ['employee_id'=>$employeeId,'payroll_period'=>$period,'base_salary'=>(float)$employee['salary'],'allowance'=>(float)$employee['allowance'],'meal_allowance_rate'=>$mealRate,'meal_allowance'=>$mealTotal,'transport_allowance'=>(float)$employee['transport_allowance'],'attendance_days'=>$days,'attendance_rate'=>(float)$employee['attendance_rate'],'attendance_allowance'=>$attendance,'deduction'=>$deduction,'bonus'=>$bonus,'thr'=>$thr];
                $row['qty']=1;$row['unit_amount']=$received;$row['total_amount']=$received;
                $row['notes']=$row['notes'] ?: 'Gaji '.$employee['name'].' periode '.$period;
            }
            $db->table('ex_expenses')->insert($row);
            $result=['id' => (int) $db->insertID()] + $row;
            if($category==='SALARY')$result+=['employee_name'=>$employee['name'],'employee_nik'=>$employee['nik'],'employee_phone'=>$employee['phone'],'employee_email'=>$employee['email']];
            return $this->ok($result, $category==='SALARY'?'Payroll dan pengeluaran gaji berhasil disimpan.':'Pengeluaran berhasil disimpan.', 201);
        } catch (\Throwable $e) {
            return $this->failMessage('Pengeluaran gagal disimpan.', 500);
        }
    }

    public function update($id = null)
    {
        try {
            $u = $this->user();
            if (($u['role'] ?? '') !== 'OWNER') return $this->failMessage('Payroll hanya dapat diedit owner.', 403);
            $db = db_connect();
            $current = $db->table('ex_expenses')->where('id', (int)$id)->where('company_id', $u['company_id'])->where('category', 'SALARY')->where('deleted_at', null)->get()->getRowArray();
            if (!$current) return $this->failMessage('Transaksi gaji tidak ditemukan.', 404);
            $d = $this->json();$employeeId=(int)($d['employee_id']??$current['employee_id']);$period=trim((string)($d['payroll_period']??$current['payroll_period']));$days=max(0,(float)($d['attendance_days']??0));$deduction=max(0,(float)($d['deduction']??0));$bonus=max(0,(float)($d['bonus']??0));$thr=max(0,(float)($d['thr']??0));
            if(!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$period))return $this->failMessage('Periode payroll tidak valid.',422);
            $employee=$db->table('ex_employees')->where('id',$employeeId)->where('company_id',$u['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();if(!$employee)return $this->failMessage('Pegawai aktif tidak ditemukan.',422);
            if($db->table('ex_expenses')->where('company_id',$u['company_id'])->where('employee_id',$employeeId)->where('payroll_period',$period)->where('category','SALARY')->where('id !=',(int)$id)->where('deleted_at',null)->countAllResults())return $this->failMessage('Gaji pegawai untuk periode tersebut sudah diproses.',422);
            $attendance=round((float)$employee['attendance_rate']*$days,2);$mealRate=(float)$employee['meal_allowance'];$mealTotal=round($mealRate*$days,2);$received=round((float)$employee['salary']+(float)$employee['allowance']+$mealTotal+(float)$employee['transport_allowance']+$attendance-$deduction+$bonus+$thr,2);if($received<0)return $this->failMessage('Potongan tidak boleh melebihi seluruh pendapatan payroll.',422);
            $row=['employee_id'=>$employeeId,'payroll_period'=>$period,'base_salary'=>(float)$employee['salary'],'allowance'=>(float)$employee['allowance'],'meal_allowance_rate'=>$mealRate,'meal_allowance'=>$mealTotal,'transport_allowance'=>(float)$employee['transport_allowance'],'attendance_days'=>$days,'attendance_rate'=>(float)$employee['attendance_rate'],'attendance_allowance'=>$attendance,'deduction'=>$deduction,'bonus'=>$bonus,'thr'=>$thr,'qty'=>1,'unit_amount'=>$received,'total_amount'=>$received,'notes'=>trim((string)($d['notes']??''))?:null,'updated_at'=>date('Y-m-d H:i:s')];
            $db->table('ex_expenses')->where('id',(int)$id)->update($row);
            return $this->ok(['id'=>(int)$id,'category'=>'SALARY','expense_date'=>$current['expense_date'],'employee_name'=>$employee['name'],'employee_nik'=>$employee['nik']]+$row,'Transaksi gaji berhasil diperbarui.');
        } catch (\Throwable $e) {log_message('error','Update payroll: '.$e->getMessage());return $this->failMessage('Transaksi gaji gagal diperbarui.',500);}
    }

    public function delete($id = null)
    {
        $u=$this->user();if(($u['role']??'')!=='OWNER')return $this->failMessage('Payroll hanya dapat dihapus owner.',403);
        $ok=db_connect()->table('ex_expenses')->where('id',(int)$id)->where('company_id',$u['company_id'])->where('category','SALARY')->where('deleted_at',null)->update(['deleted_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
        return $ok?$this->ok(null,'Transaksi gaji dihapus dari daftar. Histori tersimpan sebagai soft delete.'):$this->failMessage('Transaksi gaji gagal dihapus.',500);
    }

    public function report()
    {
        $u = $this->user();
        if ($u['role'] !== 'OWNER') return $this->failMessage('Laporan pengeluaran hanya dapat dilihat owner.', 403);
        $from = (string) ($this->request->getGet('from') ?: date('Y-m-01'));
        $to = (string) ($this->request->getGet('to') ?: date('Y-m-d'));
        $year = max(2020, (int) ($this->request->getGet('year') ?: date('Y')));
        $branch = (int) $this->request->getGet('branch_id');

        $expenses = $this->scope($u, $branch);
        $period = (clone $expenses)->where('e.expense_date >=', $from)->where('e.expense_date <=', $to);
        $manualTotal = (float) ((clone $period)->selectSum('e.total_amount')->get()->getRow('total_amount') ?? 0);
        $manualDaily = (clone $period)->select('e.expense_date label,SUM(e.total_amount) total')->groupBy('e.expense_date')->get()->getResultArray();
        $manualMonthly = (clone $expenses)->select('MONTH(e.expense_date) label,SUM(e.total_amount) total')->where('YEAR(e.expense_date)', $year)->groupBy('MONTH(e.expense_date)')->get()->getResultArray();
        $manualYearly = (clone $expenses)->select('YEAR(e.expense_date) label,SUM(e.total_amount) total')->groupBy('YEAR(e.expense_date)')->get()->getResultArray();

        $inventory = $this->inventoryOut($u, $branch);
        $inventoryPeriod = (clone $inventory)->where('m.movement_date >=', $from)->where('m.movement_date <=', $to);
        $inventoryTotal = (float) ((clone $inventoryPeriod)->selectSum('m.total_cost')->get()->getRow('total_cost') ?? 0);
        $inventoryDaily = (clone $inventoryPeriod)->select('m.movement_date label,SUM(m.total_cost) total')->groupBy('m.movement_date')->get()->getResultArray();
        $inventoryMonthly = (clone $inventory)->select('MONTH(m.movement_date) label,SUM(m.total_cost) total')->where('YEAR(m.movement_date)', $year)->groupBy('MONTH(m.movement_date)')->get()->getResultArray();
        $inventoryYearly = (clone $inventory)->select('YEAR(m.movement_date) label,SUM(m.total_cost) total')->groupBy('YEAR(m.movement_date)')->get()->getResultArray();

        $daily = $this->mergeSeries($manualDaily, $inventoryDaily, 'label');
        $monthly = array_map(fn($row) => ['month' => (int) $row['label'], 'total' => $row['total']], $this->mergeSeries($manualMonthly, $inventoryMonthly, 'label'));
        $yearly = array_map(fn($row) => ['year' => (int) $row['label'], 'total' => $row['total']], $this->mergeSeries($manualYearly, $inventoryYearly, 'label'));
        $total = $manualTotal + $inventoryTotal;

        $orders = db_connect()->table('ex_orders o')->where('o.company_id', $u['company_id'])->where('o.deleted_at', null)->where('o.status !=', 'CANCELLED')->where('DATE(o.created_at) >=', $from)->where('DATE(o.created_at) <=', $to);
        if ($branch) $orders->where('o.branch_id', $branch);
        $revenue = (float) ((clone $orders)->selectSum('o.paid_amount')->get()->getRow('paid_amount') ?? 0);
        return $this->ok(['from' => $from, 'to' => $to, 'expense' => $total, 'manual_expense' => $manualTotal, 'inventory_expense' => $inventoryTotal, 'revenue' => $revenue, 'net' => $revenue - $total, 'daily' => $daily, 'monthly' => $monthly, 'yearly' => $yearly]);
    }

    private function inventoryOut(array $u, int $branch = 0)
    {
        $b = db_connect()->table('ex_inventory_movements m')->where('m.company_id', $u['company_id'])->where('m.direction', 'OUT');
        if ($branch) $b->where('m.branch_id', $branch);
        return $b;
    }

    private function mergeSeries(array $first, array $second, string $key): array
    {
        $merged = [];
        foreach (array_merge($first, $second) as $row) {
            $label = (string) $row[$key];
            $merged[$label] = ($merged[$label] ?? 0) + (float) $row['total'];
        }
        ksort($merged);
        return array_map(fn($label, $total) => ['label' => $label, 'total' => $total], array_keys($merged), array_values($merged));
    }

    private function scope(array $u, int $requestedBranch = 0)
    {
        $b = db_connect()->table('ex_expenses e')->where('e.company_id', $u['company_id'])->where('e.deleted_at', null);
        if ($u['role'] !== 'OWNER') $b->where('e.branch_id', $u['branch_id'])->where('e.created_by', $u['id']);
        elseif ($requestedBranch) $b->where('e.branch_id', $requestedBranch);
        return $b;
    }
}
