<?php

namespace App\Controllers\Api\V1;

use App\Services\XlsxExportService;

class FinancialRecapController extends ApiController
{
    public function index()
    {
        try {
            return $this->ok($this->build(), 'Rekap laporan keuangan berhasil dimuat.');
        } catch (\InvalidArgumentException $e) {
            return $this->failMessage($e->getMessage(), 422);
        }
    }

    public function download()
    {
        try {
            $data = $this->build();
            $rows = [];
            $rows[] = ['LAPORAN PEMASUKAN', '', '', '', '', '', '', ''];
            $rows[] = ['No', 'No Order', 'Tanggal', 'Nama Customer', 'Total Qty', 'Harga', 'Diskon', 'Jumlah'];
            foreach ($data['income'] as $i => $row) $rows[] = [$i + 1, $row['order_number'], $row['date'], $row['customer_name'], $row['total_qty'], $row['price'], $row['discount'], $row['amount']];
            $rows[] = ['', '', '', '', '', '', 'Total Pemasukan', $data['total_income']];
            $rows[] = ['', '', '', '', '', '', '', ''];
            $rows[] = ['LAPORAN PENGELUARAN', '', '', '', '', '', '', ''];
            $rows[] = ['No', 'No Transaksi', 'Tanggal', 'Keterangan', 'Qty', 'Harga', 'Jumlah', ''];
            foreach ($data['expenses'] as $i => $row) $rows[] = [$i + 1, $row['transaction_number'], $row['date'], $row['description'], $row['qty'], $row['price'], $row['amount'], ''];
            $rows[] = ['', '', '', '', '', 'Total Pengeluaran', $data['total_expense'], ''];
            $rows[] = ['', '', '', '', '', 'Laba Rugi', $data['profit_loss'], ''];
            $path = WRITEPATH . 'uploads/rekap-keuangan-' . $data['from'] . '-' . $data['to'] . '.xlsx';
            (new XlsxExportService())->create($path, ['REKAP LAPORAN KEUANGAN', 'Periode ' . $data['from'] . ' s/d ' . $data['to'], 'Cabang: ' . $data['branch_name'], '', '', '', '', ''], $rows, 'Laporan Keuangan');
            return $this->response->download($path, null)->setFileName('rekap-laporan-keuangan-' . $data['from'] . '-' . $data['to'] . '.xlsx');
        } catch (\InvalidArgumentException $e) {
            return $this->failMessage($e->getMessage(), 422);
        }
    }

    private function build(): array
    {
        $u = $this->user();
        if ($u['role'] !== 'OWNER') throw new \InvalidArgumentException('Rekap laporan keuangan hanya dapat dilihat owner.');
        $from = (string) ($this->request->getGet('from') ?: date('Y-m-01'));
        $to = (string) ($this->request->getGet('to') ?: date('Y-m-d'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to) || $from > $to) throw new \InvalidArgumentException('Periode tanggal tidak valid.');
        $branchId = (int) ($this->request->getGet('branch_id') ?? 0);
        $db = db_connect();
        $branchName = 'Semua Cabang';
        if ($branchId) {
            $branch = $db->table('ex_branches')->select('name')->where('id', $branchId)->where('company_id', $u['company_id'])->where('deleted_at', null)->get()->getRowArray();
            if (!$branch) throw new \InvalidArgumentException('Cabang tidak ditemukan.');
            $branchName = $branch['name'];
        }

        $orders = $db->table('ex_orders o')->select('o.invoice_number order_number,DATE(o.created_at) date,c.name customer_name,o.item_count total_qty,o.subtotal price,o.discount_amount discount,o.total amount')->join('ex_customers c', 'c.id=o.customer_id', 'left')->where('o.company_id', $u['company_id'])->where('o.deleted_at', null)->where('o.status !=', 'CANCELLED')->where('DATE(o.created_at) >=', $from)->where('DATE(o.created_at) <=', $to);
        if ($branchId) $orders->where('o.branch_id', $branchId);
        $income = $orders->orderBy('o.created_at')->get()->getResultArray();

        $manual = $db->table('ex_expenses e')->select("CONCAT('EXP-',e.id) transaction_number,e.expense_date date,CONCAT(CASE e.category WHEN 'SALARY' THEN 'Gaji' WHEN 'RENT' THEN 'Sewa' WHEN 'OPERATIONAL' THEN 'Operasional' ELSE 'Lain-lain' END,CASE WHEN e.notes IS NULL OR e.notes='' THEN '' ELSE CONCAT(' - ',e.notes) END) description,e.qty,e.unit_amount price,e.total_amount amount")->where('e.company_id', $u['company_id'])->where('e.deleted_at', null)->where('e.expense_date >=', $from)->where('e.expense_date <=', $to);
        if ($branchId) $manual->where('e.branch_id', $branchId);
        $expenses = $manual->get()->getResultArray();

        $stock = $db->table('ex_inventory_movements m')->select("m.movement_number transaction_number,m.movement_date date,CONCAT('Pemakaian inventory - ',i.name,CASE WHEN m.notes IS NULL OR m.notes='' THEN '' ELSE CONCAT(' - ',m.notes) END) description,m.qty,m.unit_cost price,m.total_cost amount")->join('ex_inventory_items i', 'i.id=m.item_id', 'left')->where('m.company_id', $u['company_id'])->where('m.direction', 'OUT')->where('m.movement_date >=', $from)->where('m.movement_date <=', $to);
        if ($branchId) $stock->where('m.branch_id', $branchId);
        $expenses = array_merge($expenses, $stock->get()->getResultArray());
        usort($expenses, fn($a, $b) => strcmp($a['date'] . $a['transaction_number'], $b['date'] . $b['transaction_number']));
        $totalIncome = array_sum(array_map(fn($x) => (float) $x['amount'], $income));
        $totalExpense = array_sum(array_map(fn($x) => (float) $x['amount'], $expenses));
        return ['from' => $from, 'to' => $to, 'branch_id' => $branchId, 'branch_name' => $branchName, 'income' => $income, 'expenses' => $expenses, 'total_income' => $totalIncome, 'total_expense' => $totalExpense, 'profit_loss' => $totalIncome - $totalExpense];
    }
}
