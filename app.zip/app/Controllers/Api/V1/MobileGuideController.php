<?php
namespace App\Controllers\Api\V1;
class MobileGuideController extends ApiController
{public function index(){$q=trim((string)$this->request->getGet('q'));$b=db_connect()->table('ex_mobile_guides')->select('id,category,title,summary,content,video_url,sort_order')->where('is_active',1)->where('deleted_at',null);if($q!=='')$b->groupStart()->like('category',$q)->orLike('title',$q)->orLike('summary',$q)->orLike('content',$q)->groupEnd();$rows=$b->orderBy('sort_order')->orderBy('title')->get()->getResultArray();foreach($rows as &$row)$row['content']=str_replace('\\n',"\n",$row['content']);unset($row);return $this->ok($rows);}}
