<?php
namespace App\Controllers\Api\V1;

use App\Services\MobileLoginService;

class MobileLoginController extends ApiController
{
 public function password()
 {
  try {
   return $this->ok((new MobileLoginService())->password($this->json()),'Login berhasil');
  } catch(\Throwable $e) {
   return $this->loginError($e);
  }
 }

 public function sendOtp()
 {
  try {
   (new MobileLoginService())->sendOtp($this->json());
   return $this->ok(null,'Kode OTP berhasil dikirim.');
  } catch(\Throwable $e) {
   return $this->failMessage($e->getMessage(),422);
  }
 }

 public function otp()
 {
  try {
   return $this->ok((new MobileLoginService())->otp($this->json()),'Login berhasil');
  } catch(\Throwable $e) {
   return $this->loginError($e);
  }
 }

 private function loginError(\Throwable $e)
 {
  $message=$e->getMessage();
  if(str_starts_with($message,'DEVICE_ALREADY_REGISTERED|')){
   $parts=explode('|',$message,3);
   $data=['devices'=>[]];
   if(isset($parts[2])){
    $decoded=json_decode(base64_decode($parts[2]),true);
    if(is_array($decoded))$data['devices']=$decoded;
   }
   return $this->respond(['success'=>false,'message'=>$parts[1]??'Perangkat sudah terdaftar pada perangkat lain.','data'=>$data],409);
  }

  if(str_starts_with($message,'DEVICE_LIMIT_REACHED|')){
   $parts=explode('|',$message,3);
   $data=['devices'=>[]];
   if(isset($parts[2])){
    $decoded=json_decode(base64_decode($parts[2]),true);
    if(is_array($decoded))$data['devices']=$decoded;
   }
   return $this->respond(['success'=>false,'message'=>$parts[1]??'Batas perangkat pada paket sudah penuh.','data'=>$data],409);
  }

  return $this->failMessage($message,401);
 }
}