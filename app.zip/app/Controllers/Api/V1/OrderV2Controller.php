<?php

namespace App\Controllers\Api\V1;

class OrderV2Controller extends ApiController
{
    private function indoDate(string $value): string
    {
        $time = strtotime($value);
        if (!$time) return $value;
        $months = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
        return date('j', $time).' '.$months[(int) date('n', $time)].date(' Y, H:i', $time);
    }

    private function publicNotaUrl(array $order): string
    {
        $token = rtrim(strtr(base64_encode((string) service('encrypter')->encrypt((string) $order['invoice_number'])), '+/', '-_'), '=');
        return rtrim(base_url('nota'), '/').'/'.$token;
    }

    private function serviceStatusLabel(string $status): string
    {
        return ['RECEIVED'=>'Terima','PROCESSING'=>'Proses','READY'=>'Selesai','COMPLETED'=>'Diambil','CANCELLED'=>'Dihapus'][$status] ?? $status;
    }

    private function money($value): string { $s=number_format((float)$value,2,',','.'); return 'Rp '.preg_replace('/,00$/','',$s); }

    private function scopedBranch(array $user): int
    {
        if (($user['role'] ?? '') !== 'OWNER') {
            return (int) ($user['branch_id'] ?? 0);
        }

        $branchId = (int) ($this->request->getGet('branch_id') ?? 0);
        if ($branchId < 1) {
            return 0;
        }

        $exists = db_connect()->table('ex_branches')
            ->where('id', $branchId)
            ->where('company_id', $user['company_id'])
            ->where('is_active', 1)
            ->where('deleted_at', null)
            ->countAllResults() > 0;

        return $exists ? $branchId : 0;
    }

    private function orderQuery(array $user, bool $deletedOnly = false)
    {
        $query = db_connect()->table('ex_orders o')
            ->where('o.company_id', $user['company_id']);
        if ($deletedOnly) $query->where('o.deleted_at IS NOT NULL', null, false);
        else $query->where('o.deleted_at', null);
        $branchId = $this->scopedBranch($user);
        if (($user['role'] ?? '') !== 'OWNER' && $branchId < 1) {
            $query->where('1 = 0', null, false);
        } elseif ($branchId > 0) {
            $query->where('o.branch_id', $branchId);
        }
        return $query;
    }

    public function index()
    {
        $user = $this->user();
        $license = (new \App\Services\EntitlementService())->current((int) $user['company_id']);
        $dailyLimit = $license['daily_transaction_limit'] ?? null;
        $todayCount = (int) db_connect()->table('ex_orders')
            ->where('company_id', $user['company_id'])
            ->where('created_at >=', date('Y-m-d 00:00:00'))
            ->where('created_at <', date('Y-m-d 00:00:00', strtotime('+1 day')))
            ->where('deleted_at', null)
            ->countAllResults();
        $page = max(1, (int) ($this->request->getGet('page') ?: 1));
        $limit = max(10, min(50, (int) ($this->request->getGet('limit') ?: 20)));
        $search = trim((string) $this->request->getGet('q'));
        $status = strtoupper(trim((string) $this->request->getGet('status')));
        $isOwner = ($user['role'] ?? '') === 'OWNER';
        $showDeleted = $status === 'DELETED' && $isOwner;
        $countBase = $this->orderQuery($user)->join('ex_customers c', 'c.id=o.customer_id', 'left');
        if ($search !== '') {
            $countBase->groupStart()->like('o.invoice_number', $search)->orLike('c.name', $search)->groupEnd();
        }
        $statusCounts = ['ALL' => 0, 'RECEIVED' => 0, 'PROCESSING' => 0, 'READY' => 0, 'COMPLETED' => 0, 'DELETED' => 0];
        foreach ((clone $countBase)->select('o.status,COUNT(*) total')->whereIn('o.status', ['RECEIVED', 'PROCESSING', 'READY', 'COMPLETED'])->groupBy('o.status')->get()->getResultArray() as $countRow) {
            $statusCounts[$countRow['status']] = (int) $countRow['total'];
            $statusCounts['ALL'] += (int) $countRow['total'];
        }
        if ($isOwner) {
            $deletedCount = $this->orderQuery($user, true)->join('ex_customers c', 'c.id=o.customer_id', 'left');
            if ($search !== '') $deletedCount->groupStart()->like('o.invoice_number', $search)->orLike('c.name', $search)->groupEnd();
            $statusCounts['DELETED'] = (int) $deletedCount->countAllResults();
        }
        $base = $this->orderQuery($user, $showDeleted)
            ->select("o.*,c.name customer_name,c.phone customer_phone,c.email customer_email,b.name branch_name,b.address branch_address,b.phone branch_phone,creator.fullname cashier_name,(SELECT mb.address FROM ex_branches mb WHERE mb.company_id=o.company_id AND mb.is_active=1 AND mb.deleted_at IS NULL ORDER BY mb.id ASC LIMIT 1) main_branch_address,(SELECT mb.phone FROM ex_branches mb WHERE mb.company_id=o.company_id AND mb.is_active=1 AND mb.deleted_at IS NULL ORDER BY mb.id ASC LIMIT 1) main_branch_phone,COALESCE((SELECT SUM(p.amount) FROM ex_order_payments p WHERE p.order_id=o.id AND p.payment_type='DP'),0) dp_amount,(SELECT h.notes FROM ex_order_status_history h WHERE h.order_id=o.id AND h.status='CANCELLED' ORDER BY h.id DESC LIMIT 1) deletion_reason")
            ->join('ex_customers c', 'c.id=o.customer_id', 'left')
            ->join('ex_branches b', 'b.id=o.branch_id', 'left')
            ->join('ex_users creator', 'creator.id=o.created_by', 'left');
        if ($search !== '') {
            $base->groupStart()->like('o.invoice_number', $search)->orLike('c.name', $search)->groupEnd();
        }
        if (in_array($status, ['RECEIVED', 'PROCESSING', 'READY', 'COMPLETED'], true)) {
            $base->where('o.status', $status);
        }
        if ($status === 'DELETED' && !$isOwner) $base->where('1 = 0', null, false);
        $total = (clone $base)->countAllResults();
        $rows = $base->orderBy($showDeleted ? 'o.deleted_at' : 'o.id', 'DESC')->limit($limit, ($page - 1) * $limit)->get()->getResultArray();

        /*
         * DETAIL ITEM PESANAN
         * Sertakan rincian layanan pada setiap order agar frontend dapat
         * menampilkan detail pesanan tanpa query endpoint/model tambahan.
         */
        $orderIds = array_values(array_filter(array_map(
            static fn($row) => (int) ($row['id'] ?? 0),
            $rows
        )));

        $itemsByOrder = [];
        if ($orderIds) {
            $itemRows = db_connect()->table('ex_order_items')
                ->whereIn('order_id', $orderIds)
                ->orderBy('order_id', 'ASC')
                ->orderBy('id', 'ASC')
                ->get()
                ->getResultArray();

            foreach ($itemRows as $item) {
                $orderId = (int) $item['order_id'];
                $itemsByOrder[$orderId][] = [
                    'id' => (int) $item['id'],
                    'product_id' => (int) ($item['product_id'] ?? 0),
                    'product_name' => (string) ($item['product_name'] ?? ''),
                    'unit' => (string) ($item['unit'] ?? ''),
                    'qty' => (float) ($item['qty'] ?? 0),
                    'price' => (float) ($item['price'] ?? 0),
                    'subtotal' => (float) ($item['subtotal'] ?? 0),
                ];
            }
        }

        foreach ($rows as &$row) {
            if ($showDeleted) {
                $row['status'] = 'DELETED';
                $row['deletion_reason'] = preg_replace('/^Dihapus Owner:\s*/i', '', (string) ($row['deletion_reason'] ?? ''));
            }
            $row['public_note_url'] = $this->publicNotaUrl($row);
            $row['service_status_label'] = $this->serviceStatusLabel((string) $row['status']);
            $row['items'] = $itemsByOrder[(int) $row['id']] ?? [];
        }
        unset($row);

        return $this->ok([
            'rows' => $rows,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'has_more' => $page * $limit < $total,
            'status_counts' => $statusCounts,
            'today_transaction_count' => $todayCount,
            'daily_transaction_limit' => $dailyLimit === null ? null : (int) $dailyLimit,
            'can_create_transaction' => $dailyLimit === null || $todayCount < (int) $dailyLimit,
        ]);
    }

    public function updateStatus($id = null)
    {
        $user = $this->user();
        $data = $this->json();
        $status = strtoupper((string) ($data['status'] ?? ''));
        if (!in_array($status, ['PROCESSING', 'READY', 'COMPLETED'], true)) {
            return $this->failMessage('Status tidak valid.', 422);
        }
        $order = $this->orderQuery($user)->where('o.id', (int) $id)->get()->getRowArray();
        if (!$order) {
            return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.', 404);
        }
        if ($status === 'COMPLETED' && (float) ($order['outstanding_amount'] ?? 0) > 0) {
            return $this->failMessage('Pesanan masih memiliki piutang Rp '.number_format($order['outstanding_amount'],0,',','.').'. Selesaikan pembayaran terlebih dahulu.', 422);
        }
        $changes = ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')];
        if ($status === 'COMPLETED') {
            $changes['completed_at'] = date('Y-m-d H:i:s');
        }
        $db = db_connect();
        $db->transStart();
        $db->table('ex_orders')->where('id', $order['id'])->update($changes);
        $db->table('ex_order_status_history')->insert(['order_id' => $order['id'], 'status' => $status, 'notes' => trim((string) ($data['notes'] ?? '')) ?: null, 'changed_by' => $user['id'], 'created_at' => date('Y-m-d H:i:s')]);
        $db->transComplete();
        return $db->transStatus() ? $this->ok($changes, 'Status pesanan berhasil diperbarui.') : $this->failMessage('Status gagal diperbarui.', 500);
    }

    public function settle($id = null)
    {
        try {
            $user=$this->user();$data=$this->json();$db=db_connect();$order=$this->orderQuery($user)->where('o.id',(int)$id)->get()->getRowArray();
            if(!$order)return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.',404);
            if($order['status']!=='READY')return $this->failMessage('Pelunasan saat pengambilan hanya tersedia untuk pesanan berstatus Selesai.',422);
            $due=(float)($order['outstanding_amount']??max(0,(float)$order['total']-(float)$order['paid_amount']));if($due<=0)return $this->failMessage('Pesanan sudah lunas.',422);
            $cash=(float)($data['cash_received']??0);if($cash<$due)return $this->failMessage('Uang diterima kurang dari sisa piutang.',422);$method=in_array($data['payment_method']??'',['CASH','BANK_TRANSFER','QRIS'],true)?$data['payment_method']:'CASH';$now=date('Y-m-d H:i:s');
            $db->transStart();$db->table('ex_orders')->where('id',$order['id'])->update(['paid_amount'=>$order['total'],'outstanding_amount'=>0,'payment_status'=>'PAID','payment_method'=>$method,'cash_received'=>$cash,'change_amount'=>$cash-$due,'status'=>'COMPLETED','completed_at'=>$now,'updated_at'=>$now]);$db->table('ex_order_payments')->insert(['order_id'=>$order['id'],'company_id'=>$user['company_id'],'branch_id'=>$order['branch_id'],'payment_type'=>'SETTLEMENT','method'=>$method,'amount'=>$due,'cash_received'=>$cash,'change_amount'=>$cash-$due,'created_by'=>$user['id'],'created_at'=>$now]);$db->table('ex_order_status_history')->insert(['order_id'=>$order['id'],'status'=>'COMPLETED','notes'=>'Pelunasan piutang saat pengambilan','changed_by'=>$user['id'],'created_at'=>$now]);$db->transComplete();if(!$db->transStatus())throw new \RuntimeException('Pelunasan gagal disimpan.');
            return $this->ok(array_merge($order,['paid_amount'=>$order['total'],'outstanding_amount'=>0,'payment_status'=>'PAID','payment_method'=>$method,'cash_received'=>$cash,'change_amount'=>$cash-$due,'status'=>'COMPLETED','completed_at'=>$now]),'Pembayaran lunas dan pesanan sudah diambil.');
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }

    public function update($id = null)
    {
        try {
            $user = $this->user();

            if (($user['role'] ?? '') !== 'OWNER') {
                return $this->failMessage('Hanya Owner yang dapat mengedit pesanan.', 403);
            }

            $order = $this->orderQuery($user)
                ->where('o.id', (int) $id)
                ->get()
                ->getRowArray();

            if (!$order) {
                return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.', 404);
            }

            if (($order['status'] ?? '') === 'COMPLETED') {
                return $this->failMessage('Pesanan yang sudah diambil tidak dapat diedit.', 422);
            }

            if (($order['status'] ?? '') === 'CANCELLED') {
                return $this->failMessage('Pesanan sudah dihapus.', 422);
            }

            $d = $this->json();
            $db = db_connect();

            /*
             * DETAIL PESANAN
             * - Diskon dapat dipilih/dihapus dari form Detail.
             * - Jemput / antar disimpan pada fulfillment_type.
             * - Catatan disimpan pada notes.
             */
            $discountId = isset($d['discount_id']) && (int) $d['discount_id'] > 0
                ? (int) $d['discount_id']
                : 0;

            $discount = null;
            $discountAmount = 0;
            $subtotal = (float) ($order['subtotal'] ?? 0);

            if ($discountId > 0) {
                $discount = $db->table('ex_discounts')
                    ->join('ex_discount_branches db', 'db.discount_id=ex_discounts.id AND db.branch_id='.(int)$order['branch_id'], 'left')
                    ->where('id', $discountId)
                    ->where('ex_discounts.company_id', $user['company_id'])
                    ->where('ex_discounts.is_active', 1)
                    ->where('ex_discounts.deleted_at', null)
                    ->where('COALESCE(db.is_active,ex_discounts.is_active) = 1',null,false)
                    ->get()
                    ->getRowArray();

                if (!$discount) {
                    return $this->failMessage('Diskon tidak ditemukan atau sudah tidak aktif.', 422);
                }

                if ($subtotal < (float) ($discount['min_transaction'] ?? 0)) {
                    return $this->failMessage(
                        'Transaksi belum memenuhi minimum transaksi untuk diskon tersebut.',
                        422
                    );
                }

                $discountAmount = ($discount['type'] ?? '') === 'PERCENT'
                    ? $subtotal * (float) $discount['value'] / 100
                    : (float) $discount['value'];

                $discountAmount = min($subtotal, max(0, $discountAmount));
            }

            $total = max(0, $subtotal - $discountAmount);

            $fulfillmentType = strtoupper((string) ($d['fulfillment_type'] ?? ($order['fulfillment_type'] ?? 'DROP_OFF')));
            if (!in_array($fulfillmentType, ['DROP_OFF', 'PICKUP', 'DELIVERY'], true)) {
                $fulfillmentType = 'DROP_OFF';
            }

            $priority = array_key_exists('is_priority', $d)
                ? (!empty($d['is_priority']) ? 1 : 0)
                : (int) ($order['is_priority'] ?? 0);

            /*
             * PEMBAYARAN
             * Mendukung format lama PAID/UNPAID dan format baru:
             * FULL / DP / UNPAID.
             *
             * Nilai paid_amount selalu dibatasi maksimal total transaksi.
             */
            $choice = strtoupper((string) ($d['payment_choice'] ?? ''));

            $method = in_array(
                $d['payment_method'] ?? '',
                ['CASH', 'BANK_TRANSFER', 'QRIS'],
                true
            )
                ? $d['payment_method']
                : (string) ($order['payment_method'] ?? 'CASH');

            $requestedPaid = array_key_exists('paid_amount', $d)
                ? (float) $d['paid_amount']
                : (float) ($order['paid_amount'] ?? 0);

            $requestedPaid = max(0, $requestedPaid);

            if ($choice === 'UNPAID' || $choice === 'BELUM_BAYAR') {
                $paid = 0;
            } elseif ($choice === 'FULL' || $choice === 'PAID' || $choice === 'LUNAS') {
                $paid = min($requestedPaid, $total);

                /*
                 * Jika Full/Uang Pas dipilih tetapi paid_amount kosong,
                 * anggap pembayaran penuh.
                 */
                if ($paid <= 0 && $total > 0) {
                    $paid = $total;
                }
            } elseif ($choice === 'DP' || $choice === 'PARTIAL') {
                $paid = min($requestedPaid, $total);

                if ($paid <= 0 && $total > 0) {
                    return $this->failMessage('Nominal DP harus lebih dari Rp 0.', 422);
                }

                if ($paid >= $total && $total > 0) {
                    return $this->failMessage('Nominal DP harus lebih kecil dari total transaksi.', 422);
                }
            } else {
                $paid = min($requestedPaid, $total);
            }

            $paymentStatus = $paid <= 0
                ? 'UNPAID'
                : ($paid < $total ? 'PARTIAL' : 'PAID');

            $cashReceived = array_key_exists('cash_received', $d)
                ? max(0, (float) $d['cash_received'])
                : $paid;

            if ($method !== 'CASH') {
                $cashReceived = $paid;
            }

            $changeAmount = $method === 'CASH'
                ? max(0, $cashReceived - $total)
                : 0;

            $notes = trim((string) ($d['notes'] ?? ($order['notes'] ?? '')));
            $now = date('Y-m-d H:i:s');

            $changes = [
                'discount_id'       => $discountId > 0 ? $discountId : null,
                'discount_amount'  => $discountAmount,
                'total'             => $total,
                'fulfillment_type'  => $fulfillmentType,
                'is_priority'       => $priority,
                'payment_method'    => $method,
                'paid_amount'       => $paid,
                'outstanding_amount' => max(0, $total - $paid),
                'payment_status'    => $paymentStatus,
                'cash_received'     => $cashReceived,
                'change_amount'     => $changeAmount,
                'notes'             => $notes !== '' ? $notes : null,
                'updated_at'       => $now,
            ];

            $history = [
                'discount_id'      => $discountId > 0 ? $discountId : null,
                'discount_amount' => $discountAmount,
                'total'            => $total,
                'fulfillment_type' => $fulfillmentType,
                'priority'         => $priority,
                'payment_choice'   => $choice,
                'payment_method'   => $method,
                'paid_amount'      => $paid,
                'outstanding_amount' => max(0, $total - $paid),
                'notes'            => $notes,
            ];

            $db->transStart();

            $db->table('ex_orders')
                ->where('id', $order['id'])
                ->update($changes);

            $db->table('ex_order_status_history')->insert([
                'order_id'   => $order['id'],
                'status'     => $order['status'],
                'notes'      => 'Edit pesanan Owner: '.json_encode(
                    $history,
                    JSON_UNESCAPED_UNICODE
                ),
                'changed_by' => $user['id'],
                'created_at' => $now,
            ]);

            $db->table('ex_logs')->insert([
                'company_id'  => $user['company_id'],
                'user_id'     => $user['id'],
                'action'      => 'EDIT_ORDER',
                'module'      => 'ORDER',
                'reference_id' => $order['id'],
                'ip_address'  => $this->request->getIPAddress(),
                'metadata'    => json_encode([
                    'invoice' => $order['invoice_number'],
                    'changes' => $changes,
                ], JSON_UNESCAPED_UNICODE),
                'created_at'  => $now,
            ]);

            $db->transComplete();

            if (!$db->transStatus()) {
                return $this->failMessage('Perubahan pesanan gagal disimpan.', 500);
            }

            return $this->ok(
                array_merge(
                    $order,
                    $changes,
                    [
                        'public_note_url' => $this->publicNotaUrl(
                            array_merge($order, $changes)
                        ),
                    ]
                ),
                'Pesanan berhasil diperbarui.'
            );
        } catch (\Throwable $e) {
            log_message('error', 'Edit order: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 500);
        }
    }

    public function delete($id = null)
    {
        try {
            $user=$this->user();
            if(($user['role']??'')!=='OWNER') return $this->failMessage('Hanya Owner yang dapat menghapus pesanan.',403);
            $order=$this->orderQuery($user)->where('o.id',(int)$id)->get()->getRowArray();
            if(!$order)return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.',404);
            if(($order['status']??'')==='COMPLETED')return $this->failMessage('Pesanan yang sudah diambil tidak dapat dihapus.',422);
            $reason=trim((string)($this->json()['reason']??''));
            if($reason==='')return $this->failMessage('Alasan penghapusan wajib diisi.',422);
            $now=date('Y-m-d H:i:s');$db=db_connect();$db->transStart();
            $db->table('ex_orders')->where('id',$order['id'])->update(['status'=>'CANCELLED','deleted_at'=>$now,'updated_at'=>$now]);
            $db->table('ex_order_status_history')->insert(['order_id'=>$order['id'],'status'=>'CANCELLED','notes'=>'Dihapus Owner: '.$reason,'changed_by'=>$user['id'],'created_at'=>$now]);
            $db->table('ex_logs')->insert(['company_id'=>$user['company_id'],'user_id'=>$user['id'],'action'=>'DELETE_ORDER','module'=>'ORDER','reference_id'=>$order['id'],'ip_address'=>$this->request->getIPAddress(),'metadata'=>json_encode(['invoice'=>$order['invoice_number'],'reason'=>$reason],JSON_UNESCAPED_UNICODE),'created_at'=>$now]);
            $db->transComplete();
            return $db->transStatus()?$this->ok(null,'Pesanan berhasil dihapus.'):$this->failMessage('Pesanan gagal dihapus.',500);
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }

    public function emailReceipt($id = null)
    {
        try {
            $user = $this->user();
            $db = db_connect();
            $order = $this->orderQuery($user)
                ->select('o.*,c.name customer_name,c.email customer_email,c.phone customer_phone,b.name branch_name,u.fullname cashier_name')
                ->join('ex_customers c', 'c.id=o.customer_id', 'left')
                ->join('ex_branches b', 'b.id=o.branch_id', 'left')
                ->join('ex_users u', 'u.id=o.created_by', 'left')
                ->where('o.id', (int) $id)->get()->getRowArray();
            if (!$order) return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.', 404);
            $email = strtolower(trim((string) ($order['customer_email'] ?? '')));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return $this->failMessage('Pelanggan belum memiliki alamat email yang valid. Silakan lengkapi email pelanggan terlebih dahulu.', 422);
            $company = $db->table('ex_companies')->where('id', $user['company_id'])->get()->getRowArray();
            $items = $db->table('ex_order_items')->where('order_id', $order['id'])->orderBy('id')->get()->getResultArray();
            $rows = '';
            foreach ($items as $item) $rows .= '<tr><td style="padding:9px;border-bottom:1px solid #e5e7eb">'.esc($item['product_name']).'</td><td style="padding:9px;text-align:right;border-bottom:1px solid #e5e7eb">'.number_format($item['qty'],2,',','.').' '.esc($item['unit']).'</td><td style="padding:9px;text-align:right;border-bottom:1px solid #e5e7eb">Rp '.number_format($item['price'],2,',','.').'</td><td style="padding:9px;text-align:right;border-bottom:1px solid #e5e7eb">Rp '.number_format($item['subtotal'],2,',','.').'</td></tr>';
            $logo = !empty($company['logo']) ? '<img src="'.base_url($company['logo']).'" style="width:68px;height:68px;object-fit:contain;margin-right:14px">' : '';
            $body = '<div style="font-family:Arial,sans-serif;max-width:700px;margin:auto;color:#18332d"><div style="display:flex;align-items:center;border-bottom:3px solid #168a72;padding-bottom:16px">'.$logo.'<div><h2 style="margin:0">'.esc($company['company_name'] ?? 'Eksis Laundry').'</h2><div>'.esc($company['address'] ?? '').'</div><div>'.esc($company['phone'] ?? '').'</div></div></div><h2 style="color:#168a72;margin-bottom:4px">Nota Pesanan</h2><div style="font-weight:bold">'.esc($order['invoice_number']).'</div><p>Halo <b>'.esc($order['customer_name']).'</b>, berikut rincian pesanan laundry Anda.</p><table style="width:100%;border-collapse:collapse;margin-top:16px"><thead><tr style="background:#168a72;color:#fff"><th style="padding:9px;text-align:left">Produk/Layanan</th><th style="padding:9px;text-align:right">Qty</th><th style="padding:9px;text-align:right">Harga</th><th style="padding:9px;text-align:right">Jumlah</th></tr></thead><tbody>'.$rows.'</tbody></table><div style="margin:18px 0 0 auto;max-width:330px"><div style="display:flex;justify-content:space-between;padding:6px"><span>Subtotal</span><b>Rp '.number_format($order['subtotal'],2,',','.').'</b></div><div style="display:flex;justify-content:space-between;padding:6px"><span>Diskon</span><b>-Rp '.number_format($order['discount_amount'],2,',','.').'</b></div><div style="display:flex;justify-content:space-between;padding:10px 6px;border-top:2px solid #168a72;color:#168a72;font-size:18px"><b>Total</b><b>Rp '.number_format($order['total'],2,',','.').'</b></div></div><p style="margin-top:28px;text-align:center;color:#64756f">'.nl2br(esc($company['receipt_footer'] ?? 'Terima kasih telah menggunakan layanan kami.')).'</p></div>';
            $actualTotal = (float) $order['total'];
            $roundedTotal = $actualTotal;
            $rounding = 0;
            $initialPayment = $db->table('ex_order_payments')->select('amount')->where('order_id', $order['id'])->where('payment_type', 'DP')->orderBy('id', 'ASC')->get()->getRowArray();
            $dp = (float) ($initialPayment['amount'] ?? 0);
            $remaining = max(0, $roundedTotal - (float) ($order['paid_amount'] ?? 0));
            $settlement = $db->table('ex_order_payments')->select('amount')->where('order_id', $order['id'])->where('payment_type', 'SETTLEMENT')->orderBy('id', 'DESC')->get()->getRowArray();
            $paymentAtPickup = (float) ($settlement['amount'] ?? 0);
            $money = static function ($value) { $n=(float)$value; $s=number_format($n,2,',','.'); return 'Rp '.preg_replace('/,00$/','',$s); };
            $meta = '<div style="display:grid;grid-template-columns:150px 1fr;gap:7px;margin:18px 0;padding:14px;background:#f3f8f6;border-radius:10px">'
                .'<b>Tanggal</b><span>'.esc($this->indoDate((string) $order['created_at'])).'</span>'
                .'<b>Kasir</b><span>'.esc($order['cashier_name'] ?? 'Kasir').'</span>'
                .'<b>Estimasi</b><span>'.esc((string)($order['estimated_days']??'-')).' hari</span>'
                .'<b>Status layanan</b><span>'.esc($this->serviceStatusLabel((string)$order['status'])).'</span>'
                .'<b>Nota online</b><span>'.esc($this->publicNotaUrl($order)).'</span></div>';
            $paymentMethod = ['CASH' => 'Cash', 'BANK_TRANSFER' => 'Transfer Bank', 'QRIS' => 'QRIS'][$order['payment_method'] ?? ''] ?? (string) ($order['payment_method'] ?? '-');
            $paymentStatus = ['UNPAID' => 'Belum Bayar', 'PARTIAL' => 'DP', 'PAID' => 'Lunas'][$order['payment_status'] ?? ''] ?? (string) ($order['payment_status'] ?? '-');
            $totalRow = static fn ($label, $value, $style = '') => '<tr style="'.$style.'"><td style="padding:7px 6px">'.$label.'</td><td style="padding:7px 6px;text-align:right;white-space:nowrap"><b>'.$value.'</b></td></tr>';
            $totals = '<table role="presentation" style="width:330px;margin:18px 0 0 auto;border-collapse:collapse">'
                .$totalRow('Subtotal', $money($order['subtotal']))
                .$totalRow('Diskon', '-'.$money($order['discount_amount']))
                .($rounding > 0 ? $totalRow('Pembulatan', $money($rounding)) : '')
                .$totalRow('Total', $money($roundedTotal), 'border-top:2px solid #168a72;color:#168a72;font-size:18px')
                .$totalRow('DP', $money($dp))
                .$totalRow('Sisa pembayaran', $money($remaining), 'color:#b45309;border-top:1px dashed #9fb4ad')
                .$totalRow('Status', esc($paymentStatus))
                .(($order['payment_status'] ?? '') !== 'UNPAID' ? $totalRow('Metode bayar', esc($paymentMethod)) : '')
                .(($order['status'] ?? '') === 'COMPLETED' && $paymentAtPickup > 0 ? $totalRow('Nilai bayar', $money($paymentAtPickup)) : '')
                .'</table>';
            $body = '<div style="font-family:Arial,sans-serif;max-width:700px;margin:auto;color:#18332d"><div style="display:flex;align-items:center;border-bottom:3px solid #168a72;padding-bottom:16px">'.$logo.'<div><h2 style="margin:0">'.esc($company['company_name'] ?? 'Eksis Laundry').'</h2><div>'.esc($company['address'] ?? '').'</div><div>'.esc($company['phone'] ?? '').'</div></div></div><h2 style="color:#168a72;margin:22px 0 4px">Nota Pesanan</h2><div style="font-weight:bold">'.esc($order['invoice_number']).'</div><p>Halo <b>'.esc($order['customer_name']).'</b>, berikut rincian pesanan laundry Anda.</p>'.$meta.'<table style="width:100%;border-collapse:collapse;margin-top:16px"><thead><tr style="background:#168a72;color:#fff"><th style="padding:9px;text-align:left">Produk/Layanan</th><th style="padding:9px;text-align:right">Qty</th><th style="padding:9px;text-align:right">Harga</th><th style="padding:9px;text-align:right">Jumlah</th></tr></thead><tbody>'.$rows.'</tbody></table>'.$totals.'<p style="margin-top:28px;text-align:center;color:#64756f">'.nl2br(esc($company['receipt_footer'] ?? 'Terima kasih telah menggunakan layanan kami.')).'</p></div>';
            $service = new \App\Services\NotificationService();
            if (!$service->email($email, 'Nota Pesanan '.$order['invoice_number'].' - '.($company['company_name'] ?? 'Eksis Laundry'), $body)) return $this->failMessage('Email gagal dikirim: '.($service->getLastError() ?: 'periksa konfigurasi email admin.'), 502);
            return $this->ok(['email' => $email], 'Nota pesanan berhasil dikirim ke '.$email.'.');
        } catch (\Throwable $e) {
            log_message('error', 'Email receipt order: '.$e->getMessage());
            return $this->failMessage('Nota pesanan gagal dikirim melalui email.', 500);
        }
    }

    public function whatsappReceipt($id = null)
    {
        try {
            $user = $this->user();
            $db = db_connect();

            $order = $this->orderQuery($user)
                ->select('o.*,c.name customer_name,c.phone customer_phone,u.fullname cashier_name')
                ->join('ex_customers c', 'c.id=o.customer_id', 'left')
                ->join('ex_users u', 'u.id=o.created_by', 'left')
                ->where('o.id', (int) $id)
                ->get()->getRowArray();

            if (!$order) return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.', 404);
            if (($order['status'] ?? '') === 'COMPLETED') return $this->failMessage('Struk WhatsApp hanya dapat dikirim sebelum pesanan diambil.', 422);

            $phone = trim((string) ($order['customer_phone'] ?? ''));
            if ($phone === '') return $this->failMessage('Pelanggan belum memiliki nomor WhatsApp. Lengkapi nomor pelanggan terlebih dahulu.', 422);

            $company = $db->table('ex_companies')->where('id', $user['company_id'])->get()->getRowArray() ?: [];
            if (strtoupper((string) ($company['whatsapp_delivery_method'] ?? 'APP')) !== 'LINKED') {
                return $this->failMessage('Metode pengiriman saat ini adalah aplikasi WhatsApp. Gunakan aplikasi WhatsApp pada perangkat.', 422);
            }

            if (!$db->table('ex_whatsapp_sessions')->where('company_id', $user['company_id'])->where('status', 'CONNECTED')->where('deleted_at', null)->countAllResults()) {
                return $this->failMessage('WhatsApp customer belum terhubung. Scan QR terlebih dahulu pada menu Pengaturan.', 422);
            }

            $message = $this->buildWhatsAppReceiptMessage($order, $company);

            $result = (new \App\Services\EksisWhatsAppGatewayService('CUSTOMER'))->sendForCompany(
                (int) $user['company_id'],
                $phone,
                $message
            );

            if (!$result['success']) return $this->failMessage((string) ($result['message'] ?? 'Gateway WhatsApp gagal mengirim struk.'), 502);

            return $this->ok([
                'phone' => $phone,
                'message' => $message,
                'format_source' => 'backend_linked_receipt',
            ], 'Struk WhatsApp berhasil dikirim ke pelanggan.');
        } catch (\Throwable $e) {
            log_message('error', 'WhatsApp receipt order: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 500);
        }
    }

    /**
     * Preview format WhatsApp yang sama persis dengan Linked Device.
     * Mobile APP dapat memakai endpoint ini agar format tidak berbeda.
     */
    public function whatsappReceiptPreview($id = null)
    {
        try {
            $user = $this->user();
            $db = db_connect();

            $order = $this->orderQuery($user)
                ->select('o.*,c.name customer_name,c.phone customer_phone,u.fullname cashier_name')
                ->join('ex_customers c', 'c.id=o.customer_id', 'left')
                ->join('ex_users u', 'u.id=o.created_by', 'left')
                ->where('o.id', (int) $id)
                ->get()->getRowArray();

            if (!$order) return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.', 404);
            if (($order['status'] ?? '') === 'COMPLETED') return $this->failMessage('Struk WhatsApp hanya dapat dikirim sebelum pesanan diambil.', 422);

            $phone = trim((string) ($order['customer_phone'] ?? ''));
            if ($phone === '') return $this->failMessage('Pelanggan belum memiliki nomor WhatsApp.', 422);

            $company = $db->table('ex_companies')->where('id', $user['company_id'])->get()->getRowArray() ?: [];
            $message = $this->buildWhatsAppReceiptMessage($order, $company);

            return $this->ok([
                'phone' => $phone,
                'message' => $message,
                'format_source' => 'backend_linked_receipt',
            ], 'Format WhatsApp berhasil dibuat.');
        } catch (\Throwable $e) {
            log_message('error', 'WhatsApp receipt preview: '.$e->getMessage());
            return $this->failMessage($e->getMessage(), 500);
        }
    }

    private function buildWhatsAppReceiptMessage(array $order, array $company): string
    {
        $db = db_connect();
        $items = $db->table('ex_order_items')->where('order_id', $order['id'])->orderBy('id')->get()->getResultArray();

        $actualTotal = (float) $order['total'];
        $roundedTotal = $actualTotal;
        $rounding = 0;

        $dpPayment = $db->table('ex_order_payments')
            ->select('amount')
            ->where('order_id', $order['id'])
            ->where('payment_type', 'DP')
            ->orderBy('id', 'ASC')
            ->get()->getRowArray();

        $dpAmount = (float) ($dpPayment['amount'] ?? 0);
        $outstanding = max(0, $roundedTotal - (float) ($order['paid_amount'] ?? 0));

        $lines = [
            "🧺 *".trim((string) ($company['company_name'] ?? 'EKSIS LAUNDRY')).'*',
            '📍 '.trim((string) ($company['address'] ?? '')),
            '📞 '.trim((string) ($company['phone'] ?? '')),
            str_repeat('-', 32),
            '👤 Pelanggan : '.(string) $order['customer_name'],
            '🧾 No. Transaksi : '.(string) $order['invoice_number'],
            '🕐 Tanggal : '.$this->indoDate((string) $order['created_at']),
            '👨‍💼 Kasir : '.trim((string) ($order['cashier_name'] ?? 'Kasir')),
            '⏳ Estimasi : '.(string)($order['estimated_days']??'-').' hari',
            '📋 Status layanan : '.$this->serviceStatusLabel((string)$order['status']),
            str_repeat('-', 32),
            '🧺 Layanan',
        ];

        foreach ($items as $item) {
            $qty = rtrim(rtrim(number_format((float) $item['qty'], 2, '.', ''), '0'), '.');
            $lines[] = (string) $item['product_name'];
            $lines[] = $qty.' '.(string) $item['unit'].' x Rp'.number_format((float) $item['price'], 2, ',', '.').' = Rp'.number_format((float) $item['subtotal'], 2, ',', '.');
        }

        $lines[] = str_repeat('-', 32);
        $lines[] = '💰 Subtotal : Rp '.number_format((float) $order['subtotal'], 2, ',', '.');
        $lines[] = '🏷️ Diskon : -Rp '.number_format((float) $order['discount_amount'], 2, ',', '.');
        $lines[] = '💳 Total : Rp '.number_format($roundedTotal, 0, ',', '.');
        $lines[] = str_repeat('-', 32);
        $lines[] = '💵 DP : Rp '.number_format($dpAmount, 2, ',', '.');
        $lines[] = '📌 Sisa Pelunasan : -Rp'.number_format($outstanding, 2, ',', '.');

        $methodLabel = ['CASH' => 'Cash', 'BANK_TRANSFER' => 'Transfer Bank', 'QRIS' => 'QRIS'][$order['payment_method'] ?? ''] ?? (string) ($order['payment_method'] ?? '-');
        $statusLabel = ['UNPAID' => 'Belum Bayar', 'PARTIAL' => 'DP', 'PAID' => 'Lunas'][$order['payment_status'] ?? ''] ?? (string) ($order['payment_status'] ?? '-');

        $lines[] = '📋 Status : '.$statusLabel;
        if (($order['payment_status'] ?? '') !== 'UNPAID') {
            $lines[] = '💳 Metode bayar : '.$methodLabel;
        }

        $settlement = $db->table('ex_order_payments')
            ->select('amount')
            ->where('order_id', $order['id'])
            ->where('payment_type', 'SETTLEMENT')
            ->orderBy('id', 'DESC')
            ->get()->getRowArray();

        if (($order['status'] ?? '') === 'COMPLETED' && (float) ($settlement['amount'] ?? 0) > 0) {
            $lines[] = '💵 Nilai bayar : Rp '.number_format((float) $settlement['amount'], 2, ',', '.');
        }

        $footer = trim((string) ($company['receipt_footer'] ?? 'Terima kasih telah menggunakan layanan kami.'));
        if ($footer !== '') {
            $lines[] = '';
            $lines[] = '⚠️ *PERHATIAN :*';
            $lines[] = $footer;
        }
        $lines[] = '';
        $lines[] = '🔗 Nota online : '.$this->publicNotaUrl($order);

        // Normalisasi terakhir: jangan izinkan formatter/template lain
        // meninggalkan Nota online di tengah atau menduplikasinya.
        $onlineNote = '🔗 Nota online : '.$this->publicNotaUrl($order);
        $lines = array_values(array_filter($lines, static fn ($line) => !str_contains((string) $line, 'Nota online')));
        while ($lines && trim((string) end($lines)) === '') array_pop($lines);
        $lines[] = '';
        $lines[] = $onlineNote;
        return implode("\n", $lines);
    }

    public function whatsappReminder($id = null)
    {
        try {
            $user=$this->user();$db=db_connect();$order=$this->orderQuery($user)->select('o.*,c.name customer_name,c.phone customer_phone')->join('ex_customers c','c.id=o.customer_id','left')->where('o.id',(int)$id)->get()->getRowArray();
            if(!$order)return $this->failMessage('Pesanan tidak ditemukan atau bukan bagian dari cabang Anda.',404);
            if(($order['status']??'')!=='READY')return $this->failMessage('Reminder hanya dapat dikirim untuk pesanan berstatus Selesai.',422);
            if(empty($order['customer_phone']))return $this->failMessage('Pelanggan belum memiliki nomor WhatsApp.',422);
            $company=$db->table('ex_companies')->where('id',$user['company_id'])->get()->getRowArray()?:[];
            if(strtoupper((string)($company['whatsapp_delivery_method']??'APP'))!=='LINKED')return $this->failMessage('Metode pengiriman saat ini adalah aplikasi WhatsApp.',422);
            if(!$db->table('ex_whatsapp_sessions')->where('company_id',$user['company_id'])->where('status','CONNECTED')->where('deleted_at',null)->countAllResults())return $this->failMessage('WhatsApp Linked Device belum terhubung.',422);
            $message="Halo *{$order['customer_name']}* 👋\n\nLaundry Anda dengan nomor order *{$order['invoice_number']}* sudah selesai dan siap diambil. 🧺✨\n\n📦 *Detail Order*\n• No. Order: {$order['invoice_number']}\n• Layanan: {$order['service_name']}\n• Total: Rp ".number_format((float)$order['total'],2,',','.')."\n• Selesai: ".$this->indoDate((string)$order['updated_at'])."\n\nLaundry Anda masih tersimpan di outlet kami dan belum diambil.\n\nSilakan melakukan pengambilan pada jam operasional outlet.\n\n📍 *".($company['company_name']??'Eksis Laundry')."*\n".($company['address']??'');
            $result=(new \App\Services\EksisWhatsAppGatewayService('CUSTOMER'))->sendForCompany(
                (int)$user['company_id'],
                (string)$order['customer_phone'],
                $message
            );
            if(!$result['success'])return $this->failMessage((string)($result['message']??'Reminder WhatsApp gagal dikirim.'),502);
            return $this->ok(['phone'=>$order['customer_phone']],'Reminder WhatsApp berhasil dikirim.');
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }

    public function dashboard()
    {
        $user = $this->user();
        $db = db_connect();
        $company = $db->table('ex_companies')->where('id', $user['company_id'])->get()->getRowArray();
        $orders = $this->orderQuery($user);
        // Kasir bekerja dalam ruang lingkup cabang, bukan pembuat transaksi.
        // Semua user pada cabang yang sama melihat ringkasan operasional yang
        // sama, termasuk transaksi yang dibuat owner untuk cabang tersebut.
        // Owner tetap dapat melihat semua cabang atau memilih satu cabang.
        $branchScopedOrders = $this->orderQuery($user);
        $activeBranchId = $this->scopedBranch($user);
        $activeBranchName = $activeBranchId > 0
            ? (string) ($db->table('ex_branches')->select('name')->where('id', $activeBranchId)->where('company_id', $user['company_id'])->get()->getRow('name') ?? 'Cabang tidak ditemukan')
            : 'Semua Cabang';
        $today = date('Y-m-d');
        $checks = [
            'logo' => !empty($company['logo']),
            'address' => !empty($company['address']),
            'service' => $db->table('ex_products')->where('company_id', $user['company_id'])->where('is_active', 1)->where('deleted_at', null)->countAllResults() > 0,
            'whatsapp' => $db->table('ex_whatsapp_sessions')->where('company_id', $user['company_id'])->where('status', 'CONNECTED')->countAllResults() > 0,
            'receipt' => (clone $orders)->where('status', 'COMPLETED')->countAllResults() > 0,
        ];
        return $this->ok([
            'today_transactions' => (clone $branchScopedOrders)->where('DATE(o.created_at)', $today)->countAllResults(),
            'today_revenue' => (float) ((clone $branchScopedOrders)->selectSum('o.paid_amount')->where('DATE(o.created_at)', $today)->get()->getRow('paid_amount') ?? 0),
            'receivable_total' => (float) ((clone $branchScopedOrders)->selectSum('o.outstanding_amount')->where('o.outstanding_amount >', 0)->where('o.status !=', 'CANCELLED')->get()->getRow('outstanding_amount') ?? 0),
            'receivable_orders' => (clone $branchScopedOrders)->where('o.outstanding_amount >', 0)->where('o.status !=', 'CANCELLED')->countAllResults(),
            'received' => (clone $branchScopedOrders)->where('o.status', 'RECEIVED')->countAllResults(),
            'processing' => (clone $branchScopedOrders)->where('o.status', 'PROCESSING')->countAllResults(),
            'ready' => (clone $branchScopedOrders)->where('o.status', 'READY')->countAllResults(),
            'active_branch_id' => $activeBranchId,
            'active_branch_name' => $activeBranchName,
            'setup' => $checks,
        ]);
    }

    public function create()
    {
        try {
            $sessionUser=$this->user();$license=(new \App\Services\EntitlementService())->current((int)$sessionUser['company_id']);$db=db_connect();$freshUser=$db->table('ex_users u')->select('u.*,b.is_active branch_active')->join('ex_branches b','b.id=u.branch_id','left')->where('u.id',$sessionUser['id'])->where('u.is_active',1)->where('u.deleted_at',null)->get()->getRowArray();if(!$license||$license['status']!=='ACTIVE')return $this->failMessage('Lisensi tidak aktif. Silakan hubungi owner atau perpanjang paket.',403);if(!$freshUser||!(int)$freshUser['branch_active'])return $this->failMessage('Akun atau cabang dinonaktifkan karena paket berlangganan telah berakhir.',403);$dailyLimit=$license['daily_transaction_limit'];if($dailyLimit!==null){$todayCount=$db->table('ex_orders')->where('company_id',$sessionUser['company_id'])->where('DATE(created_at)',date('Y-m-d'))->where('deleted_at',null)->countAllResults();if($todayCount>=(int)$dailyLimit)return $this->failMessage('Batas '.(int)$dailyLimit.' transaksi per hari pada paket '.$license['package_name'].' sudah tercapai.',422);}
            $u=$this->user();$d=$this->json();$db=db_connect();$customer=$db->table('ex_customers')->where('id',(int)($d['customer_id']??0))->where('company_id',$u['company_id'])->where('deleted_at',null)->get()->getRowArray();if(!$customer)return $this->failMessage('Pelanggan wajib dipilih.',422);$itemCount=(int)($d['item_count']??0);if($itemCount<1)return $this->failMessage('Jumlah barang yang diterima wajib diisi minimal 1.',422);$requested=(array)($d['items']??[]);if(!$requested)return $this->failMessage('Minimal satu produk wajib dipilih.',422);$items=[];$subtotal=0;foreach($requested as $item){$product=$db->table('ex_products')->where('id',(int)($item['product_id']??0))->where('company_id',$u['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();if(!$product)return $this->failMessage('Salah satu produk tidak tersedia.',422);$qty=max(.01,(float)($item['qty']??1));$line=$qty*(float)$product['price'];$subtotal+=$line;$items[]=['product'=>$product,'qty'=>$qty,'subtotal'=>$line];}$discount=null;$discountAmount=0;if(!empty($d['discount_id'])){$discount=$db->table('ex_discounts')->where('id',(int)$d['discount_id'])->where('company_id',$u['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();if($discount&&$subtotal>=(float)$discount['min_transaction'])$discountAmount=$discount['type']==='PERCENT'?$subtotal*(float)$discount['value']/100:(float)$discount['value'];}$discountAmount=min($subtotal,$discountAmount);$total=$subtotal-$discountAmount;$method=in_array($d['payment_method']??'',['CASH','BANK_TRANSFER','QRIS'],true)?$d['payment_method']:'CASH';$cash=$method==='CASH'?(float)($d['cash_received']??0):$total;if($cash<$total)return $this->failMessage('Uang diterima kurang dari total transaksi.',422);$days=max(.01,(float)($d['estimated_days']??1));$now=date('Y-m-d H:i:s');$names=implode(', ',array_map(fn($x)=>$x['product']['name'],$items));$branchId=(int)($u['branch_id']??0);if($branchId<1)return $this->failMessage('Pengguna belum terhubung ke cabang aktif.',422);$order=['company_id'=>$u['company_id'],'branch_id'=>$branchId,'customer_id'=>$customer['id'],'invoice_number'=>'ORD-'.date('YmdHis').'-'.random_int(10,99),'status'=>'RECEIVED','service_name'=>$names,'item_count'=>$itemCount,'subtotal'=>$subtotal,'discount_id'=>$discount['id']??null,'discount_amount'=>$discountAmount,'total'=>$total,'paid_amount'=>$total,'payment_method'=>$method,'cash_received'=>$cash,'change_amount'=>$cash-$total,'notes'=>trim((string)($d['notes']??''))?:null,'received_at'=>$now,'due_at'=>date('Y-m-d H:i:s',time()+(int)round($days*86400)),'estimated_days'=>$days,'fulfillment_type'=>in_array($d['fulfillment_type']??'',['DROP_OFF','PICKUP','DELIVERY'],true)?$d['fulfillment_type']:'DROP_OFF','is_priority'=>!empty($d['is_priority'])?1:0,'created_by'=>$u['id'],'created_at'=>$now];$db->transStart();$db->table('ex_orders')->insert($order);$id=(int)$db->insertID();foreach($items as $x)$db->table('ex_order_items')->insert(['order_id'=>$id,'product_id'=>$x['product']['id'],'product_name'=>$x['product']['name'],'unit'=>$x['product']['unit'],'qty'=>$x['qty'],'price'=>$x['product']['price'],'subtotal'=>$x['subtotal'],'created_at'=>$now]);$db->table('ex_order_status_history')->insert(['order_id'=>$id,'status'=>'RECEIVED','changed_by'=>$u['id'],'created_at'=>$now]);$db->transComplete();if(!$db->transStatus())throw new \RuntimeException('Transaksi gagal disimpan.');return $this->ok($order+['id'=>$id,'customer_name'=>$customer['name'],'public_note_url'=>$this->publicNotaUrl($order+['id'=>$id])],'Pesanan berhasil dibuat.',201);
        } catch (\Throwable $e) {
            return $this->failMessage($e->getMessage(), 500);
        }
    }
}
