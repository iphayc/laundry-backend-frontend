<?php
namespace App\Controllers\Api\V1;
class PackageController extends ApiController
{public function index(){return $this->ok(db_connect()->table('ex_packages')->select('id,code,name,type,billing_cycle,price,max_branches,users_per_branch,max_devices,daily_transaction_limit,description')->where('is_active',1)->where('deleted_at',null)->orderBy('sort_order')->get()->getResultArray());}public function show($id=null){$row=db_connect()->table('ex_packages')->where('id',(int)$id)->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();return $row?$this->ok($row):$this->failMessage('Paket tidak ditemukan.',404);}}
