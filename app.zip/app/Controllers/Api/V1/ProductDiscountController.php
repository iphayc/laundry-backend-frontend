<?php
namespace App\Controllers\Api\V1;

class ProductDiscountController extends ApiController
{
    private function branchId(array $user):int{return (int)($user['branch_id']??0);}
    private function effectiveBranchId(array $user):int
    {
        $branchId=$this->branchId($user);$requested=(int)($this->request->getGet('branch_id')??0);
        if(($user['role']??'')==='OWNER'&&$requested>0&&db_connect()->table('ex_branches')->where('id',$requested)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults())return $requested;
        return $branchId;
    }

    public function products()
    {
        $user=$this->user();$db=db_connect();$manage=$this->request->getGet('manage')==='1'&&($user['role']??'')==='OWNER';$branchId=$this->effectiveBranchId($user);
        $query=$db->table('ex_products p')->select('p.*,c.code category_code,c.name category_name,c.unit category_unit')->join('ex_product_categories c','c.id=p.category_id','left')->where('p.company_id',$user['company_id'])->where('p.is_active',1)->where('p.deleted_at',null);
        if(!$manage){
            $query->select('COALESCE(pb.price,p.price) price,COALESCE(pb.is_active,p.is_active) branch_active',false)->join('ex_product_branches pb','pb.product_id=p.id AND pb.branch_id='.$branchId,'left')->where('COALESCE(pb.is_active,p.is_active) = 1',null,false);
        }
        $rows=$query->orderBy('p.name')->get()->getResultArray();
        if($manage)$this->attachProductBranches($db,$rows,(int)$user['company_id']);
        return $this->ok($rows);
    }

    private function attachProductBranches($db,array &$rows,int $companyId):void
    {
        $branches=$db->table('ex_branches')->select('id,name')->where('company_id',$companyId)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        foreach($rows as &$row){$saved=$db->table('ex_product_branches')->where('product_id',$row['id'])->get()->getResultArray();$by=[];foreach($saved as $x)$by[(int)$x['branch_id']]=$x;$row['branch_settings']=array_map(fn($b)=>['branch_id'=>(int)$b['id'],'branch_name'=>$b['name'],'price'=>(float)($by[(int)$b['id']]['price']??$row['price']),'is_active'=>(int)($by[(int)$b['id']]['is_active']??$row['is_active'])],$branches);}unset($row);
    }

    public function saveProduct($id=null)
    {
        try{
            $user=$this->user();$data=$this->json();$db=db_connect();$category=$db->table('ex_product_categories')->where('id',(int)($data['category_id']??0))->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
            if(!$category||trim((string)($data['name']??''))===''||(float)($data['price']??-1)<0)return $this->failMessage('Kategori, nama, dan harga produk wajib valid.',422);
            if($id&&!$db->table('ex_products')->where('id',(int)$id)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults())return $this->failMessage('Produk aktif tidak ditemukan.',404);
            $now=date('Y-m-d H:i:s');$row=['name'=>trim($data['name']),'category'=>in_array($category['code'],['KILOAN','SATUAN','M2'],true)?$category['code']:'SATUAN','category_id'=>$category['id'],'unit'=>$category['unit'],'price'=>(float)$data['price'],'description'=>trim((string)($data['description']??''))?:null,'updated_at'=>$now];
            $db->transStart();
            if($id){$productId=(int)$id;$db->table('ex_products')->where('id',$productId)->update($row);}else{$row+=['company_id'=>$user['company_id'],'is_active'=>1,'created_at'=>$now];$db->table('ex_products')->insert($row);$productId=(int)$db->insertID();}
            $this->saveProductBranches($db,$productId,(int)$user['company_id'],(array)($data['branch_settings']??[]),(float)$row['price'],$now);
            $db->transComplete();if(!$db->transStatus())throw new \RuntimeException('Database gagal menyimpan produk.');
            return $this->ok(['id'=>$productId,'category_name'=>$category['name']]+$row,$id?'Produk berhasil diperbarui.':'Produk berhasil ditambahkan.',$id?200:201);
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }

    private function saveProductBranches($db,int $productId,int $companyId,array $settings,float $defaultPrice,string $now):void
    {
        $provided=[];foreach($settings as $x)$provided[(int)($x['branch_id']??0)]=$x;
        $branches=$db->table('ex_branches')->select('id')->where('company_id',$companyId)->where('deleted_at',null)->get()->getResultArray();
        foreach($branches as $branch){$branchId=(int)$branch['id'];$x=$provided[$branchId]??[];$saved=['price'=>max(0,(float)($x['price']??$defaultPrice)),'is_active'=>array_key_exists('is_active',$x)?(!empty($x['is_active'])?1:0):1,'updated_at'=>$now];$exists=$db->table('ex_product_branches')->where('product_id',$productId)->where('branch_id',$branchId)->countAllResults();if($exists)$db->table('ex_product_branches')->where('product_id',$productId)->where('branch_id',$branchId)->update($saved);else $db->table('ex_product_branches')->insert($saved+['product_id'=>$productId,'branch_id'=>$branchId,'created_at'=>$now]);}
    }

    public function disableProduct($id=null){return $this->disable('ex_products',(int)$id,'Produk');}

    public function discounts()
    {
        $user=$this->user();$db=db_connect();$manage=$this->request->getGet('manage')==='1'&&($user['role']??'')==='OWNER';$branchId=$this->effectiveBranchId($user);
        $query=$db->table('ex_discounts d')->where('d.company_id',$user['company_id'])->where('d.is_active',1)->where('d.deleted_at',null);
        if(!$manage)$query->select('d.*,COALESCE(db.is_active,d.is_active) branch_active',false)->join('ex_discount_branches db','db.discount_id=d.id AND db.branch_id='.$branchId,'left')->where('COALESCE(db.is_active,d.is_active) = 1',null,false);else $query->select('d.*');
        $rows=$query->orderBy('d.id','DESC')->get()->getResultArray();
        if($manage){$branches=$db->table('ex_branches')->select('id,name')->where('company_id',$user['company_id'])->where('deleted_at',null)->orderBy('id')->get()->getResultArray();foreach($rows as &$row){$saved=$db->table('ex_discount_branches')->where('discount_id',$row['id'])->get()->getResultArray();$by=[];foreach($saved as $x)$by[(int)$x['branch_id']]=$x;$row['branch_settings']=array_map(fn($b)=>['branch_id'=>(int)$b['id'],'branch_name'=>$b['name'],'is_active'=>(int)($by[(int)$b['id']]['is_active']??$row['is_active'])],$branches);}unset($row);}
        return $this->ok($rows);
    }

    public function saveDiscount($id=null)
    {
        try{
            $user=$this->user();$data=$this->json();$type=(string)($data['type']??'');$name=trim((string)($data['name']??''));$value=(float)($data['value']??0);
            if($name===''||!in_array($type,['PERCENT','FIXED'],true)||$value<=0||($type==='PERCENT'&&$value>100))return $this->failMessage('Nama, jenis, dan nilai diskon wajib valid.',422);
            $db=db_connect();if($id&&!$db->table('ex_discounts')->where('id',(int)$id)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults())return $this->failMessage('Diskon aktif tidak ditemukan.',404);
            $now=date('Y-m-d H:i:s');$row=['name'=>$name,'type'=>$type,'value'=>$value,'min_transaction'=>max(0,(float)($data['min_transaction']??0)),'starts_at'=>empty($data['starts_at'])?null:$data['starts_at'],'ends_at'=>empty($data['ends_at'])?null:$data['ends_at'],'updated_at'=>$now];
            $db->transStart();if($id){$discountId=(int)$id;$db->table('ex_discounts')->where('id',$discountId)->update($row);}else{$row+=['company_id'=>$user['company_id'],'is_active'=>1,'created_at'=>$now];$db->table('ex_discounts')->insert($row);$discountId=(int)$db->insertID();}
            $provided=[];foreach((array)($data['branch_settings']??[]) as $x)$provided[(int)($x['branch_id']??0)]=$x;$branches=$db->table('ex_branches')->select('id')->where('company_id',$user['company_id'])->where('deleted_at',null)->get()->getResultArray();foreach($branches as $branch){$branchId=(int)$branch['id'];$x=$provided[$branchId]??[];$saved=['is_active'=>array_key_exists('is_active',$x)?(!empty($x['is_active'])?1:0):1,'updated_at'=>$now];$exists=$db->table('ex_discount_branches')->where('discount_id',$discountId)->where('branch_id',$branchId)->countAllResults();if($exists)$db->table('ex_discount_branches')->where('discount_id',$discountId)->where('branch_id',$branchId)->update($saved);else $db->table('ex_discount_branches')->insert($saved+['discount_id'=>$discountId,'branch_id'=>$branchId,'created_at'=>$now]);}
            $db->transComplete();if(!$db->transStatus())throw new \RuntimeException('Database gagal menyimpan diskon.');return $this->ok(['id'=>$discountId]+$row,$id?'Diskon berhasil diperbarui.':'Diskon berhasil ditambahkan.',$id?200:201);
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }

    public function disableDiscount($id=null){return $this->disable('ex_discounts',(int)$id,'Diskon');}
    private function disable(string $table,int $id,string $label){$user=$this->user();$db=db_connect();$row=$db->table($table)->where('id',$id)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();if(!$row)return $this->failMessage($label.' aktif tidak ditemukan.',404);$db->table($table)->where('id',$id)->update(['is_active'=>0,'updated_at'=>date('Y-m-d H:i:s')]);return $this->ok(null,$label.' dinonaktifkan. Histori transaksi tetap tersimpan.');}
}
