<?php
namespace App\Controllers\Api\V1;

class ReceivableOrderController extends ApiController
{
    private function publicNotaUrl(array $order):string
    {
        $token=rtrim(strtr(base64_encode((string)service('encrypter')->encrypt((string)$order['invoice_number'])),'+/','-_'),'=');
        return rtrim(base_url('nota'),'/').'/'.$token;
    }

    public function create()
    {
        try{
            $user=$this->user();$db=db_connect();$license=(new \App\Services\EntitlementService())->current((int)$user['company_id']);
            $fresh=$db->table('ex_users u')->select('u.*,b.is_active branch_active')->join('ex_branches b','b.id=u.branch_id','left')->where('u.id',$user['id'])->where('u.is_active',1)->where('u.deleted_at',null)->get()->getRowArray();
            if(!$license||$license['status']!=='ACTIVE')return $this->failMessage('Lisensi tidak aktif.',403);
            if(!$fresh||!(int)$fresh['branch_active'])return $this->failMessage('Akun atau cabang tidak aktif.',403);
            $branchId=(int)$fresh['branch_id'];$requestedBranch=(int)(($this->json()['branch_id']??0));
            if(($user['role']??'')==='OWNER'&&$requestedBranch>0&&$db->table('ex_branches')->where('id',$requestedBranch)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults())$branchId=$requestedBranch;
            if($license['daily_transaction_limit']!==null&&$db->table('ex_orders')->where('company_id',$user['company_id'])->where('DATE(created_at)',date('Y-m-d'))->where('deleted_at',null)->countAllResults()>=(int)$license['daily_transaction_limit'])return $this->failMessage('Batas transaksi harian paket sudah tercapai.',422);

            $data=$this->json();$customer=$db->table('ex_customers')->where('id',(int)($data['customer_id']??0))->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
            if(!$customer)return $this->failMessage('Pelanggan wajib dipilih.',422);
            $itemCount=(int)($data['item_count']??0);$requested=(array)($data['items']??[]);
            if($itemCount<1||!$requested)return $this->failMessage('Jumlah barang dan minimal satu produk wajib diisi.',422);

            $items=[];$subtotal=0;
            foreach($requested as $requestedItem){
                $product=$db->table('ex_products p')->select('p.*,COALESCE(pb.price,p.price) price',false)->join('ex_product_branches pb','pb.product_id=p.id AND pb.branch_id='.$branchId,'left')->where('p.id',(int)($requestedItem['product_id']??0))->where('p.company_id',$user['company_id'])->where('p.is_active',1)->where('p.deleted_at',null)->where('COALESCE(pb.is_active,p.is_active) = 1',null,false)->get()->getRowArray();
                if(!$product)return $this->failMessage('Salah satu produk tidak tersedia di cabang ini.',422);
                $qty=max(.01,(float)($requestedItem['qty']??1));$line=$qty*(float)$product['price'];$subtotal+=$line;$items[]=['product'=>$product,'qty'=>$qty,'subtotal'=>$line];
            }

            $discount=null;$discountAmount=0;
            if(!empty($data['discount_id'])){
                $discount=$db->table('ex_discounts d')->select('d.*')->join('ex_discount_branches db','db.discount_id=d.id AND db.branch_id='.$branchId,'left')->where('d.id',(int)$data['discount_id'])->where('d.company_id',$user['company_id'])->where('d.is_active',1)->where('d.deleted_at',null)->where('COALESCE(db.is_active,d.is_active) = 1',null,false)->get()->getRowArray();
                if(!$discount)return $this->failMessage('Diskon tidak aktif di cabang ini.',422);
                if($subtotal>=(float)$discount['min_transaction'])$discountAmount=$discount['type']==='PERCENT'?$subtotal*(float)$discount['value']/100:(float)$discount['value'];
            }
            $discountAmount=min($subtotal,$discountAmount);$total=$subtotal-$discountAmount;
            $choice=in_array($data['payment_choice']??'',['UNPAID','DP','FULL'],true)?$data['payment_choice']:'FULL';$method=in_array($data['payment_method']??'',['CASH','BANK_TRANSFER','QRIS'],true)?$data['payment_method']:'CASH';$cash=max(0,(float)($data['cash_received']??0));$paid=$choice==='UNPAID'?0:($choice==='DP'?min($cash,$total):$total);
            if($choice==='DP'&&($cash<=0||$cash>=$total))return $this->failMessage('Nominal DP harus lebih dari 0 dan kurang dari total.',422);
            if($choice==='FULL'&&$cash<$total)return $this->failMessage('Uang diterima kurang dari total.',422);
            $paymentStatus=$paid<=0?'UNPAID':($paid<$total?'PARTIAL':'PAID');$outstanding=$total-$paid;$now=date('Y-m-d H:i:s');$names=implode(', ',array_column(array_column($items,'product'),'name'));$days=max(.01,(float)($data['estimated_days']??1));
            $order=['company_id'=>$user['company_id'],'branch_id'=>$branchId,'customer_id'=>$customer['id'],'invoice_number'=>'ORD-'.date('YmdHis').'-'.random_int(10,99),'status'=>'RECEIVED','service_name'=>$names,'item_count'=>$itemCount,'subtotal'=>$subtotal,'discount_id'=>$discount['id']??null,'discount_amount'=>$discountAmount,'total'=>$total,'paid_amount'=>$paid,'outstanding_amount'=>$outstanding,'payment_method'=>$method,'payment_status'=>$paymentStatus,'cash_received'=>$cash,'change_amount'=>$choice==='FULL'?$cash-$total:0,'notes'=>trim((string)($data['notes']??''))?:null,'received_at'=>$now,'due_at'=>date('Y-m-d H:i:s',time()+(int)round($days*86400)),'estimated_days'=>$days,'fulfillment_type'=>in_array($data['fulfillment_type']??'',['DROP_OFF','PICKUP','DELIVERY'],true)?$data['fulfillment_type']:'DROP_OFF','is_priority'=>!empty($data['is_priority'])?1:0,'created_by'=>$user['id'],'created_at'=>$now];
            $db->transStart();$db->table('ex_orders')->insert($order);$id=(int)$db->insertID();
            foreach($items as $item)$db->table('ex_order_items')->insert(['order_id'=>$id,'product_id'=>$item['product']['id'],'product_name'=>$item['product']['name'],'unit'=>$item['product']['unit'],'qty'=>$item['qty'],'price'=>$item['product']['price'],'subtotal'=>$item['subtotal'],'created_at'=>$now]);
            if($paid>0)$db->table('ex_order_payments')->insert(['order_id'=>$id,'company_id'=>$user['company_id'],'branch_id'=>$branchId,'payment_type'=>$choice==='DP'?'DP':'INITIAL','method'=>$method,'amount'=>$paid,'cash_received'=>$cash,'change_amount'=>$choice==='FULL'?$cash-$total:0,'created_by'=>$user['id'],'created_at'=>$now]);
            $db->table('ex_order_status_history')->insert(['order_id'=>$id,'status'=>'RECEIVED','notes'=>$paymentStatus==='PAID'?'Lunas':($paymentStatus==='PARTIAL'?'DP, sisa piutang Rp '.number_format($outstanding,2,',','.'):'Belum bayar'),'changed_by'=>$user['id'],'created_at'=>$now]);$db->transComplete();
            if(!$db->transStatus())throw new \RuntimeException('Pesanan gagal disimpan.');
            return $this->ok($order+['id'=>$id,'customer_name'=>$customer['name'],'customer_phone'=>$customer['phone'],'customer_email'=>$customer['email'],'public_note_url'=>$this->publicNotaUrl($order+['id'=>$id])],'Pesanan berhasil dibuat.',201);
        }catch(\Throwable $e){return $this->failMessage($e->getMessage(),500);}
    }
}
