<?php
namespace App\Controllers\Api\V1;
class UserPhotoController extends ApiController
{
 public function show($id=null){
  $u=$this->user();$row=db_connect()->table('ex_users')->select('id,fullname,email,phone,role,photo')->where('id',$u['id'])->where('company_id',$u['company_id'])->where('deleted_at',null)->get()->getRowArray();
  if(!$row)return $this->failMessage('Profil pengguna tidak ditemukan.',404);$row['photo_url']=$row['photo']?base_url($row['photo']):null;return $this->ok($row);
 }
 public function self(){return $this->store((int)$this->user()['id'],false);}
 public function managed($id=null){return $this->store((int)$id,true);}
 private function store(int $id,bool $managed){
  try{$u=$this->user();if($managed&&($u['role']??'')!=='OWNER')return $this->failMessage('Hanya owner yang dapat mengganti foto pengguna.',403);
   $db=db_connect();$targetUser=$db->table('ex_users')->select('id,photo,role')->where('id',$id)->where('company_id',$u['company_id'])->where('deleted_at',null)->get()->getRowArray();if(!$targetUser)return $this->failMessage('Pengguna tidak ditemukan.',404);
   $file=$this->request->getFile('photo');if(!$file||!$file->isValid())return $this->failMessage('Foto wajib dipilih.',422);if($file->getSize()>2*1024*1024||!in_array($file->getMimeType(),['image/jpeg','image/png','image/webp'],true))return $this->failMessage('Foto harus JPG, PNG, atau WebP maksimal 2 MB.',422);
   $folder='uploads/users/'.$u['company_id'];$directory=FCPATH.$folder;if(!is_dir($directory)&&!mkdir($directory,0775,true)&&!is_dir($directory))throw new \RuntimeException('Folder foto tidak dapat dibuat.');$name=$file->getRandomName();$file->move($directory,$name);$path=$folder.'/'.$name;$db->table('ex_users')->where('id',$id)->update(['photo'=>$path,'updated_at'=>date('Y-m-d H:i:s')]);$old=$targetUser['photo'];if($old&&$old!==$path&&str_starts_with($old,'uploads/users/')&&is_file(FCPATH.$old))@unlink(FCPATH.$old);
   return $this->ok(['user_id'=>$id,'photo'=>$path,'photo_url'=>base_url($path)],'Foto profil berhasil diperbarui.');
  }catch(\Throwable $e){log_message('error','User photo: '.$e->getMessage());return $this->failMessage('Foto profil gagal disimpan.',500);}
 }
}
