<?php
namespace App\Controllers\Api\V1;
class VoucherController extends ApiController
{public function validateCode(){try{$u=$this->user();$d=$this->json();$package=db_connect()->table('ex_packages')->where('id',(int)($d['package_id']??0))->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();if(!$package)return $this->failMessage('Paket tidak ditemukan.',404);$result=(new \App\Services\VoucherService())->validate((string)($d['voucher_code']??''),(int)$u['company_id'],(float)$package['price']);return $this->ok($result,'Voucher valid dan dapat digunakan.');}catch(\InvalidArgumentException $e){return $this->failMessage($e->getMessage(),422);}}
}
