<?php
namespace App\Controllers\Api;

class VisitorsApi extends SecuredApiController
{
    protected $modelName = 'App\Models\VisitorModel';
    protected $format = 'json';
    private const WRITABLE_FIELDS = [
        'resident_id', 'identity_type', 'identity_no', 'name', 'phone',
        'identity_image', 'blacklist', 'blacklist_note',
    ];

    public function index()
    {
        if ($response = $this->requireApiKey()) return $response;
        return $this->respond($this->model->orderBy('id', 'DESC')->findAll(500));
    }

    public function show($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        $row = ctype_digit((string) $id) ? $this->model->find((int) $id) : null;
        return $row ? $this->respond($row) : $this->failNotFound('Tamu tidak ditemukan.');
    }

    public function create()
    {
        if ($response = $this->requireApiKey()) return $response;
        $data = $this->payload(self::WRITABLE_FIELDS);
        if ($errors = $this->payloadErrors()) return $this->failValidationErrors($errors);
        if ($errors = $this->validatePayload($data)) return $this->failValidationErrors($errors);
        $id = $this->model->insert($data, true);
        return $id ? $this->respondCreated(['id' => $id]) : $this->failValidationErrors($this->model->errors());
    }

    public function update($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        if (! ctype_digit((string) $id) || ! $this->model->find((int) $id)) {
            return $this->failNotFound('Tamu tidak ditemukan.');
        }
        $data = $this->payload(self::WRITABLE_FIELDS);
        if ($errors = $this->payloadErrors()) return $this->failValidationErrors($errors);
        if ($errors = $this->validatePayload($data, true)) return $this->failValidationErrors($errors);
        return $this->model->update((int) $id, $data)
            ? $this->respond(['success' => true])
            : $this->failValidationErrors($this->model->errors());
    }

    public function delete($id = null)
    {
        if ($response = $this->requireApiKey()) return $response;
        if (! ctype_digit((string) $id) || ! $this->model->find((int) $id)) {
            return $this->failNotFound('Tamu tidak ditemukan.');
        }
        return $this->model->delete((int) $id)
            ? $this->respondDeleted(['success' => true])
            : $this->failServerError('Tamu gagal diarsipkan.');
    }

    private function validatePayload(array $data, bool $partial = false): array
    {
        if ($data === []) return ['payload' => 'Tidak ada field yang dapat diproses.'];
        $rules = [
            'resident_id' => 'permit_empty|is_natural_no_zero',
            'identity_type' => 'required|in_list[KTP,SIM,PASSPORT]',
            'identity_no' => 'permit_empty|max_length[50]',
            'name' => 'required|min_length[2]|max_length[120]',
            'phone' => 'permit_empty|max_length[30]',
            'identity_image' => 'permit_empty|max_length[255]',
            'blacklist' => 'permit_empty|in_list[0,1]',
            'blacklist_note' => 'permit_empty|max_length[2000]',
        ];
        if ($partial) $rules = array_intersect_key($rules, $data);
        $validation = service('validation');
        $validation->reset()->setRules($rules);
        if (! $validation->run($data)) return $validation->getErrors();
        if (! empty($data['resident_id']) && ! db_connect()->table('residents')->where('id', (int) $data['resident_id'])->where('deleted_at', null)->countAllResults()) {
            return ['resident_id' => 'Penghuni tujuan tidak ditemukan.'];
        }
        return [];
    }
}
