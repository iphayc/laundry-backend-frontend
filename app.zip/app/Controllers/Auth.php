<?php
namespace App\Controllers;

use App\Models\UserModel;
use App\Services\PasswordPolicy;

class Auth extends BaseController
{
    private const DUMMY_PASSWORD_HASH = '$2y$10$RUPw7l1VvdAUDdtsNY5.AOvpQ02.51uYc4ycwSnLh/H7cyxruqSqu';

    public function login()
    {
        if(session('user_id')) return redirect()->to('/dashboard');
        if($this->request->getMethod()==='POST'){
            $username=trim((string)$this->request->getPost('username'));
            $password=(string)$this->request->getPost('password');
            $ip=$this->request->getIPAddress();
            $throttler=service('throttler');
            $identityKey='login_identity_'.hash('sha256',strtolower($username).'|'.$ip);
            $ipKey='login_ip_'.hash('sha256',$ip);
            if(!$throttler->check($identityKey,5,60)||!$throttler->check($ipKey,30,300)){
                log_message('warning','Login throttled for IP hash '.substr(hash('sha256',$ip),0,16));
                session()->setFlashdata('warning','Terlalu banyak percobaan login. Tunggu 60 detik lalu coba kembali.');
                return service('response')->setStatusCode(429)->setHeader('Retry-After','60')->setBody(view('auth/login'));
            }
            $user=(new UserModel())->where('username',$username)->where('active',1)->first();
            $hash=(string)($user['password_hash']??self::DUMMY_PASSWORD_HASH);
            $passwordValid=password_verify($password,$hash);
            if($user && $passwordValid){
                session()->regenerate(true); session()->set(['user_id'=>$user['id'],'user_name'=>$user['name'],'role_id'=>$user['role_id']]);
                (new UserModel())->update($user['id'],['last_login'=>date('Y-m-d H:i:s')]);
                return redirect()->to('/dashboard');
            }
            log_message('notice','Login failed for identity hash '.substr(hash('sha256',strtolower($username)),0,16).' from IP hash '.substr(hash('sha256',$ip),0,16));
            return redirect()->back()->with('error','Username atau password salah.');
        }
        return view('auth/login');
    }
    public function logout(){session()->destroy();return redirect()->to('/aEZGxhfPkA');}
    public function changePassword()
    {
        if($this->request->getMethod()==='POST'){
            $model=new UserModel();$user=$model->find(session('user_id'));
            if(!password_verify((string)$this->request->getPost('current_password'),$user['password_hash'])) return redirect()->back()->with('error','Password lama salah.');
            $password=(string)$this->request->getPost('password');
            if($error=(new PasswordPolicy())->validate($password))return redirect()->back()->with('error',$error);
            if($password!==$this->request->getPost('password_confirm')) return redirect()->back()->with('error','Konfirmasi password harus sama.');
            $model->update($user['id'],['password_hash'=>password_hash($password,PASSWORD_DEFAULT)]);
            return redirect()->to('/dashboard')->with('success','Password berhasil diubah.');
        }
        return view('auth/change_password',['title'=>'Ganti Password']);
    }
}
