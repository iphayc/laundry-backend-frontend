<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 *
 * Extend this class in any new controllers:
 * ```
 *     class Home extends BaseController
 * ```
 *
 * For security, be sure to declare any new methods as protected or private.
 */
abstract class BaseController extends Controller
{
    protected $helpers = ['form'];
    protected array $sidebarMenus = [];
    protected array $accountUser = [];
    protected array $companyProfile = [];
    /**
     * Be sure to declare properties for any property fetch you initialized.
     * The creation of dynamic property is deprecated in PHP 8.2.
     */

    // protected $session;

    /**
     * @return void
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Load here all helpers you want to be available in your controllers that extend BaseController.
        // Caution: Do not put the this below the parent::initController() call below.
        // $this->helpers = ['form', 'url'];

        // Caution: Do not edit this line.
        parent::initController($request, $response, $logger);

        try {
            $db = db_connect();
            if ($db->tableExists('companies')) {
                $this->companyProfile = $db->table('companies')
                    ->where('active', 1)
                    ->where('deleted_at', null)
                    ->orderBy('id', 'DESC')
                    ->get()
                    ->getRowArray() ?? [];
            }
        } catch (\Throwable $e) {
            log_message('error', 'Company profile: ' . $e->getMessage());
        }
        service('renderer')->setVar('companyProfile', $this->companyProfile);

        if (session('role_id')) {
            try {
                $this->sidebarMenus=(new \App\Models\MenuModel())->forRole((int)session('role_id'));
                service('renderer')->setVar('sidebarMenus',$this->sidebarMenus);
                $pendingPayments=(int)db_connect()->table('ex_payments')->where('status','WAITING')->where('deleted_at',null)->countAllResults();
                service('renderer')->setVar('sidebarBadges',['platform/payments'=>$pendingPayments]);
                $this->accountUser=db_connect()->table('users u')->select('u.id,u.username,u.name,u.email,u.phone,r.name role_name')->join('roles r','r.id=u.role_id')->where('u.id',(int)session('user_id'))->where('u.deleted_at',null)->get()->getRowArray()??[];
                service('renderer')->setVar('accountUser',$this->accountUser);
            } catch (\Throwable $e) {
                log_message('error','Dynamic menu: '.$e->getMessage());
            }
        }

        // Preload any models, libraries, etc, here.
        // $this->session = service('session');
    }
}
