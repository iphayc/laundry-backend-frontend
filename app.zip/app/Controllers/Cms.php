<?php
namespace App\Controllers;

class Cms extends BaseController
{
    private array $configs=[
        'sliders'=>['title'=>'Slider Homepage','table'=>'cms_sliders','fields'=>['title'=>'Judul','subtitle'=>'Subjudul','button_text'=>'Teks Tombol','button_url'=>'URL Tombol','sort_order'=>'Urutan','active'=>'Aktif'],'image'=>true],
        'news'=>['title'=>'Berita','table'=>'cms_posts','type'=>'news','fields'=>['title'=>'Judul','summary'=>'Ringkasan','content'=>'Isi Berita','published_at'=>'Tanggal Publikasi','active'=>'Aktif'],'image'=>true],
        'announcements'=>['title'=>'Pengumuman & Promo','table'=>'cms_posts','type'=>'announcement','fields'=>['type'=>'Jenis','title'=>'Judul','summary'=>'Ringkasan','content'=>'Isi','published_at'=>'Tanggal Publikasi','active'=>'Aktif'],'image'=>true],
        'awards'=>['title'=>'Penghargaan','table'=>'cms_awards','fields'=>['title'=>'Nama Penghargaan','recipient'=>'Penerima','level'=>'Tingkat','award_date'=>'Tanggal','description'=>'Deskripsi','sort_order'=>'Urutan','active'=>'Aktif'],'image'=>true],
        'university-acceptances'=>['title'=>'Siswa Lolos PTN','table'=>'cms_university_acceptances','fields'=>['student_id'=>'Siswa','university_name'=>'Universitas','study_program'=>'Program Studi','admission_year'=>'Tahun Diterima','description'=>'Keterangan','sort_order'=>'Urutan','active'=>'Aktif']],
    ];
    private function cfg(string $module):array{if(!isset($this->configs[$module]))throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();return $this->configs[$module];}
    public function index(string $module){$c=$this->cfg($module);$b=db_connect()->table($c['table'].' x')->select('x.*');if($module==='university-acceptances')$b->select('s.full_name student_name,s.photo_path')->join('students s','s.id=x.student_id');if(isset($c['type']))$b->where('x.type',$c['type']);$rows=$b->where('x.deleted_at',null)->orderBy(isset($c['fields']['sort_order'])?'x.sort_order':'x.id','DESC')->get()->getResultArray();return view('cms/index',['title'=>$c['title'],'module'=>$module,'config'=>$c,'rows'=>$rows]);}
    public function form(string $module,?int $id=null){$c=$this->cfg($module);$row=$id?db_connect()->table($c['table'])->where('id',$id)->where('deleted_at',null)->get()->getRowArray():[];if($id&&!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Konten tidak ditemukan.');$students=$module==='university-acceptances'?db_connect()->table('students')->select('id,full_name,student_no,photo_path')->where('active',1)->where('deleted_at',null)->orderBy('full_name')->get()->getResultArray():[];return view('cms/form',['title'=>($id?'Edit ':'Tambah ').$c['title'],'module'=>$module,'config'=>$c,'row'=>$row,'students'=>$students]);}
    public function save(string $module)
    {
        $c=$this->cfg($module);$id=(int)$this->request->getPost('id');$data=[];foreach(array_keys($c['fields']) as $field)$data[$field]=$this->request->getPost($field)===''?null:$this->request->getPost($field);
        if(isset($c['type']))$data['type']=$module==='announcements'&&in_array($data['type']??'', ['announcement','promo'],true)?$data['type']:$c['type'];
        if(isset($data['active']))$data['active']=(int)$data['active'];if(isset($data['sort_order']))$data['sort_order']=(int)$data['sort_order'];
        if(empty($data['title'])&&$module!=='university-acceptances')return redirect()->back()->withInput()->with('error','Judul wajib diisi.');
        if($module==='university-acceptances'&&(empty($data['student_id'])||empty($data['university_name'])||empty($data['admission_year'])))return redirect()->back()->withInput()->with('error','Siswa, universitas, dan tahun diterima wajib diisi.');
        if(isset($c['type'])){$base=url_title((string)$data['title'],'-',true)?:'berita';$slug=$base;$n=1;$check=db_connect()->table('cms_posts')->where('slug',$slug);if($id)$check->where('id !=',$id);while($check->countAllResults()){$slug=$base.'-'.(++$n);$check=db_connect()->table('cms_posts')->where('slug',$slug);if($id)$check->where('id !=',$id);}$data['slug']=$slug;$data['created_by']=(int)session('user_id');}
        if(!empty($c['image'])){$file=$this->request->getFile('image');if($file&&$file->isValid()&&!$file->hasMoved()){$allowed=['image/jpeg','image/png','image/webp'];if(!in_array($file->getMimeType(),$allowed,true)||$file->getSize()>5*1024*1024)return redirect()->back()->withInput()->with('error','Gambar harus JPG, PNG, atau WebP maksimal 5 MB.');$dir=FCPATH.'uploads'.DIRECTORY_SEPARATOR.'cms'.DIRECTORY_SEPARATOR.$module;if(!is_dir($dir))mkdir($dir,0775,true);$name=$file->getRandomName();$file->move($dir,$name);$data['image_path']='uploads/cms/'.$module.'/'.$name;}elseif(!$id&&$module==='sliders')return redirect()->back()->withInput()->with('error','Gambar slider wajib diisi.');}
        $data['updated_at']=date('Y-m-d H:i:s');if(!$id)$data['created_at']=$data['updated_at'];$ok=$id?db_connect()->table($c['table'])->where('id',$id)->update($data):db_connect()->table($c['table'])->insert($data);return redirect()->to('/cms/'.$module)->with($ok?'success':'error',$ok?'Konten berhasil disimpan.':'Konten gagal disimpan.');
    }
    public function delete(string $module,int $id){$c=$this->cfg($module);$ok=db_connect()->table($c['table'])->where('id',$id)->update(['active'=>0,'deleted_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);return redirect()->back()->with($ok?'success':'error',$ok?'Konten dipindahkan ke arsip.':'Konten gagal diarsipkan.');}
}
