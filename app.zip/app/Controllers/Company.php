<?php
namespace App\Controllers;

use App\Models\CompanyModel;

class Company extends BaseController
{
    public function index()
    {
        $model=new CompanyModel();$company=$model->where('active',1)->orderBy('id','DESC')->first()??[];
        if($this->request->getMethod()==='POST'){
            $data=[
                'residence_name'=>trim((string)$this->request->getPost('residence_name')),
                'address'=>trim((string)$this->request->getPost('address'))?:null,
                'phone'=>trim((string)$this->request->getPost('phone'))?:null,
                'developer'=>trim((string)$this->request->getPost('developer'))?:null,
                'email'=>trim((string)$this->request->getPost('email'))?:null,
                'maps_location'=>trim((string)$this->request->getPost('maps_location'))?:null,
                'active'=>1,
            ];
            if($data['residence_name']==='')return redirect()->back()->withInput()->with('error','Nama perumahan wajib diisi.');
            if($data['email']&&!filter_var($data['email'],FILTER_VALIDATE_EMAIL))return redirect()->back()->withInput()->with('error','Alamat email tidak valid.');
            foreach(['photo','logo'] as $field){
                $file=$this->request->getFile($field);
                if($file&&$file->isValid()&&!$file->hasMoved()){
                    if($file->getSize()>2*1024*1024)return redirect()->back()->withInput()->with('error',ucfirst($field).' maksimal 2 MB.');
                    if(!in_array($file->getMimeType(),['image/jpeg','image/png','image/webp'],true))return redirect()->back()->withInput()->with('error',ucfirst($field).' harus JPG, PNG, atau WebP.');
                    $target=FCPATH.'uploads'.DIRECTORY_SEPARATOR.'company';
                    if(!is_dir($target))mkdir($target,0775,true);
                    $name=$file->getRandomName();$file->move($target,$name);$data[$field]='uploads/company/'.$name;
                }
            }
            try {
                $saved=$company?$model->update($company['id'],$data):$model->insert($data);
                if(!$saved)return redirect()->back()->withInput()->with('error','Data company/perumahan gagal disimpan.');
            } catch (\Throwable $e) {
                log_message('error','Company save: '.$e->getMessage());
                return redirect()->back()->withInput()->with('error','Terjadi error saat menyimpan company/perumahan.');
            }
            db_connect()->table('audit_logs')->insert(['user_id'=>session('user_id'),'action'=>'UPDATE_COMPANY','table_name'=>'companies','record_id'=>(string)($company['id']??$model->getInsertID()),'ip_address'=>$this->request->getIPAddress(),'created_at'=>date('Y-m-d H:i:s')]);
            return redirect()->to('/master/company')->with('success','Data company/perumahan berhasil disimpan.');
        }
        return view('company/form',['title'=>'Master Company / Perumahan','company'=>$company]);
    }
}
