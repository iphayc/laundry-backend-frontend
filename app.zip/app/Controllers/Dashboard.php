<?php
namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $service = new \App\Services\PlatformAdminService();
        return view('dashboard/index', ['title' => 'Dashboard'] + $service->dashboard());
    }
}
