<?php
namespace App\Controllers;

use App\Models\RfidDeviceModel;

class Devices extends BaseController
{
    public function index()
    {
        $rows=db_connect()->table('rfid_devices d')
            ->select("d.*,COALESCE(GROUP_CONCAT(g.name ORDER BY g.name SEPARATOR ', '),'-') gate_names")
            ->join('gate_devices gd','gd.device_id=d.id','left')
            ->join('gates g','g.id=gd.gate_id AND g.deleted_at IS NULL','left')
            ->where('d.deleted_at',null)->groupBy('d.id')->orderBy('d.name')->get()->getResultArray();
        return view('devices/index',['title'=>'Master Device RFID','rows'=>$rows]);
    }

    public function form(?int $id=null)
    {
        helper('form');
        $db=db_connect();$device=$id?(new RfidDeviceModel())->find($id):[];
        if($id&&!$device)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Device tidak ditemukan.');
        $gates=$db->table('gates')->select('id,name,direction')->where('active',1)->where('deleted_at',null)->orderBy('name')->get()->getResultArray();
        $selected=$id?array_map('intval',array_column($db->table('gate_devices')->select('gate_id')->where('device_id',$id)->get()->getResultArray(),'gate_id')):[];
        return view('devices/form',['title'=>($id?'Edit ':'Tambah ').'Device RFID','device'=>$device,'gates'=>$gates,'selectedGates'=>$selected]);
    }

    public function save()
    {
        $id=(int)$this->request->getPost('id');$code=strtoupper(trim((string)$this->request->getPost('code')));
        $name=trim((string)$this->request->getPost('name'));$gateIds=array_values(array_unique(array_map('intval',(array)$this->request->getPost('gate_ids'))));
        if($code===''||$name==='')return redirect()->back()->withInput()->with('error','Kode dan nama perangkat wajib diisi.');
        $duplicate=db_connect()->table('rfid_devices')->where('code',$code)->where('deleted_at',null);if($id)$duplicate->where('id !=',$id);
        if($duplicate->countAllResults()>0)return redirect()->back()->withInput()->with('error','Kode perangkat sudah digunakan.');
        $apiUrl=trim((string)$this->request->getPost('api_url'));if($apiUrl!==''&&!filter_var($apiUrl,FILTER_VALIDATE_URL))return redirect()->back()->withInput()->with('error','API URL tidak valid.');
        $data=['code'=>$code,'name'=>$name,'device_type'=>$this->request->getPost('device_type'),'brand'=>trim((string)$this->request->getPost('brand'))?:null,'model'=>trim((string)$this->request->getPost('model'))?:null,'serial_number'=>trim((string)$this->request->getPost('serial_number'))?:null,'ip_address'=>trim((string)$this->request->getPost('ip_address'))?:null,'port'=>$this->request->getPost('port')!==''?(int)$this->request->getPost('port'):null,'api_url'=>$apiUrl?:null,'connection_mode'=>$this->request->getPost('connection_mode'),'connection_status'=>$this->request->getPost('connection_status'),'last_online_at'=>$this->request->getPost('last_online_at')?:null,'active'=>(int)$this->request->getPost('active'),'remark'=>trim((string)$this->request->getPost('remark'))?:null];
        $apiKey=(string)$this->request->getPost('api_key');if($apiKey!=='')$data['api_key_encrypted']=base64_encode(service('encrypter')->encrypt($apiKey));
        $db=db_connect();$model=new RfidDeviceModel();
        try{
            $db->transStart();$saved=$id?$model->update($id,$data):$model->insert($data);$deviceId=$id?:$model->getInsertID();
            if(!$saved)throw new \RuntimeException('Device gagal disimpan.');
            $db->table('gate_devices')->where('device_id',$deviceId)->delete();
            foreach($gateIds as $gateId)$db->table('gate_devices')->insert(['gate_id'=>$gateId,'device_id'=>$deviceId,'created_at'=>date('Y-m-d H:i:s')]);
            $db->transComplete();if(!$db->transStatus())throw new \RuntimeException('Transaksi database gagal.');
            return redirect()->to('/master/devices')->with('success',$id?'Device berhasil diperbarui.':'Device berhasil disimpan.');
        }catch(\Throwable $e){log_message('error','Device save: '.$e->getMessage());return redirect()->back()->withInput()->with('error','Terjadi error saat menyimpan device.');}
    }

    public function delete(int $id)
    {
        try{
            if(!(new RfidDeviceModel())->delete($id))return redirect()->back()->with('error','Device gagal diarsipkan.');
            return redirect()->back()->with('success','Device dipindahkan ke arsip (soft delete).');
        }catch(\Throwable $e){log_message('error','Device delete: '.$e->getMessage());return redirect()->back()->with('error','Terjadi error saat mengarsipkan device.');}
    }
}
