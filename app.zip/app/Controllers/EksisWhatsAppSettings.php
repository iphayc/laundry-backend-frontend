<?php

namespace App\Controllers;

use App\Services\EksisWhatsAppGatewayService;

class EksisWhatsAppSettings extends BaseController
{
    private const ADMIN_SESSION_KEY = 'ADMIN-WA-1';

    public function index()
    {
        $profile = strtoupper((string) ($this->request->getPost('profile') ?: 'ADMIN'));
        if (!in_array($profile, ['ADMIN', 'CUSTOMER'], true)) {
            $profile = 'ADMIN';
        }

        $service = new EksisWhatsAppGatewayService($profile);
        $adminConnection = $this->readAdminStatus();
        $adminQr = null;
        $adminMessage = null;
        $adminError = null;

        if ($this->request->getMethod() === 'POST') {
            $input = $this->request->getPost();
            $action = (string) ($input['action'] ?? 'save');

            try {
                if ($profile === 'ADMIN' && $action === 'connect-admin') {
                    $result = (new EksisWhatsAppGatewayService('ADMIN'))
                        ->connect(self::ADMIN_SESSION_KEY);

                    if (!$result['success']) {
                        throw new \RuntimeException(
                            $result['message'] ?? 'QR WhatsApp Admin tidak dapat dibuat.'
                        );
                    }

                    $data = is_array($result['data'] ?? null) ? $result['data'] : [];
                    $adminQr = $this->extractQr($data);
                    $adminConnection = $this->normalizeAdminStatus($data, true);
                    $this->syncAdminPhone($adminConnection['phone']);

                    $adminMessage = $adminQr
                        ? 'QR WhatsApp Admin siap. Scan menggunakan WhatsApp di HP Admin.'
                        : ($adminConnection['connected']
                            ? 'WhatsApp Admin sudah terhubung.'
                            : 'Status WhatsApp Admin berhasil diperbarui.');

                    return view('settings/eksis_whatsapp', [
                        'title' => 'Konfigurasi WhatsApp Gateway',
                        'admin' => (new EksisWhatsAppGatewayService('ADMIN'))->config(),
                        'customer' => (new EksisWhatsAppGatewayService('CUSTOMER'))->config(),
                        'adminConnection' => $adminConnection,
                        'adminQr' => $adminQr,
                        'adminMessage' => $adminMessage,
                        'adminError' => null,
                    ]);
                }

                if ($profile === 'ADMIN' && $action === 'logout-admin') {
                    $result = (new EksisWhatsAppGatewayService('ADMIN'))
                        ->logout(self::ADMIN_SESSION_KEY);

                    if (!$result['success']) {
                        throw new \RuntimeException(
                            $result['message'] ?? 'WhatsApp Admin tidak dapat dikeluarkan.'
                        );
                    }

                    $this->syncAdminPhone(null);

                    return redirect()->to('/settings/eksis-whatsapp')
                        ->with('success', 'WhatsApp Admin berhasil logout.');
                }

                $service->save($input);

                if ($action === 'test') {
                    $phone = (string) ($input['phone_number'] ?? '');
                    if ($profile === 'ADMIN' && $phone === '') {
                        $phone = (string) (($service->config()['phone_number'] ?? ''));
                    }

                    if ($phone === '') {
                        throw new \RuntimeException(
                            'Nomor WhatsApp Admin belum terhubung. Hubungkan WhatsApp Admin terlebih dahulu.'
                        );
                    }

                    $result = $service->send(
                        $phone,
                        'Pesan uji WhatsApp Gateway Eksis Laundry profil '.$profile.' berhasil dikirim.',
                        true
                    );

                    if (!$result['success']) {
                        throw new \RuntimeException(
                            'Pesan uji gagal dikirim. Status gateway: '.($result['status'] ?? '-')
                        );
                    }

                    return redirect()->to('/settings/eksis-whatsapp')
                        ->with('success', 'Konfigurasi tersimpan dan pesan uji berhasil dikirim.');
                }

                return redirect()->to('/settings/eksis-whatsapp')
                    ->with('success', 'Konfigurasi WhatsApp Gateway berhasil disimpan.');
            } catch (\Throwable $e) {
                log_message('error', 'Eksis WhatsApp settings: '.$e->getMessage());

                if ($profile === 'ADMIN' && in_array($action, ['connect-admin', 'logout-admin'], true)) {
                    $adminError = $e->getMessage();

                    return view('settings/eksis_whatsapp', [
                        'title' => 'Konfigurasi WhatsApp Gateway',
                        'admin' => (new EksisWhatsAppGatewayService('ADMIN'))->config(),
                        'customer' => (new EksisWhatsAppGatewayService('CUSTOMER'))->config(),
                        'adminConnection' => $adminConnection,
                        'adminQr' => $adminQr,
                        'adminMessage' => $adminMessage,
                        'adminError' => $adminError,
                    ]);
                }

                return redirect()->back()->withInput()->with('error', $e->getMessage());
            }
        }

        return view('settings/eksis_whatsapp', [
            'title' => 'Konfigurasi WhatsApp Gateway',
            'admin' => (new EksisWhatsAppGatewayService('ADMIN'))->config(),
            'customer' => (new EksisWhatsAppGatewayService('CUSTOMER'))->config(),
            'adminConnection' => $adminConnection,
            'adminQr' => $adminQr,
            'adminMessage' => $adminMessage,
            'adminError' => $adminError,
        ]);
    }

    /**
     * Endpoint polling status WhatsApp Admin.
     */
    public function adminStatus()
    {
        try {
            $result = (new EksisWhatsAppGatewayService('ADMIN'))
                ->status(self::ADMIN_SESSION_KEY);

            if (!$result['success']) {
                return $this->response
                    ->setStatusCode(502)
                    ->setJSON([
                        'success' => false,
                        'message' => $result['message'] ?? 'Gateway WhatsApp Admin tidak dapat dihubungi.',
                    ]);
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $state = $this->normalizeAdminStatus($data, false);

            $this->syncAdminPhone($state['phone']);

            return $this->response->setJSON([
                'success' => true,
                'connection' => $state['connection'],
                'connected' => $state['connected'],
                'phone' => $state['phone'],
                'session_key' => self::ADMIN_SESSION_KEY,
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'WhatsApp Admin status: '.$e->getMessage());

            return $this->response
                ->setStatusCode(502)
                ->setJSON([
                    'success' => false,
                    'message' => $e->getMessage(),
                ]);
        }
    }

    /**
     * Endpoint QR WhatsApp Admin untuk refresh tanpa mengekspos API key.
     */
    public function adminQr()
    {
        try {
            $result = (new EksisWhatsAppGatewayService('ADMIN'))
                ->qr(self::ADMIN_SESSION_KEY);

            if (!$result['success']) {
                return $this->response
                    ->setStatusCode(502)
                    ->setJSON([
                        'success' => false,
                        'message' => $result['message'] ?? 'QR WhatsApp Admin tidak tersedia.',
                    ]);
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $qr = $this->extractQr($data);
            $state = $this->normalizeAdminStatus($data, true);

            $this->syncAdminPhone($state['phone']);

            return $this->response->setJSON([
                'success' => true,
                'qr' => $qr,
                'connection' => $state['connection'],
                'connected' => $state['connected'],
                'phone' => $state['phone'],
                'session_key' => self::ADMIN_SESSION_KEY,
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'WhatsApp Admin QR: '.$e->getMessage());

            return $this->response
                ->setStatusCode(502)
                ->setJSON([
                    'success' => false,
                    'message' => $e->getMessage(),
                ]);
        }
    }

    private function readAdminStatus(): array
    {
        try {
            $result = (new EksisWhatsAppGatewayService('ADMIN'))
                ->status(self::ADMIN_SESSION_KEY);

            if (!$result['success']) {
                return [
                    'connection' => 'unknown',
                    'connected' => false,
                    'phone' => null,
                    'gateway_available' => false,
                ];
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $state = $this->normalizeAdminStatus($data, false);
            $state['gateway_available'] = true;
            $this->syncAdminPhone($state['phone']);

            return $state;
        } catch (\Throwable $e) {
            log_message('error', 'WhatsApp Admin initial status: '.$e->getMessage());

            return [
                'connection' => 'unknown',
                'connected' => false,
                'phone' => null,
                'gateway_available' => false,
            ];
        }
    }

    private function normalizeAdminStatus(array $data, bool $fromConnect = false): array
    {
        $raw = $data['connection']
            ?? $data['status']
            ?? $data['state']
            ?? null;

        $connected = isset($data['connected'])
            ? (bool) $data['connected']
            : in_array(
                strtolower(trim((string) $raw)),
                ['connected', 'online', 'ready', 'open', 'authenticated', 'auth_success', 'success'],
                true
            );

        $value = strtolower(trim((string) $raw));

        if ($connected) {
            $connection = 'connected';
        } elseif (in_array($value, [
            'connecting', 'waiting_scan', 'qr_ready', 'qr',
            'authenticating', 'pairing', 'pending', 'initializing',
        ], true) || $fromConnect) {
            $connection = 'connecting';
        } elseif (in_array($value, [
            'disconnected', 'logged_out', 'logout', 'closed',
            'close', 'offline', 'unauthorized',
        ], true)) {
            $connection = 'disconnected';
        } else {
            $connection = 'disconnected';
        }

        $phone = $data['number']
            ?? $data['phone']
            ?? $data['phone_number']
            ?? $data['wid']
            ?? null;

        if (is_array($phone)) {
            $phone = $phone['user'] ?? $phone['number'] ?? null;
        }

        $phone = preg_replace('/\D+/', '', (string) $phone);
        $phone = $phone !== '' ? $phone : null;

        return [
            'connection' => $connection,
            'connected' => $connection === 'connected',
            'phone' => $phone,
        ];
    }

    private function extractQr(array $data): ?string
    {
        $qr = $data['qr']
            ?? $data['qr_code']
            ?? $data['qrcode']
            ?? null;

        if (is_array($qr)) {
            $qr = $qr['data'] ?? $qr['base64'] ?? null;
        }

        $qr = trim((string) $qr);

        if ($qr === '') {
            return null;
        }

        if (!preg_match('#^(data:image/|https?://)#i', $qr)) {
            return 'data:image/png;base64,'.$qr;
        }

        return $qr;
    }

    private function syncAdminPhone(?string $phone): void
    {
        if ($phone === null) {
            return;
        }

        $phone = preg_replace('/\D+/', '', $phone);
        if ($phone === '') {
            return;
        }

        db_connect()->table('ex_whatsapp_gateway_settings')
            ->where('gateway_type', 'ADMIN')
            ->update([
                'phone_number' => $phone,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
    }
}
