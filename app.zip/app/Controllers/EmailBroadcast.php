<?php
namespace App\Controllers;

use App\Services\MessageTemplateService;
use App\Services\NotificationService;

class EmailBroadcast extends BaseController
{
    public function index()
    {
        $db=db_connect();
        $residents=$db->table('residents r')->select('r.id,r.name,r.gender,r.email,r.phone,u.unit_no,c.name cluster_name')->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->where('r.deleted_at',null)->where('r.email IS NOT NULL',null,false)->where('r.email !=','')->orderBy('r.name')->get()->getResultArray();
        $templates=$db->table('notification_templates')->whereIn('type',['email','both'])->where('status','active')->where('deleted_at',null)->orderBy('template_name')->get()->getResultArray();
        $ready=$db->table('email_smtp_settings')->where('active',1)->where('is_default',1)->where('deleted_at',null)->countAllResults()>0;
        return view('transactions/email',['title'=>'Kirim Email Penghuni','residents'=>$residents,'templates'=>$templates,'ready'=>$ready]);
    }
    public function send()
    {
        $scope=(string)$this->request->getPost('recipient_scope');$ids=array_values(array_unique(array_map('intval',(array)$this->request->getPost('resident_ids'))));$subject=trim((string)$this->request->getPost('subject'));$body=trim((string)$this->request->getPost('message'));
        if($subject===''||$body==='')return redirect()->back()->withInput()->with('warning','Subject dan isi email wajib diisi.');
        $builder=db_connect()->table('residents r')->select('r.id,r.name,r.gender,r.email,r.phone,u.unit_no,c.name cluster_name')->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->where('r.deleted_at',null)->where('r.email IS NOT NULL',null,false)->where('r.email !=','');
        if($scope!=='all'){if(!$ids)return redirect()->back()->withInput()->with('warning','Pilih minimal satu penghuni.');$builder->whereIn('r.id',$ids);}
        $rows=$builder->get()->getResultArray();if(!$rows)return redirect()->back()->withInput()->with('warning','Tidak ada penghuni dengan alamat email valid.');
        $attachment=null;$file=$this->request->getFile('attachment');
        if($file&&$file->getError()!==UPLOAD_ERR_NO_FILE){if(!$file->isValid()||$file->getSize()>10*1024*1024)return redirect()->back()->withInput()->with('error','Lampiran gagal diunggah atau melebihi 10 MB.');$dir=WRITEPATH.'uploads'.DIRECTORY_SEPARATOR.'email-broadcast';if(!is_dir($dir))mkdir($dir,0775,true);$name=$file->getRandomName();$file->move($dir,$name);$attachment=$dir.DIRECTORY_SEPARATOR.$name;}
        set_time_limit(0);$renderer=new MessageTemplateService();$service=new NotificationService();$sent=0;$failed=0;
        foreach($rows as $row){$emailSubject=$renderer->render($subject,$row);$emailBody=nl2br($renderer->render($body,$row));$service->email($row['email'],$emailSubject,$emailBody,$attachment)?$sent++:$failed++;}
        return redirect()->to('/reports/notifications?channel=email&status='.($failed?'failed':'sent'))->with($failed?($sent?'warning':'error'):'success',"Pengiriman email selesai: $sent berhasil, $failed gagal.");
    }
}
