<?php
namespace App\Controllers;

use App\Models\EmailProviderModel;

class EmailProviders extends BaseController
{
    public function index(){return view('settings/email_providers/index',['title'=>'Email Provider','rows'=>(new EmailProviderModel())->orderBy('is_default','DESC')->orderBy('account_name')->findAll()]);}
    public function form(?int $id=null){$row=$id?(new EmailProviderModel())->find($id):[];if($id&&!$row)return redirect()->to('/master/email-providers')->with('error','Email provider tidak ditemukan.');return view('settings/email_providers/form',['title'=>$id?'Edit Email Provider':'Tambah Email Provider','row'=>$row]);}
    public function save()
    {
        $id=(int)$this->request->getPost('id');$model=new EmailProviderModel();
        $data=['account_name'=>trim((string)$this->request->getPost('account_name')),'smtp_host'=>trim((string)$this->request->getPost('smtp_host')),'smtp_port'=>(int)$this->request->getPost('smtp_port'),'smtp_user'=>trim((string)$this->request->getPost('smtp_user')),'smtp_crypto'=>(string)$this->request->getPost('smtp_crypto'),'from_email'=>trim((string)$this->request->getPost('from_email')),'from_name'=>trim((string)$this->request->getPost('from_name')),'active'=>(int)$this->request->getPost('active'),'is_default'=>(int)$this->request->getPost('is_default')];
        if(!$data['account_name']||!$data['smtp_host']||!filter_var($data['from_email'],FILTER_VALIDATE_EMAIL))return redirect()->back()->withInput()->with('error','Nama akun, SMTP host, dan email pengirim yang valid wajib diisi.');
        if(!in_array($data['smtp_crypto'],['tls','ssl','none'],true))return redirect()->back()->withInput()->with('error','Enkripsi SMTP tidak valid.');
        $password=(string)$this->request->getPost('smtp_password');$existing=$id?$model->find($id):[];
        if($password!=='')$data['smtp_password_encrypted']=base64_encode(service('encrypter')->encrypt($password));
        elseif(!$id)return redirect()->back()->withInput()->with('warning','Password SMTP wajib diisi untuk provider baru.');
        if($data['is_default'])$data['active']=1;
        $db=db_connect();$db->transStart();
        if($data['is_default'])$db->table('email_smtp_settings')->where('deleted_at',null)->update(['is_default'=>0,'updated_at'=>date('Y-m-d H:i:s')]);
        $id?$model->update($id,$data):$id=(int)$model->insert($data,true);
        if(!$db->table('email_smtp_settings')->where('deleted_at',null)->where('is_default',1)->countAllResults())$db->table('email_smtp_settings')->where('id',$id)->update(['is_default'=>1,'active'=>1]);
        $db->transComplete();
        return redirect()->to('/master/email-providers')->with($db->transStatus()?'success':'error',$db->transStatus()?'Email provider berhasil disimpan.':'Email provider gagal disimpan.');
    }
    public function setDefault(int $id){$model=new EmailProviderModel();$row=$model->find($id);if(!$row)return redirect()->back()->with('error','Email provider tidak ditemukan.');$db=db_connect();$db->transStart();$db->table('email_smtp_settings')->where('deleted_at',null)->update(['is_default'=>0]);$db->table('email_smtp_settings')->where('id',$id)->update(['is_default'=>1,'active'=>1,'updated_at'=>date('Y-m-d H:i:s')]);$db->transComplete();return redirect()->back()->with($db->transStatus()?'success':'error',$db->transStatus()?$row['account_name'].' menjadi email provider default.':'Provider default gagal diubah.');}
    public function delete(int $id){$model=new EmailProviderModel();$row=$model->find($id);if(!$row)return redirect()->back()->with('error','Email provider tidak ditemukan.');if($row['is_default'])return redirect()->back()->with('warning','Provider default tidak dapat dihapus. Pindahkan default terlebih dahulu.');$model->delete($id);return redirect()->back()->with('success','Email provider dipindahkan ke arsip.');}
}
