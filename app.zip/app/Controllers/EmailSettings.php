<?php
namespace App\Controllers;

use App\Services\NotificationService;

class EmailSettings extends BaseController
{
    public function index()
    {
        $db=db_connect();
        $setting=$db->table('email_smtp_settings')->where('deleted_at',null)->orderBy('is_default','DESC')->orderBy('id','DESC')->get()->getRowArray()??[];
        if($this->request->getMethod()==='POST'){
            $data=[
                'account_name'=>trim((string)$this->request->getPost('account_name')),
                'smtp_host'=>trim((string)$this->request->getPost('smtp_host')),
                'smtp_port'=>(int)$this->request->getPost('smtp_port'),
                'smtp_user'=>trim((string)$this->request->getPost('smtp_user')),
                'smtp_crypto'=>(string)$this->request->getPost('smtp_crypto'),
                'from_email'=>trim((string)$this->request->getPost('from_email')),
                'from_name'=>trim((string)$this->request->getPost('from_name')),
                'active'=>(int)$this->request->getPost('active'),
                'updated_at'=>date('Y-m-d H:i:s'),
            ];
            if(!$data['account_name']||!$data['smtp_host']||!filter_var($data['from_email'],FILTER_VALIDATE_EMAIL))return redirect()->back()->withInput()->with('error','Nama akun, SMTP host, dan email pengirim yang valid wajib diisi.');
            $password=(string)$this->request->getPost('smtp_password');
            if($password!=='')$data['smtp_password_encrypted']=base64_encode(service('encrypter')->encrypt($password));
            try {
                if($setting)$saved=$db->table('email_smtp_settings')->where('id',$setting['id'])->update($data);
                else{$data['created_at']=date('Y-m-d H:i:s');$saved=$db->table('email_smtp_settings')->insert($data);}
                if(!$saved)return redirect()->back()->withInput()->with('error','Konfigurasi SMTP gagal disimpan.');
            } catch (\Throwable $e) {
                log_message('error','Email setting save: '.$e->getMessage());
                return redirect()->back()->withInput()->with('error','Terjadi error saat menyimpan konfigurasi SMTP.');
            }
            return redirect()->to('/settings/email')->with('success','Konfigurasi SMTP berhasil disimpan.');
        }
        return view('settings/email',['title'=>'Setting Email SMTP','setting'=>$setting]);
    }

    public function test()
    {
        $db = db_connect();
        $setting = $db->table('email_smtp_settings')
            ->where('active', 1)
            ->where('deleted_at', null)
            ->orderBy('is_default', 'DESC')
            ->orderBy('id', 'DESC')
            ->get()
            ->getRowArray();

        if (! $setting) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Konfigurasi SMTP aktif belum tersedia. Simpan dan aktifkan konfigurasi terlebih dahulu.',
            ]);
        }

        $recipient = filter_var((string) $setting['smtp_user'], FILTER_VALIDATE_EMAIL)
            ? (string) $setting['smtp_user']
            : (string) $setting['from_email'];

        if (! filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'SMTP Username dan Email Pengirim bukan alamat email yang valid.',
            ]);
        }

        $companyName = 'Eksis Laundry';
        $service = new NotificationService();
        $sent = $service->email(
            $recipient,
            'Testing Email Eksis Laundry',
            '<p>Ini adalah email testing dari <strong>' . esc($companyName) . '</strong>.</p><p>Jika email ini diterima, konfigurasi SMTP siap digunakan untuk pengiriman OTP.</p>'
        );

        return $this->response
            ->setStatusCode($sent ? 200 : 502)
            ->setJSON([
                'success' => $sent,
                'message' => $sent
                    ? 'Email testing berhasil dikirim ke ' . $recipient . '.'
                    : 'Email testing gagal: ' . ($service->getLastError() ?: 'Kesalahan SMTP tidak diketahui.'),
            ]);
    }
}
