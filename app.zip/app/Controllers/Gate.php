<?php
namespace App\Controllers;
use App\Services\GateService;
class Gate extends BaseController
{
    public function index()
    {
        $gate=db_connect()->table('gates')->select('console_slug')->where('active',1)->where('deleted_at',null)->where('console_slug IS NOT NULL',null,false)->orderBy('id')->get()->getRowArray();
        if(!$gate)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Belum ada Gate Console aktif.');
        return redirect()->to('/'.$gate['console_slug']);
    }

    public function console(string $slug)
    {
        $db=db_connect();$gate=$db->table('gates')->where('console_slug',strtolower($slug))->where('active',1)->where('deleted_at',null)->get()->getRowArray();
        if(!$gate)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Gate Console tidak ditemukan.');
        $cameras=$db->table('gate_cameras')->select('id,name,camera_type,refresh_seconds,connection_status')->where('gate_id',$gate['id'])->where('active',1)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        $barriers=$db->table('barrier_gates')->select('id,name,controller_type,connection_status,auto_close_seconds')->where('gate_id',$gate['id'])->where('active',1)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        return view('gate/index',['gate'=>$gate,'cameras'=>$cameras,'barriers'=>$barriers]);
    }

    public function camera(int $id)
    {
        $slug=strtolower(trim((string)$this->request->getGet('console_slug')));$db=db_connect();
        $camera=$db->table('gate_cameras c')->select('c.*')->join('gates g','g.id=c.gate_id')->where('c.id',$id)->where('c.active',1)->where('c.deleted_at',null)->where('g.console_slug',$slug)->where('g.active',1)->where('g.deleted_at',null)->get()->getRowArray();
        if(!$camera||$camera['camera_type']==='usb')return $this->response->setStatusCode(404);
        try{
            $auth=[];if(!empty($camera['username']))$auth=[$camera['username'],!empty($camera['password_encrypted'])?service('encrypter')->decrypt(base64_decode($camera['password_encrypted'])):''];
            $upstream=service('curlrequest')->request('GET',$camera['snapshot_url'],['auth'=>$auth,'timeout'=>4,'connect_timeout'=>2,'http_errors'=>false]);
            if($upstream->getStatusCode()>=400)throw new \RuntimeException('Camera HTTP '.$upstream->getStatusCode());
            $db->table('gate_cameras')->where('id',$id)->update(['connection_status'=>'online','last_online_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            return $this->response->setHeader('Content-Type',$upstream->getHeaderLine('Content-Type')?:'image/jpeg')->setHeader('Cache-Control','no-store')->setBody($upstream->getBody());
        }catch(\Throwable $e){log_message('error','Camera '.$camera['code'].': '.$e->getMessage());$db->table('gate_cameras')->where('id',$id)->update(['connection_status'=>'offline','updated_at'=>date('Y-m-d H:i:s')]);return $this->response->setStatusCode(502);}
    }

    public function tap()
    {
        $payload=$this->request->getJSON(true)?:$this->request->getPost();
        $slug=strtolower(trim((string)($payload['console_slug']??'')));
        $gate=db_connect()->table('gates')->select('id,direction')->where('console_slug',$slug)->where('active',1)->where('deleted_at',null)->get()->getRowArray();
        if(!$gate)return $this->response->setStatusCode(404)->setJSON(['success'=>false,'granted'=>false,'message'=>'Gate Console tidak ditemukan.']);
        if(!in_array($gate['direction'],['in','out'],true))return $this->response->setStatusCode(422)->setJSON(['success'=>false,'granted'=>false,'message'=>'Arah gate harus ditetapkan MASUK atau KELUAR pada Master Gate.']);
        $payload['gate_id']=$gate['id'];$payload['direction']=$gate['direction'];
        return $this->response->setJSON((new GateService())->process($payload));
    }
}
