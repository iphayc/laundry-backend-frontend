<?php
namespace App\Controllers;

class GateEquipment extends BaseController
{
    private function cfg(string $type): array
    {
        $configs=[
            'camera'=>['table'=>'gate_cameras','route'=>'cameras','title'=>'Master Camera','secret'=>'password_encrypted'],
            'barrier'=>['table'=>'barrier_gates','route'=>'barriers','title'=>'Master Barrier Gate','secret'=>'api_key_encrypted'],
        ];
        if(!isset($configs[$type]))throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $configs[$type];
    }

    public function index(string $type)
    {
        $c=$this->cfg($type);$rows=db_connect()->table($c['table'].' e')->select('e.*,g.name gate_name')->join('gates g','g.id=e.gate_id AND g.deleted_at IS NULL','left')->where('e.deleted_at',null)->orderBy('e.name')->get()->getResultArray();
        return view('equipment/index',['title'=>$c['title'],'type'=>$type,'route'=>$c['route'],'rows'=>$rows]);
    }

    public function form(string $type,?int $id=null)
    {
        $c=$this->cfg($type);$db=db_connect();$row=$id?$db->table($c['table'])->where('id',$id)->where('deleted_at',null)->get()->getRowArray():[];
        if($id&&!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Perangkat tidak ditemukan.');
        $gates=$db->table('gates')->select('id,name,direction')->where('active',1)->where('deleted_at',null)->orderBy('name')->get()->getResultArray();
        return view('equipment/form',['title'=>($id?'Edit ':'Tambah ').$c['title'],'type'=>$type,'route'=>$c['route'],'row'=>$row,'gates'=>$gates]);
    }

    public function save(string $type)
    {
        $c=$this->cfg($type);$id=(int)$this->request->getPost('id');$gateId=(int)$this->request->getPost('gate_id');$code=strtoupper(trim((string)$this->request->getPost('code')));$name=trim((string)$this->request->getPost('name'));
        if(!$gateId||$code===''||$name==='')return redirect()->back()->withInput()->with('warning','Gate, kode, dan nama wajib diisi.');
        if(!db_connect()->table('gates')->where('id',$gateId)->where('active',1)->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Gate tidak ditemukan atau tidak aktif.');
        $duplicate=db_connect()->table($c['table'])->where('code',$code)->where('deleted_at',null);if($id)$duplicate->where('id !=',$id);
        if($duplicate->countAllResults())return redirect()->back()->withInput()->with('error','Kode perangkat sudah digunakan.');
        $common=['gate_id'=>$gateId,'code'=>$code,'name'=>$name,'connection_status'=>$this->request->getPost('connection_status'),'active'=>(int)$this->request->getPost('active'),'remark'=>trim((string)$this->request->getPost('remark'))?:null,'updated_at'=>date('Y-m-d H:i:s')];
        if($type==='camera'){
            $cameraType=(string)$this->request->getPost('camera_type');$snapshot=trim((string)$this->request->getPost('snapshot_url'));
            if($cameraType!=='usb'&&!filter_var($snapshot,FILTER_VALIDATE_URL))return redirect()->back()->withInput()->with('error','Snapshot URL kamera wajib berupa URL yang valid.');
            $data=$common+['camera_type'=>$cameraType,'snapshot_url'=>$cameraType==='usb'?null:$snapshot,'stream_url'=>$cameraType==='usb'?null:(trim((string)$this->request->getPost('stream_url'))?:null),'username'=>$cameraType==='usb'?null:(trim((string)$this->request->getPost('username'))?:null),'refresh_seconds'=>max(1,(int)$this->request->getPost('refresh_seconds'))];
            $secret=(string)$this->request->getPost('password');
        }else{
            $openUrl=trim((string)$this->request->getPost('open_url'));if($this->request->getPost('controller_type')==='http'&&!filter_var($openUrl,FILTER_VALIDATE_URL))return redirect()->back()->withInput()->with('error','Open URL barrier wajib valid untuk controller HTTP.');
            $data=$common+['controller_type'=>$this->request->getPost('controller_type'),'open_url'=>$openUrl?:null,'close_url'=>trim((string)$this->request->getPost('close_url'))?:null,'status_url'=>trim((string)$this->request->getPost('status_url'))?:null,'relay_channel'=>trim((string)$this->request->getPost('relay_channel'))?:null,'auto_close_seconds'=>max(1,(int)$this->request->getPost('auto_close_seconds'))];
            $secret=(string)$this->request->getPost('api_key');
        }
        if($secret!=='')$data[$c['secret']]=base64_encode(service('encrypter')->encrypt($secret));
        try{$builder=db_connect()->table($c['table']);if(!$id)$data['created_at']=date('Y-m-d H:i:s');$saved=$id?$builder->where('id',$id)->update($data):$builder->insert($data);if(!$saved)throw new \RuntimeException('Save failed');return redirect()->to('/master/'.$c['route'])->with('success',$c['title'].' berhasil disimpan.');}
        catch(\Throwable $e){log_message('error','Gate equipment save: '.$e->getMessage());return redirect()->back()->withInput()->with('error','Terjadi error saat menyimpan perangkat.');}
    }

    public function delete(string $type,int $id)
    {
        $c=$this->cfg($type);
        try{if(!db_connect()->table($c['table'])->where('id',$id)->update(['deleted_at'=>date('Y-m-d H:i:s')]))throw new \RuntimeException('Delete failed');return redirect()->back()->with('success',$c['title'].' dipindahkan ke arsip.');}
        catch(\Throwable $e){log_message('error','Gate equipment delete: '.$e->getMessage());return redirect()->back()->with('error','Perangkat gagal diarsipkan.');}
    }
}
