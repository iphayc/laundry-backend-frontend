<?php
namespace App\Controllers;

class Help extends BaseController
{
    public function manual()
    {
        $isAdmin=(int)session('role_id')===1;$q=trim((string)$this->request->getGet('q'));$builder=db_connect()->table('help_articles')->where('deleted_at',null);
        if(!$isAdmin)$builder->where('active',1);
        if($q!=='')$builder->groupStart()->like('module',$q)->orLike('title',$q)->orLike('content',$q)->groupEnd();
        return view('help/manual',['title'=>'Manual Guide','rows'=>$builder->orderBy('sort_order')->orderBy('title')->get()->getResultArray(),'q'=>$q,'isAdmin'=>$isAdmin]);
    }

    public function read(int $id)
    {
        $db=db_connect();$isAdmin=(int)session('role_id')===1;
        $builder=$db->table('help_articles')->where('id',$id)->where('deleted_at',null);
        if(!$isAdmin)$builder->where('active',1);
        $row=$builder->get()->getRowArray();
        if(!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Panduan tidak ditemukan.');
        $allBuilder=$db->table('help_articles')->select('id,module,title,sort_order')->where('deleted_at',null);
        if(!$isAdmin)$allBuilder->where('active',1);
        $articles=$allBuilder->orderBy('sort_order')->orderBy('title')->get()->getResultArray();
        $position=array_search($id,array_map('intval',array_column($articles,'id')),true);
        return view('help/read',['title'=>$row['title'],'article'=>$row,'articles'=>$articles,'previous'=>$position!==false&&$position>0?$articles[$position-1]:null,'next'=>$position!==false&&isset($articles[$position+1])?$articles[$position+1]:null,'isAdmin'=>$isAdmin]);
    }

    public function form(?int $id=null)
    {
        helper('form');$row=$id?db_connect()->table('help_articles')->where('id',$id)->where('deleted_at',null)->get()->getRowArray():[];
        if($id&&!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Panduan tidak ditemukan.');
        return view('help/form',['title'=>($id?'Edit ':'Tambah ').'Manual Guide','row'=>$row]);
    }

    public function save()
    {
        $id=(int)$this->request->getPost('id');$data=['module'=>trim((string)$this->request->getPost('module')),'title'=>trim((string)$this->request->getPost('title')),'content'=>trim((string)$this->request->getPost('content')),'sort_order'=>(int)$this->request->getPost('sort_order'),'active'=>(int)$this->request->getPost('active'),'updated_at'=>date('Y-m-d H:i:s')];
        if($data['module']===''||$data['title']===''||$data['content']==='')return redirect()->back()->withInput()->with('warning','Modul, judul, dan isi panduan wajib diisi.');
        $file=$this->request->getFile('screenshot');
        if($file&&$file->isValid()&&!$file->hasMoved()){
            if($file->getSize()>3*1024*1024)return redirect()->back()->withInput()->with('warning','Screenshot maksimal 3 MB.');
            if(!in_array($file->getMimeType(),['image/jpeg','image/png','image/webp'],true))return redirect()->back()->withInput()->with('warning','Screenshot harus JPG, PNG, atau WebP.');
            $target=FCPATH.'uploads'.DIRECTORY_SEPARATOR.'help';if(!is_dir($target))mkdir($target,0775,true);$name=$file->getRandomName();$file->move($target,$name);$data['screenshot_path']='uploads/help/'.$name;
        }elseif($id){$current=db_connect()->table('help_articles')->select('screenshot_path')->where('id',$id)->get()->getRowArray();$data['screenshot_path']=$current['screenshot_path']??null;}
        try{$builder=db_connect()->table('help_articles');if(!$id)$data['created_at']=date('Y-m-d H:i:s');$ok=$id?$builder->where('id',$id)->update($data):$builder->insert($data);if(!$ok)throw new \RuntimeException('Save failed');return redirect()->to('/help/manual')->with('success','Manual Guide berhasil disimpan.');}
        catch(\Throwable $e){log_message('error','Help save: '.$e->getMessage());return redirect()->back()->withInput()->with('error','Manual Guide gagal disimpan.');}
    }

    public function delete(int $id)
    {
        $ok=db_connect()->table('help_articles')->where('id',$id)->update(['deleted_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
        return redirect()->back()->with($ok?'success':'error',$ok?'Panduan dipindahkan ke arsip.':'Panduan gagal diarsipkan.');
    }

    public function about()
    {
        $row=db_connect()->table('application_about')->where('deleted_at',null)->orderBy('id','DESC')->get()->getRowArray()??[];
        return view('help/about',['title'=>'About','about'=>$row]);
    }

    public function saveAbout()
    {
        $db=db_connect();$row=$db->table('application_about')->where('deleted_at',null)->orderBy('id','DESC')->get()->getRowArray();
        $data=['app_name'=>trim((string)$this->request->getPost('app_name')),'version'=>trim((string)$this->request->getPost('version'))?:null,'developer'=>trim((string)$this->request->getPost('developer'))?:null,'email'=>trim((string)$this->request->getPost('email'))?:null,'website'=>trim((string)$this->request->getPost('website'))?:null,'description'=>trim((string)$this->request->getPost('description'))?:null,'updated_at'=>date('Y-m-d H:i:s')];
        if($data['app_name']==='')return redirect()->back()->with('warning','Nama aplikasi wajib diisi.');
        $ok=$row?$db->table('application_about')->where('id',$row['id'])->update($data):$db->table('application_about')->insert($data+['created_at'=>date('Y-m-d H:i:s')]);
        return redirect()->back()->with($ok?'success':'error',$ok?'Informasi About berhasil diperbarui.':'Informasi About gagal disimpan.');
    }
}
