<?php

namespace App\Controllers;

use App\Services\InstallationService;
use Throwable;

class Installer extends BaseController
{
    public function index()
    {
        $installer = new InstallationService();
        $status = $installer->status();

        if ($status['installed']) {
            return redirect()->to('/aEZGxhfPkA')->with('info', 'Aplikasi sudah terpasang.');
        }

        if ($this->request->getMethod() === 'POST') {
            $rules = [
                'company_name' => 'required|min_length[3]|max_length[160]',
                'admin_name' => 'required|min_length[3]|max_length[120]',
                'admin_username' => 'required|alpha_numeric_punct|min_length[4]|max_length[60]',
                'admin_email' => 'required|valid_email|max_length[160]',
                'admin_password' => 'required|min_length[12]|max_length[255]',
                'admin_password_confirm' => 'required|matches[admin_password]',
                'activation_email' => 'required|valid_email|max_length[160]',
            ];
            if (! $this->validate($rules)) {
                return redirect()->back()->withInput()
                    ->with('error', implode(' ', $this->validator->getErrors()));
            }

            $password = (string) $this->request->getPost('admin_password');
            if (! preg_match('/[A-Z]/', $password)
                || ! preg_match('/[a-z]/', $password)
                || ! preg_match('/\d/', $password)
                || ! preg_match('/[^A-Za-z0-9]/', $password)) {
                return redirect()->back()->withInput()
                    ->with('error', 'Password admin harus mengandung huruf besar, huruf kecil, angka, dan simbol.');
            }

            try {
                $installer->install((array) $this->request->getPost());
                session()->destroy();
                return redirect()->to('/register')
                    ->with('success', 'Instalasi selesai. Masukkan kode aktivasi untuk server ini.');
            } catch (Throwable $e) {
                log_message('critical', 'Installation failed: ' . $e->getMessage());
                return redirect()->back()->withInput()
                    ->with('error', 'Instalasi gagal: ' . $e->getMessage());
            }
        }

        return view('installer/index', [
            'status' => $status,
            'phpVersion' => PHP_VERSION,
            'requiredExtensions' => [
                'mysqli' => extension_loaded('mysqli'),
                'intl' => extension_loaded('intl'),
                'mbstring' => extension_loaded('mbstring'),
                'json' => extension_loaded('json'),
            ],
            'writableReady' => is_writable(WRITEPATH),
        ]);
    }
}
