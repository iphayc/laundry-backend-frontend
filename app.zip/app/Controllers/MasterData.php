<?php
namespace App\Controllers;

class MasterData extends BaseController
{
    private array $modules=[
        'users'=>['title'=>'Pengguna','table'=>'users','fields'=>['role_id'=>'Role ID','group_id'=>'Group ID','username'=>'Username','name'=>'Nama','email'=>'Email','phone'=>'Telepon','active'=>'Aktif']],
        'roles'=>['title'=>'Master Role','table'=>'roles','fields'=>['name'=>'Nama Role','description'=>'Deskripsi']],
        'groups'=>['title'=>'Group','table'=>'groups','fields'=>['parent_id'=>'Parent ID','name'=>'Nama','description'=>'Deskripsi']],
        'menus'=>['title'=>'Menu Dinamis','table'=>'menus','fields'=>['parent_id'=>'Parent Menu','name'=>'Nama Menu','route'=>'Route / URL','icon'=>'Icon CSS','sort_order'=>'Urutan','active'=>'Aktif']],
        'email-recipients'=>['title'=>'Penerima Email','table'=>'email_recipients','fields'=>['name'=>'Nama Penerima','email'=>'Alamat Email / To (pisahkan koma)','cc'=>'CC (pisahkan koma)','template_id'=>'Template Email','description'=>'Keterangan','active'=>'Aktif']],
        'notification-templates'=>['title'=>'Master Template','table'=>'notification_templates','fields'=>['type'=>'Jenis','template_name'=>'Nama Template','subject'=>'Subject','body'=>'Body','remark'=>'Remark','status'=>'Status']],
    ];
    private function cfg(string $module): array {if(!isset($this->modules[$module]))throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();return $this->modules[$module];}
    public function index(string $module)
    {
        $c=$this->cfg($module);$db=db_connect();$builder=$db->table($c['table']);
        if(in_array('deleted_at',$db->getFieldNames($c['table']),true))$builder->where('deleted_at',null);
        if($module==='menus')$builder->orderBy('sort_order','ASC');
        $rows=$builder->get()->getResultArray();
        if($module==='menus')return view('master/menu_tree',['title'=>$c['title'],'module'=>$module,'menuTree'=>$this->buildMenuTree($rows)]);
        if($module==='users'){foreach($rows as &$row){$row['role_id']=$db->table('roles')->select('name')->where('id',$row['role_id'])->where('deleted_at',null)->get()->getRow('name')??'-';$row['group_id']=$db->table('groups')->select('name')->where('id',$row['group_id'])->where('deleted_at',null)->get()->getRow('name')??'-';}}
        if($module==='gates'){foreach($rows as &$row){$row['cluster_id']=$row['cluster_id']?$db->table('clusters')->select('name')->where('id',$row['cluster_id'])->where('deleted_at',null)->get()->getRow('name')??'-':'Gerbang Utama / Tanpa Cluster';}}
        if($module==='vehicles'){foreach($rows as &$row){$resident=$db->table('residents r')->select("CONCAT(r.name,' - Grup: ',COALESCE(h.name,IF(r.is_household_head=1,r.name,'Tanpa Grup')),' - ',COALESCE(u.unit_no,'Tanpa Unit')) label",false)->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('residents h','h.id=r.household_head_id AND h.deleted_at IS NULL','left')->where('r.id',$row['resident_id'])->where('r.deleted_at',null)->get()->getRowArray();$row['resident_id']=$resident['label']??'-';$row['vehicle_type_id']=$db->table('vehicle_types')->select('name')->where('id',$row['vehicle_type_id'])->where('deleted_at',null)->get()->getRow('name')??'-';}}
        if($module==='units'){foreach($rows as &$row){$row['cluster_id']=$db->table('clusters')->select('name')->where('id',$row['cluster_id'])->where('deleted_at',null)->get()->getRow('name')??'-';}}
        if($module==='residents'){foreach($rows as &$row){$unit=$db->table('units u')->select("CONCAT(c.name,' - ',u.unit_no) label",false)->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->where('u.id',$row['unit_id'])->where('u.deleted_at',null)->get()->getRowArray();$row['unit_id']=$unit['label']??'-';$headId=$row['household_head_id']??null;$isHead=(int)($row['is_household_head']??0)===1;$row['household_head_id']=$isHead?$row['name'].' (Kepala)':($headId?$db->table('residents')->select('name')->where('id',$headId)->where('deleted_at',null)->get()->getRow('name')??'-':'-');$row['is_household_head']=$isHead?'Ya':'Tidak';$gender=$row['gender']??null;$row['gender']=$gender==='male'?'Laki-laki':($gender==='female'?'Perempuan':'-');$row['suspended']=(int)($row['suspended']??0)===1?'Ya':'Tidak';}}
        if($module==='cards'){foreach($rows as &$row){$resident=$db->table('residents r')->select("CONCAT(r.name,' - ',COALESCE(u.unit_no,'Tanpa Unit')) label",false)->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->where('r.id',$row['resident_id'])->where('r.deleted_at',null)->get()->getRowArray();$row['resident_id']=$resident['label']??'-';}}
        if($module==='visitors'){foreach($rows as &$row){$resident=$row['resident_id']?$db->table('residents r')->select("CONCAT(r.name,' - ',COALESCE(u.unit_no,'Tanpa Unit')) label",false)->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->where('r.id',$row['resident_id'])->where('r.deleted_at',null)->get()->getRowArray():[];$row['resident_id']=$resident['label']??'-';}}
        if($module==='email-recipients'){foreach($rows as &$row)$row['template_id']=$row['template_id']?$db->table('notification_templates')->select('template_name')->where('id',$row['template_id'])->where('deleted_at',null)->get()->getRow('template_name')??'-':'-';}
        return view('master/index',['title'=>$c['title'],'module'=>$module,'config'=>$c,'rows'=>$rows]);
    }
    public function form(string $module,?int $id=null)
    {
        $c=$this->cfg($module);$db=db_connect();$row=$id?$db->table($c['table'])->where('id',$id)->where('deleted_at',null)->get()->getRowArray():[];$options=[];$documents=[];
        if($module==='users'){$options['role_id']=$db->table('roles')->select('id value,name label')->where('deleted_at',null)->orderBy('name')->get()->getResultArray();$options['group_id']=$db->table('groups')->select('id value,name label')->where('deleted_at',null)->orderBy('name')->get()->getResultArray();}
        if(in_array($module,['units','gates'],true)){$options['cluster_id']=$db->table('clusters')->select('id value,name label')->where('active',1)->where('deleted_at',null)->orderBy('name')->get()->getResultArray();if($module==='gates')array_unshift($options['cluster_id'],['value'=>'','label'=>'- Gerbang Utama / Tanpa Cluster -']);}
        if($module==='gates'){$options['gate_type']=[['value'=>'main','label'=>'Gerbang Utama'],['value'=>'cluster','label'=>'Gerbang Cluster']];$options['direction']=[['value'=>'in','label'=>'Masuk'],['value'=>'out','label'=>'Keluar'],['value'=>'both','label'=>'Masuk & Keluar (tidak untuk console tetap)']];}
        if($module==='residents')$options['unit_id']=$db->table('units u')->select("u.id value,CONCAT(c.name,' - ',u.unit_no) label",false)->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->where('u.active',1)->where('u.deleted_at',null)->orderBy('c.name')->orderBy('u.unit_no')->get()->getResultArray();
        if($module==='residents'){$options['household_head_id']=$db->table('residents h')->select("h.id value,CONCAT(h.name,' - ',u.unit_no) label",false)->join('units u','u.id=h.unit_id AND u.deleted_at IS NULL','left')->where('h.is_household_head',1)->where('h.deleted_at',null)->orderBy('h.name')->get()->getResultArray();$options['gender']=[['value'=>'male','label'=>'Laki-laki'],['value'=>'female','label'=>'Perempuan']];}
        if(in_array($module,['vehicles','cards','visitors'],true))$options['resident_id']=$db->table('residents r')->select("r.id value,CONCAT(r.name,' - Grup: ',COALESCE(h.name,IF(r.is_household_head=1,r.name,'Tanpa Grup')),' - ',COALESCE(u.unit_no,'Tanpa Unit')) label",false)->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('residents h','h.id=r.household_head_id AND h.deleted_at IS NULL','left')->where('r.deleted_at',null)->orderBy('r.name')->get()->getResultArray();
        if($module==='vehicles')$options['vehicle_type_id']=$db->table('vehicle_types')->select('id value,name label')->where('active',1)->where('deleted_at',null)->orderBy('name')->get()->getResultArray();
        if($module==='menus'){$allMenus=$db->table('menus')->where('deleted_at',null)->orderBy('sort_order')->get()->getResultArray();$options['parent_id']=[['value'=>'','label'=>'- Menu Utama -'],...$this->menuParentOptions($this->buildMenuTree($allMenus),(int)($id??0))];}
        if($module==='notification-templates')$options['type']=[['value'=>'email','label'=>'Email'],['value'=>'whatsapp','label'=>'WhatsApp'],['value'=>'both','label'=>'Email & WhatsApp']];
        if($module==='email-recipients')$options['template_id']=$db->table('notification_templates')->select('id value,template_name label')->whereIn('type',['email','both'])->where('status','active')->where('deleted_at',null)->orderBy('template_name')->get()->getResultArray();
        return view('master/form',['title'=>($id?'Edit ':'Tambah ').$c['title'],'module'=>$module,'config'=>$c,'row'=>$row,'options'=>$options,'documents'=>$documents]);
    }
    public function save(string $module)
    {
        $c=$this->cfg($module);$id=$this->request->getPost('id');$data=[];
        foreach(array_keys($c['fields']) as $field)$data[$field]=$this->request->getPost($field)===''?null:$this->request->getPost($field);
        if($module==='notification-templates')$data['status']=$data['status']==='1'?'active':'inactive';
        if($module==='roles' && !$data['name'])return redirect()->back()->withInput()->with('error','Nama role wajib diisi.');
        if($module==='gates'){
            $data['console_slug']=strtolower(trim((string)$data['console_slug'],'/ '));
            if($data['console_slug']===''||!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/',$data['console_slug']))return redirect()->back()->withInput()->with('error','URL Gate Console wajib diisi dengan huruf kecil, angka, atau tanda hubung. Contoh: main-in.');
            $duplicate=db_connect()->table('gates')->where('console_slug',$data['console_slug'])->where('deleted_at',null);
            if($id)$duplicate->where('id !=',(int)$id);
            if($duplicate->countAllResults()>0)return redirect()->back()->withInput()->with('error','URL Gate Console sudah digunakan gate lain.');
        }
        if($module==='vehicles'){
            if(empty($data['resident_id'])||empty($data['vehicle_type_id']))return redirect()->back()->withInput()->with('warning','Penghuni dan jenis kendaraan wajib dipilih.');
            $db=db_connect();
            if(!$db->table('residents')->where('id',(int)$data['resident_id'])->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Data penghuni yang dipilih tidak ditemukan.');
            if(!$db->table('vehicle_types')->where('id',(int)$data['vehicle_type_id'])->where('active',1)->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Jenis kendaraan yang dipilih tidak valid atau tidak aktif.');
        }
        $requiredRelations=['units'=>['cluster_id','Cluster'],'residents'=>['unit_id','Unit rumah'],'cards'=>['resident_id','Penghuni']];
        if(isset($requiredRelations[$module])){
            [$relationField,$relationLabel]=$requiredRelations[$module];
            if(empty($data[$relationField]))return redirect()->back()->withInput()->with('warning',$relationLabel.' wajib dipilih.');
        }
        if($module==='units'&&!db_connect()->table('clusters')->where('id',(int)$data['cluster_id'])->where('active',1)->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Cluster yang dipilih tidak ditemukan atau tidak aktif.');
        if($module==='residents'&&!db_connect()->table('units')->where('id',(int)$data['unit_id'])->where('active',1)->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Unit rumah yang dipilih tidak ditemukan atau tidak aktif.');
        if($module==='residents'){
            $data['is_household_head']=!empty($data['is_household_head'])?1:0;
            if($data['is_household_head'])$data['household_head_id']=null;
            elseif(empty($data['household_head_id']))return redirect()->back()->withInput()->with('warning','Pilih Grup Penghuni atau aktifkan Kepala Rumah Tangga / Pemilik.');
            else{
                $head=db_connect()->table('residents')->where('id',(int)$data['household_head_id'])->where('is_household_head',1)->where('deleted_at',null)->get()->getRowArray();
                if(!$head)return redirect()->back()->withInput()->with('error','Kepala rumah tangga yang dipilih tidak valid.');
                if((int)$head['unit_id']!==(int)$data['unit_id'])return redirect()->back()->withInput()->with('warning','Grup penghuni harus berasal dari unit rumah yang sama.');
            }
        }
        if($module==='cards'&&!db_connect()->table('residents')->where('id',(int)$data['resident_id'])->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Penghuni yang dipilih tidak ditemukan.');
        if($module==='visitors'&&!empty($data['resident_id'])&&!db_connect()->table('residents')->where('id',(int)$data['resident_id'])->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Penghuni tujuan tidak ditemukan.');
        if($module==='email-recipients'){
            $to=$this->normalizeEmailList((string)$data['email']);$cc=$this->normalizeEmailList((string)($data['cc']??''));
            if(!$to['valid']||!$to['emails'])return redirect()->back()->withInput()->with('error','Minimal satu alamat email tujuan yang valid wajib diisi. Gunakan pemisah koma.');
            if(!$cc['valid'])return redirect()->back()->withInput()->with('error','Alamat email CC tidak valid. Gunakan pemisah koma.');
            $data['email']=implode(', ',$to['emails']);$data['cc']=$cc['emails']?implode(', ',$cc['emails']):null;
            if(empty($data['template_id'])||!db_connect()->table('notification_templates')->where('id',(int)$data['template_id'])->whereIn('type',['email','both'])->where('status','active')->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Template email aktif wajib dipilih.');
        }
        if($module==='notification-templates'&&(!$data['template_name']||!$data['body']))return redirect()->back()->withInput()->with('error','Nama template dan body wajib diisi.');
        if($module==='users'){
            $password=(string)$this->request->getPost('password');
            $confirmation=(string)$this->request->getPost('password_confirm');
            if(!$id && $password==='')return redirect()->back()->withInput()->with('error','Password wajib diisi untuk pengguna baru.');
            if($password!==''){
                if(strlen($password)<8)return redirect()->back()->withInput()->with('error','Password minimal 8 karakter.');
                if($password!==$confirmation)return redirect()->back()->withInput()->with('error','Konfirmasi password tidak sama.');
                $data['password_hash']=password_hash($password,PASSWORD_DEFAULT);
            }
        }
        try {
            $builder=db_connect()->table($c['table']);
            $saved=$id?$builder->where('id',$id)->update($data):$builder->insert($data);
            if(!$saved)return redirect()->back()->withInput()->with('error','Data gagal disimpan. Silakan periksa data lalu coba lagi.');
            if($module==='residents'){$residentId=$id?(int)$id:(int)db_connect()->insertID();$this->saveResidentDocuments($residentId);}
            return redirect()->to('/master/'.$module)->with('success',$id?'Data berhasil diperbarui.':'Data berhasil disimpan.');
        } catch (\Throwable $e) {
            log_message('error','MasterData save '.$module.': '.$e->getMessage());
            return redirect()->back()->withInput()->with('error','Terjadi error saat menyimpan data.');
        }
    }
    public function delete(string $module,int $id)
    {
        $c=$this->cfg($module);$db=db_connect();$fields=$db->getFieldNames($c['table']);
        if(!in_array('deleted_at',$fields,true))return redirect()->back()->with('error','Tabel ini belum mendukung soft delete.');
        $ids=[$id];
        if($module==='menus'){
            for($i=0;$i<count($ids);$i++){
                $children=$db->table('menus')->select('id')->where('parent_id',$ids[$i])->where('deleted_at',null)->get()->getResultArray();
                foreach($children as $child)if(!in_array((int)$child['id'],$ids,true))$ids[]=(int)$child['id'];
            }
        }
        try {
            if(!$db->table($c['table'])->whereIn('id',$ids)->update(['deleted_at'=>date('Y-m-d H:i:s')]))return redirect()->back()->with('error','Data gagal dipindahkan ke arsip.');
            return redirect()->back()->with('success','Data dipindahkan ke arsip (soft delete).');
        } catch (\Throwable $e) {
            log_message('error','MasterData delete '.$module.': '.$e->getMessage());
            return redirect()->back()->with('error','Terjadi error saat menghapus data.');
        }
    }

    public function resetPassword(int $id)
    {
        $db=db_connect();
        $canReset=(int)session('role_id')===1 || $db->table('role_permissions rp')->join('permissions p','p.id=rp.permission_id')->where('rp.role_id',(int)session('role_id'))->where('p.code','users.manage')->where('p.deleted_at',null)->countAllResults()>0;
        if(!$canReset)return $this->response->setStatusCode(403)->setBody('403 - Anda tidak memiliki izin untuk mereset password pengguna.');
        $user=$db->table('users')->select('id,username,name')->where('id',$id)->where('deleted_at',null)->get()->getRowArray();
        if(!$user)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Pengguna tidak ditemukan.');
        if($this->request->getMethod()==='POST'){
            $password=(string)$this->request->getPost('password');
            $confirmation=(string)$this->request->getPost('password_confirm');
            if(strlen($password)<8)return redirect()->back()->with('error','Password baru minimal 8 karakter.');
            if($password!==$confirmation)return redirect()->back()->with('error','Konfirmasi password tidak sama.');
            $db->transStart();
            $db->table('users')->where('id',$id)->update(['password_hash'=>password_hash($password,PASSWORD_DEFAULT),'updated_at'=>date('Y-m-d H:i:s')]);
            $db->table('audit_logs')->insert(['user_id'=>session('user_id'),'action'=>'RESET_PASSWORD','table_name'=>'users','record_id'=>(string)$id,'ip_address'=>$this->request->getIPAddress(),'created_at'=>date('Y-m-d H:i:s')]);
            $db->transComplete();
            if(!$db->transStatus())return redirect()->back()->with('error','Password gagal direset karena transaksi database gagal.');
            return redirect()->to('/master/users')->with('success','Password '.$user['name'].' berhasil direset.');
        }
        return view('master/reset_password',['title'=>'Reset Password Pengguna','user'=>$user]);
    }

    public function deleteResidentDocument(int $id)
    {
        $db=db_connect();$document=$db->table('resident_documents')->where('id',$id)->where('deleted_at',null)->get()->getRowArray();
        if(!$document)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Dokumen penghuni tidak ditemukan.');
        $ok=$db->table('resident_documents')->where('id',$id)->update(['deleted_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
        return redirect()->to('/master/residents/form/'.$document['resident_id'])->with($ok?'success':'error',$ok?'Dokumen pendukung dipindahkan ke arsip.':'Dokumen gagal diarsipkan.');
    }

    public function residentDetail(int $id)
    {
        $db=db_connect();
        $resident=$db->table('residents r')->select('r.*,u.unit_no,c.name cluster_name,h.name household_head_name')->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->join('residents h','h.id=r.household_head_id AND h.deleted_at IS NULL','left')->where('r.id',$id)->where('r.deleted_at',null)->get()->getRowArray();
        if(!$resident)return $this->response->setStatusCode(404)->setBody('<div class="alert alert-danger">Data penghuni tidak ditemukan.</div>');
        $documents=$db->table('resident_documents')->where('resident_id',$id)->where('deleted_at',null)->orderBy('id','DESC')->get()->getResultArray();
        return view('master/resident_detail',['resident'=>$resident,'documents'=>$documents]);
    }

    public function viewResidentDocument(int $id)
    {
        $document=db_connect()->table('resident_documents')->where('id',$id)->where('deleted_at',null)->get()->getRowArray();
        if(!$document)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Dokumen penghuni tidak ditemukan.');
        $path=WRITEPATH.str_replace(['/', '\\'],DIRECTORY_SEPARATOR,$document['file_path']);
        if(!is_file($path))throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('File dokumen tidak ditemukan.');
        $fileName=str_replace(['"',"\r","\n"],'',basename($document['original_name']));
        return $this->response->setHeader('Content-Type',$document['mime_type']?:'application/octet-stream')->setHeader('Content-Disposition','inline; filename="'.$fileName.'"')->setBody(file_get_contents($path));
    }

    private function saveResidentDocuments(int $residentId): void
    {
        $files=$this->request->getFiles()['supporting_files']??[];$types=(array)$this->request->getPost('document_type');$remarks=(array)$this->request->getPost('document_remark');
        foreach($files as $index=>$file){
            if(!$file||$file->getError()===UPLOAD_ERR_NO_FILE)continue;
            if(!$file->isValid()||$file->hasMoved())throw new \RuntimeException('File dokumen pendukung tidak valid.');
            if($file->getSize()>5*1024*1024)throw new \RuntimeException('Dokumen pendukung maksimal 5 MB per file.');
            if(!in_array($file->getMimeType(),['image/jpeg','image/png','image/webp','application/pdf'],true))throw new \RuntimeException('Dokumen harus JPG, PNG, WebP, atau PDF.');
            $type=in_array($types[$index]??'other',['ktp','kk','other'],true)?$types[$index]:'other';$target=WRITEPATH.'uploads'.DIRECTORY_SEPARATOR.'residents'.DIRECTORY_SEPARATOR.$residentId;if(!is_dir($target))mkdir($target,0775,true);$name=$file->getRandomName();$original=$file->getClientName();$mime=$file->getMimeType();$size=$file->getSize();$file->move($target,$name);
            db_connect()->table('resident_documents')->insert(['resident_id'=>$residentId,'document_type'=>$type,'original_name'=>$original,'file_path'=>'uploads/residents/'.$residentId.'/'.$name,'mime_type'=>$mime,'file_size'=>$size,'remark'=>trim((string)($remarks[$index]??''))?:null,'created_at'=>date('Y-m-d H:i:s')]);
        }
    }

    private function buildMenuTree(array $rows,?int $parentId=null): array
    {
        $branch=[];
        foreach($rows as $row){
            $rowParent=$row['parent_id']===null?null:(int)$row['parent_id'];
            if($rowParent===$parentId){
                $row['children']=$this->buildMenuTree($rows,(int)$row['id']);
                $branch[]=$row;
            }
        }
        return $branch;
    }

    private function menuParentOptions(array $nodes,int $excludeId,int $depth=0): array
    {
        $options=[];
        foreach($nodes as $node){
            if((int)$node['id']===$excludeId)continue;
            $options[]=['value'=>$node['id'],'label'=>str_repeat('— ',$depth).$node['name']];
            $options=[...$options,...$this->menuParentOptions($node['children']??[],$excludeId,$depth+1)];
        }
        return $options;
    }

    private function normalizeEmailList(string $value): array
    {
        $emails=array_values(array_unique(array_filter(array_map('trim',explode(',',$value)))));
        if(!$emails)return ['valid'=>$value===''||trim($value)==='','emails'=>[]];
        foreach($emails as $email)if(!filter_var($email,FILTER_VALIDATE_EMAIL))return ['valid'=>false,'emails'=>$emails];
        return ['valid'=>true,'emails'=>$emails];
    }
}
