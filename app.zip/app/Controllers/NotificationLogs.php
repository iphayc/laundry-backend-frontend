<?php
namespace App\Controllers;

class NotificationLogs extends BaseController
{
    public function index()
    {
        $from=(string)($this->request->getGet('from')?:date('Y-m-01'));$to=(string)($this->request->getGet('to')?:date('Y-m-d'));
        $channel=(string)$this->request->getGet('channel');$status=(string)$this->request->getGet('status');
        $builder=db_connect()->table('notification_logs')->where('deleted_at',null)->where('last_attempt_at >=',$from.' 00:00:00')->where('last_attempt_at <=',$to.' 23:59:59');
        if(in_array($channel,['email','whatsapp'],true))$builder->where('channel',$channel);
        if(in_array($status,['sent','failed'],true))$builder->where('status',$status);
        $rows=$builder->orderBy('last_attempt_at','DESC')->get()->getResultArray();
        return view('reports/notification_logs',['title'=>'Log Email & WhatsApp','rows'=>$rows,'from'=>$from,'to'=>$to,'channel'=>$channel,'status'=>$status]);
    }

    public function resend(int $id)
    {
        $log=db_connect()->table('notification_logs')->where('id',$id)->where('deleted_at',null)->get()->getRowArray();
        if(!$log)return redirect()->back()->with('error','Log pengiriman tidak ditemukan.');
        if($log['status']!=='failed')return redirect()->back()->with('warning','Hanya pengiriman gagal yang dapat dikirim ulang.');
        if($log['channel']==='email'){
            $attachment=$log['attachment_path']&&is_file($log['attachment_path'])?$log['attachment_path']:null;
            $ok=(new \App\Services\NotificationService())->email($this->split($log['recipient']),(string)$log['subject'],$log['message'],$attachment,$this->split((string)$log['cc']),$id);
        }else{
            $service=new \App\Services\WhatsAppService();
            $result=$log['media_url']?$service->sendImage($log['recipient'],$log['media_url'],$log['message'],$id):$service->send($log['recipient'],$log['message'],$id);$ok=$result['success'];
        }
        return redirect()->back()->with($ok?'success':'error',$ok?'Pengiriman ulang berhasil.':'Pengiriman ulang masih gagal. Periksa kolom error message.');
    }

    private function split(string $value): array{return array_values(array_filter(array_map('trim',explode(',',$value))));}
}
