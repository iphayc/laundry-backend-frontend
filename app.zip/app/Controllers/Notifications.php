<?php
namespace App\Controllers;
class Notifications extends BaseController
{
    public function index(){return $this->response->setJSON(db_connect()->table('notifications')->where('deleted_at',null)->whereIn('status',['pending','sent'])->orderBy('created_at','DESC')->limit(20)->get()->getResultArray());}
}
