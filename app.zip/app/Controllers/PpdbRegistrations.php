<?php
namespace App\Controllers;

use App\Models\PpdbRegistrationModel;

class PpdbRegistrations extends BaseController
{
    public function index()
    {
        $rows=db_connect()->table('ppdb_registrations r')->select('r.*,a.name academic_year,COALESCE(SUM(CASE WHEN p.status IN ("paid","partial_refund","refunded") AND p.deleted_at IS NULL THEN p.amount ELSE 0 END),0) paid_amount',false)->join('academic_years a','a.id=r.academic_year_id')->join('ppdb_payments p','p.registration_id=r.id','left')->where('r.deleted_at',null)->groupBy('r.id')->orderBy('r.registration_date','DESC')->orderBy('r.id','DESC')->get()->getResultArray();
        return view('ppdb/registrations/index',['title'=>'PPDB - Pendaftaran','rows'=>$rows]);
    }
    public function form(?int $id=null)
    {
        $row=$id?(new PpdbRegistrationModel())->find($id):[];if($id&&!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Pendaftaran tidak ditemukan.');
        $years=db_connect()->table('academic_years')->select('id,name')->where('active',1)->where('deleted_at',null)->orderBy('start_date','DESC')->get()->getResultArray();
        return view('ppdb/registrations/form',['title'=>($id?'Edit':'Tambah').' Pendaftaran PPDB','row'=>$row,'years'=>$years]);
    }
    public function save()
    {
        $id=(int)$this->request->getPost('id');$model=new PpdbRegistrationModel();$existing=$id?$model->find($id):[];
        $data=['academic_year_id'=>(int)$this->request->getPost('academic_year_id'),'registration_date'=>$this->request->getPost('registration_date'),'target_grade'=>trim((string)$this->request->getPost('target_grade')),'full_name'=>trim((string)$this->request->getPost('full_name')),'nickname'=>trim((string)$this->request->getPost('nickname'))?:null,'nisn'=>trim((string)$this->request->getPost('nisn'))?:null,'nik'=>trim((string)$this->request->getPost('nik'))?:null,'birth_place'=>trim((string)$this->request->getPost('birth_place'))?:null,'birth_date'=>$this->request->getPost('birth_date')?:null,'gender'=>(string)$this->request->getPost('gender'),'religion'=>trim((string)$this->request->getPost('religion'))?:null,'previous_school'=>trim((string)$this->request->getPost('previous_school'))?:null,'address'=>trim((string)$this->request->getPost('address'))?:null,'city'=>trim((string)$this->request->getPost('city'))?:null,'postal_code'=>trim((string)$this->request->getPost('postal_code'))?:null,'phone'=>trim((string)$this->request->getPost('phone'))?:null,'email'=>trim((string)$this->request->getPost('email'))?:null,'father_name'=>trim((string)$this->request->getPost('father_name'))?:null,'mother_name'=>trim((string)$this->request->getPost('mother_name'))?:null,'guardian_name'=>trim((string)$this->request->getPost('guardian_name'))?:null,'parent_phone'=>trim((string)$this->request->getPost('parent_phone')),'parent_email'=>trim((string)$this->request->getPost('parent_email'))?:null,'registration_fee'=>(float)$this->request->getPost('registration_fee'),'status'=>(string)$this->request->getPost('status'),'notes'=>trim((string)$this->request->getPost('notes'))?:null,'updated_by'=>(int)session('user_id')];
        if(!$data['academic_year_id']||!$data['registration_date']||!$data['target_grade']||!$data['full_name']||!$data['parent_phone'])return redirect()->back()->withInput()->with('error','Tahun akademik, tanggal, tingkat tujuan, nama siswa, dan telepon orang tua wajib diisi.');
        if(!in_array($data['gender'],['male','female'],true)||!in_array($data['status'],['draft','submitted','verified','accepted','rejected','cancelled'],true))return redirect()->back()->withInput()->with('error','Gender atau status tidak valid.');
        if(($data['email']&&!filter_var($data['email'],FILTER_VALIDATE_EMAIL))||($data['parent_email']&&!filter_var($data['parent_email'],FILTER_VALIDATE_EMAIL)))return redirect()->back()->withInput()->with('error','Format email tidak valid.');
        if(!db_connect()->table('academic_years')->where('id',$data['academic_year_id'])->where('deleted_at',null)->countAllResults())return redirect()->back()->withInput()->with('error','Tahun akademik tidak ditemukan.');
        if(!$id){$data['registration_no']='REG-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));$data['created_by']=(int)session('user_id');}
        $ok=$id?$model->update($id,$data):$model->insert($data);return redirect()->to('/ppdb/registrations')->with($ok?'success':'error',$ok?'Pendaftaran berhasil disimpan.':'Pendaftaran gagal disimpan.');
    }
    public function delete(int $id)
    {
        if(db_connect()->table('ppdb_payments')->where('registration_id',$id)->where('deleted_at',null)->countAllResults()||db_connect()->table('ppdb_admissions')->where('registration_id',$id)->where('deleted_at',null)->countAllResults())return redirect()->back()->with('warning','Pendaftaran yang sudah memiliki pembayaran atau penerimaan tidak dapat diarsipkan.');
        return redirect()->back()->with((new PpdbRegistrationModel())->delete($id)?'success':'error','Pendaftaran dipindahkan ke arsip.');
    }
    public function document(int $id){$row=db_connect()->table('ppdb_registrations')->where('id',$id)->where('deleted_at',null)->get()->getRowArray();if(!$row||!$row['form_document'])throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Dokumen formulir tidak ditemukan.');$path=WRITEPATH.str_replace(['/', '\\'],DIRECTORY_SEPARATOR,$row['form_document']);if(!is_file($path))throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('File formulir tidak ditemukan.');return $this->response->setHeader('Content-Type',mime_content_type($path)?:'application/octet-stream')->setHeader('Content-Disposition','inline; filename="'.basename($path).'"')->setBody(file_get_contents($path));}
}
