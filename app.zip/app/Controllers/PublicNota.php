<?php
namespace App\Controllers;

use CodeIgniter\Exceptions\PageNotFoundException;

class PublicNota extends BaseController
{
    public function show(string $token)
    {
        try {
            $raw = base64_decode(strtr($token, '-_', '+/'), true);
            if ($raw === false) throw new \RuntimeException('Invalid token');
            $plain = service('encrypter')->decrypt($raw);
            $invoice = trim((string)$plain);
            if ($invoice === '') throw new \RuntimeException('Invalid invoice');
            $db=db_connect();
            $order=$db->table('ex_orders o')
                ->select('o.*,c.name customer_name,c.phone customer_phone,c.email customer_email,b.name branch_name,u.fullname cashier_name,co.company_name,co.owner_name,co.address,co.phone company_phone,co.email company_email,co.logo company_logo,co.receipt_footer')
                ->join('ex_customers c','c.id=o.customer_id','left')
                ->join('ex_branches b','b.id=o.branch_id','left')
                ->join('ex_users u','u.id=o.created_by','left')
                ->join('ex_companies co','co.id=o.company_id','left')
                ->where('o.invoice_number',$invoice)->where('o.deleted_at',null)->where('o.status !=','CANCELLED')->get()->getRowArray();
            if(!$order) throw PageNotFoundException::forPageNotFound('Nota tidak ditemukan.');
            $items=$db->table('ex_order_items')->where('order_id',$order['id'])->orderBy('id')->get()->getResultArray();
            $order['items']=$items;
            return view('public/nota',['title'=>'Nota '.$invoice,'order'=>$order]);
        } catch (PageNotFoundException $e) { throw $e; }
          catch (\Throwable $e) { throw PageNotFoundException::forPageNotFound('Nota tidak ditemukan atau link tidak valid.'); }
    }
}
