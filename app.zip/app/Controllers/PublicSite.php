<?php
namespace App\Controllers;

class PublicSite extends BaseController
{
    private function shared(string $title):array{return ['title'=>$title,'company'=>$this->companyProfile];}
    public function home(){return view('public/home',$this->shared('Home')+['packages'=>$this->packageRows(3),'guides'=>db_connect()->table('ex_mobile_guides')->where('is_active',1)->where('deleted_at',null)->orderBy('sort_order')->limit(6)->get()->getResultArray()]);}
    public function guides(){$q=trim((string)$this->request->getGet('q'));$b=db_connect()->table('ex_mobile_guides')->where('is_active',1)->where('deleted_at',null);if($q!=='')$b->groupStart()->like('title',$q)->orLike('category',$q)->orLike('content',$q)->groupEnd();return view('public/guides',$this->shared('Panduan Mobile')+['rows'=>$b->orderBy('sort_order')->get()->getResultArray(),'q'=>$q]);}
    public function profile(){return view('public/profile',$this->shared('Profil Eksis Laundry'));}
    public function packages(){return view('public/packages',$this->shared('Paket')+['packages'=>$this->packageRows()]);}
    public function registration(){return view('public/registration',$this->shared('Pendaftaran PPDB'));}
    public function news(){return view('public/news',$this->shared('Berita')+['rows'=>db_connect()->table('cms_posts')->where('type','news')->where('active',1)->where('deleted_at',null)->orderBy('published_at','DESC')->get()->getResultArray()]);}
    public function newsDetail(string $slug){$row=db_connect()->table('cms_posts')->where('slug',$slug)->where('type','news')->where('active',1)->where('deleted_at',null)->get()->getRowArray();if(!$row)throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Berita tidak ditemukan.');return view('public/news_detail',$this->shared($row['title'])+['row'=>$row]);}
    public function contact(){if($this->request->getMethod()==='POST'){session()->setFlashdata('success','Pesan Anda telah diterima. Tim Eksis Laundry akan segera menghubungi Anda.');return redirect()->to('/kontak');}return view('public/contact',$this->shared('Kontak'));}
    private function packageRows(?int $limit=null):array{$builder=db_connect()->table('ex_packages')->where('is_active',1)->where('deleted_at',null)->orderBy('sort_order');if($limit)$builder->limit($limit);return $builder->get()->getResultArray();}
}
