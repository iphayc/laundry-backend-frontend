<?php
namespace App\Controllers;

use App\Services\LicenseService;
use App\Services\NotificationService;

class Registration extends BaseController
{
    public function index()
    {
        helper('form');
        $db = db_connect();
        $license = new LicenseService();
        $tableAvailable = $db->tableExists('application_registration');
        $registration = $tableAvailable
            ? ($db->table('application_registration')->orderBy('id','DESC')->get()->getRowArray() ?? [])
            : [];
        $isValid = $license->registrationIsValid($registration);

        if ($this->request->getMethod() === 'POST') {
            if (! $tableAvailable) {
                return redirect()->back()->withInput()
                    ->with('error', 'Penyimpanan lisensi belum dipasang oleh administrator.');
            }

            $email = strtolower(trim((string) $this->request->getPost('email')));
            $code = strtoupper(trim((string) $this->request->getPost('code')));
            $expectedCode = $license->activationCode($email);

            if (! $registration
                || ! hash_equals(strtolower($registration['registered_email']), $email)
                || ! hash_equals($expectedCode, $code)) {
                return redirect()->back()->withInput()->with('error','Email atau kode registrasi tidak valid untuk komputer ini.');
            }

            $db->table('application_registration')->where('id',$registration['id'])->update([
                'machine_id_hash' => $license->machineFingerprint(),
                'license_code_hash' => password_hash($expectedCode, PASSWORD_DEFAULT),
                'license_code_encrypted' => base64_encode(service('encrypter')->encrypt($expectedCode)),
                'active' => 1,
                'activated_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return redirect()->to('/aEZGxhfPkA')->with('success','Registrasi aplikasi berhasil. Silakan login.');
        }

        return view('registration/index', [
            'registration' => $registration,
            'isValid' => $isValid,
            'machineId' => $license->machineId(),
        ]);
    }

    public function sendCode()
    {
        $db = db_connect();
        if (! $db->tableExists('application_registration')) {
            return redirect()->back()->with('error', 'Penyimpanan lisensi belum dipasang oleh administrator.');
        }
        $registration = $db->table('application_registration')->orderBy('id','DESC')->get()->getRowArray();
        $email = strtolower(trim((string) $this->request->getPost('email')));

        if (! $registration || ! hash_equals(strtolower($registration['registered_email']), $email)) {
            return redirect()->back()->with('error','Email tidak terdaftar.');
        }

        if ($registration['last_code_sent_at'] && time() - strtotime($registration['last_code_sent_at']) < 60) {
            return redirect()->back()->with('warning','Tunggu minimal 60 detik sebelum meminta kode kembali.');
        }

        $license = new LicenseService();
        $code = $license->activationCode($email);
        $machineId = $license->machineId();
        $body = '<p>Permintaan aktivasi aplikasi diterima.</p>'
            . '<p>Machine ID:</p><p><code>' . esc($machineId) . '</code></p>'
            . '<p>Kode aktivasi:</p><h2>' . esc($code) . '</h2>'
            . '<p>Kode hanya berlaku untuk Machine ID dan email ini. Jangan bagikan kepada pihak lain.</p>';
        $ok = (new NotificationService())->email($email, 'Kode Aktivasi Aplikasi', $body);
        if($ok)$db->table('application_registration')->where('id',$registration['id'])->update(['last_code_sent_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
        return redirect()->back()->with($ok?'success':'error',$ok?'Kode registrasi berhasil dikirim ke email terdaftar.':'Kode gagal dikirim. Periksa Setting SMTP dan Log Email.');
    }
}
