<?php
namespace App\Controllers;
class Reports extends BaseController
{
    public function index(){return view('reports/index',['title'=>'Laporan Trafik']);}
    public function data()
    {
        $from=$this->request->getGet('from')?:date('Y-m-01');$to=$this->request->getGet('to')?:date('Y-m-d');
        $rows=$this->reportRows($from,$to);
        return $this->response->setJSON(['data'=>$rows]);
    }

    public function email()
    {
        $db=db_connect();$from=(string)($this->request->getGet('from')?:$this->request->getPost('from')?:date('Y-m-01'));$to=(string)($this->request->getGet('to')?:$this->request->getPost('to')?:date('Y-m-d'));
        $recipients=$db->table('email_recipients')->where('active',1)->where('deleted_at',null)->orderBy('name')->get()->getResultArray();
        $smtpReady=$db->table('email_smtp_settings')->where('active',1)->where('deleted_at',null)->countAllResults()>0;
        if($this->request->getMethod()==='POST'){
            $ids=array_map('intval',(array)$this->request->getPost('recipient_ids'));
            if(!$ids)return redirect()->back()->withInput()->with('error','Pilih minimal satu penerima email.');
            if(!$smtpReady)return redirect()->to('/settings/email')->with('error','Konfigurasi SMTP aktif belum tersedia.');
            $selected=$db->table('email_recipients')->whereIn('id',$ids)->where('active',1)->where('deleted_at',null)->get()->getResultArray();
            if(!$selected)return redirect()->back()->with('error','Penerima email tidak ditemukan.');
            $rows=$this->reportRows($from,$to);$dir=WRITEPATH.'reports';
            if(!is_dir($dir))mkdir($dir,0775,true);
            $file=$dir.DIRECTORY_SEPARATOR.'laporan-trafik-'.$from.'-'.$to.'-'.date('His').'.csv';
            $handle=fopen($file,'wb');fwrite($handle,"\xEF\xBB\xBF");fputcsv($handle,['Waktu','Gate','Kartu','Subjek','Kendaraan','Nopol','Arah','Hasil','Keterangan']);
            foreach($rows as $row)fputcsv($handle,[$row['event_time'],$row['gate_name'],$row['card_no'],$row['subject_type'],$row['vehicle_type'],$row['plate_no'],$row['direction'],$row['result'],$row['reason']]);
            fclose($handle);
            $addresses=[];$ccAddresses=[];
            foreach($selected as $recipient){
                $addresses=[...$addresses,...$this->splitEmails((string)$recipient['email'])];
                $ccAddresses=[...$ccAddresses,...$this->splitEmails((string)($recipient['cc']??''))];
            }
            $addresses=array_values(array_unique($addresses));$ccAddresses=array_values(array_diff(array_unique($ccAddresses),$addresses));
            $subject="Laporan Trafik Residence One {$from} s/d {$to}";
            $message="<h2>Laporan Trafik Residence One</h2><p>Periode: <strong>".esc($from)." sampai ".esc($to)."</strong></p><p>Total data: <strong>".count($rows)."</strong>. Detail laporan terlampir dalam format CSV yang dapat dibuka di Excel.</p>";
            $sent=(new \App\Services\NotificationService())->email($addresses,$subject,$message,$file,$ccAddresses);
            if($sent)@unlink($file);
            if(!$sent)return redirect()->back()->withInput()->with('error','Email gagal dikirim. Periksa konfigurasi SMTP dan log aplikasi.');
            $db->table('audit_logs')->insert(['user_id'=>session('user_id'),'action'=>'EMAIL_REPORT','table_name'=>'access_logs','record_id'=>$from.'_'.$to,'new_data'=>json_encode(['recipients'=>$addresses,'cc'=>$ccAddresses,'rows'=>count($rows)]),'ip_address'=>$this->request->getIPAddress(),'created_at'=>date('Y-m-d H:i:s')]);
            return redirect()->to('/reports?from='.$from.'&to='.$to)->with('success','Laporan berhasil dikirim ke '.count($addresses).' penerima.');
        }
        return view('reports/email',['title'=>'Email Laporan Trafik','from'=>$from,'to'=>$to,'recipients'=>$recipients,'smtpReady'=>$smtpReady]);
    }

    private function reportRows(string $from,string $to): array
    {
        return db_connect()->table('access_logs l')->select('l.event_time,l.card_no,l.subject_type,l.plate_no,l.direction,l.result,l.reason,g.name gate_name,vt.name vehicle_type')->join('gates g','g.id=l.gate_id')->join('vehicle_types vt','vt.id=l.vehicle_type_id','left')->where('l.deleted_at',null)->where('l.event_time >=',$from.' 00:00:00')->where('l.event_time <=',$to.' 23:59:59')->orderBy('l.event_time','DESC')->get()->getResultArray();
    }

    private function splitEmails(string $value): array
    {
        return array_values(array_filter(array_map('trim',explode(',',$value)),fn($email)=>filter_var($email,FILTER_VALIDATE_EMAIL)));
    }
}
