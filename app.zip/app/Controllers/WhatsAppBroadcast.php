<?php
namespace App\Controllers;

class WhatsAppBroadcast extends BaseController
{
    public function index()
    {
        helper('form');
        $db=db_connect();$residents=$db->table('residents r')->select("r.id,r.name,r.gender,r.email,r.phone,u.unit_no,c.name cluster_name")->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->where('r.deleted_at',null)->where('r.phone IS NOT NULL',null,false)->where('r.phone !=','')->orderBy('r.name')->get()->getResultArray();
        $templates=$db->table('notification_templates')->whereIn('type',['whatsapp','both'])->where('status','active')->where('deleted_at',null)->orderBy('template_name')->get()->getResultArray();
        $waReady=$db->table('whatsapp_providers')->where('is_default',1)->where('active',1)->where('deleted_at',null)->countAllResults()>0;
        return view('transactions/whatsapp',['title'=>'Kirim WhatsApp Penghuni','residents'=>$residents,'templates'=>$templates,'waReady'=>$waReady]);
    }

    public function send()
    {
        $ids=array_values(array_unique(array_map('intval',(array)$this->request->getPost('resident_ids'))));$subject=trim((string)$this->request->getPost('subject'));$message=trim((string)$this->request->getPost('message'));
        if(!$ids)return redirect()->back()->withInput()->with('warning','Pilih minimal satu penghuni.');
        if(count($ids)>20)return redirect()->back()->withInput()->with('error','Maksimal pengiriman adalah 20 penghuni dalam satu transaksi.');
        if($subject===''||$message==='')return redirect()->back()->withInput()->with('warning','Judul dan isi pesan wajib diisi.');
        $rows=db_connect()->table('residents r')->select('r.id,r.name,r.gender,r.email,r.phone,u.unit_no,c.name cluster_name')->join('units u','u.id=r.unit_id AND u.deleted_at IS NULL','left')->join('clusters c','c.id=u.cluster_id AND c.deleted_at IS NULL','left')->whereIn('r.id',$ids)->where('r.deleted_at',null)->where('r.phone IS NOT NULL',null,false)->where('r.phone !=','')->get()->getResultArray();
        if(count($rows)!==count($ids))return redirect()->back()->withInput()->with('error','Sebagian penghuni tidak ditemukan atau belum memiliki nomor WhatsApp.');
        $imageUrl=null;
        $attachmentSource=(string)$this->request->getPost('attachment_source');
        if(!in_array($attachmentSource,['none','upload','url'],true))$attachmentSource='none';
        $file=$this->request->getFile('attachment');
        if($attachmentSource==='url'){
            $imageUrl=trim((string)$this->request->getPost('image_url'));
            if($imageUrl===''||!$this->isPublicImageUrl($imageUrl)){
                return redirect()->back()->withInput()->with('warning','URL gambar wajib berupa alamat HTTP/HTTPS publik. URL localhost, loopback, dan jaringan lokal tidak dapat dipakai.');
            }
        }elseif($attachmentSource==='upload'){
            if(!$file||$file->getError()===UPLOAD_ERR_NO_FILE)return redirect()->back()->withInput()->with('warning','Pilih file gambar yang akan diunggah.');
            if(!$file->isValid())return redirect()->back()->withInput()->with('error','Lampiran gagal diunggah.');
            if($file->getSize()>5*1024*1024)return redirect()->back()->withInput()->with('error','Lampiran maksimal 5 MB.');
            if(!in_array($file->getMimeType(),['image/jpeg','image/png','image/webp'],true))return redirect()->back()->withInput()->with('error','Lampiran WhatsApp harus berupa JPG, PNG, atau WebP.');
            if(!$this->isPublicImageUrl(base_url('uploads/whatsapp-attachments/test.jpg'))){
                return redirect()->back()->withInput()->with('warning','Aplikasi masih memakai alamat localhost/jaringan lokal. File upload tidak dapat diambil oleh gateway WhatsApp; gunakan opsi URL Publik.');
            }
            $relative='uploads/whatsapp-attachments/'.date('Y/m');$directory=FCPATH.str_replace('/',DIRECTORY_SEPARATOR,$relative);if(!is_dir($directory))mkdir($directory,0775,true);
            $filename=$file->getRandomName();$file->move($directory,$filename);$imageUrl=base_url($relative.'/'.$filename);
        }
        $renderer=new \App\Services\MessageTemplateService();$service=new \App\Services\WhatsAppService();$sent=0;$failed=0;
        foreach($rows as $row){$personalSubject=$renderer->render($subject,$row);$personalMessage=$renderer->render($message,$row);$sendResult=$imageUrl?$service->sendImage($row['phone'],$imageUrl,$personalMessage,null,$personalSubject):$service->send($row['phone'],$personalMessage,null,$personalSubject);$sendResult['success']?$sent++:$failed++;}
        $result=compact('sent','failed');
        $flashType=$result['failed']===0?'success':($result['sent']>0?'warning':'error');
        return redirect()->to('/reports/notifications?channel=whatsapp&status='.($result['failed']?'failed':'sent'))->with($flashType,"Pengiriman selesai: {$result['sent']} berhasil, {$result['failed']} gagal.");
    }

    private function isPublicImageUrl(string $url): bool
    {
        if(filter_var($url,FILTER_VALIDATE_URL)===false)return false;
        $parts=parse_url($url);
        if(!in_array(strtolower((string)($parts['scheme']??'')),['http','https'],true))return false;
        $host=strtolower(trim((string)($parts['host']??''),'[]'));
        if($host===''||$host==='localhost'||str_ends_with($host,'.localhost')||str_ends_with($host,'.local'))return false;
        if(filter_var($host,FILTER_VALIDATE_IP)!==false){
            return filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)!==false;
        }
        return str_contains($host,'.');
    }
}
