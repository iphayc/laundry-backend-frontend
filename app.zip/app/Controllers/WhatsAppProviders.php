<?php
namespace App\Controllers;

use App\Models\WhatsAppProviderModel;

class WhatsAppProviders extends BaseController
{
    public function index()
    {
        return view('settings/whatsapp_providers/index', [
            'title' => 'WhatsApp Provider',
            'rows' => (new WhatsAppProviderModel())->orderBy('is_default', 'DESC')->orderBy('name')->findAll(),
        ]);
    }

    public function form(?int $id=null)
    {
        $row = $id ? (new WhatsAppProviderModel())->find($id) : [];
        if ($id && ! $row) return redirect()->to('/master/whatsapp-providers')->with('error', 'Provider WhatsApp tidak ditemukan.');
        return view('settings/whatsapp_providers/form', ['title'=>$id?'Edit WhatsApp Provider':'Tambah WhatsApp Provider','row'=>$row]);
    }

    public function save()
    {
        $id = (int) $this->request->getPost('id');
        $code = strtolower(trim((string) $this->request->getPost('code')));
        $data = [
            'code' => preg_replace('/[^a-z0-9_-]/', '', $code),
            'name' => trim((string) $this->request->getPost('name')),
            'auth_type' => (string) $this->request->getPost('auth_type'),
            'default_url_text' => trim((string) $this->request->getPost('default_url_text')) ?: null,
            'default_url_image' => trim((string) $this->request->getPost('default_url_image')) ?: null,
            'number_key' => trim((string) $this->request->getPost('number_key')) ?: null,
            'phone_number_id' => trim((string) $this->request->getPost('phone_number_id')) ?: null,
            'phone_number' => preg_replace('/\D/', '', (string) $this->request->getPost('phone_number')) ?: null,
            'graph_version' => trim((string) $this->request->getPost('graph_version')) ?: 'v25.0',
            'is_default' => (int) $this->request->getPost('is_default'),
            'active' => (int) $this->request->getPost('active'),
        ];
        if ($data['code']==='' || $data['name']==='') return redirect()->back()->withInput()->with('warning', 'Kode dan nama provider wajib diisi.');
        if (! in_array($data['auth_type'], ['token','api_key_number_key','meta_official','custom'], true)) return redirect()->back()->withInput()->with('error', 'Jenis autentikasi tidak valid.');
        foreach (['default_url_text','default_url_image'] as $field) if ($data[$field] && ! filter_var($data[$field], FILTER_VALIDATE_URL)) return redirect()->back()->withInput()->with('error', 'URL bawaan provider tidak valid.');
        if ($data['is_default']) $data['active'] = 1;

        $model = new WhatsAppProviderModel();
        $existing=$id?$model->find($id):[];
        $token=trim((string)$this->request->getPost('token'));$apiKey=(string)$this->request->getPost('api_key');
        if($token!=='')$data['token_encrypted']=base64_encode(service('encrypter')->encrypt($token));
        if($apiKey!=='')$data['api_key_encrypted']=base64_encode(service('encrypter')->encrypt($apiKey));
        if(in_array($data['auth_type'],['token','meta_official'],true)&&$token===''&&empty($existing['token_encrypted']))return redirect()->back()->withInput()->with('warning','Token wajib diisi untuk jenis autentikasi ini.');
        if($data['auth_type']==='api_key_number_key'&&$apiKey===''&&empty($existing['api_key_encrypted']))return redirect()->back()->withInput()->with('warning','API Key wajib diisi.');
        if($data['auth_type']==='api_key_number_key'&&!$data['number_key'])return redirect()->back()->withInput()->with('warning','Number Key wajib diisi.');
        if($data['auth_type']==='meta_official'&&!$data['phone_number_id'])return redirect()->back()->withInput()->with('warning','Phone Number ID Meta wajib diisi.');
        if($data['auth_type']==='meta_official'&&!preg_match('/^\d+$/',(string)$data['phone_number_id']))return redirect()->back()->withInput()->with('warning','Phone Number ID Meta hanya boleh berisi angka.');
        if($data['auth_type']==='meta_official'&&!preg_match('/^v\d+\.\d+$/',(string)$data['graph_version']))return redirect()->back()->withInput()->with('warning','Versi Graph API harus seperti v25.0.');
        if ($model->withDeleted()->where('code', $data['code'])->where('id !=', $id ?: 0)->first()) return redirect()->back()->withInput()->with('error', 'Kode provider sudah digunakan.');
        $db = db_connect();
        $db->transStart();
        if ($data['is_default']) $db->table('whatsapp_providers')->where('deleted_at', null)->update(['is_default'=>0,'updated_at'=>date('Y-m-d H:i:s')]);
        $id ? $model->update($id, $data) : $id = (int) $model->insert($data, true);
        if (! $db->table('whatsapp_providers')->where('deleted_at', null)->where('is_default', 1)->countAllResults()) $db->table('whatsapp_providers')->where('id', $id)->update(['is_default'=>1,'active'=>1]);
        $db->transComplete();
        return redirect()->to('/master/whatsapp-providers')->with($db->transStatus()?'success':'error', $db->transStatus()?'Provider WhatsApp berhasil disimpan.':'Provider WhatsApp gagal disimpan.');
    }

    public function setDefault(int $id)
    {
        $model = new WhatsAppProviderModel();$row = $model->find($id);
        if (! $row) return redirect()->back()->with('error', 'Provider WhatsApp tidak ditemukan.');
        $db=db_connect();$db->transStart();
        $db->table('whatsapp_providers')->where('deleted_at', null)->update(['is_default'=>0,'updated_at'=>date('Y-m-d H:i:s')]);
        $db->table('whatsapp_providers')->where('id', $id)->update(['is_default'=>1,'active'=>1,'updated_at'=>date('Y-m-d H:i:s')]);
        $db->transComplete();
        return redirect()->to('/master/whatsapp-providers')->with($db->transStatus()?'success':'error', $db->transStatus()?$row['name'].' menjadi provider default.':'Provider default gagal diubah.');
    }

    public function delete(int $id)
    {
        $model=new WhatsAppProviderModel();$row=$model->find($id);
        if (! $row) return redirect()->back()->with('error','Provider WhatsApp tidak ditemukan.');
        if ((int)$row['is_default']===1) return redirect()->back()->with('warning','Provider default tidak dapat dihapus. Pilih provider default lain terlebih dahulu.');
        $model->delete($id);
        return redirect()->to('/master/whatsapp-providers')->with('success','Provider WhatsApp berhasil dihapus.');
    }
}
