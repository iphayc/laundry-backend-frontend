<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateParkingSchema extends Migration
{
    public function up()
    {
        $sql = [
"CREATE TABLE roles (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL UNIQUE, description VARCHAR(255), created_at DATETIME NULL, updated_at DATETIME NULL)",
"CREATE TABLE groups (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, parent_id INT UNSIGNED NULL, name VARCHAR(100) NOT NULL, description VARCHAR(255), created_at DATETIME NULL, updated_at DATETIME NULL, INDEX(parent_id))",
"CREATE TABLE permissions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(100) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, module VARCHAR(80) NOT NULL)",
"CREATE TABLE role_permissions (role_id INT UNSIGNED NOT NULL, permission_id INT UNSIGNED NOT NULL, PRIMARY KEY(role_id,permission_id))",
"CREATE TABLE users (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, role_id INT UNSIGNED NOT NULL, group_id INT UNSIGNED NULL, username VARCHAR(60) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, email VARCHAR(160), phone VARCHAR(30), password_hash VARCHAR(255) NOT NULL, active TINYINT(1) DEFAULT 1, last_login DATETIME NULL, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL, INDEX(role_id), INDEX(group_id))",
"CREATE TABLE clusters (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(30) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, address VARCHAR(255), active TINYINT(1) DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL)",
"CREATE TABLE units (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, cluster_id INT UNSIGNED NOT NULL, unit_no VARCHAR(40) NOT NULL, owner_name VARCHAR(120), phone VARCHAR(30), active TINYINT(1) DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL, UNIQUE(cluster_id,unit_no), INDEX(cluster_id))",
"CREATE TABLE gates (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, cluster_id INT UNSIGNED NULL, code VARCHAR(30) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, gate_type ENUM('main','cluster') DEFAULT 'cluster', direction ENUM('in','out','both') DEFAULT 'both', device_code VARCHAR(80), active TINYINT(1) DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL)",
"CREATE TABLE vehicle_types (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(50) NOT NULL, active TINYINT(1) DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL)",
"CREATE TABLE residents (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, unit_id INT UNSIGNED NOT NULL, identity_no VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, phone VARCHAR(30), email VARCHAR(160), identity_image VARCHAR(255), suspended TINYINT(1) DEFAULT 0, suspension_note TEXT, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL, INDEX(unit_id))",
"CREATE TABLE vehicles (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, resident_id INT UNSIGNED NULL, vehicle_type_id INT UNSIGNED NOT NULL, plate_no VARCHAR(20) NOT NULL UNIQUE, brand VARCHAR(60), color VARCHAR(40), active TINYINT(1) DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL)",
"CREATE TABLE access_cards (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, resident_id INT UNSIGNED NULL, card_no VARCHAR(80) NOT NULL UNIQUE, card_type ENUM('resident','visitor') DEFAULT 'resident', status ENUM('active','inactive','lost','blocked') DEFAULT 'active', expires_at DATETIME NULL, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL)",
"CREATE TABLE visitors (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, identity_type ENUM('KTP','SIM','PASSPORT') DEFAULT 'KTP', identity_no VARCHAR(50), name VARCHAR(120) NOT NULL, phone VARCHAR(30), identity_image VARCHAR(255), blacklist TINYINT(1) DEFAULT 0, blacklist_note TEXT, created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL, INDEX(identity_no), INDEX(name))",
"CREATE TABLE visits (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, visitor_id INT UNSIGNED NOT NULL, unit_id INT UNSIGNED NOT NULL, access_card_id INT UNSIGNED NULL, vehicle_type_id INT UNSIGNED NULL, plate_no VARCHAR(20), visitor_card_no VARCHAR(80), purpose VARCHAR(255), check_in DATETIME NOT NULL, check_out DATETIME NULL, status ENUM('inside','completed','denied') DEFAULT 'inside', created_by INT UNSIGNED NULL, created_at DATETIME NULL, updated_at DATETIME NULL, INDEX(check_in), INDEX(check_out), INDEX(plate_no), INDEX(status))",
"CREATE TABLE access_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, card_no VARCHAR(80), subject_type ENUM('resident','visitor','pedestrian','unknown') NOT NULL, subject_id INT UNSIGNED NULL, visit_id BIGINT UNSIGNED NULL, gate_id INT UNSIGNED NOT NULL, direction ENUM('in','out') NOT NULL, vehicle_type_id INT UNSIGNED NULL, plate_no VARCHAR(20), event_time DATETIME NOT NULL, result ENUM('granted','denied') NOT NULL, reason VARCHAR(255), forced_suspended_trial TINYINT(1) DEFAULT 0, raw_payload JSON NULL, created_at DATETIME NULL, INDEX(event_time), INDEX(card_no), INDEX(result))",
"CREATE TABLE notifications (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, visit_id BIGINT UNSIGNED NULL, type VARCHAR(60) NOT NULL, title VARCHAR(160) NOT NULL, message TEXT NOT NULL, channel SET('popup','email','whatsapp') DEFAULT 'popup', status ENUM('pending','sent','read','failed') DEFAULT 'pending', sent_at DATETIME NULL, read_at DATETIME NULL, created_at DATETIME NULL, updated_at DATETIME NULL, INDEX(status))",
"CREATE TABLE settings (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT, description VARCHAR(255), updated_by INT UNSIGNED NULL, updated_at DATETIME NULL)",
"CREATE TABLE audit_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NULL, action VARCHAR(80) NOT NULL, table_name VARCHAR(80), record_id VARCHAR(50), old_data JSON NULL, new_data JSON NULL, ip_address VARCHAR(45), created_at DATETIME NULL, INDEX(created_at))"
        ];
        foreach ($sql as $query) $this->db->query($query);
    }

    public function down()
    {
        foreach (['audit_logs','settings','notifications','access_logs','visits','visitors','access_cards','vehicles','residents','vehicle_types','gates','units','clusters','users','role_permissions','permissions','groups','roles'] as $table) {
            $this->forge->dropTable($table, true);
        }
    }
}
