<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateDynamicMenus extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE menus (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            parent_id INT UNSIGNED NULL,
            name VARCHAR(100) NOT NULL,
            route VARCHAR(160) NULL,
            icon VARCHAR(80) DEFAULT 'far fa-circle',
            sort_order INT DEFAULT 0,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            INDEX(parent_id), INDEX(sort_order)
        )");
        $this->db->query("CREATE TABLE role_menus (
            role_id INT UNSIGNED NOT NULL,
            menu_id INT UNSIGNED NOT NULL,
            PRIMARY KEY(role_id,menu_id),
            INDEX(menu_id)
        )");

        $now=date('Y-m-d H:i:s');
        $menus=[
            ['id'=>1,'parent_id'=>null,'name'=>'Dashboard','route'=>'dashboard','icon'=>'fas fa-chart-pie','sort_order'=>10,'active'=>1,'created_at'=>$now],
            ['id'=>2,'parent_id'=>null,'name'=>'Data Master','route'=>null,'icon'=>'fas fa-database','sort_order'=>20,'active'=>1,'created_at'=>$now],
            ['id'=>3,'parent_id'=>2,'name'=>'Cluster','route'=>'master/clusters','icon'=>'far fa-circle','sort_order'=>21,'active'=>1,'created_at'=>$now],
            ['id'=>4,'parent_id'=>2,'name'=>'Unit','route'=>'master/units','icon'=>'far fa-circle','sort_order'=>22,'active'=>1,'created_at'=>$now],
            ['id'=>5,'parent_id'=>2,'name'=>'Gate','route'=>'master/gates','icon'=>'far fa-circle','sort_order'=>23,'active'=>1,'created_at'=>$now],
            ['id'=>6,'parent_id'=>2,'name'=>'Penghuni','route'=>'master/residents','icon'=>'far fa-circle','sort_order'=>24,'active'=>1,'created_at'=>$now],
            ['id'=>7,'parent_id'=>2,'name'=>'Kendaraan','route'=>'master/vehicles','icon'=>'far fa-circle','sort_order'=>25,'active'=>1,'created_at'=>$now],
            ['id'=>8,'parent_id'=>2,'name'=>'Kartu Akses','route'=>'master/cards','icon'=>'far fa-circle','sort_order'=>26,'active'=>1,'created_at'=>$now],
            ['id'=>9,'parent_id'=>2,'name'=>'Tamu / Blacklist','route'=>'master/visitors','icon'=>'far fa-circle','sort_order'=>27,'active'=>1,'created_at'=>$now],
            ['id'=>10,'parent_id'=>null,'name'=>'Gate Console','route'=>'gate','icon'=>'fas fa-id-card','sort_order'=>30,'active'=>1,'created_at'=>$now],
            ['id'=>11,'parent_id'=>null,'name'=>'Laporan','route'=>'reports','icon'=>'fas fa-file-export','sort_order'=>40,'active'=>1,'created_at'=>$now],
            ['id'=>12,'parent_id'=>null,'name'=>'Manajemen User','route'=>null,'icon'=>'fas fa-users-cog','sort_order'=>50,'active'=>1,'created_at'=>$now],
            ['id'=>13,'parent_id'=>12,'name'=>'User','route'=>'master/users','icon'=>'far fa-circle','sort_order'=>51,'active'=>1,'created_at'=>$now],
            ['id'=>14,'parent_id'=>12,'name'=>'Role & Group','route'=>'access-control','icon'=>'far fa-circle','sort_order'=>52,'active'=>1,'created_at'=>$now],
            ['id'=>15,'parent_id'=>12,'name'=>'Master Menu','route'=>'master/menus','icon'=>'far fa-circle','sort_order'=>53,'active'=>1,'created_at'=>$now],
        ];
        $this->db->table('menus')->insertBatch($menus);
        foreach($menus as $menu)$this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menu['id']]);
        foreach([1,2,3,4,5,6,7,8,9,10,11] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>2,'menu_id'=>$menuId]);
        foreach([1,2,6,7,8,9,10,11] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>3,'menu_id'=>$menuId]);
        foreach([1,11] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>4,'menu_id'=>$menuId]);
    }

    public function down()
    {
        $this->forge->dropTable('role_menus',true);
        $this->forge->dropTable('menus',true);
    }
}
