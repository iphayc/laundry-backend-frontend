<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class StandardizeSoftDeletes extends Migration
{
    private array $tables=['roles','groups','permissions','vehicle_types','menus','visits','access_logs','notifications','settings'];

    public function up()
    {
        foreach($this->tables as $table){
            if(!$this->db->fieldExists('deleted_at',$table)){
                $definition=['type'=>'DATETIME','null'=>true];
                if($this->db->fieldExists('updated_at',$table))$definition['after']='updated_at';
                elseif($this->db->fieldExists('created_at',$table))$definition['after']='created_at';
                $this->forge->addColumn($table,['deleted_at'=>$definition]);
                $this->db->query("CREATE INDEX idx_{$table}_deleted_at ON {$table} (deleted_at)");
            }
        }
    }

    public function down()
    {
        foreach($this->tables as $table){
            if($this->db->fieldExists('deleted_at',$table))$this->forge->dropColumn($table,'deleted_at');
        }
    }
}
