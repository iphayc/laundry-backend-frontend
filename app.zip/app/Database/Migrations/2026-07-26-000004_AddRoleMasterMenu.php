<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddRoleMasterMenu extends Migration
{
    public function up()
    {
        $parent=$this->db->table('menus')->select('id')->where('route',null)->where('name','Manajemen User')->where('deleted_at',null)->get()->getRowArray();
        if(!$parent)return;

        $existing=$this->db->table('menus')->where('route','master/roles')->where('deleted_at',null)->get()->getRowArray();
        if($existing){
            $menuId=(int)$existing['id'];
        }else{
            $this->db->table('menus')->insert([
                'parent_id'=>$parent['id'],
                'name'=>'Master Role',
                'route'=>'master/roles',
                'icon'=>'far fa-circle',
                'sort_order'=>52,
                'active'=>1,
                'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $menuId=(int)$this->db->insertID();
        }

        $adminRole=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        if($adminRole && !$this->db->table('role_menus')->where(['role_id'=>$adminRole['id'],'menu_id'=>$menuId])->countAllResults()){
            $this->db->table('role_menus')->insert(['role_id'=>$adminRole['id'],'menu_id'=>$menuId]);
        }
        $this->db->table('menus')->where('route','access-control')->update(['sort_order'=>53]);
        $this->db->table('menus')->where('route','master/menus')->update(['sort_order'=>54]);
    }

    public function down()
    {
        $menu=$this->db->table('menus')->select('id')->where('route','master/roles')->get()->getRowArray();
        if($menu){
            $this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
            $this->db->table('menus')->where('id',$menu['id'])->delete();
        }
    }
}
