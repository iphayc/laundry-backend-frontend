<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddEmailManagement extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE email_recipients (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(120) NOT NULL,
            email VARCHAR(160) NOT NULL,
            description VARCHAR(255) NULL,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(email), INDEX(deleted_at)
        )");
        $this->db->query("CREATE TABLE email_smtp_settings (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            account_name VARCHAR(100) NOT NULL,
            smtp_host VARCHAR(160) NOT NULL,
            smtp_port INT NOT NULL DEFAULT 587,
            smtp_user VARCHAR(160) NULL,
            smtp_password_encrypted TEXT NULL,
            smtp_crypto ENUM('tls','ssl','none') DEFAULT 'tls',
            from_email VARCHAR(160) NOT NULL,
            from_name VARCHAR(120) NOT NULL,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(active), INDEX(deleted_at)
        )");
        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if($parent){
            $now=date('Y-m-d H:i:s');
            $menus=[
                ['parent_id'=>$parent['id'],'name'=>'Penerima Email','route'=>'master/email-recipients','icon'=>'far fa-envelope','sort_order'=>28,'active'=>1,'created_at'=>$now],
                ['parent_id'=>$parent['id'],'name'=>'Setting SMTP','route'=>'settings/email','icon'=>'fas fa-mail-bulk','sort_order'=>29,'active'=>1,'created_at'=>$now],
            ];
            foreach($menus as $menu){
                $this->db->table('menus')->insert($menu);$menuId=(int)$this->db->insertID();
                $this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menuId]);
            }
        }
    }

    public function down()
    {
        $menus=$this->db->table('menus')->select('id')->whereIn('route',['master/email-recipients','settings/email'])->get()->getResultArray();
        foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
        $this->db->table('menus')->whereIn('route',['master/email-recipients','settings/email'])->delete();
        $this->forge->dropTable('email_smtp_settings',true);
        $this->forge->dropTable('email_recipients',true);
    }
}
