<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class GroupEmailMenus extends Migration
{
    public function up()
    {
        $dataMaster=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if(!$dataMaster)return;
        $settingEmail=$this->db->table('menus')->where('name','Setting Email')->where('deleted_at',null)->get()->getRowArray();
        if(!$settingEmail){
            $this->db->table('menus')->insert([
                'parent_id'=>$dataMaster['id'],'name'=>'Setting Email','route'=>null,
                'icon'=>'fas fa-envelope-open-text','sort_order'=>28,'active'=>1,
                'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $settingId=(int)$this->db->insertID();
        }else{$settingId=(int)$settingEmail['id'];}
        $this->db->table('menus')->where('route','master/email-recipients')->update(['parent_id'=>$settingId,'sort_order'=>281]);
        $this->db->table('menus')->where('route','settings/email')->update(['parent_id'=>$settingId,'sort_order'=>282]);
        if(!$this->db->table('role_menus')->where(['role_id'=>1,'menu_id'=>$settingId])->countAllResults())$this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$settingId]);
    }

    public function down()
    {
        $setting=$this->db->table('menus')->where('name','Setting Email')->get()->getRowArray();
        $dataMaster=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->get()->getRowArray();
        if($setting&&$dataMaster){
            $this->db->table('menus')->where('route','master/email-recipients')->update(['parent_id'=>$dataMaster['id'],'sort_order'=>28]);
            $this->db->table('menus')->where('route','settings/email')->update(['parent_id'=>$dataMaster['id'],'sort_order'=>29]);
            $this->db->table('role_menus')->where('menu_id',$setting['id'])->delete();
            $this->db->table('menus')->where('id',$setting['id'])->delete();
        }
    }
}
