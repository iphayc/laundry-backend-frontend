<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddCompanyProfile extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE companies (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            residence_name VARCHAR(160) NOT NULL,
            address TEXT NULL,
            phone VARCHAR(40) NULL,
            developer VARCHAR(160) NULL,
            email VARCHAR(160) NULL,
            maps_location TEXT NULL,
            photo VARCHAR(255) NULL,
            logo VARCHAR(255) NULL,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(active), INDEX(deleted_at)
        )");
        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if($parent){
            $this->db->table('menus')->insert([
                'parent_id'=>$parent['id'],'name'=>'Company / Perumahan','route'=>'master/company',
                'icon'=>'fas fa-building','sort_order'=>20,'active'=>1,'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $menuId=(int)$this->db->insertID();
            $this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menuId]);
        }
    }

    public function down()
    {
        $menu=$this->db->table('menus')->select('id')->where('route','master/company')->get()->getRowArray();
        if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();}
        $this->forge->dropTable('companies',true);
    }
}
