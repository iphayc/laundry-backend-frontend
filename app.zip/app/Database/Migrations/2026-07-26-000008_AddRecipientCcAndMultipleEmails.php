<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddRecipientCcAndMultipleEmails extends Migration
{
    public function up()
    {
        $this->forge->modifyColumn('email_recipients',['email'=>['name'=>'email','type'=>'TEXT','null'=>false]]);
        if(!$this->db->fieldExists('cc','email_recipients'))$this->forge->addColumn('email_recipients',['cc'=>['type'=>'TEXT','null'=>true,'after'=>'email']]);
    }

    public function down()
    {
        if($this->db->fieldExists('cc','email_recipients'))$this->forge->dropColumn('email_recipients','cc');
        $this->forge->modifyColumn('email_recipients',['email'=>['name'=>'email','type'=>'VARCHAR','constraint'=>160,'null'=>false]]);
    }
}
