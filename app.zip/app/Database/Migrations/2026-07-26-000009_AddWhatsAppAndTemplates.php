<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddWhatsAppAndTemplates extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE whatsapp_settings (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            url_send_text VARCHAR(500) NOT NULL,
            url_send_image VARCHAR(500) NULL,
            api_key_encrypted TEXT NULL,
            key_number VARCHAR(160) NULL,
            phone_number VARCHAR(40) NULL,
            active TINYINT(1) DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(active), INDEX(deleted_at)
        )");
        $this->db->query("CREATE TABLE notification_templates (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type ENUM('email','whatsapp','both') NOT NULL DEFAULT 'email',
            template_name VARCHAR(160) NOT NULL,
            subject VARCHAR(255) NULL,
            body TEXT NOT NULL,
            remark TEXT NULL,
            status ENUM('active','inactive') DEFAULT 'active',
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(type), INDEX(status), INDEX(deleted_at)
        )");
        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if($parent){
            $now=date('Y-m-d H:i:s');
            $menus=[
                ['parent_id'=>$parent['id'],'name'=>'Setting WhatsApp','route'=>'settings/whatsapp','icon'=>'fab fa-whatsapp','sort_order'=>30,'active'=>1,'created_at'=>$now],
                ['parent_id'=>$parent['id'],'name'=>'Master Template','route'=>'master/notification-templates','icon'=>'fas fa-file-code','sort_order'=>31,'active'=>1,'created_at'=>$now],
            ];
            foreach($menus as $menu){$this->db->table('menus')->insert($menu);$menuId=(int)$this->db->insertID();$this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menuId]);}
        }
    }

    public function down()
    {
        $menus=$this->db->table('menus')->select('id')->whereIn('route',['settings/whatsapp','master/notification-templates'])->get()->getResultArray();
        foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
        $this->db->table('menus')->whereIn('route',['settings/whatsapp','master/notification-templates'])->delete();
        $this->forge->dropTable('notification_templates',true);
        $this->forge->dropTable('whatsapp_settings',true);
    }
}
