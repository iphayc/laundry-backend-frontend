<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddCrudToRoleMenus extends Migration
{
    public function up()
    {
        foreach([
            'can_create'=>0,
            'can_read'=>1,
            'can_update'=>0,
            'can_delete'=>0,
        ] as $field=>$default){
            if(!$this->db->fieldExists($field,'role_menus'))$this->forge->addColumn('role_menus',[$field=>['type'=>'TINYINT','constraint'=>1,'default'=>$default]]);
        }
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        if($admin)$this->db->table('role_menus')->where('role_id',$admin['id'])->update(['can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
    }

    public function down()
    {
        foreach(['can_delete','can_update','can_read','can_create'] as $field)if($this->db->fieldExists($field,'role_menus'))$this->forge->dropColumn('role_menus',$field);
    }
}
