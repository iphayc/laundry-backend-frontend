<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddGateConsoleSlug extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('console_slug','gates')){
            $this->forge->addColumn('gates',[
                'console_slug'=>['type'=>'VARCHAR','constraint'=>80,'null'=>true,'after'=>'device_code'],
            ]);
        }

        $rows=$this->db->table('gates')->select('id,code,name')->get()->getResultArray();
        $used=[];
        foreach($rows as $row){
            $base=strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/','-',(string)($row['code']?:$row['name'])),'-'))?:'gate-'.$row['id'];
            $slug=$base;$suffix=2;
            while(isset($used[$slug]))$slug=$base.'-'.$suffix++;
            $used[$slug]=true;
            $this->db->table('gates')->where('id',$row['id'])->update(['console_slug'=>$slug]);
        }

        $index=$this->db->query("SHOW INDEX FROM gates WHERE Key_name = 'gates_console_slug_unique'")->getRowArray();
        if(!$index){
            $this->db->query('CREATE UNIQUE INDEX gates_console_slug_unique ON gates (console_slug)');
        }
    }

    public function down()
    {
        if($this->db->fieldExists('console_slug','gates'))$this->forge->dropColumn('gates','console_slug');
    }
}
