<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddRfidDevices extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE rfid_devices (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(60) NOT NULL UNIQUE,
            name VARCHAR(160) NOT NULL,
            device_type ENUM('rfid','nfc','qr','anpr','other') NOT NULL DEFAULT 'rfid',
            brand VARCHAR(100) NULL,
            model VARCHAR(100) NULL,
            serial_number VARCHAR(120) NULL,
            ip_address VARCHAR(45) NULL,
            port INT UNSIGNED NULL,
            api_url VARCHAR(500) NULL,
            api_key_encrypted TEXT NULL,
            connection_mode ENUM('http','tcp','serial','wiegand') NOT NULL DEFAULT 'http',
            connection_status ENUM('online','offline','unknown') NOT NULL DEFAULT 'unknown',
            last_online_at DATETIME NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            remark TEXT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(device_type), INDEX(connection_status), INDEX(active), INDEX(deleted_at)
        )");
        $this->db->query("CREATE TABLE gate_devices (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            gate_id INT UNSIGNED NOT NULL,
            device_id INT UNSIGNED NOT NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            UNIQUE KEY gate_device_unique (gate_id,device_id),
            INDEX(device_id)
        )");

        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if($parent){
            $this->db->table('menus')->insert(['parent_id'=>$parent['id'],'name'=>'Master Device RFID','route'=>'master/devices','icon'=>'fas fa-satellite-dish','sort_order'=>18,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);
            $menuId=(int)$this->db->insertID();
            $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
            if($admin)$this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        }

        $this->db->table('permissions')->insert(['code'=>'devices.manage','name'=>'Devices Manage','module'=>'devices']);
        $permissionId=(int)$this->db->insertID();
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        if($admin)$this->db->table('role_permissions')->insert(['role_id'=>$admin['id'],'permission_id'=>$permissionId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
    }

    public function down()
    {
        $permission=$this->db->table('permissions')->select('id')->where('code','devices.manage')->get()->getRowArray();
        if($permission)$this->db->table('role_permissions')->where('permission_id',$permission['id'])->delete();
        $this->db->table('permissions')->where('code','devices.manage')->delete();
        $menu=$this->db->table('menus')->select('id')->where('route','master/devices')->get()->getRowArray();
        if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();}
        $this->forge->dropTable('gate_devices',true);
        $this->forge->dropTable('rfid_devices',true);
    }
}
