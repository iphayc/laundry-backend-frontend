<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddVisitorResident extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('resident_id','visitors')){
            $this->forge->addColumn('visitors',[
                'resident_id'=>['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'id'],
            ]);
            $this->db->query('CREATE INDEX visitors_resident_id_index ON visitors (resident_id)');
        }
    }

    public function down()
    {
        if($this->db->fieldExists('resident_id','visitors'))$this->forge->dropColumn('visitors','resident_id');
    }
}
