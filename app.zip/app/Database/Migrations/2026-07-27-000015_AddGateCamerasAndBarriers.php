<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddGateCamerasAndBarriers extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE gate_cameras (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            gate_id INT UNSIGNED NOT NULL,
            code VARCHAR(60) NOT NULL UNIQUE,
            name VARCHAR(160) NOT NULL,
            camera_type ENUM('snapshot','mjpeg','rtsp','onvif') NOT NULL DEFAULT 'snapshot',
            snapshot_url VARCHAR(500) NOT NULL,
            stream_url VARCHAR(500) NULL,
            username VARCHAR(160) NULL,
            password_encrypted TEXT NULL,
            refresh_seconds INT UNSIGNED NOT NULL DEFAULT 3,
            connection_status ENUM('online','offline','unknown') NOT NULL DEFAULT 'unknown',
            last_online_at DATETIME NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            remark TEXT NULL,
            created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL,
            INDEX(gate_id), INDEX(active), INDEX(deleted_at)
        )");
        $this->db->query("CREATE TABLE barrier_gates (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            gate_id INT UNSIGNED NOT NULL,
            code VARCHAR(60) NOT NULL UNIQUE,
            name VARCHAR(160) NOT NULL,
            controller_type ENUM('http','tcp','relay') NOT NULL DEFAULT 'http',
            open_url VARCHAR(500) NULL,
            close_url VARCHAR(500) NULL,
            status_url VARCHAR(500) NULL,
            api_key_encrypted TEXT NULL,
            relay_channel VARCHAR(40) NULL,
            auto_close_seconds INT UNSIGNED NOT NULL DEFAULT 5,
            connection_status ENUM('online','offline','unknown') NOT NULL DEFAULT 'unknown',
            last_online_at DATETIME NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            remark TEXT NULL,
            created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL,
            INDEX(gate_id), INDEX(active), INDEX(deleted_at)
        )");
        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        foreach([
            ['Master Camera','master/cameras','fas fa-video',19],
            ['Master Barrier Gate','master/barriers','fas fa-road',20],
        ] as [$name,$route,$icon,$sort]){
            if($parent){$this->db->table('menus')->insert(['parent_id'=>$parent['id'],'name'=>$name,'route'=>$route,'icon'=>$icon,'sort_order'=>$sort,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$menuId=(int)$this->db->insertID();if($admin)$this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);}
        }
        foreach([['cameras.manage','Cameras Manage','cameras'],['barriers.manage','Barriers Manage','barriers']] as [$code,$name,$module]){
            $this->db->table('permissions')->insert(compact('code','name','module'));$permissionId=(int)$this->db->insertID();
            if($admin)$this->db->table('role_permissions')->insert(['role_id'=>$admin['id'],'permission_id'=>$permissionId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        }
    }

    public function down()
    {
        $permissions=$this->db->table('permissions')->select('id')->whereIn('code',['cameras.manage','barriers.manage'])->get()->getResultArray();
        foreach($permissions as $permission)$this->db->table('role_permissions')->where('permission_id',$permission['id'])->delete();
        $this->db->table('permissions')->whereIn('code',['cameras.manage','barriers.manage'])->delete();
        $menus=$this->db->table('menus')->select('id')->whereIn('route',['master/cameras','master/barriers'])->get()->getResultArray();
        foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
        $this->db->table('menus')->whereIn('route',['master/cameras','master/barriers'])->delete();
        $this->forge->dropTable('barrier_gates',true);$this->forge->dropTable('gate_cameras',true);
    }
}
