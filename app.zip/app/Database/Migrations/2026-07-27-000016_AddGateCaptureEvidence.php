<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddGateCaptureEvidence extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('capture_image','access_logs'))$this->forge->addColumn('access_logs',[
            'capture_image'=>['type'=>'VARCHAR','constraint'=>500,'null'=>true,'after'=>'raw_payload'],
            'entry_access_log_id'=>['type'=>'BIGINT','constraint'=>20,'unsigned'=>true,'null'=>true,'after'=>'capture_image'],
        ]);
        $index=$this->db->query("SHOW INDEX FROM access_logs WHERE Key_name = 'access_logs_entry_log_index'")->getRowArray();
        if(!$index)$this->db->query('CREATE INDEX access_logs_entry_log_index ON access_logs (entry_access_log_id)');
    }

    public function down()
    {
        foreach(['entry_access_log_id','capture_image'] as $field)if($this->db->fieldExists($field,'access_logs'))$this->forge->dropColumn('access_logs',$field);
    }
}
