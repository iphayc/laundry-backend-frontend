<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddUsbCameraMode extends Migration
{
    public function up()
    {
        $this->db->query("ALTER TABLE gate_cameras MODIFY camera_type ENUM('snapshot','mjpeg','rtsp','onvif','usb') NOT NULL DEFAULT 'snapshot'");
        $this->db->query('ALTER TABLE gate_cameras MODIFY snapshot_url VARCHAR(500) NULL');
    }

    public function down()
    {
        $this->db->table('gate_cameras')->where('camera_type','usb')->update(['camera_type'=>'snapshot','active'=>0]);
        $this->db->query("ALTER TABLE gate_cameras MODIFY camera_type ENUM('snapshot','mjpeg','rtsp','onvif') NOT NULL DEFAULT 'snapshot'");
        $this->db->table('gate_cameras')->where('snapshot_url',null)->update(['snapshot_url'=>'http://127.0.0.1/disabled-camera']);
        $this->db->query('ALTER TABLE gate_cameras MODIFY snapshot_url VARCHAR(500) NOT NULL');
    }
}
