<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class GroupDeviceMenus extends Migration
{
    public function up()
    {
        $dataMaster=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if(!$dataMaster)return;

        $parent=$this->db->table('menus')->where('name','Master Devices')->where('deleted_at',null)->get()->getRowArray();
        if(!$parent){
            $this->db->table('menus')->insert([
                'parent_id'=>$dataMaster['id'],'name'=>'Master Devices','route'=>null,
                'icon'=>'fas fa-microchip','sort_order'=>18,'active'=>1,'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $parentId=(int)$this->db->insertID();
        }else{$parentId=(int)$parent['id'];}

        $children=$this->db->table('menus')->select('id,route')->whereIn('route',['master/devices','master/cameras','master/barriers'])->where('deleted_at',null)->get()->getResultArray();
        $childIds=array_map('intval',array_column($children,'id'));
        if($childIds){
            $roleAccess=$this->db->table('role_menus')->select('role_id,MAX(can_create) can_create,MAX(can_read) can_read,MAX(can_update) can_update,MAX(can_delete) can_delete')->whereIn('menu_id',$childIds)->groupBy('role_id')->get()->getResultArray();
            foreach($roleAccess as $access){
                if(!$this->db->table('role_menus')->where(['role_id'=>$access['role_id'],'menu_id'=>$parentId])->countAllResults())$this->db->table('role_menus')->insert(['role_id'=>$access['role_id'],'menu_id'=>$parentId,'can_create'=>$access['can_create'],'can_read'=>1,'can_update'=>$access['can_update'],'can_delete'=>$access['can_delete']]);
            }
            $sort=['master/devices'=>1,'master/cameras'=>2,'master/barriers'=>3];
            foreach($children as $child)$this->db->table('menus')->where('id',$child['id'])->update(['parent_id'=>$parentId,'sort_order'=>$sort[$child['route']]]);
        }
    }

    public function down()
    {
        $dataMaster=$this->db->table('menus')->select('id')->where('name','Data Master')->where('parent_id',null)->get()->getRowArray();
        $parent=$this->db->table('menus')->select('id')->where('name','Master Devices')->where('deleted_at',null)->get()->getRowArray();
        if(!$dataMaster||!$parent)return;
        foreach(['master/devices'=>18,'master/cameras'=>19,'master/barriers'=>20] as $route=>$sort)$this->db->table('menus')->where('route',$route)->update(['parent_id'=>$dataMaster['id'],'sort_order'=>$sort]);
        $this->db->table('role_menus')->where('menu_id',$parent['id'])->delete();
        $this->db->table('menus')->where('id',$parent['id'])->delete();
    }
}
