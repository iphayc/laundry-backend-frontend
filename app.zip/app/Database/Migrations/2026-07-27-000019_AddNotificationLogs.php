<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddNotificationLogs extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE notification_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            notification_id BIGINT UNSIGNED NULL,
            channel ENUM('email','whatsapp') NOT NULL,
            recipient TEXT NOT NULL,
            cc TEXT NULL,
            subject VARCHAR(255) NULL,
            message LONGTEXT NOT NULL,
            media_url VARCHAR(1000) NULL,
            attachment_path VARCHAR(1000) NULL,
            status ENUM('sent','failed') NOT NULL DEFAULT 'failed',
            error_message TEXT NULL,
            response_code INT NULL,
            response_body LONGTEXT NULL,
            attempt_count INT UNSIGNED NOT NULL DEFAULT 1,
            last_attempt_at DATETIME NOT NULL,
            sent_at DATETIME NULL,
            created_by INT UNSIGNED NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(channel), INDEX(status), INDEX(last_attempt_at), INDEX(notification_id), INDEX(deleted_at)
        )");

        $report=$this->db->table('menus')->where('route','reports')->where('deleted_at',null)->get()->getRowArray();
        if($report){
            $parentId=(int)$report['id'];
            $this->db->table('menus')->where('id',$parentId)->update(['route'=>null,'name'=>'Laporan','icon'=>'fas fa-file-export']);
            $this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>'Laporan Trafik','route'=>'reports','icon'=>'fas fa-chart-line','sort_order'=>1,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$trafficId=(int)$this->db->insertID();
            $this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>'Log Email & WhatsApp','route'=>'reports/notifications','icon'=>'fas fa-paper-plane','sort_order'=>2,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$logId=(int)$this->db->insertID();
            $accessRows=$this->db->table('role_menus')->where('menu_id',$parentId)->get()->getResultArray();
            foreach($accessRows as $access){
                $rights=['role_id'=>$access['role_id'],'can_create'=>$access['can_create'],'can_read'=>$access['can_read'],'can_update'=>$access['can_update'],'can_delete'=>$access['can_delete']];
                $this->db->table('role_menus')->insert($rights+['menu_id'=>$trafficId]);
                $this->db->table('role_menus')->insert($rights+['menu_id'=>$logId]);
            }
        }
        $this->db->table('permissions')->insert(['code'=>'notification_logs.manage','name'=>'Notification Logs Manage','module'=>'reports']);$permissionId=(int)$this->db->insertID();
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        if($admin)$this->db->table('role_permissions')->insert(['role_id'=>$admin['id'],'permission_id'=>$permissionId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
    }

    public function down()
    {
        $permission=$this->db->table('permissions')->select('id')->where('code','notification_logs.manage')->get()->getRowArray();
        if($permission)$this->db->table('role_permissions')->where('permission_id',$permission['id'])->delete();
        $this->db->table('permissions')->where('code','notification_logs.manage')->delete();
        $children=$this->db->table('menus')->select('id')->whereIn('route',['reports','reports/notifications'])->get()->getResultArray();
        foreach($children as $child)$this->db->table('role_menus')->where('menu_id',$child['id'])->delete();
        if($children)$this->db->table('menus')->whereIn('id',array_column($children,'id'))->delete();
        $parent=$this->db->table('menus')->where('name','Laporan')->where('route',null)->where('deleted_at',null)->get()->getRowArray();
        if($parent)$this->db->table('menus')->where('id',$parent['id'])->update(['route'=>'reports','icon'=>'fas fa-file-export']);
        $this->forge->dropTable('notification_logs',true);
    }
}
