<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddWhatsAppBroadcastMenu extends Migration
{
    public function up()
    {
        $parent=$this->db->table('menus')->where('name','Transaksi')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        if(!$parent){$this->db->table('menus')->insert(['parent_id'=>null,'name'=>'Transaksi','route'=>null,'icon'=>'fas fa-exchange-alt','sort_order'=>30,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$parentId=(int)$this->db->insertID();}else{$parentId=(int)$parent['id'];}
        $this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>'Kirim WhatsApp Penghuni','route'=>'transactions/whatsapp','icon'=>'fab fa-whatsapp','sort_order'=>1,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$menuId=(int)$this->db->insertID();
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        if($admin){foreach([$parentId,$menuId] as $id)if(!$this->db->table('role_menus')->where(['role_id'=>$admin['id'],'menu_id'=>$id])->countAllResults())$this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$id,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);}
        $this->db->table('permissions')->insert(['code'=>'whatsapp_broadcast.create','name'=>'WhatsApp Broadcast Create','module'=>'transactions']);$permissionId=(int)$this->db->insertID();
        if($admin)$this->db->table('role_permissions')->insert(['role_id'=>$admin['id'],'permission_id'=>$permissionId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>0]);
    }

    public function down()
    {
        $permission=$this->db->table('permissions')->select('id')->where('code','whatsapp_broadcast.create')->get()->getRowArray();if($permission)$this->db->table('role_permissions')->where('permission_id',$permission['id'])->delete();$this->db->table('permissions')->where('code','whatsapp_broadcast.create')->delete();
        $menu=$this->db->table('menus')->select('id,parent_id')->where('route','transactions/whatsapp')->get()->getRowArray();if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();$children=$this->db->table('menus')->where('parent_id',$menu['parent_id'])->countAllResults();if(!$children){$this->db->table('role_menus')->where('menu_id',$menu['parent_id'])->delete();$this->db->table('menus')->where('id',$menu['parent_id'])->delete();}}
    }
}
