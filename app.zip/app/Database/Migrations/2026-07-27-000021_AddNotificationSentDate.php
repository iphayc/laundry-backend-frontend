<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddNotificationSentDate extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('sent_date','notification_logs')){
            $this->forge->addColumn('notification_logs',[
                'sent_date'=>['type'=>'DATE','null'=>true,'after'=>'sent_at'],
            ]);
            $this->db->query('CREATE INDEX notification_logs_sent_date_index ON notification_logs (sent_date)');
        }
        $this->db->query('UPDATE notification_logs SET sent_date = DATE(sent_at) WHERE sent_at IS NOT NULL AND sent_date IS NULL');
    }

    public function down()
    {
        if($this->db->fieldExists('sent_date','notification_logs'))$this->forge->dropColumn('notification_logs','sent_date');
    }
}
