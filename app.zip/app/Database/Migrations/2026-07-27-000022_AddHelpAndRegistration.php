<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddHelpAndRegistration extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE help_articles (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, module VARCHAR(120) NOT NULL, title VARCHAR(255) NOT NULL,
            content LONGTEXT NOT NULL, sort_order INT NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL,
            INDEX(module), INDEX(active), INDEX(deleted_at)
        )");
        $this->db->query("CREATE TABLE application_about (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, app_name VARCHAR(160) NOT NULL, version VARCHAR(40) NULL,
            developer VARCHAR(160) NULL, email VARCHAR(160) NULL, website VARCHAR(255) NULL, description TEXT NULL,
            created_at DATETIME NULL, updated_at DATETIME NULL, deleted_at DATETIME NULL
        )");
        $now=date('Y-m-d H:i:s');
        $this->db->table('application_about')->insert(['app_name'=>'Parking Cluster & Gate VMS','version'=>'1.0','developer'=>'IPAY','email'=>'iphayc@gmail.com','description'=>'Sistem parkir cluster perumahan, akses RFID, camera, barrier, pengunjung, dan notifikasi.','created_at'=>$now]);
        foreach([
            ['Dashboard','Menggunakan Dashboard','Dashboard menampilkan ringkasan aktivitas parkir dan grafik. Gunakan menu export pada setiap grafik untuk menyimpan PNG, JPEG, PDF, atau CSV.',1],
            ['Data Master','Mengelola Data Master','Buka Data Master, pilih modul, lalu gunakan tombol Tambah, Edit, atau Arsip. Data yang dihapus menggunakan soft delete.',2],
            ['Gate Console','Menjalankan Gate Console','Buka URL gate khusus seperti /main-in. Pastikan RFID, camera, dan barrier telah dikonfigurasi. Tempelkan kartu untuk memvalidasi akses, mengambil foto, dan membuka barrier.',3],
            ['Penghuni','Mendaftarkan Penghuni','Buat Cluster dan Unit Rumah terlebih dahulu, lalu tambahkan penghuni dan pilih unit rumahnya.',4],
            ['Kendaraan','Mendaftarkan Kendaraan','Pilih penghuni dan jenis kendaraan, kemudian isi nomor polisi, merek, warna, dan status aktif.',5],
            ['Kartu Akses','Mendaftarkan Kartu RFID','Pilih penghuni, masukkan nomor kartu RFID, tipe kartu, status aktif, dan tanggal kedaluwarsa bila ada.',6],
            ['Devices','Mengatur RFID, Camera, dan Barrier','Hubungkan perangkat ke gate yang benar. Untuk USB Webcam pilih jenis USB Webcam dan izinkan akses kamera pada browser Gate Console.',7],
            ['WhatsApp','Mengirim Pengumuman WhatsApp','Buka Transaksi > Kirim WhatsApp Penghuni. Pilih maksimal 20 penerima. Tanpa lampiran menggunakan URL Send Text; lampiran gambar menggunakan URL Send Image.',8],
            ['Laporan','Melihat dan Mengekspor Laporan','Gunakan filter tanggal atau jenis/status, lalu ekspor data menggunakan tombol Excel atau PDF.',9],
            ['User & Role','Mengatur User dan Hak Akses','Buat role, group, dan user. Atur akses menu serta hak Create, Read, Update, dan Delete melalui Role & Group.',10],
        ] as [$module,$title,$content,$sort])$this->db->table('help_articles')->insert(['module'=>$module,'title'=>$title,'content'=>$content,'sort_order'=>$sort,'active'=>1,'created_at'=>$now]);

        $this->db->table('menus')->insert(['parent_id'=>null,'name'=>'Help','route'=>null,'icon'=>'fas fa-question-circle','sort_order'=>90,'active'=>1,'created_at'=>$now]);$parentId=(int)$this->db->insertID();
        $menuIds=[];
        foreach([['Manual Guide','help/manual','fas fa-book',1],['About','help/about','fas fa-info-circle',2],['Register Aplikasi','register','fas fa-key',3]] as [$name,$route,$icon,$sort]){$this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>$name,'route'=>$route,'icon'=>$icon,'sort_order'=>$sort,'active'=>1,'created_at'=>$now]);$menuIds[]=(int)$this->db->insertID();}
        $roles=$this->db->table('roles')->select('id,name')->where('deleted_at',null)->get()->getResultArray();
        foreach($roles as $role){$admin=$role['name']==='Administrator';foreach([$parentId,...$menuIds] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>$role['id'],'menu_id'=>$menuId,'can_create'=>$admin?1:0,'can_read'=>1,'can_update'=>$admin?1:0,'can_delete'=>$admin?1:0]);}
        foreach([['help.manage','Help Manage','help'],['registration.manage','Registration Manage','registration']] as [$codeValue,$name,$module]){$this->db->table('permissions')->insert(['code'=>$codeValue,'name'=>$name,'module'=>$module]);$permissionId=(int)$this->db->insertID();$admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();if($admin)$this->db->table('role_permissions')->insert(['role_id'=>$admin['id'],'permission_id'=>$permissionId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);}
    }

    public function down()
    {
        $permissions=$this->db->table('permissions')->select('id')->whereIn('code',['help.manage','registration.manage'])->get()->getResultArray();foreach($permissions as $permission)$this->db->table('role_permissions')->where('permission_id',$permission['id'])->delete();$this->db->table('permissions')->whereIn('code',['help.manage','registration.manage'])->delete();
        $menus=$this->db->table('menus')->select('id')->groupStart()->where('name','Help')->orWhereIn('route',['help/manual','help/about','register'])->groupEnd()->get()->getResultArray();foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();if($menus)$this->db->table('menus')->whereIn('id',array_column($menus,'id'))->delete();
        $this->forge->dropTable('application_about',true);$this->forge->dropTable('help_articles',true);
    }
}
