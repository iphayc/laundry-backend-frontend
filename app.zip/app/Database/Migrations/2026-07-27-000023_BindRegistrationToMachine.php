<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class BindRegistrationToMachine extends Migration
{
    public function up()
    {
        // Intentionally empty. The application owner provisions the
        // registration table and license separately from migrations.
    }

    public function down()
    {
        // Intentionally empty.
    }
}
