<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ExpandManualGuide extends Migration
{
    public function up()
    {
        $this->forge->addColumn('help_articles', [
            'screenshot_path' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
                'after'      => 'content',
            ],
        ]);

        $now = date('Y-m-d H:i:s');
        $guides = [
            ['Dashboard', 'Menggunakan Dashboard', "Tujuan:\nMelihat ringkasan operasional parkir dan tren akses secara cepat.\n\nLangkah penggunaan:\n1. Buka menu Dashboard setelah login.\n2. Periksa kartu statistik untuk total penghuni, kendaraan, kartu aktif, dan akses hari ini.\n3. Arahkan kursor ke grafik untuk melihat nilai rinci.\n4. Klik ikon menu pada grafik untuk mengunduh PNG, JPEG, PDF, atau CSV.\n5. Gunakan grafik untuk membandingkan trafik harian, subjek akses, hasil tap, dan jenis kendaraan.\n\nCatatan:\nData grafik berasal dari transaksi access log. Pastikan transaksi gate tercatat agar grafik terisi.", 1, 'uploads/help/dashboard.png'],
            ['Company', 'Mengatur Identitas Perumahan', "Tujuan:\nMengatur identitas perusahaan/perumahan yang digunakan pada logo, favicon, login, footer, dan Gate Console.\n\nLangkah penggunaan:\n1. Buka Data Master > Company / Perumahan.\n2. Isi nama perumahan, alamat, telepon, pengembang, email, dan lokasi Maps.\n3. Unggah foto perumahan dan logo berformat JPG, PNG, atau WebP maksimal 2 MB.\n4. Klik Simpan.\n5. Muat ulang halaman untuk melihat perubahan branding.\n\nCatatan:\nGunakan logo persegi transparan agar tampil baik pada sidebar dan favicon.", 2, null],
            ['Data Master', 'Urutan Pengisian Data Master', "Tujuan:\nMenyiapkan relasi data parkir dengan urutan yang benar.\n\nUrutan yang disarankan:\n1. Buat Cluster.\n2. Buat Unit Rumah dan pilih Cluster.\n3. Buat Penghuni dan pilih Unit Rumah.\n4. Buat Jenis Kendaraan.\n5. Buat Kendaraan dan pilih Penghuni serta Jenis Kendaraan.\n6. Buat Kartu Akses dan pilih Penghuni.\n7. Buat Gate, lalu hubungkan RFID, Camera, dan Barrier.\n\nPengelolaan data:\n- Klik nama atau ikon Edit untuk memperbarui data.\n- Tombol Arsip menggunakan soft delete sehingga data tidak dihapus permanen.\n- Gunakan pencarian DataTables untuk menemukan data.\n- Gunakan Excel atau PDF untuk mengekspor daftar.", 3, 'uploads/help/data-master.png'],
            ['Gate', 'Mengatur Master Gate dan URL Console', "Tujuan:\nMendaftarkan titik gerbang dan menentukan arah operasionalnya.\n\nLangkah penggunaan:\n1. Buka Data Master > Gate.\n2. Pilih Cluster bila gate berada di dalam cluster, atau kosongkan untuk gerbang utama.\n3. Isi kode dan nama gate.\n4. Pilih tipe gate dan arah Masuk atau Keluar.\n5. Isi URL Gate Console unik, misalnya main-in.\n6. Simpan lalu buka URL seperti http://server:8080/main-in.\n\nCatatan:\nSatu URL console sebaiknya mewakili satu gate dan satu arah tetap.", 4, null],
            ['Penghuni', 'Mendaftarkan Penghuni dan Unit Rumah', "Tujuan:\nMenghubungkan penghuni dengan cluster dan unit rumahnya.\n\nLangkah penggunaan:\n1. Pastikan Cluster dan Unit Rumah sudah tersedia.\n2. Buka Data Master > Penghuni lalu klik Tambah.\n3. Pilih Unit Rumah dari dropdown.\n4. Isi nomor identitas, nama, telepon, dan email.\n5. Gunakan status Suspended jika akses penghuni perlu dihentikan sementara.\n6. Isi catatan penangguhan agar alasan tercatat.\n7. Klik Simpan.\n\nCatatan:\nEmail dan nomor telepon digunakan untuk pengiriman notifikasi.", 5, null],
            ['Kendaraan', 'Mendaftarkan Kendaraan Penghuni', "Tujuan:\nMencatat kendaraan yang diizinkan menggunakan akses parkir.\n\nLangkah penggunaan:\n1. Buat Jenis Kendaraan terlebih dahulu.\n2. Buka Data Master > Kendaraan lalu klik Tambah.\n3. Pilih Penghuni dan Jenis Kendaraan dari dropdown.\n4. Isi nomor polisi, merek, dan warna.\n5. Pastikan status Aktif dipilih.\n6. Klik Simpan.\n\nCatatan:\nNomor polisi akan ikut tercatat pada transaksi gate dan laporan trafik.", 6, null],
            ['Kartu Akses', 'Mendaftarkan Kartu RFID', "Tujuan:\nMenghubungkan nomor kartu RFID dengan penghuni.\n\nLangkah penggunaan:\n1. Buka Data Master > Kartu Akses lalu klik Tambah.\n2. Pilih Penghuni.\n3. Isi nomor kartu sesuai hasil pembacaan RFID.\n4. Tentukan tipe dan status kartu.\n5. Isi tanggal kedaluwarsa jika kartu bersifat sementara.\n6. Klik Simpan dan lakukan uji tap di Gate Console.\n\nKartu akan ditolak apabila tidak dikenal, nonaktif, kedaluwarsa, atau penghuni sedang suspended.", 7, null],
            ['Tamu', 'Mengelola Tamu dan Blacklist', "Tujuan:\nMencatat tamu serta penghuni yang akan dikunjungi.\n\nLangkah penggunaan:\n1. Buka Data Master > Tamu / Blacklist.\n2. Pilih Penghuni Tujuan.\n3. Isi tipe identitas, nomor identitas, nama, dan telepon tamu.\n4. Aktifkan Blacklist apabila tamu tidak diizinkan masuk.\n5. Isi alasan pada Catatan Blacklist.\n6. Klik Simpan.\n\nCatatan:\nPeriksa kembali status blacklist sebelum memberikan akses manual.", 8, null],
            ['Master Devices', 'Mengatur RFID, Camera, dan Barrier', "Tujuan:\nMenghubungkan perangkat fisik dengan Gate Console.\n\nRFID:\n1. Daftarkan perangkat RFID, jenis, alamat IP/API, dan gate yang dilayani.\n2. Pastikan perangkat aktif.\n\nCamera:\n1. Pilih gate dan jenis kamera.\n2. Untuk USB Webcam, browser akan meminta izin kamera.\n3. Untuk IP Camera, isi Snapshot URL atau Stream URL serta kredensial bila diperlukan.\n\nBarrier:\n1. Pilih gate dan jenis controller.\n2. Isi Open URL, Close URL, Status URL, token, dan waktu auto-close.\n3. Uji integrasi di lingkungan aman sebelum digunakan.", 9, 'uploads/help/devices.png'],
            ['Gate Console', 'Menjalankan Gate Console', "Tujuan:\nMemproses tap kartu, mengambil foto kendaraan, dan membuka barrier.\n\nLangkah penggunaan:\n1. Buka URL khusus gate, misalnya /main-in. Gate Console tidak memerlukan login user.\n2. Pastikan tampilan kamera live muncul.\n3. Tempelkan kartu RFID; reader dapat mengisi nomor kartu otomatis.\n4. Sistem memvalidasi kartu, penghuni, kendaraan, arah, dan status akses.\n5. Saat akses masuk berhasil, kamera mengambil foto kendaraan, menyimpannya di server, lalu barrier terbuka.\n6. Saat akses keluar berhasil, sistem menampilkan foto masuk, mengambil foto keluar, menyimpan transaksi, lalu barrier terbuka.\n7. Perhatikan panel status untuk pesan diterima atau ditolak.\n\nJam Gate Console menggunakan format 24 jam HH:MM:SS.", 10, 'uploads/help/gate-console.png'],
            ['Transaksi WhatsApp', 'Mengirim Pengumuman WhatsApp', "Tujuan:\nMengirim notifikasi atau pengumuman kepada beberapa penghuni.\n\nLangkah penggunaan:\n1. Pastikan Setting WhatsApp aktif dan URL API sudah benar.\n2. Buka Transaksi > Kirim WhatsApp Penghuni.\n3. Isi judul dan pesan.\n4. Pilih maksimal 20 penghuni per pengiriman.\n5. Lampiran bersifat opsional dan maksimal 5 MB.\n6. Klik Kirim dan periksa toast hasil proses.\n\nKetentuan endpoint:\n- Tanpa lampiran menggunakan URL Send Text.\n- Dengan lampiran gambar menggunakan URL Send Image.\n\nPengiriman gagal dapat diperiksa dan dikirim ulang melalui Log Email & WhatsApp.", 11, 'uploads/help/whatsapp.png'],
            ['Setting Email', 'Mengatur SMTP dan Penerima Email', "Tujuan:\nMenyiapkan akun SMTP dan daftar penerima laporan.\n\nSetting SMTP:\n1. Buka Setting Email > SMTP Account.\n2. Isi host, port, username, password, enkripsi, alamat pengirim, dan nama pengirim.\n3. Aktifkan konfigurasi lalu Simpan.\n\nPenerima Email:\n1. Buka Setting Email > Penerima Email.\n2. Isi nama dan satu atau beberapa alamat email dipisahkan koma.\n3. Isi CC dengan pola yang sama bila diperlukan.\n4. Pastikan status Aktif.\n\nGunakan alamat dan kredensial SMTP khusus aplikasi bila penyedia email mendukungnya.", 12, null],
            ['Setting WhatsApp', 'Mengatur Gateway WhatsApp', "Tujuan:\nMenghubungkan aplikasi dengan penyedia API WhatsApp.\n\nLangkah penggunaan:\n1. Buka Data Master > Setting WhatsApp.\n2. Isi URL Send Text dan URL Send Image.\n3. Isi API Key, Key Number, dan nomor HP pengirim.\n4. Aktifkan konfigurasi.\n5. Klik Simpan.\n6. Lakukan pengiriman percobaan ke satu penghuni.\n\nCatatan:\nAPI Key disimpan terenkripsi. Pastikan format payload sesuai layanan gateway yang digunakan.", 13, null],
            ['Master Template', 'Mengelola Template Email dan WhatsApp', "Tujuan:\nMenyediakan isi pesan yang dapat digunakan ulang.\n\nLangkah penggunaan:\n1. Buka Data Master > Master Template.\n2. Klik Tambah.\n3. Pilih jenis Email, WhatsApp, atau Both.\n4. Isi nama template, subject, body, remark, dan status.\n5. Gunakan placeholder seperti {{nama}}, {{tanggal}}, atau {{nopol}} bila proses pengiriman mendukungnya.\n6. Klik Simpan.\n\nNonaktifkan template yang tidak lagi digunakan tanpa menghapus riwayatnya.", 14, null],
            ['Laporan', 'Melihat dan Mengekspor Laporan Trafik', "Tujuan:\nMenganalisis riwayat akses kendaraan dan kartu.\n\nLangkah penggunaan:\n1. Buka menu Laporan > Laporan Trafik.\n2. Pilih tanggal Dari dan Sampai.\n3. Klik Terapkan.\n4. Gunakan pencarian tabel untuk kartu, gate, penghuni, nomor polisi, arah, atau hasil akses.\n5. Pilih jumlah data 10, 20, 50, 100, atau All.\n6. Klik Excel atau PDF untuk mengunduh data.\n7. Klik Email untuk mengirim laporan ke penerima yang telah dikonfigurasi.\n\nPastikan rentang tanggal tidak terlalu besar agar laporan tetap cepat.", 15, 'uploads/help/reports.png'],
            ['Log Notifikasi', 'Memeriksa Log Email dan WhatsApp', "Tujuan:\nMemantau seluruh hasil pengiriman notifikasi.\n\nLangkah penggunaan:\n1. Buka Laporan > Log Email & WhatsApp.\n2. Filter tanggal, jenis Email/WhatsApp, dan status.\n3. Periksa Sent Date, tujuan, isi, status, serta Error Message.\n4. Jika status gagal, perbaiki konfigurasi terkait.\n5. Klik Resend untuk mengirim ulang.\n6. Gunakan Excel atau PDF untuk ekspor log.\n\nResend membuat percobaan pengiriman baru dan hasilnya tetap tercatat.", 16, null],
            ['User', 'Mengelola Pengguna Aplikasi', "Tujuan:\nMembuat akun operator dan administrator.\n\nLangkah penggunaan:\n1. Buka Manajemen User > Pengguna.\n2. Klik Tambah.\n3. Pilih Role dan Group.\n4. Isi username, nama, email, telepon, password, dan konfirmasi password.\n5. Aktifkan user lalu Simpan.\n6. Gunakan tombol Edit untuk memperbarui data.\n7. Gunakan tombol Reset Password bila pengguna lupa password.\n8. Tombol Arsip menggunakan soft delete.\n\nJangan membagikan akun admin untuk penggunaan operasional harian.", 17, null],
            ['Role & Access', 'Mengatur Role dan Access Control', "Tujuan:\nMembatasi menu dan aksi berdasarkan role pengguna.\n\nLangkah penggunaan:\n1. Buat atau edit nama role pada Master Role.\n2. Buka Access Control.\n3. Pilih role yang akan diatur.\n4. Centang menu yang boleh ditampilkan.\n5. Pilih Create, Read, Update, dan Delete sesuai kebutuhan.\n6. Tombol Read memberikan akses lihat saja.\n7. Tombol Semua mengaktifkan CRUD penuh.\n8. Atur Permission aksi dengan cara yang sama.\n9. Klik Simpan Akses Role.\n\nAdministrator memiliki seluruh akses secara default.", 18, 'uploads/help/access-control.png'],
            ['Profile', 'Mengubah Profile dan Password', "Tujuan:\nMemperbarui data akun yang sedang login.\n\nProfile:\n1. Klik tombol Profile di kanan atas.\n2. Pilih Profile.\n3. Perbarui nama, email, dan telepon pada dialog.\n4. Klik Simpan Profile.\n\nChange Password:\n1. Klik Profile > Change Password.\n2. Isi password lama.\n3. Isi password baru minimal 8 karakter dan konfirmasinya.\n4. Klik Ubah Password.\n\nRole dan username tidak dapat diubah melalui dialog profile.", 19, null],
            ['Registrasi', 'Aktivasi Aplikasi pada Server', "Tujuan:\nMengaktifkan aplikasi untuk Machine ID server.\n\nLangkah penggunaan:\n1. Ketika lisensi tidak cocok, aplikasi otomatis membuka halaman Register.\n2. Catat Machine ID server yang ditampilkan.\n3. Gunakan email terdaftar untuk meminta kode aktivasi.\n4. Periksa email lalu masukkan kode pada form Register.\n5. Klik Aktifkan Aplikasi.\n6. Setelah berhasil, lanjutkan ke halaman Login.\n\nLisensi hanya terikat pada komputer server yang menjalankan PHP/CodeIgniter. Komputer client dan Gate Console tidak perlu diaktivasi terpisah.", 20, null],
        ];

        foreach ($guides as [$module, $title, $content, $sort, $screenshot]) {
            $existing = $this->db->table('help_articles')
                ->where('title', $title)
                ->where('deleted_at', null)
                ->get()
                ->getRowArray();
            $data = [
                'module'          => $module,
                'title'           => $title,
                'content'         => $content,
                'screenshot_path' => $screenshot,
                'sort_order'      => $sort,
                'active'          => 1,
                'updated_at'      => $now,
            ];
            if ($existing) {
                $this->db->table('help_articles')->where('id', $existing['id'])->update($data);
            } else {
                $this->db->table('help_articles')->insert($data + ['created_at' => $now]);
            }
        }
    }

    public function down()
    {
        $this->forge->dropColumn('help_articles', 'screenshot_path');
    }
}
