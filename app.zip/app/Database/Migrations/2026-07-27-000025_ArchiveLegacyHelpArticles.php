<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ArchiveLegacyHelpArticles extends Migration
{
    private array $legacyTitles = [
        'Mengelola Data Master',
        'Mendaftarkan Penghuni',
        'Mendaftarkan Kendaraan',
        'Melihat dan Mengekspor Laporan',
        'Mengatur User dan Hak Akses',
    ];

    public function up()
    {
        $now = date('Y-m-d H:i:s');
        $this->db->table('help_articles')
            ->whereIn('title', $this->legacyTitles)
            ->where('deleted_at', null)
            ->update(['deleted_at' => $now, 'updated_at' => $now]);
    }

    public function down()
    {
        $this->db->table('help_articles')
            ->whereIn('title', $this->legacyTitles)
            ->update(['deleted_at' => null]);
    }
}
