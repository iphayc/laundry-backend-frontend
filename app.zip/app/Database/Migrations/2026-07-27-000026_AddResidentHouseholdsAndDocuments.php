<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddResidentHouseholdsAndDocuments extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE resident_households (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            unit_id INT UNSIGNED NOT NULL,
            code VARCHAR(40) NOT NULL UNIQUE,
            name VARCHAR(120) NOT NULL,
            remark VARCHAR(255) NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(unit_id), INDEX(active), INDEX(deleted_at)
        )");
        $this->forge->addColumn('residents', [
            'household_id' => ['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'unit_id'],
            'gender'       => ['type'=>'ENUM','constraint'=>['male','female'],'null'=>true,'after'=>'name'],
            'birth_date'   => ['type'=>'DATE','null'=>true,'after'=>'gender'],
        ]);
        $this->db->query("CREATE TABLE resident_documents (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            resident_id INT UNSIGNED NOT NULL,
            document_type ENUM('ktp','kk','other') NOT NULL DEFAULT 'other',
            original_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            mime_type VARCHAR(100) NULL,
            file_size INT UNSIGNED NULL,
            remark VARCHAR(255) NULL,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            deleted_at DATETIME NULL,
            INDEX(resident_id), INDEX(document_type), INDEX(deleted_at)
        )");

        $now=date('Y-m-d H:i:s');
        $parent=$this->db->table('menus')->select('id')->where('name','Data Master')->where('deleted_at',null)->get()->getRowArray();
        if(!$parent)return;
        $this->db->table('menus')->insert(['parent_id'=>$parent['id'],'name'=>'Grup Penghuni','route'=>'master/resident-groups','icon'=>'fas fa-users','sort_order'=>23,'active'=>1,'created_at'=>$now]);
        $menuId=(int)$this->db->insertID();
        $residentMenu=$this->db->table('menus')->select('id')->where('route','master/residents')->where('deleted_at',null)->get()->getRowArray();
        foreach($this->db->table('roles')->select('id,name')->where('deleted_at',null)->get()->getResultArray() as $role){
            $access=$residentMenu?$this->db->table('role_menus')->where('role_id',$role['id'])->where('menu_id',$residentMenu['id'])->get()->getRowArray():null;
            $admin=$role['name']==='Administrator';
            $this->db->table('role_menus')->insert(['role_id'=>$role['id'],'menu_id'=>$menuId,'can_create'=>$access['can_create']??($admin?1:0),'can_read'=>$access['can_read']??($admin?1:0),'can_update'=>$access['can_update']??($admin?1:0),'can_delete'=>$access['can_delete']??($admin?1:0)]);
        }
    }

    public function down()
    {
        $menu=$this->db->table('menus')->select('id')->where('route','master/resident-groups')->get()->getRowArray();
        if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();}
        $this->forge->dropTable('resident_documents',true);
        $this->forge->dropColumn('residents',['household_id','gender','birth_date']);
        $this->forge->dropTable('resident_households',true);
    }
}
