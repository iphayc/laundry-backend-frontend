<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UseResidentAsHouseholdHead extends Migration
{
    public function up()
    {
        $this->forge->addColumn('residents', [
            'household_head_id' => ['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'unit_id'],
            'is_household_head' => ['type'=>'TINYINT','constraint'=>1,'default'=>0,'after'=>'household_head_id'],
        ]);

        if ($this->db->tableExists('resident_households')) {
            $households=$this->db->table('resident_households')->select('id')->where('deleted_at',null)->get()->getResultArray();
            foreach($households as $household){
                $members=$this->db->table('residents')->select('id')->where('household_id',$household['id'])->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
                if(!$members)continue;
                $headId=(int)$members[0]['id'];
                $this->db->table('residents')->where('id',$headId)->update(['is_household_head'=>1,'household_head_id'=>null]);
                if(count($members)>1)$this->db->table('residents')->whereIn('id',array_map('intval',array_column(array_slice($members,1),'id')))->update(['is_household_head'=>0,'household_head_id'=>$headId]);
            }
        }

        if(in_array('household_id',$this->db->getFieldNames('residents'),true))$this->forge->dropColumn('residents','household_id');
        $this->forge->dropTable('resident_households',true);

        $menus=$this->db->table('menus')->select('id')->where('route','master/resident-groups')->get()->getResultArray();
        foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
        if($menus)$this->db->table('menus')->whereIn('id',array_column($menus,'id'))->update(['active'=>0,'deleted_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
    }

    public function down()
    {
        $this->db->query("CREATE TABLE resident_households (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, unit_id INT UNSIGNED NOT NULL,
            code VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, remark VARCHAR(255) NULL,
            active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL,
            deleted_at DATETIME NULL, INDEX(unit_id), INDEX(active), INDEX(deleted_at)
        )");
        $this->forge->addColumn('residents',['household_id'=>['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'unit_id']]);
        $this->forge->dropColumn('residents',['household_head_id','is_household_head']);
    }
}
