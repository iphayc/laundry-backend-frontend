<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class InitializeHouseholdHeads extends Migration
{
    public function up()
    {
        $units=$this->db->table('residents')->select('unit_id')->where('deleted_at',null)->groupBy('unit_id')->get()->getResultArray();
        foreach($units as $unit){
            $head=$this->db->table('residents')->select('id')->where('unit_id',$unit['unit_id'])->where('is_household_head',1)->where('deleted_at',null)->orderBy('id')->get()->getRowArray();
            if(!$head){
                $head=$this->db->table('residents')->select('id')->where('unit_id',$unit['unit_id'])->where('deleted_at',null)->orderBy('id')->get()->getRowArray();
                if(!$head)continue;
                $this->db->table('residents')->where('id',$head['id'])->update(['is_household_head'=>1,'household_head_id'=>null,'updated_at'=>date('Y-m-d H:i:s')]);
            }
            $this->db->table('residents')->where('unit_id',$unit['unit_id'])->where('id !=',$head['id'])->where('is_household_head',0)->where('household_head_id',null)->where('deleted_at',null)->update(['household_head_id'=>$head['id'],'updated_at'=>date('Y-m-d H:i:s')]);
        }
    }

    public function down()
    {
        $this->db->table('residents')->update(['household_head_id'=>null,'is_household_head'=>0]);
    }
}
