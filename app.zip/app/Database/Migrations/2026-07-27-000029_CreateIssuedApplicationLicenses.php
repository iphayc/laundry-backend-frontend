<?php

namespace App\Database\Migrations;

use App\Services\LicenseService;
use CodeIgniter\Database\Migration;

class CreateIssuedApplicationLicenses extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'registered_email' => [
                'type' => 'VARCHAR',
                'constraint' => 160,
            ],
            'machine_id' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'machine_id_hash' => [
                'type' => 'CHAR',
                'constraint' => 64,
            ],
            'license_code_hash' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'active' => [
                'type' => 'TINYINT',
                'constraint' => 1,
                'default' => 1,
            ],
            'registered_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'last_generated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'created_by' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['registered_email', 'machine_id_hash'], false, true);
        $this->forge->createTable('issued_application_licenses', true);

        $license = new LicenseService();
        $email = 'iphayc@gmail.com';
        $machineId = $license->machineId();
        $code = $license->activationCode($email, $machineId);
        $now = date('Y-m-d H:i:s');

        $this->db->table('issued_application_licenses')->insert([
            'registered_email' => $email,
            'machine_id' => $machineId,
            'machine_id_hash' => $license->machineFingerprint($machineId),
            'license_code_hash' => password_hash($code, PASSWORD_DEFAULT),
            'active' => 1,
            'registered_at' => $now,
            'last_generated_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function down()
    {
        $this->forge->dropTable('issued_application_licenses', true);
    }
}
