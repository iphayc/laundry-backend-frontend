<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddWhatsAppProviderAndToken extends Migration
{
    public function up()
    {
        if (! $this->db->fieldExists('provider', 'whatsapp_settings')) {
            $this->forge->addColumn('whatsapp_settings', [
                'provider' => [
                    'type' => 'VARCHAR',
                    'constraint' => 30,
                    'default' => 'custom',
                    'after' => 'id',
                ],
            ]);
        }

        if (! $this->db->fieldExists('token_encrypted', 'whatsapp_settings')) {
            $this->forge->addColumn('whatsapp_settings', [
                'token_encrypted' => [
                    'type' => 'TEXT',
                    'null' => true,
                    'after' => 'api_key_encrypted',
                ],
            ]);
        }
    }

    public function down()
    {
        if ($this->db->fieldExists('token_encrypted', 'whatsapp_settings')) {
            $this->forge->dropColumn('whatsapp_settings', 'token_encrypted');
        }
        if ($this->db->fieldExists('provider', 'whatsapp_settings')) {
            $this->forge->dropColumn('whatsapp_settings', 'provider');
        }
    }
}
