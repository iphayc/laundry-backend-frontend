<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateWhatsAppProviders extends Migration
{
    public function up()
    {
        if (! $this->db->tableExists('whatsapp_providers')) {
            $this->forge->addField([
                'id' => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
                'code' => ['type' => 'VARCHAR', 'constraint' => 30],
                'name' => ['type' => 'VARCHAR', 'constraint' => 100],
                'auth_type' => ['type' => 'VARCHAR', 'constraint' => 30, 'default' => 'token'],
                'default_url_text' => ['type' => 'VARCHAR', 'constraint' => 500, 'null' => true],
                'default_url_image' => ['type' => 'VARCHAR', 'constraint' => 500, 'null' => true],
                'is_default' => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
                'active' => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
                'created_at' => ['type' => 'DATETIME', 'null' => true],
                'updated_at' => ['type' => 'DATETIME', 'null' => true],
                'deleted_at' => ['type' => 'DATETIME', 'null' => true],
            ]);
            $this->forge->addKey('id', true);
            $this->forge->addUniqueKey('code');
            $this->forge->addKey(['is_default', 'active', 'deleted_at']);
            $this->forge->createTable('whatsapp_providers');
        }

        $current = $this->db->table('whatsapp_settings')->select('provider')->where('deleted_at', null)->orderBy('id', 'DESC')->get()->getRowArray();
        $defaultCode = strtolower((string) ($current['provider'] ?? 'fonnte'));
        if (! in_array($defaultCode, ['fonnte', 'watzap', 'custom'], true)) $defaultCode = 'fonnte';
        $now = date('Y-m-d H:i:s');
        foreach ([
            ['code'=>'fonnte','name'=>'Fonnte','auth_type'=>'token','default_url_text'=>'https://api.fonnte.com/send','default_url_image'=>'https://api.fonnte.com/send'],
            ['code'=>'watzap','name'=>'Watzap','auth_type'=>'api_key_number_key','default_url_text'=>'https://api.watzap.id/v1/send_message','default_url_image'=>'https://api.watzap.id/v1/send_image_url'],
            ['code'=>'custom','name'=>'Custom / Legacy API','auth_type'=>'custom','default_url_text'=>null,'default_url_image'=>null],
        ] as $provider) {
            if (! $this->db->table('whatsapp_providers')->where('code', $provider['code'])->countAllResults()) {
                $this->db->table('whatsapp_providers')->insert($provider + ['is_default'=>$provider['code']===$defaultCode?1:0,'active'=>1,'created_at'=>$now]);
            }
        }

        if (! $this->db->fieldExists('provider_id', 'whatsapp_settings')) {
            $this->forge->addColumn('whatsapp_settings', [
                'provider_id' => ['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'provider'],
            ]);
        }
        $providers = $this->db->table('whatsapp_providers')->select('id,code')->get()->getResultArray();
        foreach ($providers as $provider) {
            $this->db->table('whatsapp_settings')->where('provider', $provider['code'])->update(['provider_id'=>$provider['id']]);
        }

        $settingMenu = $this->db->table('menus')->select('parent_id')->where('route', 'settings/whatsapp')->where('deleted_at', null)->get()->getRowArray();
        $parent = $settingMenu && $settingMenu['parent_id']
            ? $this->db->table('menus')->where('id', $settingMenu['parent_id'])->where('deleted_at', null)->get()->getRowArray()
            : $this->db->table('menus')->where('name', 'Data Master')->where('parent_id', null)->where('deleted_at', null)->get()->getRowArray();
        if ($parent && ! $this->db->table('menus')->where('route', 'master/whatsapp-providers')->countAllResults()) {
            $this->db->table('menus')->insert(['parent_id'=>$parent['id'],'name'=>'WhatsApp Provider','route'=>'master/whatsapp-providers','icon'=>'fas fa-network-wired','sort_order'=>29,'active'=>1,'created_at'=>$now]);
            $menuId = (int) $this->db->insertID();
            $admin = $this->db->table('roles')->select('id')->where('name', 'Administrator')->where('deleted_at', null)->get()->getRowArray();
            if ($admin) $this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        }
    }

    public function down()
    {
        $menu = $this->db->table('menus')->select('id')->where('route', 'master/whatsapp-providers')->get()->getRowArray();
        if ($menu) {
            $this->db->table('role_menus')->where('menu_id', $menu['id'])->delete();
            $this->db->table('menus')->where('id', $menu['id'])->delete();
        }
        if ($this->db->fieldExists('provider_id', 'whatsapp_settings')) $this->forge->dropColumn('whatsapp_settings', 'provider_id');
        $this->forge->dropTable('whatsapp_providers', true);
    }
}
