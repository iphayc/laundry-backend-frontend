<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class GroupWhatsAppProviderMenu extends Migration
{
    public function up()
    {
        $setting = $this->db->table('menus')->select('parent_id')->where('route', 'settings/whatsapp')->where('deleted_at', null)->get()->getRowArray();
        if ($setting && $setting['parent_id']) {
            $this->db->table('menus')->where('route', 'master/whatsapp-providers')->update(['parent_id'=>$setting['parent_id'],'sort_order'=>29,'updated_at'=>date('Y-m-d H:i:s')]);
        }
    }

    public function down()
    {
        $master = $this->db->table('menus')->select('id')->where('name', 'Data Master')->where('parent_id', null)->where('deleted_at', null)->get()->getRowArray();
        if ($master) $this->db->table('menus')->where('route', 'master/whatsapp-providers')->update(['parent_id'=>$master['id'],'updated_at'=>date('Y-m-d H:i:s')]);
    }
}
