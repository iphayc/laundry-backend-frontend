<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddEmailProvidersAndBroadcast extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('is_default','email_smtp_settings')){
            $this->forge->addColumn('email_smtp_settings',['is_default'=>['type'=>'TINYINT','constraint'=>1,'default'=>0,'after'=>'active']]);
        }
        $default=$this->db->table('email_smtp_settings')->where('deleted_at',null)->orderBy('active','DESC')->orderBy('id','DESC')->get()->getRowArray();
        if($default)$this->db->table('email_smtp_settings')->where('id',$default['id'])->update(['is_default'=>1]);

        $setting=$this->db->table('menus')->select('parent_id')->where('route','settings/email')->where('deleted_at',null)->get()->getRowArray();
        $notificationParent=$setting['parent_id']??null;
        $transaction=$this->db->table('menus')->where('name','Transaksi')->where('parent_id',null)->where('deleted_at',null)->get()->getRowArray();
        $admin=$this->db->table('roles')->select('id')->where('name','Administrator')->where('deleted_at',null)->get()->getRowArray();
        $now=date('Y-m-d H:i:s');
        foreach([
            [$notificationParent,'Email Provider','master/email-providers','fas fa-at',28],
            [$transaction['id']??null,'Kirim Email Penghuni','transactions/email','fas fa-envelope-open-text',2],
        ] as [$parentId,$name,$route,$icon,$sort]){
            if(!$parentId||$this->db->table('menus')->where('route',$route)->countAllResults())continue;
            $this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>$name,'route'=>$route,'icon'=>$icon,'sort_order'=>$sort,'active'=>1,'created_at'=>$now]);
            $menuId=(int)$this->db->insertID();
            if($admin)$this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        }
    }

    public function down()
    {
        $menus=$this->db->table('menus')->select('id')->whereIn('route',['master/email-providers','transactions/email'])->get()->getResultArray();
        foreach($menus as $menu)$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();
        $this->db->table('menus')->whereIn('route',['master/email-providers','transactions/email'])->delete();
        if($this->db->fieldExists('is_default','email_smtp_settings'))$this->forge->dropColumn('email_smtp_settings','is_default');
    }
}
