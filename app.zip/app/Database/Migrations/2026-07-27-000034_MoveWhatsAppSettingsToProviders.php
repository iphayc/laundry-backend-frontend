<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MoveWhatsAppSettingsToProviders extends Migration
{
    public function up()
    {
        foreach([
            'token_encrypted'=>['type'=>'TEXT','null'=>true,'after'=>'default_url_image'],
            'api_key_encrypted'=>['type'=>'TEXT','null'=>true,'after'=>'token_encrypted'],
            'number_key'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true,'after'=>'api_key_encrypted'],
            'phone_number_id'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true,'after'=>'number_key'],
            'phone_number'=>['type'=>'VARCHAR','constraint'=>40,'null'=>true,'after'=>'phone_number_id'],
            'graph_version'=>['type'=>'VARCHAR','constraint'=>20,'default'=>'v25.0','after'=>'phone_number'],
        ] as $field=>$definition)if(!$this->db->fieldExists($field,'whatsapp_providers'))$this->forge->addColumn('whatsapp_providers',[$field=>$definition]);

        if($this->db->tableExists('whatsapp_settings')){
            $settings=$this->db->table('whatsapp_settings')->where('deleted_at',null)->get()->getResultArray();
            foreach($settings as $setting){
                $provider=$this->db->table('whatsapp_providers')->where('id',(int)($setting['provider_id']??0))->get()->getRowArray();
                if(!$provider)$provider=$this->db->table('whatsapp_providers')->where('code',$setting['provider']??'custom')->get()->getRowArray();
                if(!$provider)continue;
                $this->db->table('whatsapp_providers')->where('id',$provider['id'])->update([
                    'default_url_text'=>$setting['url_send_text']?:$provider['default_url_text'],
                    'default_url_image'=>$setting['url_send_image']?:$provider['default_url_image'],
                    'token_encrypted'=>$setting['token_encrypted']??null,
                    'api_key_encrypted'=>$setting['api_key_encrypted']??null,
                    'number_key'=>$setting['key_number']??null,
                    'phone_number'=>$setting['phone_number']??null,
                    'active'=>$setting['active']??1,
                    'updated_at'=>date('Y-m-d H:i:s'),
                ]);
            }
        }
        if(!$this->db->table('whatsapp_providers')->where('code','meta')->countAllResults()){
            $this->db->table('whatsapp_providers')->insert(['code'=>'meta','name'=>'Meta Official / WhatsApp Cloud API','auth_type'=>'meta_official','default_url_text'=>'https://graph.facebook.com','default_url_image'=>'https://graph.facebook.com','graph_version'=>'v25.0','is_default'=>0,'active'=>1,'created_at'=>date('Y-m-d H:i:s')]);
        }
        $menu=$this->db->table('menus')->select('id')->where('route','settings/whatsapp')->get()->getRowArray();
        if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();}
        if($this->db->tableExists('whatsapp_settings'))$this->forge->dropTable('whatsapp_settings',true);
    }

    public function down()
    {
        // Pemulihan tabel lama tidak dilakukan karena secret sudah dipindahkan ke provider.
    }
}
