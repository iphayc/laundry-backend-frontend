<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateWatzapProviderUrls extends Migration
{
    public function up()
    {
        if($this->db->tableExists('whatsapp_providers')){
            $this->db->table('whatsapp_providers')->where('code','watzap')->update([
                'default_url_text'=>'https://api.watzap.id/v1/send_message',
                'default_url_image'=>'https://api.watzap.id/v1/send_image_url',
                'updated_at'=>date('Y-m-d H:i:s'),
            ]);
        }
    }

    public function down()
    {
        if($this->db->tableExists('whatsapp_providers')){
            $this->db->table('whatsapp_providers')->where('code','watzap')->update([
                'default_url_text'=>null,
                'default_url_image'=>null,
                'updated_at'=>date('Y-m-d H:i:s'),
            ]);
        }
    }
}
