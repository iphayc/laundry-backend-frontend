<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddEmailTemplateToRecipients extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('template_id','email_recipients')){
            $this->forge->addColumn('email_recipients',['template_id'=>['type'=>'INT','constraint'=>10,'unsigned'=>true,'null'=>true,'after'=>'cc']]);
        }
        $template=$this->db->table('notification_templates')->select('id')->whereIn('type',['email','both'])->where('status','active')->where('deleted_at',null)->orderBy('id')->get()->getRowArray();
        if(!$template){
            $this->db->table('notification_templates')->insert([
                'type'=>'email','template_name'=>'Aktivitas Gate','subject'=>'Aktivitas Gate - {{gate}} - {{waktu}}',
                'body'=>"Yth. {{nama}},\n\nBerikut kami sampaikan aktivitas gate terbaru.\n\nGate: {{gate}}\nWaktu: {{waktu}}\nKartu: {{kartu}}\nArah: {{arah}}\nHasil: {{hasil}}\nKeterangan: {{keterangan}}\n\nFoto aktivitas terlampir pada email ini.",
                'remark'=>'Template bawaan pengiriman aktivitas gate dari dashboard.','status'=>'active','created_at'=>date('Y-m-d H:i:s'),
            ]);
            $template=['id'=>(int)$this->db->insertID()];
        }
        if($template)$this->db->table('email_recipients')->where('template_id',null)->update(['template_id'=>$template['id']]);
    }

    public function down()
    {
        if($this->db->fieldExists('template_id','email_recipients'))$this->forge->dropColumn('email_recipients','template_id');
    }
}
