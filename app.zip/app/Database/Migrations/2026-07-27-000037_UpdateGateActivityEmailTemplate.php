<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateGateActivityEmailTemplate extends Migration
{
    public function up()
    {
        $this->db->table('notification_templates')->where('template_name','Aktivitas Gate')->where('deleted_at',null)->update([
            'subject'=>'Laporan Aktivitas Gate {{dari}} s.d. {{sampai}}',
            'body'=>"Yth. {{nama}},\n\nTerlampir laporan aktivitas gate periode {{dari}} sampai {{sampai}} sebanyak {{jumlah}} data dalam format Excel.\n\nMohon periksa file lampiran untuk rincian aktivitas.",
            'remark'=>'Template bawaan pengiriman Excel aktivitas gate dari dashboard.',
            'updated_at'=>date('Y-m-d H:i:s'),
        ]);
    }
    public function down(){}
}
