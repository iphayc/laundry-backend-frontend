<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddResidentAddress extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('address','residents')){
            $this->forge->addColumn('residents',['address'=>['type'=>'TEXT','null'=>true,'after'=>'birth_date']]);
        }
    }

    public function down()
    {
        if($this->db->fieldExists('address','residents'))$this->forge->dropColumn('residents','address');
    }
}
