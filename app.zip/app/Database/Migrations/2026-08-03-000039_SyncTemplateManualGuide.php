<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class SyncTemplateManualGuide extends Migration
{
    public function up()
    {
        $now = date('Y-m-d H:i:s');

        // Arsipkan seluruh panduan bawaan lama agar modul parkir yang sudah
        // dikeluarkan tidak muncul kembali pada instalasi yang telah berjalan.
        $this->db->table('help_articles')
            ->whereIn('id', range(1, 25))
            ->update(['active' => 0, 'deleted_at' => $now, 'updated_at' => $now]);

        $articles = [
            ['Mulai', 'Mengenal Eksis School ERP', "Tujuan:\nMemahami fungsi template dan urutan konfigurasi awal aplikasi.\n\nLangkah awal:\n1. Login menggunakan akun administrator.\n2. Buka Dashboard untuk memastikan koneksi database dan ringkasan sistem tampil.\n3. Lengkapi identitas pada Data Master > Company / Aplikasi.\n4. Atur role, group, pengguna, serta hak akses pada Manajemen User.\n5. Siapkan provider Email atau WhatsApp bila fitur notifikasi akan digunakan.\n6. Buat Master Template dan Penerima Email sesuai kebutuhan.\n7. Periksa Manual Guide dan About sebelum aplikasi diserahkan kepada pengguna.\n\nCatatan:\n- Template hanya menampilkan modul yang didukung tabel db_eksiserp.\n- Form transaksi, modul parkir, Gate Console, dan Master Device tidak tersedia.", 1],
            ['Dashboard', 'Menggunakan Dashboard Administrasi', "Tujuan:\nMemantau kondisi dasar aplikasi dan memastikan database tersambung.\n\nInformasi yang tersedia:\n- Jumlah pengguna.\n- Jumlah role.\n- Jumlah menu aktif.\n- Jumlah template notifikasi aktif.\n- Daftar 21 tabel yang terdeteksi pada db_eksiserp.\n- Sepuluh aktivitas sistem terbaru dari audit log.\n\nLangkah penggunaan:\n1. Buka menu Dashboard setelah login.\n2. Periksa empat kartu ringkasan di bagian atas.\n3. Periksa Aktivitas Sistem Terbaru untuk melihat pengguna, aksi, tabel, dan record terakhir.\n4. Pastikan panel Sinkronisasi Database menampilkan tabel aplikasi.\n\nJika data tidak muncul:\n- Periksa koneksi database pada file .env.\n- Pastikan tabel terkait tersedia dan akun database memiliki izin baca.", 2],
            ['Company', 'Mengatur Identitas Company / Aplikasi', "Tujuan:\nMengatur identitas yang digunakan pada halaman login, logo, favicon, header, dan footer aplikasi.\n\nLangkah penggunaan:\n1. Buka Data Master > Company / Aplikasi.\n2. Isi nama aplikasi/company, alamat, telepon, developer, email, dan lokasi Maps bila diperlukan.\n3. Unggah logo dengan format gambar yang didukung.\n4. Unggah foto company bila dibutuhkan.\n5. Pastikan status Aktif dipilih.\n6. Klik Simpan.\n7. Muat ulang halaman untuk melihat perubahan identitas dan logo.\n\nCatatan:\n- Gunakan file logo yang ringan dan proporsional.\n- Hanya data company aktif yang digunakan oleh tampilan aplikasi.", 3],
            ['Email Provider', 'Mengatur Email Provider', "Tujuan:\nMenyimpan satu atau lebih konfigurasi penyedia SMTP.\n\nLangkah penggunaan:\n1. Buka Data Master > Setting Notifikasi > Email Provider.\n2. Klik Tambah.\n3. Isi nama akun, SMTP host, port, username, password, jenis enkripsi, email pengirim, dan nama pengirim.\n4. Aktifkan provider.\n5. Pilih sebagai Default bila provider tersebut menjadi pengirim utama.\n6. Klik Simpan.\n7. Gunakan tombol Edit untuk memperbarui dan Arsip untuk menonaktifkan data lama.\n\nCatatan keamanan:\n- Password SMTP disimpan dalam bentuk terenkripsi.\n- Pastikan hanya satu konfigurasi yang digunakan sebagai default.", 4],
            ['WhatsApp Provider', 'Mengatur WhatsApp Provider', "Tujuan:\nMenyimpan konfigurasi gateway WhatsApp yang dapat digunakan layanan notifikasi.\n\nLangkah penggunaan:\n1. Buka Data Master > Setting Notifikasi > WhatsApp Provider.\n2. Klik Tambah.\n3. Pilih tipe autentikasi dan isi URL pengiriman teks serta gambar.\n4. Isi token atau API key sesuai dokumentasi provider.\n5. Isi number key, phone number ID, nomor pengirim, atau versi Graph bila diperlukan.\n6. Aktifkan provider dan pilih sebagai Default bila menjadi provider utama.\n7. Klik Simpan.\n\nCatatan keamanan:\n- Token dan API key disimpan secara terenkripsi.\n- Kebutuhan setiap kolom bergantung pada provider yang dipilih.", 5],
            ['Master Template', 'Mengelola Template Notifikasi', "Tujuan:\nMenyediakan format pesan Email atau WhatsApp yang dapat digunakan ulang.\n\nLangkah penggunaan:\n1. Buka Data Master > Master Template.\n2. Klik Tambah.\n3. Pilih jenis Email, WhatsApp, atau Both.\n4. Isi nama template.\n5. Isi Subject untuk template email.\n6. Isi Body dan Remark sesuai kebutuhan.\n7. Aktifkan status template lalu klik Simpan.\n\nCatatan:\n- Gunakan nama template yang jelas dan unik.\n- Placeholder hanya dapat digunakan bila modul pemanggil memang menyediakan nilai penggantinya.\n- Template nonaktif tidak ditawarkan pada pilihan penerima email.", 6],
            ['Penerima Email', 'Mengelola Penerima Email', "Tujuan:\nMenentukan alamat tujuan dan template untuk notifikasi email.\n\nLangkah penggunaan:\n1. Pastikan Master Template berjenis Email atau Both sudah aktif.\n2. Buka Data Master > Setting Notifikasi > Penerima Email.\n3. Klik Tambah.\n4. Isi nama penerima.\n5. Isi satu atau beberapa alamat To, dipisahkan dengan koma.\n6. Isi CC bila diperlukan, juga dipisahkan dengan koma.\n7. Pilih template email aktif.\n8. Isi deskripsi, aktifkan data, lalu klik Simpan.\n\nCatatan:\n- Sistem memvalidasi format setiap alamat email.\n- Data penerima dapat diedit atau diarsipkan dari tabel daftar.", 7],
            ['Setting SMTP', 'Mengatur dan Menguji SMTP', "Tujuan:\nMenentukan akun SMTP aktif dan menguji koneksi pengiriman email.\n\nLangkah penggunaan:\n1. Buka Data Master > Setting Notifikasi > Setting SMTP.\n2. Isi host, port, username, password, enkripsi, alamat pengirim, dan nama pengirim.\n3. Aktifkan konfigurasi dan tentukan sebagai default bila diperlukan.\n4. Klik Simpan.\n5. Gunakan fungsi Test Email untuk memastikan server SMTP dapat mengirim pesan.\n\nJika pengujian gagal:\n- Periksa host dan port.\n- Periksa username serta password.\n- Pastikan jenis enkripsi sesuai dengan server SMTP.\n- Periksa firewall dan log aplikasi.", 8],
            ['Log Notifikasi', 'Memeriksa Log Notifikasi', "Tujuan:\nMemantau hasil pengiriman Email dan WhatsApp.\n\nLangkah penggunaan:\n1. Buka menu Log Notifikasi.\n2. Pilih rentang tanggal.\n3. Filter channel Email atau WhatsApp bila diperlukan.\n4. Filter status Sent atau Failed.\n5. Periksa tujuan, subject, isi pesan, jumlah percobaan, response, dan error message.\n6. Untuk data berstatus Failed, klik Resend setelah konfigurasi provider diperbaiki.\n\nCatatan:\n- Resend hanya tersedia untuk pengiriman yang gagal.\n- Riwayat response membantu administrator mendiagnosis masalah provider.", 9],
            ['User', 'Mengelola Pengguna', "Tujuan:\nMembuat dan memelihara akun pengguna aplikasi.\n\nLangkah penggunaan:\n1. Buka Manajemen User > User.\n2. Klik Tambah.\n3. Pilih Role dan Group.\n4. Isi username, nama, email, telepon, password, dan konfirmasi password.\n5. Aktifkan pengguna lalu klik Simpan.\n6. Gunakan Edit untuk memperbarui profil pengguna.\n7. Gunakan Reset Password bila pengguna lupa password.\n8. Gunakan Arsip untuk menonaktifkan data tanpa menghapus permanen.\n\nCatatan keamanan:\n- Gunakan password yang kuat dan unik.\n- Jangan gunakan akun administrator untuk operasional harian.", 10],
            ['Role & Access', 'Mengatur Role, Group, dan Hak Akses', "Tujuan:\nMembatasi menu dan tindakan sesuai tanggung jawab pengguna.\n\nLangkah penggunaan:\n1. Buat atau edit role melalui Manajemen User > Master Role.\n2. Buat group bila struktur kelompok pengguna diperlukan.\n3. Buka Manajemen User > Role & Group.\n4. Pilih role yang akan diatur.\n5. Centang menu yang boleh diakses oleh role tersebut.\n6. Atur hak Create, Read, Update, dan Delete sesuai kebutuhan.\n7. Atur permission tambahan yang relevan.\n8. Klik Simpan lalu uji menggunakan akun dengan role tersebut.\n\nCatatan:\n- Hak Read menentukan apakah menu dapat dibuka.\n- Berikan hak minimum yang diperlukan.", 11],
            ['Master Menu', 'Mengelola Menu Dinamis', "Tujuan:\nMengatur struktur navigasi yang tampil pada sidebar aplikasi.\n\nLangkah penggunaan:\n1. Buka Manajemen User > Master Menu.\n2. Klik Tambah untuk membuat menu.\n3. Pilih Parent Menu bila menu menjadi submenu.\n4. Isi nama, route, icon CSS, urutan, dan status aktif.\n5. Klik Simpan.\n6. Buka Role & Group dan berikan akses menu kepada role yang memerlukan.\n7. Gunakan Edit untuk memperbarui atau Arsip untuk menyembunyikan menu beserta turunannya.\n\nPeringatan:\n- Route harus benar-benar tersedia pada aplikasi.\n- Jangan menambahkan kembali route transaksi, parkir, gate, atau device yang sudah dikeluarkan.", 12],
            ['Profile', 'Mengubah Profile dan Password', "Tujuan:\nMemperbarui data akun yang sedang login dan mengganti password pribadi.\n\nMengubah profile:\n1. Klik Profile di kanan atas.\n2. Buka form Profile.\n3. Perbarui nama, email, dan telepon.\n4. Klik Simpan Profile.\n\nMengubah password:\n1. Klik Profile > Change Password.\n2. Isi password lama.\n3. Isi password baru minimal 8 karakter.\n4. Ulangi password baru pada kolom konfirmasi.\n5. Klik Simpan.\n\nCatatan keamanan:\n- Jangan membagikan password kepada pengguna lain.\n- Segera ganti password bila dicurigai telah diketahui pihak lain.", 13],
            ['Help', 'Mengelola Manual Guide dan About', "Tujuan:\nMenyediakan dokumentasi penggunaan dan informasi versi aplikasi.\n\nManual Guide:\n1. Buka Help > Manual Guide.\n2. Gunakan pencarian untuk menemukan modul atau judul.\n3. Klik judul atau tombol Baca untuk membuka panduan.\n4. Gunakan Cetak / Simpan PDF bila membutuhkan salinan.\n5. Administrator dapat menambah, mengedit, mengunggah screenshot, dan mengarsipkan panduan.\n\nAbout:\n1. Buka Help > About.\n2. Administrator dapat memperbarui nama aplikasi, versi, developer, email, website, dan deskripsi.\n3. Klik Simpan untuk memperbarui informasi.\n\nCatatan:\n- Perbarui panduan setiap kali menu atau alur aplikasi berubah.", 14],
            ['Registrasi', 'Mengaktifkan Aplikasi pada Server', "Tujuan:\nMengaktifkan aplikasi untuk Machine ID server tempat aplikasi dijalankan.\n\nLangkah penggunaan:\n1. Buka Help > Register Aplikasi atau ikuti pengalihan otomatis ketika lisensi belum valid.\n2. Catat Machine ID yang ditampilkan.\n3. Masukkan email terdaftar untuk meminta kode aktivasi.\n4. Periksa email lalu masukkan kode pada form registrasi.\n5. Selesaikan aktivasi dan login kembali.\n\nCatatan:\n- Kode aktivasi terikat pada Machine ID.\n- Perpindahan server dapat menghasilkan Machine ID baru.\n- Hubungi administrator lisensi bila kode tidak diterima atau tidak valid.", 15],
        ];

        foreach ($articles as [$module, $title, $content, $sortOrder]) {
            $this->db->table('help_articles')->insert([
                'module' => $module,
                'title' => $title,
                'content' => $content,
                'screenshot_path' => null,
                'sort_order' => $sortOrder,
                'active' => 1,
                'created_at' => $now,
                'updated_at' => $now,
                'deleted_at' => null,
            ]);
        }
    }

    public function down()
    {
        $this->db->table('help_articles')
            ->where('created_at', '>=', date('Y-m-d 00:00:00'))
            ->whereIn('module', ['Mulai', 'Dashboard', 'Company', 'Email Provider', 'WhatsApp Provider', 'Master Template', 'Penerima Email', 'Setting SMTP', 'Log Notifikasi', 'User', 'Role & Access', 'Master Menu', 'Profile', 'Help', 'Registrasi'])
            ->delete();
    }
}
