<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePpdbModule extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => ['type'=>'INT','unsigned'=>true,'auto_increment'=>true],
            'name' => ['type'=>'VARCHAR','constraint'=>30],
            'start_date' => ['type'=>'DATE','null'=>true],
            'end_date' => ['type'=>'DATE','null'=>true],
            'registration_open_at' => ['type'=>'DATE','null'=>true],
            'registration_close_at' => ['type'=>'DATE','null'=>true],
            'active' => ['type'=>'TINYINT','constraint'=>1,'default'=>1],
            'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true)->addUniqueKey('name')->createTable('academic_years',true);

        $this->forge->addField([
            'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
            'registration_no'=>['type'=>'VARCHAR','constraint'=>30],
            'academic_year_id'=>['type'=>'INT','unsigned'=>true],
            'registration_date'=>['type'=>'DATE'],
            'target_grade'=>['type'=>'VARCHAR','constraint'=>30],
            'full_name'=>['type'=>'VARCHAR','constraint'=>160],
            'nickname'=>['type'=>'VARCHAR','constraint'=>60,'null'=>true],
            'nisn'=>['type'=>'VARCHAR','constraint'=>20,'null'=>true],
            'nik'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],
            'birth_place'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],
            'birth_date'=>['type'=>'DATE','null'=>true],
            'gender'=>['type'=>'ENUM','constraint'=>['male','female']],
            'religion'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],
            'previous_school'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'address'=>['type'=>'TEXT','null'=>true],
            'city'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],
            'postal_code'=>['type'=>'VARCHAR','constraint'=>10,'null'=>true],
            'phone'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],
            'email'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'father_name'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'mother_name'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'guardian_name'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'parent_phone'=>['type'=>'VARCHAR','constraint'=>30],
            'parent_email'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],
            'registration_fee'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0],
            'status'=>['type'=>'ENUM','constraint'=>['draft','submitted','verified','accepted','rejected','cancelled'],'default'=>'submitted'],
            'notes'=>['type'=>'TEXT','null'=>true],
            'created_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'updated_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true)->addUniqueKey('registration_no')->addKey('academic_year_id')->addKey('status');
        $this->forge->addForeignKey('academic_year_id','academic_years','id','RESTRICT','RESTRICT')->createTable('ppdb_registrations',true);

        $this->forge->addField([
            'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
            'payment_no'=>['type'=>'VARCHAR','constraint'=>30],
            'registration_id'=>['type'=>'BIGINT','unsigned'=>true],
            'payment_date'=>['type'=>'DATE'],
            'payment_method'=>['type'=>'ENUM','constraint'=>['cash','bank_transfer','card','ewallet','other'],'default'=>'cash'],
            'amount'=>['type'=>'DECIMAL','constraint'=>'15,2'],
            'reference_no'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],
            'status'=>['type'=>'ENUM','constraint'=>['pending','paid','void','refunded','partial_refund'],'default'=>'paid'],
            'notes'=>['type'=>'TEXT','null'=>true],
            'created_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'updated_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true)->addUniqueKey('payment_no')->addKey('registration_id')->addKey('status');
        $this->forge->addForeignKey('registration_id','ppdb_registrations','id','RESTRICT','RESTRICT')->createTable('ppdb_payments',true);

        $this->forge->addField([
            'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
            'refund_no'=>['type'=>'VARCHAR','constraint'=>30],
            'payment_id'=>['type'=>'BIGINT','unsigned'=>true],
            'refund_date'=>['type'=>'DATE'],
            'amount'=>['type'=>'DECIMAL','constraint'=>'15,2'],
            'reason'=>['type'=>'TEXT'],
            'method'=>['type'=>'ENUM','constraint'=>['cash','bank_transfer','original_method','other'],'default'=>'original_method'],
            'status'=>['type'=>'ENUM','constraint'=>['requested','approved','paid','rejected','cancelled'],'default'=>'requested'],
            'approved_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'approved_at'=>['type'=>'DATETIME','null'=>true],
            'created_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'updated_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true)->addUniqueKey('refund_no')->addKey('payment_id')->addKey('status');
        $this->forge->addForeignKey('payment_id','ppdb_payments','id','RESTRICT','RESTRICT')->createTable('ppdb_refunds',true);

        $this->forge->addField([
            'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
            'admission_no'=>['type'=>'VARCHAR','constraint'=>30],
            'registration_id'=>['type'=>'BIGINT','unsigned'=>true],
            'decision_date'=>['type'=>'DATE'],
            'decision'=>['type'=>'ENUM','constraint'=>['accepted','rejected','waiting_list']],
            'student_no'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],
            'accepted_grade'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],
            'enrollment_deadline'=>['type'=>'DATE','null'=>true],
            'enrollment_status'=>['type'=>'ENUM','constraint'=>['not_applicable','pending','completed','cancelled'],'default'=>'pending'],
            'notes'=>['type'=>'TEXT','null'=>true],
            'decided_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],
            'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true],
        ]);
        $this->forge->addKey('id',true)->addUniqueKey('admission_no')->addUniqueKey('registration_id')->addKey('decision');
        $this->forge->addForeignKey('registration_id','ppdb_registrations','id','RESTRICT','RESTRICT')->createTable('ppdb_admissions',true);

        $year=(int)date('Y');$now=date('Y-m-d H:i:s');
        $this->db->table('academic_years')->insert(['name'=>$year.'/'.($year+1),'start_date'=>$year.'-07-01','end_date'=>($year+1).'-06-30','registration_open_at'=>$year.'-01-01','registration_close_at'=>$year.'-06-30','active'=>1,'created_at'=>$now,'updated_at'=>$now]);

        $parentId=$this->insertMenu(null,'PPDB',null,'fas fa-user-graduate',5);
        $menus=[
            $this->insertMenu($parentId,'Pendaftaran','ppdb/registrations','fas fa-file-signature',1),
            $this->insertMenu($parentId,'Pembayaran','ppdb/payments','fas fa-cash-register',2),
            $this->insertMenu($parentId,'Pengembalian','ppdb/refunds','fas fa-undo-alt',3),
            $this->insertMenu($parentId,'Penerimaan','ppdb/admissions','fas fa-user-check',4),
        ];
        foreach(['ppdb.registrations'=>'Pendaftaran PPDB','ppdb.payments'=>'Pembayaran PPDB','ppdb.refunds'=>'Pengembalian PPDB','ppdb.admissions'=>'Penerimaan PPDB'] as $code=>$name){
            $this->db->table('permissions')->insert(['code'=>$code,'name'=>$name,'module'=>'ppdb','deleted_at'=>null]);
        }
        if($this->db->table('roles')->where('id',1)->where('deleted_at',null)->countAllResults()){
            foreach([$parentId,...$menus] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
            $permissions=$this->db->table('permissions')->select('id')->like('code','ppdb.','after')->get()->getResultArray();
            foreach($permissions as $permission)$this->db->table('role_permissions')->insert(['role_id'=>1,'permission_id'=>$permission['id'],'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        }
    }

    private function insertMenu(?int $parentId,string $name,?string $route,string $icon,int $sort): int
    {
        $now=date('Y-m-d H:i:s');$this->db->table('menus')->insert(['parent_id'=>$parentId,'name'=>$name,'route'=>$route,'icon'=>$icon,'sort_order'=>$sort,'active'=>1,'created_at'=>$now,'updated_at'=>$now]);return (int)$this->db->insertID();
    }

    public function down()
    {
        $ids=array_column($this->db->table('menus')->select('id')->groupStart()->where('name','PPDB')->orLike('route','ppdb/','after')->groupEnd()->get()->getResultArray(),'id');
        if($ids){$this->db->table('role_menus')->whereIn('menu_id',$ids)->delete();$this->db->table('menus')->whereIn('id',$ids)->delete();}
        $permissionIds=array_column($this->db->table('permissions')->select('id')->like('code','ppdb.','after')->get()->getResultArray(),'id');
        if($permissionIds){$this->db->table('role_permissions')->whereIn('permission_id',$permissionIds)->delete();$this->db->table('permissions')->whereIn('id',$permissionIds)->delete();}
        $this->forge->dropTable('ppdb_admissions',true);$this->forge->dropTable('ppdb_refunds',true);$this->forge->dropTable('ppdb_payments',true);$this->forge->dropTable('ppdb_registrations',true);$this->forge->dropTable('academic_years',true);
    }
}
