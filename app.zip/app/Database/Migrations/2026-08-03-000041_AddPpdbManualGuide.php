<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class AddPpdbManualGuide extends Migration
{
    public function up()
    {
        $now=date('Y-m-d H:i:s');
        $this->db->table('help_articles')->where('title','Menggunakan Dashboard Administrasi')->where('deleted_at',null)->set('content',str_replace('Daftar 21 tabel','Daftar tabel',(string)($this->db->table('help_articles')->select('content')->where('title','Menggunakan Dashboard Administrasi')->where('deleted_at',null)->get()->getRow('content')??'')))->update();
        $articles=[
            ['PPDB','Mengelola Pendaftaran PPDB',"Tujuan:\nMencatat calon siswa sebagai sumber data utama proses PPDB.\n\nLangkah penggunaan:\n1. Buka PPDB > Pendaftaran.\n2. Klik Tambah Pendaftaran.\n3. Pilih tahun akademik, tanggal, dan tingkat kelas tujuan.\n4. Isi data calon siswa serta orang tua atau wali.\n5. Isi biaya pendaftaran dan status proses.\n6. Klik Simpan; nomor pendaftaran dibuat otomatis.\n7. Gunakan Edit untuk melengkapi atau memverifikasi data.\n\nStatus:\n- Draft: data belum diajukan.\n- Submitted: pendaftaran telah diajukan.\n- Verified: data telah diperiksa.\n- Accepted atau Rejected: mengikuti keputusan penerimaan.\n- Cancelled: pendaftaran dibatalkan.\n\nCatatan:\nPendaftaran yang sudah memiliki pembayaran atau keputusan penerimaan tidak dapat diarsipkan.",3],
            ['PPDB','Mengelola Pembayaran PPDB',"Tujuan:\nMencatat pembayaran yang diterima dari calon siswa.\n\nLangkah penggunaan:\n1. Buka PPDB > Pembayaran.\n2. Klik Tambah Pembayaran.\n3. Pilih nomor pendaftaran.\n4. Isi tanggal, metode, nominal, dan nomor referensi.\n5. Tentukan status lalu klik Simpan.\n6. Nomor pembayaran dibuat otomatis.\n\nStatus:\n- Pending: pembayaran belum dikonfirmasi.\n- Paid: pembayaran sudah diterima.\n- Void: transaksi dibatalkan.\n- Partial Refund atau Refunded: diperbarui otomatis dari pengembalian yang dibayar.\n\nCatatan:\nPembayaran yang sudah memiliki transaksi pengembalian tidak dapat diarsipkan.",4],
            ['PPDB','Mengelola Pengembalian PPDB',"Tujuan:\nMencatat permintaan dan realisasi pengembalian pembayaran PPDB.\n\nLangkah penggunaan:\n1. Buka PPDB > Pengembalian.\n2. Klik Tambah Pengembalian.\n3. Pilih pembayaran yang akan dikembalikan.\n4. Isi tanggal, nominal, metode, dan alasan.\n5. Simpan dengan status Diajukan.\n6. Ubah menjadi Disetujui setelah otorisasi.\n7. Ubah menjadi Dibayar setelah dana benar-benar diserahkan.\n\nKontrol sistem:\n- Total pengembalian aktif tidak boleh melebihi nominal pembayaran.\n- Status pembayaran diperbarui otomatis setelah refund dibayar.\n- Refund yang sudah dibayar tidak dapat diarsipkan.",5],
            ['PPDB','Mengelola Penerimaan PPDB',"Tujuan:\nMencatat keputusan seleksi dan proses daftar ulang calon siswa.\n\nLangkah penggunaan:\n1. Buka PPDB > Penerimaan.\n2. Klik Tambah Keputusan.\n3. Pilih pendaftaran yang belum memiliki keputusan.\n4. Isi tanggal dan pilih Diterima, Ditolak, atau Daftar Tunggu.\n5. Untuk siswa diterima, isi tingkat kelas diterima, nomor siswa bila sudah tersedia, dan batas daftar ulang.\n6. Pilih status daftar ulang lalu klik Simpan.\n\nCatatan:\n- Satu pendaftaran hanya memiliki satu keputusan aktif.\n- Keputusan otomatis memperbarui status pendaftaran.\n- Modul Data Siswa pada tahap Akademik nanti dapat menggunakan hasil penerimaan yang daftar ulangnya selesai.",6],
        ];
        $this->db->table('help_articles')->where('deleted_at',null)->set('sort_order','sort_order+4',false)->where('sort_order >=',3)->update();
        foreach($articles as [$module,$title,$content,$sort])$this->db->table('help_articles')->insert(['module'=>$module,'title'=>$title,'content'=>$content,'sort_order'=>$sort,'active'=>1,'created_at'=>$now,'updated_at'=>$now]);
    }
    public function down(){ $this->db->table('help_articles')->whereIn('title',['Mengelola Pendaftaran PPDB','Mengelola Pembayaran PPDB','Mengelola Pengembalian PPDB','Mengelola Penerimaan PPDB'])->delete(); }
}
