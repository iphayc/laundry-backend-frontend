<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class CreatePublicPortalAndCms extends Migration
{
    public function up()
    {
        $this->forge->addColumn('ppdb_registrations',[
            'parent_user_id'=>['type'=>'INT','unsigned'=>true,'null'=>true,'after'=>'academic_year_id'],
            'form_document'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true,'after'=>'notes'],
            'form_returned_at'=>['type'=>'DATETIME','null'=>true,'after'=>'form_document'],
            'workflow_step'=>['type'=>'ENUM','constraint'=>['form_taken','payment_pending','payment_verification','form_returned','selection','accepted','rejected','cancelled'],'default'=>'form_taken','after'=>'form_returned_at'],
        ]);
        $this->forge->addColumn('ppdb_payments',[
            'proof_path'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true,'after'=>'reference_no'],
            'verified_by'=>['type'=>'INT','unsigned'=>true,'null'=>true,'after'=>'proof_path'],
            'verified_at'=>['type'=>'DATETIME','null'=>true,'after'=>'verified_by'],
        ]);

        $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'user_id'=>['type'=>'INT','unsigned'=>true],'nik'=>['type'=>'VARCHAR','constraint'=>30,'null'=>true],'address'=>['type'=>'TEXT','null'=>true],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true)->addUniqueKey('user_id')->addForeignKey('user_id','users','id','CASCADE','RESTRICT')->createTable('parent_profiles',true);

        $this->forge->addField(['id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],'user_id'=>['type'=>'INT','unsigned'=>true,'null'=>true],'registration_id'=>['type'=>'BIGINT','unsigned'=>true,'null'=>true],'student_no'=>['type'=>'VARCHAR','constraint'=>30],'full_name'=>['type'=>'VARCHAR','constraint'=>160],'photo_path'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'active'=>['type'=>'TINYINT','constraint'=>1,'default'=>1],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);
        $this->forge->addKey('id',true)->addUniqueKey('student_no')->addUniqueKey('registration_id')->createTable('students',true);

        $this->createSliderTable();$this->createPostTable();$this->createAwardTable();$this->createUniversityAcceptanceTable();
        $now=date('Y-m-d H:i:s');
        foreach([['Orang Tua','Akun portal orang tua'],['Siswa','Akun portal siswa']] as [$name,$description])if(!$this->db->table('roles')->where('name',$name)->where('deleted_at',null)->countAllResults())$this->db->table('roles')->insert(['name'=>$name,'description'=>$description,'created_at'=>$now,'updated_at'=>$now]);
        $management=(int)($this->db->table('groups')->select('id')->where('name','Management')->where('deleted_at',null)->get()->getRow('id')??0);
        foreach(['Orang Tua','Siswa'] as $name)if(!$this->db->table('groups')->where('name',$name)->where('deleted_at',null)->countAllResults())$this->db->table('groups')->insert(['parent_id'=>$management?:null,'name'=>$name,'description'=>'Group portal '.$name,'created_at'=>$now,'updated_at'=>$now]);

        $parent=$this->menu(null,'CMS Website',null,'fas fa-globe',6);$children=[];
        foreach([['Slider','cms/sliders','fas fa-images'],['Berita','cms/news','fas fa-newspaper'],['Pengumuman & Promo','cms/announcements','fas fa-bullhorn'],['Penghargaan','cms/awards','fas fa-trophy'],['Lolos PTN','cms/university-acceptances','fas fa-university']] as $i=>$m)$children[]=$this->menu($parent,$m[0],$m[1],$m[2],$i+1);
        if($this->db->table('roles')->where('id',1)->countAllResults())foreach([$parent,...$children] as $menuId)$this->db->table('role_menus')->insert(['role_id'=>1,'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);
        foreach(['Slider inspiratif','Program unggulan sekolah','Lingkungan belajar yang menyenangkan','Prestasi dan masa depan siswa'] as $i=>$title)$this->db->table('cms_sliders')->insert(['title'=>$title,'subtitle'=>'Eksis School ERP — belajar, bertumbuh, dan berprestasi bersama.','image_path'=>'images/login-school-cartoon.png','button_text'=>$i===0?'Daftar PPDB':null,'button_url'=>$i===0?'ppdb-account/register':null,'sort_order'=>$i+1,'active'=>1,'created_at'=>$now,'updated_at'=>$now]);
    }
    private function createSliderTable(){ $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'title'=>['type'=>'VARCHAR','constraint'=>180],'subtitle'=>['type'=>'TEXT','null'=>true],'image_path'=>['type'=>'VARCHAR','constraint'=>255],'button_text'=>['type'=>'VARCHAR','constraint'=>60,'null'=>true],'button_url'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'sort_order'=>['type'=>'INT','default'=>0],'active'=>['type'=>'TINYINT','constraint'=>1,'default'=>1],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);$this->forge->addKey('id',true)->createTable('cms_sliders',true);}
    private function createPostTable(){ $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'type'=>['type'=>'ENUM','constraint'=>['news','announcement','promo']],'slug'=>['type'=>'VARCHAR','constraint'=>190],'title'=>['type'=>'VARCHAR','constraint'=>220],'summary'=>['type'=>'TEXT','null'=>true],'content'=>['type'=>'LONGTEXT'],'image_path'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'published_at'=>['type'=>'DATETIME','null'=>true],'active'=>['type'=>'TINYINT','constraint'=>1,'default'=>1],'created_by'=>['type'=>'INT','unsigned'=>true,'null'=>true],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);$this->forge->addKey('id',true)->addUniqueKey('slug')->addKey('type')->createTable('cms_posts',true);}
    private function createAwardTable(){ $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'title'=>['type'=>'VARCHAR','constraint'=>220],'recipient'=>['type'=>'VARCHAR','constraint'=>160,'null'=>true],'level'=>['type'=>'VARCHAR','constraint'=>100,'null'=>true],'award_date'=>['type'=>'DATE','null'=>true],'description'=>['type'=>'TEXT','null'=>true],'image_path'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'sort_order'=>['type'=>'INT','default'=>0],'active'=>['type'=>'TINYINT','constraint'=>1,'default'=>1],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);$this->forge->addKey('id',true)->createTable('cms_awards',true);}
    private function createUniversityAcceptanceTable(){ $this->forge->addField(['id'=>['type'=>'INT','unsigned'=>true,'auto_increment'=>true],'student_id'=>['type'=>'BIGINT','unsigned'=>true],'university_name'=>['type'=>'VARCHAR','constraint'=>180],'study_program'=>['type'=>'VARCHAR','constraint'=>180,'null'=>true],'admission_year'=>['type'=>'YEAR'],'description'=>['type'=>'TEXT','null'=>true],'sort_order'=>['type'=>'INT','default'=>0],'active'=>['type'=>'TINYINT','constraint'=>1,'default'=>1],'created_at'=>['type'=>'DATETIME','null'=>true],'updated_at'=>['type'=>'DATETIME','null'=>true],'deleted_at'=>['type'=>'DATETIME','null'=>true]]);$this->forge->addKey('id',true)->addKey('student_id')->addForeignKey('student_id','students','id','RESTRICT','RESTRICT')->createTable('cms_university_acceptances',true);}
    private function menu(?int $parent,string $name,?string $route,string $icon,int $sort):int{$now=date('Y-m-d H:i:s');$this->db->table('menus')->insert(['parent_id'=>$parent,'name'=>$name,'route'=>$route,'icon'=>$icon,'sort_order'=>$sort,'active'=>1,'created_at'=>$now,'updated_at'=>$now]);return (int)$this->db->insertID();}
    public function down(){foreach(['cms_university_acceptances','cms_awards','cms_posts','cms_sliders','students','parent_profiles'] as $table)$this->forge->dropTable($table,true);$this->forge->dropColumn('ppdb_payments',['proof_path','verified_by','verified_at']);$this->forge->dropColumn('ppdb_registrations',['parent_user_id','form_document','form_returned_at','workflow_step']);}
}
