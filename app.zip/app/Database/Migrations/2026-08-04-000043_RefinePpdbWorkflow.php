<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class RefinePpdbWorkflow extends Migration
{
    public function up(){ $this->db->query("ALTER TABLE ppdb_registrations MODIFY workflow_step ENUM('form_taken','payment_pending','payment_verification','payment_verified','form_returned','selection','accepted','rejected','cancelled') NOT NULL DEFAULT 'form_taken'"); }
    public function down(){ $this->db->table('ppdb_registrations')->where('workflow_step','payment_verified')->update(['workflow_step'=>'payment_verification']);$this->db->query("ALTER TABLE ppdb_registrations MODIFY workflow_step ENUM('form_taken','payment_pending','payment_verification','form_returned','selection','accepted','rejected','cancelled') NOT NULL DEFAULT 'form_taken'"); }
}
