<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreateMobileAuthentication extends Migration
{
 public function up(){
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_users (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,role ENUM('OWNER','CASHIER') DEFAULT 'OWNER',fullname VARCHAR(100) NOT NULL,username VARCHAR(50) NULL,email VARCHAR(120) NOT NULL,phone VARCHAR(30),password VARCHAR(255) NOT NULL,photo VARCHAR(255),is_active TINYINT(1) DEFAULT 1,last_login DATETIME,created_at DATETIME,updated_at DATETIME,deleted_at DATETIME,UNIQUE(email),UNIQUE(username),INDEX(company_id),FOREIGN KEY(company_id) REFERENCES ex_companies(id)) ENGINE=InnoDB");
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_user_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,device_id BIGINT UNSIGNED NULL,token_hash CHAR(64) NOT NULL UNIQUE,expires_at DATETIME NOT NULL,revoked_at DATETIME NULL,created_at DATETIME NOT NULL,INDEX(user_id),INDEX(expires_at),FOREIGN KEY(user_id) REFERENCES ex_users(id),FOREIGN KEY(device_id) REFERENCES ex_devices(id)) ENGINE=InnoDB");
 }
 public function down(){$this->forge->dropTable('ex_user_tokens',true);$this->forge->dropTable('ex_users',true);}
}
