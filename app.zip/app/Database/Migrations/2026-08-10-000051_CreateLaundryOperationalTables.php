<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreateLaundryOperationalTables extends Migration
{
 public function up(){
  $sql=[
   "CREATE TABLE IF NOT EXISTS ex_customers (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,name VARCHAR(120) NOT NULL,phone VARCHAR(30) NULL,email VARCHAR(120) NULL,address TEXT NULL,notes TEXT NULL,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,INDEX(company_id),INDEX(phone)) ENGINE=InnoDB",
   "CREATE TABLE IF NOT EXISTS ex_orders (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,customer_id BIGINT UNSIGNED NULL,invoice_number VARCHAR(40) NOT NULL UNIQUE,status ENUM('RECEIVED','PROCESSING','READY','COMPLETED','CANCELLED') NOT NULL DEFAULT 'RECEIVED',service_name VARCHAR(120) NOT NULL,total DECIMAL(15,2) NOT NULL DEFAULT 0,paid_amount DECIMAL(15,2) NOT NULL DEFAULT 0,notes TEXT NULL,received_at DATETIME NULL,due_at DATETIME NULL,completed_at DATETIME NULL,created_by BIGINT UNSIGNED NULL,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,INDEX(company_id),INDEX(customer_id),INDEX(status)) ENGINE=InnoDB",
   "CREATE TABLE IF NOT EXISTS ex_branches (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,name VARCHAR(120) NOT NULL,address TEXT NULL,phone VARCHAR(30) NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,INDEX(company_id)) ENGINE=InnoDB"
  ];foreach($sql as $query)$this->db->query($query);
 }
 public function down(){$this->db->query('DROP TABLE IF EXISTS ex_orders');$this->db->query('DROP TABLE IF EXISTS ex_customers');$this->db->query('DROP TABLE IF EXISTS ex_branches');}
}
