<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddProductsAndOrderPayments extends Migration
{
 public function up(){
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_products (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,name VARCHAR(120) NOT NULL,unit VARCHAR(30) NOT NULL DEFAULT 'kg',price DECIMAL(15,2) NOT NULL DEFAULT 0,duration_hours INT UNSIGNED NULL,description TEXT NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,INDEX(company_id)) ENGINE=InnoDB");
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_order_items (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,order_id BIGINT UNSIGNED NOT NULL,product_id BIGINT UNSIGNED NULL,product_name VARCHAR(120) NOT NULL,unit VARCHAR(30) NOT NULL,qty DECIMAL(12,2) NOT NULL DEFAULT 1,price DECIMAL(15,2) NOT NULL DEFAULT 0,subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,created_at DATETIME NULL,INDEX(order_id),INDEX(product_id)) ENGINE=InnoDB");
  foreach(["ALTER TABLE ex_orders ADD payment_method ENUM('CASH','BANK_TRANSFER','QRIS') NULL AFTER paid_amount","ALTER TABLE ex_orders ADD cash_received DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER payment_method","ALTER TABLE ex_orders ADD change_amount DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER cash_received"] as $sql){try{$this->db->query($sql);}catch(\Throwable $e){}}
 }
 public function down(){$this->db->query('DROP TABLE IF EXISTS ex_order_items');$this->db->query('DROP TABLE IF EXISTS ex_products');foreach(['change_amount','cash_received','payment_method'] as $column){try{$this->db->query("ALTER TABLE ex_orders DROP COLUMN $column");}catch(\Throwable $e){}}}
}
