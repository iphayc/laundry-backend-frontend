<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class FixEmailConfigurationMenu extends Migration
{
    public function up()
    {
        $menu = $this->db->table('menus')->where('route', 'settings/email')->get()->getRowArray();
        if ($menu) {
            $this->db->table('menus')->where('id', $menu['id'])->update([
                'parent_id' => null,
                'name' => 'Konfigurasi Email',
                'icon' => 'fas fa-envelope-open-text',
                'sort_order' => 72,
                'active' => 1,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            $this->db->table('role_menus')->ignore(true)->insert(['role_id' => 1, 'menu_id' => $menu['id']]);
        }

        $smtp = $this->db->table('email_smtp_settings')->where('deleted_at', null)->orderBy('is_default', 'DESC')->get()->getRowArray();
        if ($smtp) {
            $this->db->table('email_smtp_settings')->where('id', $smtp['id'])->update([
                'account_name' => 'Eksis Laundry SMTP',
                'from_name' => 'Eksis Laundry',
                'active' => 1,
                'is_default' => 1,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }

    public function down()
    {
        $this->db->table('menus')->where('route', 'settings/email')->update(['active' => 0]);
    }
}
