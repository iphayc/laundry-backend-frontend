<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddDiscountsAndOrderWorkflow extends Migration
{
 public function up(){
  foreach(["ALTER TABLE ex_products ADD category ENUM('KILOAN','SATUAN','M2') NOT NULL DEFAULT 'KILOAN' AFTER name","ALTER TABLE ex_orders ADD estimated_days DECIMAL(6,2) NULL AFTER due_at","ALTER TABLE ex_orders ADD fulfillment_type ENUM('DROP_OFF','PICKUP','DELIVERY') NOT NULL DEFAULT 'DROP_OFF' AFTER estimated_days","ALTER TABLE ex_orders ADD is_priority TINYINT(1) NOT NULL DEFAULT 0 AFTER fulfillment_type","ALTER TABLE ex_orders ADD discount_id BIGINT UNSIGNED NULL AFTER is_priority","ALTER TABLE ex_orders ADD discount_amount DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER discount_id","ALTER TABLE ex_orders ADD subtotal DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER discount_amount"] as $sql){try{$this->db->query($sql);}catch(\Throwable $e){}}
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_discounts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,name VARCHAR(120) NOT NULL,type ENUM('PERCENT','FIXED') NOT NULL,value DECIMAL(15,2) NOT NULL,min_transaction DECIMAL(15,2) NOT NULL DEFAULT 0,starts_at DATETIME NULL,ends_at DATETIME NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,INDEX(company_id),INDEX(is_active)) ENGINE=InnoDB");
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_order_status_history (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,order_id BIGINT UNSIGNED NOT NULL,status VARCHAR(30) NOT NULL,notes TEXT NULL,changed_by BIGINT UNSIGNED NULL,created_at DATETIME NULL,INDEX(order_id)) ENGINE=InnoDB");
 }
 public function down(){$this->db->query('DROP TABLE IF EXISTS ex_order_status_history');$this->db->query('DROP TABLE IF EXISTS ex_discounts');foreach(['subtotal','discount_amount','discount_id','is_priority','fulfillment_type','estimated_days'] as $c){try{$this->db->query("ALTER TABLE ex_orders DROP COLUMN $c");}catch(\Throwable $e){}}try{$this->db->query('ALTER TABLE ex_products DROP COLUMN category');}catch(\Throwable $e){}}
}
