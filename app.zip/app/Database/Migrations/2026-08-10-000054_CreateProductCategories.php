<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreateProductCategories extends Migration
{
 public function up(){
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_product_categories (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,code VARCHAR(30) NOT NULL UNIQUE,name VARCHAR(80) NOT NULL,unit VARCHAR(20) NOT NULL,description VARCHAR(255) NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,sort_order INT NOT NULL DEFAULT 0,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL) ENGINE=InnoDB");
  $now=date('Y-m-d H:i:s');foreach([['KILOAN','Kiloan','kg',1],['SATUAN','Satuan','pcs',2],['M2','M²','m²',3]] as [$code,$name,$unit,$sort])if(!$this->db->table('ex_product_categories')->where('code',$code)->countAllResults())$this->db->table('ex_product_categories')->insert(compact('code','name','unit')+['sort_order'=>$sort,'is_active'=>1,'created_at'=>$now]);
  try{$this->db->query('ALTER TABLE ex_products ADD category_id BIGINT UNSIGNED NULL AFTER category');}catch(\Throwable $e){}
  $this->db->query('UPDATE ex_products p JOIN ex_product_categories c ON c.code=p.category SET p.category_id=c.id WHERE p.category_id IS NULL');
  if(!$this->db->table('menus')->where('route','platform/product-categories')->where('deleted_at',null)->countAllResults()){$this->db->table('menus')->insert(['parent_id'=>null,'name'=>'Kategori Produk','route'=>'platform/product-categories','icon'=>'fas fa-tags','sort_order'=>35,'active'=>1,'created_at'=>$now]);$menuId=(int)$this->db->insertID();$admin=$this->db->table('roles')->where('name','Administrator')->get()->getRowArray();if($admin)$this->db->table('role_menus')->insert(['role_id'=>$admin['id'],'menu_id'=>$menuId,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);}
 }
 public function down(){$menu=$this->db->table('menus')->where('route','platform/product-categories')->get()->getRowArray();if($menu){$this->db->table('role_menus')->where('menu_id',$menu['id'])->delete();$this->db->table('menus')->where('id',$menu['id'])->delete();}try{$this->db->query('ALTER TABLE ex_products DROP COLUMN category_id');}catch(\Throwable $e){}$this->db->query('DROP TABLE IF EXISTS ex_product_categories');}
}
