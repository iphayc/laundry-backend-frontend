<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddBranchReporting extends Migration
{
 public function up(){foreach(["ALTER TABLE ex_orders ADD branch_id BIGINT UNSIGNED NULL AFTER company_id","ALTER TABLE ex_users ADD branch_id BIGINT UNSIGNED NULL AFTER company_id"] as $sql){try{$this->db->query($sql);}catch(\Throwable $e){}}$companies=$this->db->table('ex_companies')->select('id,company_name,address,phone')->where('deleted_at',null)->get()->getResultArray();foreach($companies as $company){$branch=$this->db->table('ex_branches')->where('company_id',$company['id'])->where('deleted_at',null)->orderBy('id')->get()->getRowArray();if(!$branch){$this->db->table('ex_branches')->insert(['company_id'=>$company['id'],'name'=>'Cabang Utama','address'=>$company['address'],'phone'=>$company['phone'],'is_active'=>1,'created_at'=>date('Y-m-d H:i:s')]);$branchId=(int)$this->db->insertID();}else $branchId=(int)$branch['id'];$this->db->table('ex_orders')->where('company_id',$company['id'])->where('branch_id',null)->update(['branch_id'=>$branchId]);$this->db->table('ex_users')->where('company_id',$company['id'])->where('branch_id',null)->update(['branch_id'=>$branchId]);}}
 public function down(){foreach(['ex_orders','ex_users'] as $table){try{$this->db->query("ALTER TABLE $table DROP COLUMN branch_id");}catch(\Throwable $e){}}}
}
