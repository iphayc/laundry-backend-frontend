<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AssignBranchOnOrderInsert extends Migration
{public function up(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_ex_orders_branch');$this->db->query("CREATE TRIGGER trg_ex_orders_branch BEFORE INSERT ON ex_orders FOR EACH ROW SET NEW.branch_id=COALESCE(NEW.branch_id,(SELECT branch_id FROM ex_users WHERE id=NEW.created_by LIMIT 1),(SELECT id FROM ex_branches WHERE company_id=NEW.company_id AND deleted_at IS NULL ORDER BY id LIMIT 1))");}catch(\Throwable $e){}}public function down(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_ex_orders_branch');}catch(\Throwable $e){}}}
