<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddInvoiceUniqueCode extends Migration
{public function up(){foreach(["ALTER TABLE ex_invoices ADD base_amount DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER package_id","ALTER TABLE ex_invoices ADD unique_code SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER base_amount","ALTER TABLE ex_invoices ADD payment_account_id BIGINT UNSIGNED NULL AFTER payment_method"] as $sql){try{$this->db->query($sql);}catch(\Throwable $e){}}$this->db->query('UPDATE ex_invoices SET base_amount=amount WHERE base_amount=0');}public function down(){foreach(['payment_account_id','unique_code','base_amount'] as $column){try{$this->db->query("ALTER TABLE ex_invoices DROP COLUMN $column");}catch(\Throwable $e){}}}}
