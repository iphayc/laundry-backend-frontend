<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CancelRejectedInvoice extends Migration
{public function up(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_payment_reject_invoice');$this->db->query("CREATE TRIGGER trg_payment_reject_invoice AFTER UPDATE ON ex_payments FOR EACH ROW BEGIN IF NEW.status='REJECTED' AND OLD.status<>NEW.status THEN UPDATE ex_invoices SET status='CANCELLED',updated_at=NOW() WHERE id=NEW.invoice_id; END IF; END");}catch(\Throwable $e){}}public function down(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_payment_reject_invoice');}catch(\Throwable $e){}}}
