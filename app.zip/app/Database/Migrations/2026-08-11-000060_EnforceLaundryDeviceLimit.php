<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class EnforceLaundryDeviceLimit extends Migration
{public function up(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_ex_devices_limit');$this->db->query("CREATE TRIGGER trg_ex_devices_limit BEFORE INSERT ON ex_devices FOR EACH ROW BEGIN DECLARE allowed_devices INT DEFAULT 1; DECLARE active_devices INT DEFAULT 0; SELECT COALESCE(p.max_branches,1) INTO allowed_devices FROM ex_licenses l JOIN ex_packages p ON p.id=l.package_id WHERE l.company_id=NEW.company_id AND l.deleted_at IS NULL ORDER BY l.id DESC LIMIT 1; SELECT COUNT(*) INTO active_devices FROM ex_devices WHERE company_id=NEW.company_id AND status='ACTIVE' AND deleted_at IS NULL; IF active_devices >= allowed_devices THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Batas perangkat sesuai jumlah cabang telah tercapai. Nonaktifkan perangkat lama dari admin untuk berpindah perangkat.'; END IF; END");}catch(\Throwable $e){log_message('error','Device limit trigger: '.$e->getMessage());}}
 public function down(){try{$this->db->query('DROP TRIGGER IF EXISTS trg_ex_devices_limit');}catch(\Throwable $e){}}}
