<?php
namespace App\Database\Migrations;use CodeIgniter\Database\Migration;
class ExtendLicenseHistoryEvents extends Migration{public function up(){$this->db->query("ALTER TABLE ex_license_history MODIFY event ENUM('REGISTER','ACTIVATE','UPGRADE','RENEW','EXPIRE','BLOCK','DEVICE_BIND','DOWNGRADE_FREE') NOT NULL");}public function down(){$this->db->table('ex_license_history')->where('event','DOWNGRADE_FREE')->update(['event'=>'EXPIRE']);$this->db->query("ALTER TABLE ex_license_history MODIFY event ENUM('REGISTER','ACTIVATE','UPGRADE','RENEW','EXPIRE','BLOCK','DEVICE_BIND') NOT NULL");}}
