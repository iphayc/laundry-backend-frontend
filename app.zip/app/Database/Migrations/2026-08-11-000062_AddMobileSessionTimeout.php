<?php
namespace App\Database\Migrations;use CodeIgniter\Database\Migration;
class AddMobileSessionTimeout extends Migration{public function up(){$this->db->table('ex_app_settings')->ignore(true)->insert(['setting_key'=>'session_timeout_minutes','setting_value'=>'60','value_type'=>'INTEGER','is_public'=>1,'description'=>'Idle timeout sesi mobile dalam menit','updated_at'=>date('Y-m-d H:i:s')]);}public function down(){$this->db->table('ex_app_settings')->where('setting_key','session_timeout_minutes')->delete();}}
