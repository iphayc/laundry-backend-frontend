<?php
namespace App\Database\Migrations;use CodeIgniter\Database\Migration;
class AddOrderItemCount extends Migration{public function up(){try{$this->db->query('ALTER TABLE ex_orders ADD item_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER service_name');}catch(\Throwable $e){}}public function down(){try{$this->db->query('ALTER TABLE ex_orders DROP COLUMN item_count');}catch(\Throwable $e){}}}
