<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class EnsureRegisteredCompaniesHaveMainBranch extends Migration
{
    public function up()
    {
        $companies = $this->db->table('ex_companies')
            ->select('id,address,phone')
            ->where('deleted_at', null)
            ->get()->getResultArray();
        $now = date('Y-m-d H:i:s');
        foreach ($companies as $company) {
            $branchId = (int) ($this->db->table('ex_branches')->select('id')
                ->where('company_id', $company['id'])->where('deleted_at', null)
                ->orderBy('id')->get()->getRow('id') ?? 0);
            if ($branchId < 1) {
                $this->db->table('ex_branches')->insert([
                    'company_id' => $company['id'],
                    'name' => 'Cabang Utama',
                    'address' => $company['address'] ?: null,
                    'phone' => $company['phone'] ?: null,
                    'is_active' => 1,
                    'created_at' => $now,
                ]);
                $branchId = (int) $this->db->insertID();
            }
            $this->db->table('ex_users')->where('company_id', $company['id'])
                ->where('branch_id', null)->where('deleted_at', null)
                ->update(['branch_id' => $branchId, 'updated_at' => $now]);
        }
    }

    public function down()
    {
        // Data cabang operasional tidak dihapus saat rollback.
    }
}
