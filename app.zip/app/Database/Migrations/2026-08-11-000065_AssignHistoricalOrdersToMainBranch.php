<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AssignHistoricalOrdersToMainBranch extends Migration
{
    public function up()
    {
        $companies = $this->db->table('ex_companies c')
            ->select('c.id,b.id branch_id')
            ->join('ex_branches b', 'b.company_id=c.id AND b.deleted_at IS NULL', 'inner')
            ->where('c.deleted_at', null)
            ->orderBy('c.id')->orderBy('b.id')
            ->get()->getResultArray();

        $mainBranches = [];
        foreach ($companies as $company) {
            $companyId = (int) $company['id'];
            if (!isset($mainBranches[$companyId])) {
                $mainBranches[$companyId] = (int) $company['branch_id'];
            }
        }

        $now = date('Y-m-d H:i:s');
        foreach ($mainBranches as $companyId => $branchId) {
            $this->db->table('ex_orders')
                ->where('company_id', $companyId)
                ->where('branch_id', null)
                ->update(['branch_id' => $branchId, 'updated_at' => $now]);
        }
    }

    public function down()
    {
        // Relasi cabang transaksi historis dipertahankan agar data operasional aman.
    }
}
