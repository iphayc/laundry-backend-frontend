<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddLicenseDisableReason extends Migration
{
    public function up(){foreach(['ex_users','ex_branches'] as $table){try{$this->db->query("ALTER TABLE {$table} ADD disabled_reason VARCHAR(30) NULL AFTER is_active");}catch(\Throwable $e){}}}
    public function down(){foreach(['ex_users','ex_branches'] as $table){try{$this->db->query("ALTER TABLE {$table} DROP COLUMN disabled_reason");}catch(\Throwable $e){}}}
}
