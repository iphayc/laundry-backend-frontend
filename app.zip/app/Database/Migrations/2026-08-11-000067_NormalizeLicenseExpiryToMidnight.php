<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class NormalizeLicenseExpiryToMidnight extends Migration
{
    public function up(){$this->db->query("UPDATE ex_licenses SET expires_at=CONCAT(DATE(expires_at),' 00:00:00'),updated_at=NOW() WHERE expires_at IS NOT NULL AND TIME(expires_at)<>'00:00:00'");}
    public function down(){}
}
