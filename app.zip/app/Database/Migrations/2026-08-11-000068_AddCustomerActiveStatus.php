<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddCustomerActiveStatus extends Migration
{
    public function up(){try{$this->db->query("ALTER TABLE ex_customers ADD is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER notes");}catch(\Throwable $e){}}
    public function down(){try{$this->db->query("ALTER TABLE ex_customers DROP COLUMN is_active");}catch(\Throwable $e){}}
}
