<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreatePackageVouchers extends Migration
{
 public function up(){
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_vouchers (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,voucher_code VARCHAR(50) NOT NULL UNIQUE,valid_from DATE NOT NULL,expires_at DATE NOT NULL,discount_amount DECIMAL(15,2) NOT NULL DEFAULT 0,min_transaction DECIMAL(15,2) NOT NULL DEFAULT 0,qty INT UNSIGNED NOT NULL DEFAULT 1,qty_used INT UNSIGNED NOT NULL DEFAULT 0,status ENUM('AVAILABLE','USED','CANCEL') NOT NULL DEFAULT 'AVAILABLE',created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL) ENGINE=InnoDB");
  $this->db->query("CREATE TABLE IF NOT EXISTS ex_voucher_usages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,voucher_id INT UNSIGNED NOT NULL,company_id BIGINT UNSIGNED NOT NULL,invoice_id BIGINT UNSIGNED NULL,discount_amount DECIMAL(15,2) NOT NULL DEFAULT 0,status ENUM('RESERVED','USED','CANCEL') NOT NULL DEFAULT 'RESERVED',used_at DATETIME NULL,created_at DATETIME NULL,updated_at DATETIME NULL,UNIQUE KEY uq_voucher_company(voucher_id,company_id),INDEX idx_voucher_usage_invoice(invoice_id),CONSTRAINT fk_voucher_usage_voucher FOREIGN KEY(voucher_id) REFERENCES ex_vouchers(id)) ENGINE=InnoDB");
  foreach(["ALTER TABLE ex_invoices ADD voucher_id INT UNSIGNED NULL AFTER package_id","ALTER TABLE ex_invoices ADD voucher_code VARCHAR(50) NULL AFTER voucher_id","ALTER TABLE ex_invoices ADD discount_amount DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER base_amount"] as $sql)try{$this->db->query($sql);}catch(\Throwable $e){}
  $now=date('Y-m-d H:i:s');if(!$this->db->table('menus')->where('route','platform/vouchers')->countAllResults()){$this->db->table('menus')->insert(['name'=>'Voucher Discount','route'=>'platform/vouchers','icon'=>'fas fa-ticket-alt','sort_order'=>45,'active'=>1,'created_at'=>$now]);$id=(int)$this->db->insertID();$this->db->table('role_menus')->ignore(true)->insert(['role_id'=>1,'menu_id'=>$id,'can_create'=>1,'can_read'=>1,'can_update'=>1,'can_delete'=>1]);}
 }
 public function down(){$m=$this->db->table('menus')->where('route','platform/vouchers')->get()->getRowArray();if($m){$this->db->table('role_menus')->where('menu_id',$m['id'])->delete();$this->db->table('menus')->where('id',$m['id'])->delete();}$this->db->query('DROP TABLE IF EXISTS ex_voucher_usages');$this->db->query('DROP TABLE IF EXISTS ex_vouchers');}
}
