<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class NormalizeMobileGuideLineBreaks extends Migration
{public function up(){$this->db->query("UPDATE ex_mobile_guides SET content=REPLACE(content, '\\\\n', CHAR(10)) WHERE content LIKE '%\\\\n%'");}public function down(){}}
