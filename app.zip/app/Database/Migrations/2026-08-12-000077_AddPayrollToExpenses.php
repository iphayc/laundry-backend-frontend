<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddPayrollToExpenses extends Migration
{
 public function up(){
  $fields=[
   'employee_id'=>['type'=>'BIGINT','unsigned'=>true,'null'=>true,'after'=>'branch_id'],
   'payroll_period'=>['type'=>'CHAR','constraint'=>7,'null'=>true,'after'=>'employee_id'],
   'base_salary'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'payroll_period'],
   'allowance'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'base_salary'],
   'meal_allowance'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'allowance'],
   'transport_allowance'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'meal_allowance'],
   'attendance_days'=>['type'=>'DECIMAL','constraint'=>'8,2','default'=>0,'after'=>'transport_allowance'],
   'attendance_rate'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'attendance_days'],
   'attendance_allowance'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'attendance_rate'],
   'deduction'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'attendance_allowance'],
   'bonus'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'deduction'],
   'thr'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'bonus'],
  ];
  foreach($fields as $name=>$definition)if(!$this->db->fieldExists($name,'ex_expenses'))$this->forge->addColumn('ex_expenses',[$name=>$definition]);
  $this->db->query('CREATE INDEX idx_expense_employee_period ON ex_expenses (company_id,employee_id,payroll_period)');
 }
 public function down(){
  try{$this->db->query('DROP INDEX idx_expense_employee_period ON ex_expenses');}catch(\Throwable $e){}
  foreach(['employee_id','payroll_period','base_salary','allowance','meal_allowance','transport_allowance','attendance_days','attendance_rate','attendance_allowance','deduction','bonus','thr'] as $field)if($this->db->fieldExists($field,'ex_expenses'))$this->forge->dropColumn('ex_expenses',$field);
 }
}
