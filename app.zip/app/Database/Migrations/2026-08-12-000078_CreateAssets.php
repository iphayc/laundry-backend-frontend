<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreateAssets extends Migration
{
 public function up(){$this->db->query("CREATE TABLE IF NOT EXISTS ex_assets (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id BIGINT UNSIGNED NOT NULL,asset_number VARCHAR(30) NOT NULL,input_date DATE NOT NULL,acquisition_date DATE NOT NULL,asset_name VARCHAR(150) NOT NULL,description TEXT NULL,qty DECIMAL(15,3) NOT NULL DEFAULT 1,unit_value DECIMAL(15,2) NOT NULL DEFAULT 0,total_value DECIMAL(15,2) NOT NULL DEFAULT 0,depreciation_years INT UNSIGNED NOT NULL DEFAULT 1,annual_depreciation DECIMAL(15,2) NOT NULL DEFAULT 0,created_by BIGINT UNSIGNED NULL,created_at DATETIME NULL,updated_at DATETIME NULL,deleted_at DATETIME NULL,UNIQUE KEY uq_asset_number(company_id,asset_number),INDEX idx_assets_company(company_id,deleted_at)) ENGINE=InnoDB");}
 public function down(){$this->forge->dropTable('ex_assets',true);}
}
