<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddMealRateToPayroll extends Migration
{
 public function up(){if(!$this->db->fieldExists('meal_allowance_rate','ex_expenses'))$this->forge->addColumn('ex_expenses',['meal_allowance_rate'=>['type'=>'DECIMAL','constraint'=>'15,2','default'=>0,'after'=>'allowance']]);}
 public function down(){if($this->db->fieldExists('meal_allowance_rate','ex_expenses'))$this->forge->dropColumn('ex_expenses','meal_allowance_rate');}
}
