<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class RoundAssetQuantity extends Migration
{
 public function up(){$this->db->query('UPDATE ex_assets SET qty=ROUND(qty)');$this->db->query('ALTER TABLE ex_assets MODIFY qty BIGINT UNSIGNED NOT NULL DEFAULT 1');}
 public function down(){$this->db->query('ALTER TABLE ex_assets MODIFY qty DECIMAL(15,3) NOT NULL DEFAULT 1');}
}
