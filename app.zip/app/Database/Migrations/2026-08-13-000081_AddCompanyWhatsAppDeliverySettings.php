<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddCompanyWhatsAppDeliverySettings extends Migration
{
 public function up(){
  if(!$this->db->fieldExists('whatsapp_delivery_method','ex_companies'))$this->forge->addColumn('ex_companies',['whatsapp_delivery_method'=>['type'=>'VARCHAR','constraint'=>20,'default'=>'APP','after'=>'receipt_footer']]);
  if(!$this->db->fieldExists('whatsapp_linked_terms_at','ex_companies'))$this->forge->addColumn('ex_companies',['whatsapp_linked_terms_at'=>['type'=>'DATETIME','null'=>true,'after'=>'whatsapp_delivery_method']]);
 }
 public function down(){foreach(['whatsapp_linked_terms_at','whatsapp_delivery_method'] as $field)if($this->db->fieldExists($field,'ex_companies'))$this->forge->dropColumn('ex_companies',$field);}
}
