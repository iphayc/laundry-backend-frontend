<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddBranchToMobileDevices extends Migration
{
    public function up()
    {
        $db = $this->db;

        if (!$db->fieldExists('branch_id', 'ex_devices')) {
            $this->forge->addColumn('ex_devices', [
                'branch_id' => [
                    'type' => 'BIGINT',
                    'unsigned' => true,
                    'null' => true,
                    'after' => 'company_id',
                ],
            ]);
        }

        // One device per branch is enforced for FREE accounts.
        // Keep it nullable for legacy device rows created before branch binding.
        try {
            $db->query(
                "ALTER TABLE ex_devices
                 ADD INDEX idx_ex_devices_branch (company_id, branch_id)"
            );
        } catch (\Throwable $e) {
            // Index may already exist; continue safely.
        }
    }

    public function down()
    {
        if ($this->db->fieldExists('branch_id', 'ex_devices')) {
            $this->forge->dropColumn('ex_devices', 'branch_id');
        }
    }
}
