<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class GenericDeviceTransfer extends Migration
{
    public function up()
    {
        $db = $this->db;

        // Device history needs a REPLACED state.
        try {
            $db->query("ALTER TABLE ex_devices MODIFY status ENUM('ACTIVE','DISABLED','LOGGED_OUT','REPLACED') DEFAULT 'ACTIVE'");
        } catch (\Throwable $e) {
            log_message('error', 'Unable to extend ex_devices.status: '.$e->getMessage());
        }

        // The old trigger counted devices company-wide and used max_branches as
        // a device limit. Device quota is now enforced by MobileLoginService,
        // with one active mobile device per licensed branch.
        try {
            $db->query('DROP TRIGGER IF EXISTS trg_ex_devices_limit');
        } catch (\Throwable $e) {
            log_message('error', 'Unable to drop old device trigger: '.$e->getMessage());
        }

        // Existing licenses should follow the current package branch quota.
        try {
            $db->query(
                "UPDATE ex_licenses l
                 INNER JOIN ex_packages p ON p.id=l.package_id
                 SET l.device_limit=GREATEST(1,COALESCE(p.max_devices,p.max_branches*2,1))
                 WHERE l.deleted_at IS NULL"
            );
        } catch (\Throwable $e) {
            log_message('error', 'Unable to synchronize license device_limit: '.$e->getMessage());
        }
    }

    public function down()
    {
        // Keep REPLACED rows as history. Do not destroy device history on rollback.
        try {
            $this->db->query('DROP TRIGGER IF EXISTS trg_ex_devices_limit');
        } catch (\Throwable $e) {}
    }
}
