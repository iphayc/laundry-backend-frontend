<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class AddPackageMaxDevices extends Migration
{
 public function up(){
  try{$this->db->query("ALTER TABLE ex_packages ADD max_devices INT UNSIGNED NOT NULL DEFAULT 1 AFTER users_per_branch");}catch(\Throwable $e){}
  $this->db->query("UPDATE ex_packages SET max_devices=CASE WHEN code='FREE' THEN 1 ELSE GREATEST(1,max_branches*2) END");
  $this->db->query("UPDATE ex_licenses l INNER JOIN ex_packages p ON p.id=l.package_id SET l.device_limit=GREATEST(1,COALESCE(p.max_devices,p.max_branches*2,1)) WHERE l.deleted_at IS NULL");
 }
 public function down(){try{$this->db->query("ALTER TABLE ex_packages DROP COLUMN max_devices");}catch(\Throwable $e){}}
}
