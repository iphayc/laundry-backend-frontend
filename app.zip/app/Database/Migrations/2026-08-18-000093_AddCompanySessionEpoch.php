<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class AddCompanySessionEpoch extends Migration
{
 public function up()
 {
  if(!$this->db->fieldExists('session_epoch','ex_companies'))$this->forge->addColumn('ex_companies',['session_epoch'=>['type'=>'INT','constraint'=>10,'unsigned'=>true,'default'=>1,'null'=>false,'after'=>'status']]);
  $this->db->table('ex_user_tokens')->where('revoked_at',null)->update(['expires_at'=>'9999-12-31 23:59:59']);
  $this->db->query('DROP TRIGGER IF EXISTS trg_ex_license_session_insert');
  $this->db->query('DROP TRIGGER IF EXISTS trg_ex_license_session_update');
  $this->db->query("CREATE TRIGGER trg_ex_license_session_insert AFTER INSERT ON ex_licenses FOR EACH ROW BEGIN UPDATE ex_companies SET session_epoch=session_epoch+1 WHERE id=NEW.company_id; UPDATE ex_user_tokens SET revoked_at=NOW() WHERE revoked_at IS NULL AND user_id IN (SELECT id FROM ex_users WHERE company_id=NEW.company_id); END");
  $this->db->query("CREATE TRIGGER trg_ex_license_session_update AFTER UPDATE ON ex_licenses FOR EACH ROW BEGIN IF NOT (OLD.package_id <=> NEW.package_id) THEN UPDATE ex_companies SET session_epoch=session_epoch+1 WHERE id=NEW.company_id; UPDATE ex_user_tokens SET revoked_at=NOW() WHERE revoked_at IS NULL AND user_id IN (SELECT id FROM ex_users WHERE company_id=NEW.company_id); END IF; END");
 }
 public function down()
 {
  $this->db->query('DROP TRIGGER IF EXISTS trg_ex_license_session_insert');
  $this->db->query('DROP TRIGGER IF EXISTS trg_ex_license_session_update');
  if($this->db->fieldExists('session_epoch','ex_companies'))$this->forge->dropColumn('ex_companies','session_epoch');
 }
}
