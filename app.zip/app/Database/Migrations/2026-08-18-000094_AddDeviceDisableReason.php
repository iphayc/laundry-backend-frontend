<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddDeviceDisableReason extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('disabled_reason','ex_devices')){
            $this->forge->addColumn('ex_devices',[
                'disabled_reason'=>[
                    'type'=>'VARCHAR','constraint'=>30,'null'=>true,'after'=>'status'
                ]
            ]);
        }
    }

    public function down()
    {
        if($this->db->fieldExists('disabled_reason','ex_devices'))
            $this->forge->dropColumn('ex_devices','disabled_reason');
    }
}
