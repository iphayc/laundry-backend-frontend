<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddBranchToCustomers extends Migration
{
    public function up()
    {
        if(!$this->db->fieldExists('branch_id','ex_customers')){
            $this->forge->addColumn('ex_customers',[
                'branch_id'=>['type'=>'BIGINT','constraint'=>20,'unsigned'=>true,'null'=>true,'after'=>'company_id']
            ]);
            $this->db->query('CREATE INDEX idx_ex_customers_branch ON ex_customers (company_id, branch_id)');
        }
        $this->db->query("UPDATE ex_customers c SET c.branch_id=COALESCE(
            (SELECT o.branch_id FROM ex_orders o WHERE o.customer_id=c.id AND o.deleted_at IS NULL ORDER BY o.id DESC LIMIT 1),
            (SELECT b.id FROM ex_branches b WHERE b.company_id=c.company_id AND b.deleted_at IS NULL ORDER BY b.id LIMIT 1)
        ) WHERE c.branch_id IS NULL");
    }

    public function down()
    {
        if($this->db->fieldExists('branch_id','ex_customers'))
            $this->forge->dropColumn('ex_customers','branch_id');
    }
}
