<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateBranchProductDiscountSettings extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE IF NOT EXISTS ex_product_branches (
            product_id BIGINT UNSIGNED NOT NULL, branch_id BIGINT UNSIGNED NOT NULL,
            price DECIMAL(15,2) NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NULL, updated_at DATETIME NULL,
            PRIMARY KEY(product_id,branch_id), INDEX(branch_id),
            FOREIGN KEY(product_id) REFERENCES ex_products(id), FOREIGN KEY(branch_id) REFERENCES ex_branches(id)
        ) ENGINE=InnoDB");
        $this->db->query("CREATE TABLE IF NOT EXISTS ex_discount_branches (
            discount_id BIGINT UNSIGNED NOT NULL, branch_id BIGINT UNSIGNED NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NULL, updated_at DATETIME NULL,
            PRIMARY KEY(discount_id,branch_id), INDEX(branch_id),
            FOREIGN KEY(discount_id) REFERENCES ex_discounts(id), FOREIGN KEY(branch_id) REFERENCES ex_branches(id)
        ) ENGINE=InnoDB");
        $now=date('Y-m-d H:i:s');
        $this->db->query("INSERT IGNORE INTO ex_product_branches(product_id,branch_id,price,is_active,created_at)
            SELECT p.id,b.id,p.price,p.is_active,? FROM ex_products p JOIN ex_branches b ON b.company_id=p.company_id AND b.deleted_at IS NULL WHERE p.deleted_at IS NULL",[$now]);
        $this->db->query("INSERT IGNORE INTO ex_discount_branches(discount_id,branch_id,is_active,created_at)
            SELECT d.id,b.id,d.is_active,? FROM ex_discounts d JOIN ex_branches b ON b.company_id=d.company_id AND b.deleted_at IS NULL WHERE d.deleted_at IS NULL",[$now]);
    }

    public function down()
    {
        $this->forge->dropTable('ex_discount_branches',true);
        $this->forge->dropTable('ex_product_branches',true);
    }
}
