<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ScopeInventoryAndAssetsByBranch extends Migration
{
    public function up()
    {
        if (!$this->db->fieldExists('branch_id', 'ex_inventory_items')) {
            $this->forge->addColumn('ex_inventory_items', ['branch_id' => ['type' => 'BIGINT', 'constraint' => 20, 'unsigned' => true, 'null' => true, 'after' => 'company_id']]);
            $this->db->query('CREATE INDEX idx_inventory_items_branch ON ex_inventory_items (company_id, branch_id)');
        }
        if (!$this->db->fieldExists('branch_id', 'ex_assets')) {
            $this->forge->addColumn('ex_assets', ['branch_id' => ['type' => 'BIGINT', 'constraint' => 20, 'unsigned' => true, 'null' => true, 'after' => 'company_id']]);
            $this->db->query('CREATE INDEX idx_assets_branch ON ex_assets (company_id, branch_id)');
        }
        // Data lama sebelumnya bersifat global: tempatkan pada cabang utama.
        $this->db->query("UPDATE ex_inventory_items i SET i.branch_id=(SELECT b.id FROM ex_branches b WHERE b.company_id=i.company_id AND b.is_active=1 AND b.deleted_at IS NULL ORDER BY b.id LIMIT 1) WHERE i.branch_id IS NULL");
        $this->db->query("UPDATE ex_assets a SET a.branch_id=(SELECT b.id FROM ex_branches b WHERE b.company_id=a.company_id AND b.is_active=1 AND b.deleted_at IS NULL ORDER BY b.id LIMIT 1) WHERE a.branch_id IS NULL");
    }

    public function down()
    {
        if ($this->db->fieldExists('branch_id', 'ex_inventory_items')) $this->forge->dropColumn('ex_inventory_items', 'branch_id');
        if ($this->db->fieldExists('branch_id', 'ex_assets')) $this->forge->dropColumn('ex_assets', 'branch_id');
    }
}
