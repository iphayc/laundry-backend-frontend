<?php
namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ParkingSeeder extends Seeder
{
    public function run()
    {
        $initialAdminPassword = (string) env('security.initialAdminPassword', '');
        if (strlen($initialAdminPassword) < 16) {
            throw new \RuntimeException('security.initialAdminPassword wajib diisi minimal 16 karakter sebelum menjalankan seeder.');
        }

        $now = date('Y-m-d H:i:s');
        $this->db->table('roles')->insertBatch([
            ['id'=>1,'name'=>'Administrator','description'=>'Akses penuh','created_at'=>$now],
            ['id'=>2,'name'=>'Creator','description'=>'Tambah dan kelola data operasional','created_at'=>$now],
            ['id'=>3,'name'=>'Editor','description'=>'Edit data tamu tertentu','created_at'=>$now],
            ['id'=>4,'name'=>'Viewer','description'=>'Lihat dan cetak laporan','created_at'=>$now],
        ]);
        $this->db->table('groups')->insertBatch([
            ['id'=>1,'parent_id'=>null,'name'=>'Residence One','description'=>'Root organisasi','created_at'=>$now],
            ['id'=>2,'parent_id'=>1,'name'=>'Security','description'=>'Petugas keamanan','created_at'=>$now],
            ['id'=>3,'parent_id'=>1,'name'=>'Management','description'=>'Pengelola kawasan','created_at'=>$now],
        ]);
        $permissions = [];
        foreach (['dashboard.view','users.manage','masters.manage','residents.manage','visitors.manage','blacklist.manage','gate.operate','reports.view','reports.export','settings.manage'] as $i=>$code) {
            $permissions[]=['id'=>$i+1,'code'=>$code,'name'=>ucwords(str_replace(['.','_'],' ',$code)),'module'=>explode('.',$code)[0]];
        }
        $this->db->table('permissions')->insertBatch($permissions);
        foreach ($permissions as $p) $this->db->table('role_permissions')->insert(['role_id'=>1,'permission_id'=>$p['id']]);
        $this->db->table('users')->insert(['role_id'=>1,'group_id'=>3,'username'=>'admin','name'=>'Administrator','email'=>'admin@residenceone.local','password_hash'=>password_hash($initialAdminPassword, PASSWORD_DEFAULT),'active'=>1,'created_at'=>$now]);
        $this->db->table('clusters')->insertBatch([
            ['id'=>1,'code'=>'R1-A','name'=>'Cluster Anggrek','address'=>'Residence One','active'=>1,'created_at'=>$now],
            ['id'=>2,'code'=>'R1-B','name'=>'Cluster Bougenville','address'=>'Residence One','active'=>1,'created_at'=>$now],
        ]);
        $this->db->table('units')->insertBatch([
            ['id'=>1,'cluster_id'=>1,'unit_no'=>'A-01','owner_name'=>'Budi Santoso','phone'=>'081234567890','active'=>1,'created_at'=>$now],
            ['id'=>2,'cluster_id'=>2,'unit_no'=>'B-12','owner_name'=>'Sari Dewi','phone'=>'081298765432','active'=>1,'created_at'=>$now],
        ]);
        $this->db->table('vehicle_types')->insertBatch([
            ['id'=>1,'code'=>'CAR','name'=>'Mobil','active'=>1,'created_at'=>$now],
            ['id'=>2,'code'=>'MOTOR','name'=>'Motor','active'=>1,'created_at'=>$now],
            ['id'=>3,'code'=>'WALK','name'=>'Pejalan Kaki','active'=>1,'created_at'=>$now],
        ]);
        $this->db->table('gates')->insertBatch([
            ['id'=>1,'cluster_id'=>null,'code'=>'MAIN-IN','name'=>'Gerbang Utama Masuk','gate_type'=>'main','direction'=>'in','device_code'=>'RFID-MAIN-IN','active'=>1,'created_at'=>$now],
            ['id'=>2,'cluster_id'=>null,'code'=>'MAIN-OUT','name'=>'Gerbang Utama Keluar','gate_type'=>'main','direction'=>'out','device_code'=>'RFID-MAIN-OUT','active'=>1,'created_at'=>$now],
            ['id'=>3,'cluster_id'=>1,'code'=>'A-INOUT','name'=>'Gate Cluster Anggrek','gate_type'=>'cluster','direction'=>'both','device_code'=>'RFID-A','active'=>1,'created_at'=>$now],
        ]);
        $this->db->table('residents')->insert(['id'=>1,'unit_id'=>1,'identity_no'=>'3174000000000001','name'=>'Budi Santoso','phone'=>'081234567890','email'=>'budi@example.test','suspended'=>0,'created_at'=>$now]);
        $this->db->table('vehicles')->insert(['resident_id'=>1,'vehicle_type_id'=>1,'plate_no'=>'B 1234 R1','brand'=>'Toyota','color'=>'Hitam','active'=>1,'created_at'=>$now]);
        $this->db->table('access_cards')->insert(['resident_id'=>1,'card_no'=>'R1-000001','card_type'=>'resident','status'=>'active','created_at'=>$now]);
        foreach (['day_start'=>'05:00','night_start'=>'18:00','day_limit_hours'=>'3','night_limit_hours'=>'6'] as $key=>$value) {
            $this->db->table('settings')->insert(['setting_key'=>$key,'setting_value'=>$value,'updated_at'=>$now]);
        }
    }
}
