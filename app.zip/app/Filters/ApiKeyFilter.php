<?php
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class ApiKeyFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $expected=(string) config('Parking')->gateApiKey;
        if ($expected === '') {
            log_message('critical', 'Gate API key is not configured.');
            return service('response')->setStatusCode(503)->setJSON(['status'=>503,'error'=>'API gate belum dikonfigurasi']);
        }
        if(!hash_equals($expected,(string)$request->getHeaderLine('X-Gate-Key'))){
            return service('response')->setStatusCode(401)->setJSON(['status'=>401,'error'=>'API key tidak valid']);
        }
    }
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null){}
}
