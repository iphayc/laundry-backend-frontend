<?php
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session('user_id')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }
        if ((int)session('role_id') !== 1) {
            $path=trim($request->getUri()->getPath(),'/');
            $basePath=trim((string)parse_url(config('App')->baseURL,PHP_URL_PATH),'/');
            if($basePath && str_starts_with($path,$basePath))$path=trim(substr($path,strlen($basePath)),'/');
            $alwaysAllowed=['logout','change-password','account/profile','account/change-password'];
            if(!in_array($path,$alwaysAllowed,true)){
                $accessRows=db_connect()->table('menus m')->select('m.route,rm.can_create,rm.can_read,rm.can_update,rm.can_delete')->join('role_menus rm','rm.menu_id=m.id')->where('rm.role_id',(int)session('role_id'))->where('m.active',1)->where('m.deleted_at',null)->where('m.route IS NOT NULL',null,false)->get()->getResultArray();
                $matched=null;$matchedLength=-1;
                foreach($accessRows as $access){$route=trim((string)$access['route'],'/');if(($path===$route||str_starts_with($path,$route.'/'))&&strlen($route)>$matchedLength){$matched=$access;$matchedLength=strlen($route);}}
                if(!$matched)return $this->accessDenied('Role Anda tidak memiliki akses ke menu ini.');
                $operation='read';$method=strtoupper($request->getMethod());
                if($method!=='GET'){
                    if(str_contains($path,'/delete/'))$operation='delete';
                    elseif(str_contains($path,'reset-password'))$operation='update';
                    elseif(str_ends_with($path,'/save'))$operation=$request->getPost('id')?'update':'create';
                    elseif(str_ends_with($path,'/send'))$operation='create';
                    elseif($path==='reports/email')$operation='create';
                    else$operation='update';
                }elseif(preg_match('#/form/\d+$#',$path))$operation='update';
                elseif(str_ends_with($path,'/form'))$operation='create';
                if(empty($matched['can_'.$operation]))return $this->accessDenied('Role Anda tidak memiliki izin '.strtoupper($operation).' pada menu ini.');
            }
        }
    }
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}

    private function accessDenied(string $message): ResponseInterface
    {
        $company=[];$roleName='User';
        try{
            $db=db_connect();$company=$db->table('companies')->where('active',1)->where('deleted_at',null)->orderBy('id','DESC')->get()->getRowArray()??[];
            $roleName=$db->table('roles')->select('name')->where('id',(int)session('role_id'))->where('deleted_at',null)->get()->getRow('name')??'User';
        }catch(\Throwable $e){log_message('error','Access denied company profile: '.$e->getMessage());}
        return service('response')->setStatusCode(403)->setBody(view('errors/access_denied',['message'=>$message,'company'=>$company,'roleName'=>$roleName]));
    }
}
