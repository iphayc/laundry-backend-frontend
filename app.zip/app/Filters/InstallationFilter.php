<?php

namespace App\Filters;

use App\Services\InstallationService;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class InstallationFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! (new InstallationService())->isInstalled()) {
            return redirect()->to('/install');
        }

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
