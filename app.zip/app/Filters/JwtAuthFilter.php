<?php
namespace App\Filters;
use App\Libraries\JwtService;
use App\Services\EntitlementService;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
class JwtAuthFilter implements FilterInterface
{
 public function before(RequestInterface $request,$arguments=null)
 {
  $header=$request->getHeaderLine('Authorization');
  if(!preg_match('/^Bearer\s+(\S+)$/i',$header,$m))return service('response')->setStatusCode(401)->setJSON(['success'=>false,'message'=>'Access token tidak tersedia.','errors'=>['reason'=>'ACCESS_TOKEN_EXPIRED']]);
  try{$claims=(new JwtService())->decode($m[1]);}
  catch(\Throwable $e){return service('response')->setStatusCode(401)->setJSON(['success'=>false,'message'=>'Access token kedaluwarsa.','errors'=>['reason'=>'ACCESS_TOKEN_EXPIRED']]);}
  try{
   $license=(new EntitlementService())->current((int)$claims['company_id']);
   $db=db_connect();$epoch=(int)($db->table('ex_companies')->select('session_epoch')->where('id',(int)$claims['company_id'])->get()->getRow('session_epoch')??1);
   if((int)($claims['session_epoch']??0)!==max(1,$epoch))return service('response')->setStatusCode(401)->setJSON(['success'=>false,'message'=>'Paket atau sesi perusahaan telah berubah. Silakan login kembali.','errors'=>['reason'=>'SESSION_REVOKED']]);
   $user=$db->table('ex_users')->where('id',(int)$claims['sub'])->where('company_id',(int)$claims['company_id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
   if(!$user)return service('response')->setStatusCode(401)->setJSON(['success'=>false,'message'=>'Akun sudah tidak aktif. Silakan login kembali.','errors'=>['reason'=>'SESSION_REVOKED']]);
   if(!empty($license['branch_selection_required'])&&($user['role']??'')!=='OWNER')return service('response')->setStatusCode(403)->setJSON(['success'=>false,'message'=>'Owner harus memilih cabang yang dinonaktifkan setelah downgrade paket.','errors'=>['reason'=>'BRANCH_SELECTION_REQUIRED']]);
   if(($user['role']??'')!=='OWNER'&&!$db->table('ex_branches')->where('id',(int)($user['branch_id']??0))->where('company_id',(int)$claims['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults())return service('response')->setStatusCode(401)->setJSON(['success'=>false,'message'=>'Cabang user sudah tidak aktif.','errors'=>['reason'=>'SESSION_REVOKED']]);
   $request->user=$user;
  }catch(\Throwable $e){log_message('error','Validasi sesi JWT sementara gagal: '.$e->getMessage());return service('response')->setStatusCode(503)->setJSON(['success'=>false,'message'=>'Validasi sesi sementara tidak tersedia. Session tetap dipertahankan.','errors'=>['reason'=>'TEMPORARY_ERROR']]);}
 }
 public function after(RequestInterface $request,ResponseInterface $response,$arguments=null){}
}
