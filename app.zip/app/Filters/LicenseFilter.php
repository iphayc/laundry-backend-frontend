<?php
namespace App\Filters;

use App\Services\LicenseService;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class LicenseFilter implements FilterInterface
{
    public function before(RequestInterface $request,$arguments=null)
    {
        // $path = trim($request->getUri()->getPath(), '/');

        // $publicRoutes = [
        //     '',
        //     'profil',
        //     'paket',
        //     'panduan',
        //     'kontak',
        //     'pendaftaran',
        //     'register',
        //     'aEZGxhfPkA'
        // ];

        // if (in_array($path, $publicRoutes, true)) {
        //     return;
        // }
       
        // try {
        //     $db = db_connect();
        //     if (! $db->tableExists('application_registration')) {
        //         log_message('critical', 'License filter: application_registration table is missing.');
        //         return redirect()->to('/register')
        //             ->with('error', 'Penyimpanan lisensi belum tersedia. Hubungi administrator aplikasi.');
        //     }

        //     $registration = $db->table('application_registration')
        //         ->orderBy('id', 'DESC')
        //         ->get()
        //         ->getRowArray() ?? [];

        //     if (! (new LicenseService())->registrationIsValid($registration)) {
        //         if ($registration && ! empty($registration['active'])) {
        //             $db->table('application_registration')
        //                 ->where('id', $registration['id'])
        //                 ->update(['active' => 0, 'updated_at' => date('Y-m-d H:i:s')]);
        //         }

        //         return redirect()->to('/register')
        //             ->with('warning', 'Lisensi tidak cocok dengan komputer ini. Silakan aktivasi ulang.');
        //     }
        // }
        // catch(\Throwable $e){
        //     log_message('critical','License filter failed closed: '.$e->getMessage());
        //     return redirect()->to('/register')
        //         ->with('error', 'Lisensi tidak dapat diverifikasi. Akses aplikasi dikunci sementara.');
        // }
        // return null;
    }
    public function after(RequestInterface $request,ResponseInterface $response,$arguments=null){}
}
