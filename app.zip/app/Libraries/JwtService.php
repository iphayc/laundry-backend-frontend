<?php
namespace App\Libraries;
class JwtService
{
 private string $secret;public function __construct(){$this->secret=(string)env('jwt.secret',env('encryption.key'));if(strlen($this->secret)<32)throw new \RuntimeException('JWT secret belum dikonfigurasi.');}
 public function accessToken(array $user,int $ttl=900):string{$now=time();$epoch=(int)(db_connect()->table('ex_companies')->select('session_epoch')->where('id',(int)$user['company_id'])->get()->getRow('session_epoch')??1);return $this->encode(['iss'=>base_url(),'sub'=>(string)$user['id'],'company_id'=>(int)$user['company_id'],'role'=>$user['role'],'session_epoch'=>max(1,$epoch),'iat'=>$now,'exp'=>$now+$ttl,'type'=>'access']);}
 public function refreshToken():string{return rtrim(strtr(base64_encode(random_bytes(48)),'+/','-_'),'=');}
 public function decode(string $jwt):array{$parts=explode('.',$jwt);if(count($parts)!==3)throw new \RuntimeException('Token tidak valid.');[$h,$p,$s]=$parts;$expected=$this->sign($h.'.'.$p);if(!hash_equals($expected,$s))throw new \RuntimeException('Tanda tangan token tidak valid.');$data=json_decode($this->b64decode($p),true);if(!is_array($data)||($data['type']??'')!=='access'||($data['exp']??0)<time())throw new \RuntimeException('Token kedaluwarsa atau tidak valid.');return $data;}
 private function encode(array $payload):string{$h=$this->b64(json_encode(['alg'=>'HS256','typ'=>'JWT']));$p=$this->b64(json_encode($payload));return $h.'.'.$p.'.'.$this->sign($h.'.'.$p);}
 private function sign(string $value):string{return $this->b64(hash_hmac('sha256',$value,$this->secret,true));}
 private function b64(string $v):string{return rtrim(strtr(base64_encode($v),'+/','-_'),'=');}
 private function b64decode(string $v):string{$v=strtr($v,'-_','+/');return base64_decode(str_pad($v,(int)ceil(strlen($v)/4)*4,'=',STR_PAD_RIGHT))?:'';}
}
