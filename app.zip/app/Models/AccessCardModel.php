<?php
namespace App\Models;
class AccessCardModel extends BaseAppModel {protected $table='access_cards';protected $allowedFields=['resident_id','card_no','card_type','status','expires_at'];}
