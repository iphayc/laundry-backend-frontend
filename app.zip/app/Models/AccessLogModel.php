<?php
namespace App\Models;
class AccessLogModel extends BaseAppModel {
    protected $table='access_logs'; protected $useTimestamps=false; protected $allowedFields=['card_no','subject_type','subject_id','visit_id','gate_id','direction','vehicle_type_id','plate_no','event_time','result','reason','forced_suspended_trial','raw_payload','capture_image','entry_access_log_id','created_at'];
}
