<?php
namespace App\Models;

use CodeIgniter\Model;

abstract class BaseAppModel extends Model
{
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;
    protected $protectFields = true;
}
