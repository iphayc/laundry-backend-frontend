<?php
namespace App\Models;
class ClusterModel extends BaseAppModel {protected $table='clusters';protected $allowedFields=['code','name','address','active'];}
