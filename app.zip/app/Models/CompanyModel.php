<?php
namespace App\Models;
class CompanyModel extends BaseAppModel {protected $table='companies';protected $allowedFields=['residence_name','address','phone','developer','email','maps_location','photo','logo','active'];}
