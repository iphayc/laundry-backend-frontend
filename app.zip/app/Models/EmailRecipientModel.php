<?php
namespace App\Models;
class EmailRecipientModel extends BaseAppModel {protected $table='email_recipients';protected $allowedFields=['name','email','cc','description','active'];}
