<?php
namespace App\Models;
class EmailSmtpSettingModel extends BaseAppModel {protected $table='email_smtp_settings';protected $allowedFields=['account_name','smtp_host','smtp_port','smtp_user','smtp_password_encrypted','smtp_crypto','from_email','from_name','active'];}
