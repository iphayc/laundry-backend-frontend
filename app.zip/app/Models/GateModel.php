<?php
namespace App\Models;
class GateModel extends BaseAppModel {protected $table='gates';protected $allowedFields=['cluster_id','code','name','gate_type','direction','device_code','console_slug','active'];}
