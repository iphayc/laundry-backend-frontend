<?php
namespace App\Models;
class GroupModel extends BaseAppModel {protected $table='groups';protected $allowedFields=['parent_id','name','description'];}
