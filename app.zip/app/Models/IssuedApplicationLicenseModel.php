<?php

namespace App\Models;

class IssuedApplicationLicenseModel extends BaseAppModel
{
    protected $table = 'issued_application_licenses';
    protected $allowedFields = [
        'registered_email',
        'machine_id',
        'machine_id_hash',
        'license_code_hash',
        'active',
        'registered_at',
        'last_generated_at',
        'created_by',
    ];
}
