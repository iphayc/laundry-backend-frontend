<?php
namespace App\Models;
class MasterModel extends BaseAppModel
{
    public function for(string $table, array $fields, bool $softDelete=true): self
    {
        $clone=clone $this; $clone->table=$table; $clone->allowedFields=$fields; $clone->useSoftDeletes=$softDelete; return $clone;
    }
}
