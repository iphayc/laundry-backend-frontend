<?php
namespace App\Models;

use CodeIgniter\Model;

class MenuModel extends Model
{
    protected $table='menus';
    protected $returnType='array';
    protected $useTimestamps=true;
    protected $useSoftDeletes=true;
    protected $allowedFields=['parent_id','name','route','icon','sort_order','active'];

    public function forRole(int $roleId): array
    {
        $rows=$this->select('menus.*')
            ->join('role_menus rm','rm.menu_id=menus.id')
            ->where('rm.role_id',$roleId)->where('menus.active',1)
            ->where('menus.deleted_at',null)
            ->orderBy('menus.sort_order','ASC')->findAll();
        return $this->buildTree($rows);
    }

    private function buildTree(array $rows,?int $parentId=null): array
    {
        $branch=[];
        foreach($rows as $row){
            $rowParent=$row['parent_id']===null?null:(int)$row['parent_id'];
            if($rowParent===$parentId){
                $row['children']=$this->buildTree($rows,(int)$row['id']);
                $branch[]=$row;
            }
        }
        return $branch;
    }
}
