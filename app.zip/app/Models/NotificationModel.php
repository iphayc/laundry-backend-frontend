<?php
namespace App\Models;
class NotificationModel extends BaseAppModel {
    protected $table='notifications'; protected $allowedFields=['visit_id','type','title','message','channel','status','sent_at','read_at'];
}
