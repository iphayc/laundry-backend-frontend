<?php
namespace App\Models;
class NotificationTemplateModel extends BaseAppModel {protected $table='notification_templates';protected $allowedFields=['type','template_name','subject','body','remark','status'];}
