<?php
namespace App\Models;
class PermissionModel extends BaseAppModel {protected $table='permissions';protected $useTimestamps=false;protected $allowedFields=['code','name','module'];}
