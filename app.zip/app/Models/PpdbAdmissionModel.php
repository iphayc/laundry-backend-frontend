<?php
namespace App\Models;
class PpdbAdmissionModel extends BaseAppModel {protected $table='ppdb_admissions';protected $allowedFields=['admission_no','registration_id','decision_date','decision','student_no','accepted_grade','enrollment_deadline','enrollment_status','notes','decided_by'];}
