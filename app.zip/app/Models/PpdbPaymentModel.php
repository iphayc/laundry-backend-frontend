<?php
namespace App\Models;
class PpdbPaymentModel extends BaseAppModel {protected $table='ppdb_payments';protected $allowedFields=['payment_no','registration_id','payment_date','payment_method','amount','reference_no','proof_path','verified_by','verified_at','status','notes','created_by','updated_by'];}
