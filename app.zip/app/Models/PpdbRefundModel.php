<?php
namespace App\Models;
class PpdbRefundModel extends BaseAppModel {protected $table='ppdb_refunds';protected $allowedFields=['refund_no','payment_id','refund_date','amount','reason','method','status','approved_by','approved_at','created_by','updated_by'];}
