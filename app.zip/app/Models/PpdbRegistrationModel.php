<?php
namespace App\Models;
class PpdbRegistrationModel extends BaseAppModel {protected $table='ppdb_registrations';protected $allowedFields=['registration_no','academic_year_id','parent_user_id','registration_date','target_grade','full_name','nickname','nisn','nik','birth_place','birth_date','gender','religion','previous_school','address','city','postal_code','phone','email','father_name','mother_name','guardian_name','parent_phone','parent_email','registration_fee','status','notes','form_document','form_returned_at','workflow_step','created_by','updated_by'];}
