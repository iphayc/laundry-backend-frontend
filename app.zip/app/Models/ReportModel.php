<?php
namespace App\Models;
use CodeIgniter\Model;
class ReportModel extends Model
{
    public function traffic(string $from,string $to): array
    {
        return $this->db->table('access_logs l')->select('DATE(l.event_time) date,l.subject_type,l.result,COUNT(*) total')->where('l.deleted_at',null)->where('l.event_time >=',$from.' 00:00:00')->where('l.event_time <=',$to.' 23:59:59')->groupBy(['DATE(l.event_time)','l.subject_type','l.result'])->get()->getResultArray();
    }
    public function overstay(int $hours=6): array
    {
        return $this->db->table('visits v')->select('v.*,vs.name,u.unit_no,c.name cluster_name,TIMESTAMPDIFF(HOUR,v.check_in,NOW()) duration_hours')->join('visitors vs','vs.id=v.visitor_id')->join('units u','u.id=v.unit_id')->join('clusters c','c.id=u.cluster_id')->where('v.deleted_at',null)->where('v.status','inside')->where('v.check_in <',date('Y-m-d H:i:s',time()-$hours*3600))->get()->getResultArray();
    }
}
