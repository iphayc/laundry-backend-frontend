<?php

namespace App\Models;

class ResidentDocumentModel extends BaseAppModel
{
    protected $table = 'resident_documents';
    protected $allowedFields = [
        'resident_id',
        'document_type',
        'original_name',
        'file_path',
        'mime_type',
        'file_size',
        'remark',
    ];
}
