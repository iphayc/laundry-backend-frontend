<?php
namespace App\Models;
class ResidentModel extends BaseAppModel {
    protected $table='residents'; protected $allowedFields=['unit_id','household_head_id','is_household_head','identity_no','name','gender','birth_date','address','phone','email','identity_image','suspended','suspension_note'];
}
