<?php
namespace App\Models;

class RfidDeviceModel extends BaseAppModel
{
    protected $table='rfid_devices';
    protected $allowedFields=['code','name','device_type','brand','model','serial_number','ip_address','port','api_url','api_key_encrypted','connection_mode','connection_status','last_online_at','active','remark'];
}
