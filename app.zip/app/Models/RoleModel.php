<?php
namespace App\Models;
class RoleModel extends BaseAppModel {protected $table='roles';protected $allowedFields=['name','description'];}
