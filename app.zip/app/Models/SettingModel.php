<?php
namespace App\Models;
class SettingModel extends BaseAppModel {protected $table='settings';protected $createdField='';protected $allowedFields=['setting_key','setting_value','description','updated_by'];}
