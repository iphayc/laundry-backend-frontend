<?php
namespace App\Models;
class UnitModel extends BaseAppModel {protected $table='units';protected $allowedFields=['cluster_id','unit_no','owner_name','phone','active'];}
