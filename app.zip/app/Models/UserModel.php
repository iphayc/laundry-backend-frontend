<?php
namespace App\Models;
class UserModel extends BaseAppModel {
    protected $table='users'; protected $allowedFields=['role_id','group_id','username','name','email','phone','password_hash','active','last_login'];
}
