<?php
namespace App\Models;
class VehicleModel extends BaseAppModel {protected $table='vehicles';protected $allowedFields=['resident_id','vehicle_type_id','plate_no','brand','color','active'];}
