<?php
namespace App\Models;
class VisitModel extends BaseAppModel {
    protected $table='visits'; protected $allowedFields=['visitor_id','unit_id','access_card_id','vehicle_type_id','plate_no','visitor_card_no','purpose','check_in','check_out','status','created_by'];
}
