<?php
namespace App\Models;
class VisitorModel extends BaseAppModel {
    protected $table='visitors'; protected $allowedFields=['resident_id','identity_type','identity_no','name','phone','identity_image','blacklist','blacklist_note'];
}
