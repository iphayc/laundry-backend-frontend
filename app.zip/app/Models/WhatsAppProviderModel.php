<?php
namespace App\Models;

class WhatsAppProviderModel extends BaseAppModel
{
    protected $table = 'whatsapp_providers';
    protected $allowedFields = ['code','name','auth_type','default_url_text','default_url_image','token_encrypted','api_key_encrypted','number_key','phone_number_id','phone_number','graph_version','is_default','active'];
}
