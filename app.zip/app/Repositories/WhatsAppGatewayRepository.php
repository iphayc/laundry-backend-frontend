<?php

namespace App\Repositories;

class WhatsAppGatewayRepository
{
    private $db;
    private string $type;

    public function __construct(string $type = 'ADMIN')
    {
        $this->db = db_connect();
        $this->type = in_array($type, ['ADMIN', 'CUSTOMER'], true)
            ? $type
            : 'ADMIN';
    }

    public function type(): string
    {
        return $this->type;
    }

    public function current(): array
    {
        return $this->db->table('ex_whatsapp_gateway_settings')
            ->where('gateway_type', $this->type)
            ->orderBy('id', 'DESC')
            ->get()->getRowArray() ?? [];
    }

    public function save(array $data): void
    {
        $row = $this->current();

        $data['gateway_type'] = $this->type;
        $data['updated_at'] = date('Y-m-d H:i:s');

        if ($row) {
            $this->db->table('ex_whatsapp_gateway_settings')
                ->where('id', $row['id'])
                ->update($data);
            return;
        }

        $data['created_at'] = date('Y-m-d H:i:s');
        $this->db->table('ex_whatsapp_gateway_settings')->insert($data);
    }
}
