<?php
namespace App\Services;

class BarrierService
{
    public function openForGate(int $gateId): array
    {
        $barriers=db_connect()->table('barrier_gates')->where('gate_id',$gateId)->where('active',1)->where('deleted_at',null)->get()->getResultArray();
        if(!$barriers)return ['configured'=>false,'opened'=>false,'message'=>'Barrier belum dikonfigurasi.'];
        $opened=0;
        foreach($barriers as $barrier){
            if($barrier['controller_type']!=='http'||empty($barrier['open_url']))continue;
            try{
                $headers=[];if(!empty($barrier['api_key_encrypted']))$headers['Authorization']='Bearer '.service('encrypter')->decrypt(base64_decode($barrier['api_key_encrypted']));
                service('curlrequest')->request('POST',$barrier['open_url'],['headers'=>$headers,'timeout'=>2,'connect_timeout'=>1,'http_errors'=>false]);
                db_connect()->table('barrier_gates')->where('id',$barrier['id'])->update(['connection_status'=>'online','last_online_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);$opened++;
            }catch(\Throwable $e){log_message('error','Barrier '.$barrier['code'].': '.$e->getMessage());db_connect()->table('barrier_gates')->where('id',$barrier['id'])->update(['connection_status'=>'offline','updated_at'=>date('Y-m-d H:i:s')]);}
        }
        return ['configured'=>true,'opened'=>$opened>0,'message'=>$opened?'Perintah buka barrier terkirim.':'Perintah buka barrier gagal.'];
    }
}
