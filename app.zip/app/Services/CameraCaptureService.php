<?php
namespace App\Services;

class CameraCaptureService
{
    public function captureForGate(int $gateId, ?string $browserImage=null, ?int $cameraId=null): array
    {
        $db=db_connect();$builder=$db->table('gate_cameras')->where('gate_id',$gateId)->where('active',1)->where('deleted_at',null);
        if($cameraId)$builder->where('id',$cameraId);
        else$builder->orderBy("camera_type = 'usb'",'ASC',false)->orderBy('id');
        $camera=$builder->get()->getRowArray();
        if(!$camera)return ['configured'=>false,'captured'=>false,'message'=>'Camera belum dikonfigurasi.','path'=>null,'url'=>null];
        try{
            if($camera['camera_type']==='usb'){
                if(!$browserImage||!preg_match('#^data:image/(jpeg|png|webp);base64,(.+)$#s',$browserImage,$matches))throw new \RuntimeException('Frame USB camera tidak diterima.');
                $extension=$matches[1]==='jpeg'?'jpg':$matches[1];$body=base64_decode($matches[2],true);
                if($body===false||strlen($body)>5*1024*1024)throw new \RuntimeException('Ukuran frame USB camera tidak valid.');
            }else{
                $options=['timeout'=>5,'connect_timeout'=>2,'http_errors'=>false];
                if(!empty($camera['username']))$options['auth']=[$camera['username'],!empty($camera['password_encrypted'])?service('encrypter')->decrypt(base64_decode($camera['password_encrypted'])):''];
                $response=service('curlrequest')->request('GET',$camera['snapshot_url'],$options);
                if($response->getStatusCode()>=400)throw new \RuntimeException('Camera HTTP '.$response->getStatusCode());
                $body=(string)$response->getBody();$contentType=strtolower($response->getHeaderLine('Content-Type'));$extension=str_contains($contentType,'png')?'png':(str_contains($contentType,'webp')?'webp':'jpg');
            }
            if($body===''||@getimagesizefromstring($body)===false)throw new \RuntimeException('Respons kamera bukan file gambar yang valid.');
            $relative='uploads/gate-captures/'.date('Y/m');$directory=FCPATH.str_replace('/',DIRECTORY_SEPARATOR,$relative);
            if(!is_dir($directory)&&!mkdir($directory,0775,true)&&!is_dir($directory))throw new \RuntimeException('Folder capture tidak dapat dibuat.');
            $filename='gate-'.$gateId.'-cam-'.$camera['id'].'-'.date('Ymd-His').'-'.bin2hex(random_bytes(3)).'.'.$extension;
            if(file_put_contents($directory.DIRECTORY_SEPARATOR.$filename,$body)===false)throw new \RuntimeException('Snapshot gagal disimpan.');
            $path=$relative.'/'.$filename;
            $db->table('gate_cameras')->where('id',$camera['id'])->update(['connection_status'=>'online','last_online_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            return ['configured'=>true,'captured'=>true,'message'=>'Foto kendaraan berhasil disimpan.','path'=>$path,'url'=>base_url($path),'camera_name'=>$camera['name']];
        }catch(\Throwable $e){
            log_message('error','Camera capture '.$camera['code'].': '.$e->getMessage());
            $db->table('gate_cameras')->where('id',$camera['id'])->update(['connection_status'=>'offline','updated_at'=>date('Y-m-d H:i:s')]);
            return ['configured'=>true,'captured'=>false,'message'=>'Foto kendaraan gagal diambil.','path'=>null,'url'=>null,'camera_name'=>$camera['name']];
        }
    }
}
