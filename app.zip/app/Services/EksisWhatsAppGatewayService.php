<?php

namespace App\Services;

use App\Repositories\WhatsAppGatewayRepository;

class EksisWhatsAppGatewayService
{
    private WhatsAppGatewayRepository $repo;

    public function __construct(string $profile = 'ADMIN')
    {
        $this->repo = new WhatsAppGatewayRepository($profile);
    }

    public function config(bool $secret = false): array
    {
        $row = $this->repo->current();

        if ($secret && !empty($row['api_key_encrypted'])) {
            $row['api_key'] = service('encrypter')->decrypt(
                base64_decode($row['api_key_encrypted'])
            );
        }

        unset($row['api_key_encrypted']);
        return $row;
    }

    public function save(array $input): void
    {
        $current = $this->repo->current();

        $data = [
            'node_engine_url'    => trim((string) ($input['node_engine_url'] ?? '')),
            'send_url'           => trim((string) ($input['send_url'] ?? '')),
            'qr_url'             => trim((string) ($input['qr_url'] ?? '')),
            'phone_number'       => $this->repo->type() === 'CUSTOMER' ? null : (preg_replace('/\D/', '', (string) ($input['phone_number'] ?? '')) ?: null),
            'send_delay_seconds' => max(0, min(3600, (int) ($input['send_delay_seconds'] ?? 2))),
            'is_active'          => !empty($input['is_active']) ? 1 : 0,
        ];

        foreach (['node_engine_url', 'send_url', 'qr_url'] as $field) {
            $parts = parse_url($data[$field]);
            $scheme = strtolower((string) ($parts['scheme'] ?? ''));

            if (
                !$parts ||
                !in_array($scheme, ['http', 'https'], true) ||
                empty($parts['host'])
            ) {
                throw new \InvalidArgumentException(
                    'URL gateway wajib berupa URL HTTP atau HTTPS yang valid.'
                );
            }
        }

        $key = trim((string) ($input['api_key'] ?? ''));

        if ($key !== '') {
            $data['api_key_encrypted'] = base64_encode(
                service('encrypter')->encrypt($key)
            );
        } elseif (empty($current['api_key_encrypted'])) {
            throw new \InvalidArgumentException('API key wajib diisi.');
        }

        $this->repo->save($data);
    }

    /**
     * Pengiriman ADMIN tetap memakai konfigurasi ADMIN.
     *
     * Untuk CUSTOMER, caller wajib memberikan session_key. Ini mencegah
     * pengiriman customer memakai session/default WhatsApp yang salah.
     */
    public function send(
        string $number,
        string $message,
        bool $allowInactive = false,
        ?string $sessionKey = null
    ): array {
        $cfg = $this->config(true);

        if (!$allowInactive && empty($cfg['is_active'])) {
            throw new \RuntimeException('WhatsApp Gateway tidak aktif.');
        }

        // ADMIN memakai session tetap ADMIN-WA-1, CUSTOMER memakai session
        // yang ditentukan oleh company. Dengan demikian pengiriman tidak
        // pernah jatuh ke session/global WhatsApp yang lain.
        $sessionKey = $this->resolveSessionKey($sessionKey);

        $number = preg_replace('/\D/', '', $number);

        if (str_starts_with($number, '0')) {
            $number = '62'.substr($number, 1);
        }

        if ($number === '' || trim($message) === '') {
            throw new \InvalidArgumentException('Nomor dan pesan wajib diisi.');
        }

        $url = $this->withSessionKey($cfg['send_url'], $sessionKey);

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => json_encode(
                array_filter([
                    'number' => $number,
                    'message' => $message,
                    'session_key' => $sessionKey,
                ], static fn ($value) => $value !== null && $value !== ''),
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Accept: application/json',
                'x-api-key: '.$cfg['api_key'],
            ],
        ]);

        $body = curl_exec($curl);
        $error = curl_error($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($body === false) {
            return [
                'success' => false,
                'status' => $status ?: null,
                'message' => $error ?: 'Gateway tidak memberikan respons',
            ];
        }

        $decoded = json_decode((string) $body, true);

        $success = $status >= 200 &&
            $status < 300 &&
            (!is_array($decoded) || ($decoded['success'] ?? true) !== false);

        return [
            'success' => $success,
            'status' => $status,
            'data' => $decoded ?? $body,
            'message' => is_array($decoded)
                ? ($decoded['message'] ?? null)
                : null,
        ];
    }

    /**
     * Mengirim menggunakan session WhatsApp milik company tertentu.
     */
    public function sendForCompany(
        int $companyId,
        string $number,
        string $message
    ): array {
        if ($this->repo->type() !== 'CUSTOMER') {
            throw new \LogicException('sendForCompany hanya untuk gateway CUSTOMER.');
        }

        $session = db_connect()->table('ex_whatsapp_sessions')
            ->where('company_id', $companyId)
            ->where('provider', 'CUSTOMER_GATEWAY')
            ->where('status', 'CONNECTED')
            ->where('deleted_at', null)
            ->orderBy('id', 'DESC')
            ->get()->getRowArray();

        if (!$session) {
            return [
                'success' => false,
                'status' => 422,
                'message' => 'WhatsApp customer belum terhubung. Scan QR terlebih dahulu.',
            ];
        }

        return $this->send(
            $number,
            $message,
            false,
            (string) $session['session_key']
        );
    }

    /**
     * Meminta QR untuk session customer tertentu.
     *
     * Gateway 8082 menerima session_key sebagai query parameter dan juga
     * body agar implementasi Gateway dapat memilih salah satu cara tersebut.
     */
    /**
     * Meminta QR untuk session WhatsApp.
     *
     * ADMIN selalu memakai session tetap ADMIN-WA-1.
     * CUSTOMER wajib mengirim session_key milik company.
     */
    public function connect(?string $sessionKey = null): array
    {
        $cfg = $this->activeConfig();

        $sessionKey = $this->resolveSessionKey($sessionKey);

        $url = $this->withSessionKey(
            (string) ($cfg['qr_url'] ?? ''),
            $sessionKey
        );

        if ($url === '') {
            $url = $this->endpoint(
                (string) ($cfg['node_engine_url'] ?? ''),
                'qr'
            );
            $url = $this->withSessionKey($url, $sessionKey);
        }

        return $this->request($url, 'GET', $sessionKey);
    }

    /**
     * Status session customer tertentu.
     */
    /**
     * Status session WhatsApp.
     *
     * ADMIN otomatis memakai ADMIN-WA-1.
     * CUSTOMER wajib mengirim session_key.
     */
    public function status(?string $sessionKey = null): array
    {
        $cfg = $this->activeConfig();
        $sessionKey = $this->resolveSessionKey($sessionKey);

        $url = $this->statusUrl($cfg);

        return $this->request(
            $this->withSessionKey($url, $sessionKey),
            'GET',
            $sessionKey
        );
    }

    /**
     * QR langsung dipertahankan untuk kompatibilitas.
     */
    public function qr(?string $sessionKey = null): array
    {
        return $this->connect($sessionKey);
    }

    /**
     * Logout hanya session yang bersangkutan.
     * ADMIN otomatis logout ADMIN-WA-1.
     */
    public function logout(?string $sessionKey = null): array
    {
        $cfg = $this->activeConfig();
        $sessionKey = $this->resolveSessionKey($sessionKey);

        $url = $this->logoutUrl($cfg);

        return $this->request(
            $this->withSessionKey($url, $sessionKey),
            'POST',
            $sessionKey
        );
    }

    private function resolveSessionKey(?string $sessionKey): string
    {
        if ($this->repo->type() === 'ADMIN') {
            return 'ADMIN-WA-1';
        }

        $sessionKey = trim((string) $sessionKey);

        if ($sessionKey === '') {
            throw new \InvalidArgumentException(
                'Session WhatsApp customer belum ditentukan.'
            );
        }

        return $sessionKey;
    }

    private function activeConfig(): array
    {
        $cfg = $this->config(true);

        if (empty($cfg) || empty($cfg['is_active'])) {
            throw new \RuntimeException(
                'Konfigurasi WhatsApp gateway belum aktif.'
            );
        }

        return $cfg;
    }

    private function statusUrl(array $cfg): string
    {
        // Prefer URL QR dari Gateway 8082 dan ubah /qr menjadi /status.
        // Contoh:
        // /index.php/wa/qr -> /index.php/wa/status
        $qrUrl = trim((string) ($cfg['qr_url'] ?? ''));

        if ($qrUrl !== '') {
            $status = preg_replace(
                '#/qr/?(?:\?.*)?$#i',
                '/status',
                $qrUrl
            );

            if (is_string($status) && $status !== $qrUrl) {
                return $status;
            }
        }

        // Fallback ke Node Engine bila Gateway belum menyediakan URL status.
        return $this->endpoint(
            (string) ($cfg['node_engine_url'] ?? ''),
            'status'
        );
    }

    private function logoutUrl(array $cfg): string
    {
        // Node Engine biasanya menyediakan /logout.
        // Gateway CI4 juga dapat mengekspos /logout pada URL yang sama.
        $qrUrl = trim((string) ($cfg['qr_url'] ?? ''));

        if ($qrUrl !== '') {
            $logout = preg_replace(
                '#/qr/?(?:\?.*)?$#i',
                '/logout',
                $qrUrl
            );

            if (is_string($logout) && $logout !== $qrUrl) {
                return $logout;
            }
        }

        return $this->endpoint(
            (string) ($cfg['node_engine_url'] ?? ''),
            'logout'
        );
    }

    private function endpoint(string $base, string $path): string
    {
        $base = rtrim(trim($base), '/');

        if ($base === '') {
            throw new \RuntimeException('URL Node Engine WhatsApp belum diatur.');
        }

        return $base.'/'.$path;
    }

    private function withSessionKey(string $url, ?string $sessionKey): string
    {
        $url = trim($url);

        if ($url === '' || trim((string) $sessionKey) === '') {
            return $url;
        }

        $separator = str_contains($url, '?') ? '&' : '?';

        return $url.$separator.'session_key='.rawurlencode((string) $sessionKey);
    }

    private function request(
        string $url,
        string $method = 'GET',
        ?string $sessionKey = null
    ): array {
        $cfg = $this->config(true);

        $curl = curl_init();

        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
        ];

        if (!empty($cfg['api_key'])) {
            $headers[] = 'x-api-key: '.$cfg['api_key'];
        }

        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER => $headers,
        ];

        if ($method === 'POST') {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = json_encode([
                'session_key' => $sessionKey,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        curl_setopt_array($curl, $options);

        $body = curl_exec($curl);
        $error = curl_error($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($body === false) {
            return [
                'success' => false,
                'status' => $status ?: null,
                'message' => $error ?: 'Gateway tidak dapat dihubungi',
            ];
        }

        $decoded = json_decode((string) $body, true);

        $success = $status >= 200 &&
            $status < 300 &&
            (!is_array($decoded) || ($decoded['success'] ?? true) !== false);

        return [
            'success' => $success,
            'status' => $status,
            'data' => $decoded ?? $body,
            'message' => is_array($decoded)
                ? ($decoded['message'] ?? null)
                : null,
        ];
    }
}
