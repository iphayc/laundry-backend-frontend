<?php
namespace App\Services;

class EntitlementService
{
    private $db;
    public function __construct(){$this->db=db_connect();}

    public function current(int $companyId):?array
    {
        $license=$this->latest($companyId);
        if(!$license)return null;
        // Paket FREE tidak memiliki masa kedaluwarsa. Lisensi berbayar yang
        // sudah melewati expires_at langsung diturunkan ke FREE; perubahan
        // ini sekaligus mencabut sesi lama agar login berikutnya memakai
        // seluruh aturan/limit paket FREE.
        if(($license['package_code']??'')!=='FREE'&&$license['status']==='ACTIVE'&&$license['expires_at']&&strtotime($license['expires_at'])<=time())$license=$this->downgradeToFree($companyId,$license);
        $license['device_limit']=max(1,(int)($license['max_devices']??$license['device_limit']??1));
        $this->db->table('ex_licenses')->where('id',$license['id'])->update(['device_limit'=>$license['device_limit'],'updated_at'=>date('Y-m-d H:i:s')]);
        $this->applyPackageLimits($companyId,$license);
        $activeBranches=$this->db->table('ex_branches')->where('company_id',$companyId)->where('is_active',1)->where('deleted_at',null)->countAllResults();
        $license['branch_selection_required']=$activeBranches>max(1,(int)$license['max_branches']);
        $license['branches_to_disable']=max(0,$activeBranches-max(1,(int)$license['max_branches']));
        $features=$this->db->table('ex_package_features pf')->select('f.code,f.value_type,pf.value')->join('ex_features f','f.id=pf.feature_id')->where('pf.package_id',$license['package_id'])->where('f.is_active',1)->where('f.deleted_at',null)->get()->getResultArray();
        $license['features']=[];
        foreach($features as $f){$v=$f['value'];if($f['value_type']==='BOOLEAN')$v=$v==='1';elseif($f['value_type']==='INTEGER'&&$v!=='UNLIMITED')$v=(int)$v;$license['features'][$f['code']]=$v;}
        unset($license['package_id']);return $license;
    }

    private function latest(int $companyId):?array
    {
        return $this->db->table('ex_licenses l')->select('l.id,l.license_key,l.license_type,l.status,l.starts_at,l.expires_at,l.device_limit,p.id package_id,p.code package_code,p.name package_name,p.type package_type,p.max_branches,p.users_per_branch,p.max_devices,p.daily_transaction_limit')->join('ex_packages p','p.id=l.package_id')->where('l.company_id',$companyId)->where('l.deleted_at',null)->orderBy('l.id','DESC')->get()->getRowArray()?:null;
    }

    private function downgradeToFree(int $companyId,array $expired):array
    {
        $now=date('Y-m-d H:i:s');$free=$this->db->table('ex_packages')->where('code','FREE')->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
        if(!$free){$this->db->table('ex_licenses')->where('id',$expired['id'])->update(['status'=>'EXPIRED','updated_at'=>$now]);$expired['status']='EXPIRED';return $expired;}
        $mainBranch=(int)($this->db->table('ex_branches')->select('id')->where('company_id',$companyId)->where('deleted_at',null)->orderBy('id')->get()->getRow('id')??0);
        $this->db->transStart();
        $this->db->table('ex_licenses')->where('id',$expired['id'])->update(['status'=>'EXPIRED','updated_at'=>$now]);
        $this->db->table('ex_licenses')->insert(['license_key'=>'EXL-'.strtoupper(bin2hex(random_bytes(8))),'company_id'=>$companyId,'package_id'=>$free['id'],'license_type'=>'TRIAL','status'=>'ACTIVE','starts_at'=>$now,'activated_at'=>$now,'device_limit'=>1,'created_at'=>$now]);
        $licenseId=(int)$this->db->insertID();
        // Jangan bergantung hanya pada trigger database. Production yang
        // belum memiliki trigger tetap harus membatalkan access/refresh
        // token saat paket berbayar berakhir.
        $companyUsers=$this->db->table('ex_users')->select('id')->where('company_id',$companyId)->where('deleted_at',null)->get()->getResultArray();
        if($companyUsers)$this->db->table('ex_user_tokens')->whereIn('user_id',array_column($companyUsers,'id'))->where('revoked_at',null)->update(['revoked_at'=>$now]);
        $this->db->table('ex_companies')->where('id',$companyId)->set('session_epoch','session_epoch + 1',false)->update(['updated_at'=>$now]);
        // Cabang tidak dipilih otomatis. Owner wajib menentukan sendiri cabang
        // non-utama yang dikunci jika jumlah cabang aktif melebihi paket baru.
        if($mainBranch)$this->db->table('ex_branches')->where('id',$mainBranch)->update(['is_active'=>1,'disabled_reason'=>null,'updated_at'=>$now]);
        $this->db->table('ex_users')->where('company_id',$companyId)->where('role','OWNER')->where('deleted_at',null)->update(['branch_id'=>$mainBranch?:null,'is_active'=>1,'disabled_reason'=>null,'updated_at'=>$now]);
        $this->db->table('ex_license_history')->insert(['license_id'=>$licenseId,'company_id'=>$companyId,'package_id'=>$free['id'],'event'=>'DOWNGRADE_FREE','previous_status'=>'EXPIRED','new_status'=>'ACTIVE','notes'=>'Langganan berakhir; owner wajib memilih cabang yang dinonaktifkan jika melebihi kuota FREE.','created_at'=>$now]);
        $this->db->transComplete();return $this->latest($companyId);
    }

    public function restoreAfterUpgrade(int $companyId):void
    {
        $license=$this->latest($companyId);if($license&&$license['status']==='ACTIVE')$this->applyPackageLimits($companyId,$license);
    }

    private function applyPackageLimits(int $companyId,array $license):void
    {
        $now=date('Y-m-d H:i:s');$branchLimit=max(1,(int)$license['max_branches']);$userLimit=max(1,(int)$license['users_per_branch']);$reasons=['LICENSE_EXPIRED','LICENSE_LIMIT'];
        $branches=$this->db->table('ex_branches')->where('company_id',$companyId)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        if(!$branches)return;
        $mainBranch=(int)$branches[0]['id'];
        if(!(int)$branches[0]['is_active']){$this->db->table('ex_branches')->where('id',$mainBranch)->update(['is_active'=>1,'disabled_reason'=>null,'updated_at'=>$now]);$branches[0]['is_active']=1;$branches[0]['disabled_reason']=null;}
        $activeBranches=array_values(array_filter($branches,fn($b)=>(int)$b['is_active']===1));
        // Jangan menentukan korban downgrade berdasarkan urutan ID. Selama
        // jumlahnya berlebih, owner harus memilih cabang melalui form Cabang.
        if(count($activeBranches)>$branchLimit)return;
        $allowed=array_map(fn($b)=>(int)$b['id'],$activeBranches);
        // Cabang yang sudah dinonaktifkan manual sebelum memilih paket lebih
        // kecil menjadi cabang terkunci bila memang mengisi selisih kuota.
        $neededLocks=max(0,count($branches)-$branchLimit);
        $locked=count(array_filter($branches,fn($b)=>($b['disabled_reason']??null)==='PACKAGE_DOWNGRADE'));
        foreach($branches as $branch){if($locked>=$neededLocks)break;if(!(int)$branch['is_active']&&($branch['disabled_reason']??null)==='MANUAL'){$this->db->table('ex_branches')->where('id',$branch['id'])->update(['disabled_reason'=>'PACKAGE_DOWNGRADE','updated_at'=>$now]);$locked++;}}
        $this->db->table('ex_users')->where('company_id',$companyId)->where('role','OWNER')->where('deleted_at',null)->update(['branch_id'=>$mainBranch,'is_active'=>1,'disabled_reason'=>null,'updated_at'=>$now]);
        $revoked=[];
        $allUsers=$this->db->table('ex_users')->where('company_id',$companyId)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        foreach($allowed as $branchId){$eligible=array_values(array_filter($allUsers,fn($u)=>(int)$u['branch_id']===$branchId&&($u['disabled_reason']??null)!=='MANUAL'));usort($eligible,fn($a,$b)=>(($a['role']==='OWNER'?0:1)<=>($b['role']==='OWNER'?0:1))?:((int)$a['id']<=>(int)$b['id']));$keep=array_slice($eligible,0,$userLimit);$keepIds=array_map(fn($u)=>(int)$u['id'],$keep);foreach($eligible as $u){$id=(int)$u['id'];if(in_array($id,$keepIds,true))$this->db->table('ex_users')->where('id',$id)->update(['is_active'=>1,'disabled_reason'=>null,'updated_at'=>$now]);else{$this->db->table('ex_users')->where('id',$id)->update(['is_active'=>0,'disabled_reason'=>'LICENSE_LIMIT','updated_at'=>$now]);$revoked[]=$id;}}}
        foreach($allUsers as $u){if($u['role']==='OWNER'||in_array((int)$u['branch_id'],$allowed,true)||($u['disabled_reason']??null)==='MANUAL')continue;if((int)$u['is_active']===1||in_array($u['disabled_reason']??'',$reasons,true)){$this->db->table('ex_users')->where('id',$u['id'])->update(['is_active'=>0,'disabled_reason'=>'LICENSE_LIMIT','updated_at'=>$now]);$revoked[]=(int)$u['id'];}}
        if($revoked)$this->db->table('ex_user_tokens')->whereIn('user_id',array_values(array_unique($revoked)))->where('revoked_at',null)->update(['revoked_at'=>$now]);
        $this->applyDeviceLimits($companyId,$allowed,max(1,(int)($license['max_devices']??$license['device_limit']??1)),$now);
    }

    private function applyDeviceLimits(int $companyId,array $allowedBranches,int $deviceLimit,string $now):void
    {
        $devices=$this->db->table('ex_devices')->where('company_id',$companyId)->where('deleted_at',null)->orderBy('id')->get()->getResultArray();
        $kept=0;$disabled=[];
        foreach($devices as $device){
            $reason=$device['disabled_reason']??null;
            if($reason==='MANUAL'||$device['status']==='REPLACED')continue;
            $branchAllowed=in_array((int)($device['branch_id']??0),$allowedBranches,true);
            if($branchAllowed&&$kept<$deviceLimit){
                // Hanya device yang sebelumnya dibatasi lisensi yang boleh
                // dipulihkan otomatis; device manual tetap tidak disentuh.
                if($device['status']==='ACTIVE'||in_array($reason,['LICENSE_EXPIRED','LICENSE_LIMIT','PACKAGE_DOWNGRADE'],true)){
                    $this->db->table('ex_devices')->where('id',$device['id'])->update(['status'=>'ACTIVE','disabled_reason'=>null,'updated_at'=>$now]);
                    $kept++;
                }
                continue;
            }
            if($device['status']==='ACTIVE'||in_array($reason,['LICENSE_EXPIRED','LICENSE_LIMIT','PACKAGE_DOWNGRADE'],true)){
                $this->db->table('ex_devices')->where('id',$device['id'])->update(['status'=>'DISABLED','disabled_reason'=>'LICENSE_LIMIT','updated_at'=>$now]);
                $disabled[]=(int)$device['id'];
            }
        }
        if(!$disabled)return;
        $this->db->table('ex_user_tokens')->whereIn('device_id',$disabled)->where('revoked_at',null)->update(['revoked_at'=>$now]);
        $this->db->table('ex_license_devices')->whereIn('device_id',$disabled)->where('revoked_at',null)->update(['revoked_at'=>$now]);
    }

    public function bindDevice(int $companyId,int $deviceId):array
    {
        $license=$this->current($companyId);if(!$license||!in_array($license['status'],['ACTIVE','TRIAL'],true))throw new \RuntimeException('Lisensi tidak aktif.');$device=$this->db->table('ex_devices')->where('id',$deviceId)->where('company_id',$companyId)->where('status','ACTIVE')->where('deleted_at',null)->get()->getRowArray();if(!$device)throw new \RuntimeException('Device tidak ditemukan atau tidak aktif.');$bound=$this->db->table('ex_license_devices')->where('license_id',$license['id'])->where('revoked_at',null)->countAllResults();$binding=$this->db->table('ex_license_devices')->where('license_id',$license['id'])->where('device_id',$deviceId)->get()->getRowArray();$exists=$binding&&$binding['revoked_at']===null;if(!$exists&&$bound>=(int)$license['device_limit'])throw new \RuntimeException('Batas device lisensi telah tercapai.');if(!$exists){$now=date('Y-m-d H:i:s');if($binding)$this->db->table('ex_license_devices')->where('license_id',$license['id'])->where('device_id',$deviceId)->update(['bound_at'=>$now,'revoked_at'=>null]);else $this->db->table('ex_license_devices')->insert(['license_id'=>$license['id'],'device_id'=>$deviceId,'bound_at'=>$now]);$package=$this->db->table('ex_licenses')->select('package_id')->where('id',$license['id'])->get()->getRow('package_id');$this->db->table('ex_license_history')->insert(['license_id'=>$license['id'],'company_id'=>$companyId,'package_id'=>$package,'event'=>'DEVICE_BIND','new_status'=>$license['status'],'notes'=>$device['device_name'].' / '.$device['device_uuid'],'created_at'=>$now]);}return ['license'=>$license,'device'=>['id'=>$device['id'],'device_uuid'=>$device['device_uuid'],'bound'=>true]];
    }
}
