<?php
namespace App\Services;

use App\Models\AccessLogModel;

class GateService
{
    public function process(array $payload): array
    {
        $db=db_connect(); $card=(string)($payload['card_no']??''); $gate=(int)($payload['gate_id']??0); $direction=$payload['direction']??'in';
        $access=$db->table('access_cards ac')->select('ac.*,r.name,r.suspended,r.id resident_id')->join('residents r','r.id=ac.resident_id AND r.deleted_at IS NULL','left')->where('ac.card_no',$card)->where('ac.deleted_at',null)->get()->getRowArray();
        $granted=true; $reason='Akses diberikan'; $subject='unknown'; $subjectId=null; $forced=0;
        if(!$access){$granted=false;$reason='Kartu tidak dikenal';}
        elseif($access['status']!=='active'){$granted=false;$reason='Kartu tidak aktif';$subject='resident';$subjectId=$access['resident_id'];}
        elseif((int)$access['suspended']===1){$granted=false;$reason='Penghuni sedang suspended';$subject='resident';$subjectId=$access['resident_id'];$forced=1;}
        else{$subject=$access['card_type'];$subjectId=$access['resident_id'];}
        $entryLog=null;
        if($granted&&$direction==='out'){
            $latest=$db->table('access_logs')->select('id,direction,capture_image,event_time')->where('card_no',$card)->where('result','granted')->where('deleted_at',null)->orderBy('event_time','DESC')->orderBy('id','DESC')->get()->getRowArray();
            if($latest&&$latest['direction']==='in')$entryLog=$latest;
        }
        $capture=$granted?(new CameraCaptureService())->captureForGate($gate,$payload['camera_image']??null,isset($payload['camera_id'])?(int)$payload['camera_id']:null):['configured'=>false,'captured'=>false,'message'=>'Akses ditolak; foto tidak diambil.','path'=>null,'url'=>null];
        $rawPayload=$payload;unset($rawPayload['camera_image']);
        $id=(new AccessLogModel())->insert(['card_no'=>$card,'subject_type'=>$subject,'subject_id'=>$subjectId,'gate_id'=>$gate,'direction'=>$direction,'vehicle_type_id'=>$payload['vehicle_type_id']??null,'plate_no'=>$payload['plate_no']??null,'event_time'=>date('Y-m-d H:i:s'),'result'=>$granted?'granted':'denied','reason'=>$reason,'forced_suspended_trial'=>$forced,'raw_payload'=>json_encode($rawPayload),'capture_image'=>$capture['path'],'entry_access_log_id'=>$entryLog['id']??null,'created_at'=>date('Y-m-d H:i:s')]);
        // Urutan: kartu valid -> foto disimpan -> transaksi dicatat -> barrier dibuka.
        if($granted&&$capture['captured'])$barrier=(new BarrierService())->openForGate($gate);
        elseif($granted)$barrier=['configured'=>false,'opened'=>false,'message'=>'Barrier tidak dibuka karena foto kendaraan gagal disimpan.'];
        else$barrier=['configured'=>false,'opened'=>false,'message'=>'Akses ditolak; barrier tidak dibuka.'];
        return ['success'=>true,'granted'=>$granted,'message'=>$reason,'resident'=>$access['name']??null,'capture'=>$capture,'current_image'=>$capture['url'],'entry_image'=>!empty($entryLog['capture_image'])?base_url($entryLog['capture_image']):null,'entry_time'=>$entryLog['event_time']??null,'barrier'=>$barrier,'access_log_id'=>(int)$id,'event_time'=>date(DATE_ATOM)];
    }
}
