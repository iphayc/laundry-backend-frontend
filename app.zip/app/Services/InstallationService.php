<?php

namespace App\Services;

use Config\Services;
use RuntimeException;
use Throwable;

class InstallationService
{
    public function status(): array
    {
        $config = config('Database')->default;
        $status = [
            'databaseConfigured' => trim((string) ($config['database'] ?? '')) !== '',
            'connected' => false,
            'installed' => false,
            'message' => null,
            'database' => (string) ($config['database'] ?? ''),
            'hostname' => (string) ($config['hostname'] ?? ''),
            'port' => (int) ($config['port'] ?? 3306),
        ];

        if (! $status['databaseConfigured']) {
            $status['message'] = 'Nama database belum diatur pada file .env.';
            return $status;
        }

        try {
            $db = db_connect();
            $db->initialize();
            $status['connected'] = true;
            $status['installed'] = $db->tableExists('users')
                && $db->tableExists('application_registration')
                && $db->table('users')->where('deleted_at', null)->countAllResults() > 0;
        } catch (Throwable $e) {
            $status['message'] = $e->getMessage();
        }

        return $status;
    }

    public function isInstalled(): bool
    {
        return (bool) $this->status()['installed'];
    }

    public function install(array $input): void
    {
        $status = $this->status();
        if (! $status['connected']) {
            throw new RuntimeException('Database tidak dapat dihubungkan. Periksa konfigurasi database pada .env.');
        }
        if ($status['installed']) {
            throw new RuntimeException('Aplikasi sudah terpasang. Wizard instalasi telah dikunci.');
        }

        $migrations = Services::migrations();
        if (! $migrations->latest()) {
            $messages = $migrations->getCliMessages();
            throw new RuntimeException('Migrasi database gagal. ' . implode(' ', $messages));
        }

        $db = db_connect();
        $now = date('Y-m-d H:i:s');

        if (! $db->tableExists('application_registration')) {
            $db->query("CREATE TABLE application_registration (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                registered_email VARCHAR(160) NOT NULL,
                machine_id_hash CHAR(64) NULL,
                license_code_hash VARCHAR(255) NULL,
                license_code_encrypted TEXT NULL,
                active TINYINT(1) NOT NULL DEFAULT 0,
                activated_at DATETIME NULL,
                last_code_sent_at DATETIME NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL,
                INDEX(registered_email), INDEX(active)
            )");
        }

        $this->seedRolesAndGroups($now);
        $this->seedPermissions();
        $this->seedAdmin($input, $now);
        $this->seedDefaults($now);
        $this->saveCompany($input, $now);
        $this->grantAdministratorAccess();

        $email = strtolower(trim((string) $input['activation_email']));
        $registration = $db->table('application_registration')->orderBy('id', 'DESC')->get()->getRowArray();
        $registrationData = [
            'registered_email' => $email,
            'machine_id_hash' => null,
            'license_code_hash' => null,
            'license_code_encrypted' => null,
            'active' => 0,
            'activated_at' => null,
            'updated_at' => $now,
        ];
        if ($registration) {
            $db->table('application_registration')->where('id', $registration['id'])->update($registrationData);
        } else {
            $db->table('application_registration')->insert($registrationData + ['created_at' => $now]);
        }
    }

    private function seedRolesAndGroups(string $now): void
    {
        $db = db_connect();
        if (! $db->table('roles')->where('deleted_at', null)->countAllResults()) {
            $db->table('roles')->insertBatch([
                ['id' => 1, 'name' => 'Administrator', 'description' => 'Akses penuh', 'created_at' => $now],
                ['id' => 2, 'name' => 'Creator', 'description' => 'Tambah dan kelola data operasional', 'created_at' => $now],
                ['id' => 3, 'name' => 'Editor', 'description' => 'Mengubah data operasional', 'created_at' => $now],
                ['id' => 4, 'name' => 'Viewer', 'description' => 'Akses baca dan laporan', 'created_at' => $now],
            ]);
        }
        if (! $db->table('groups')->where('deleted_at', null)->countAllResults()) {
            $db->table('groups')->insertBatch([
                ['id' => 1, 'parent_id' => null, 'name' => 'Perumahan', 'description' => 'Root organisasi', 'created_at' => $now],
                ['id' => 2, 'parent_id' => 1, 'name' => 'Security', 'description' => 'Petugas keamanan', 'created_at' => $now],
                ['id' => 3, 'parent_id' => 1, 'name' => 'Management', 'description' => 'Pengelola kawasan', 'created_at' => $now],
            ]);
        }
    }

    private function seedPermissions(): void
    {
        $db = db_connect();
        foreach ([
            'dashboard.view', 'users.manage', 'masters.manage', 'residents.manage',
            'visitors.manage', 'blacklist.manage', 'gate.operate', 'reports.view',
            'reports.export', 'settings.manage',
        ] as $code) {
            if (! $db->table('permissions')->where('code', $code)->countAllResults()) {
                $db->table('permissions')->insert([
                    'code' => $code,
                    'name' => ucwords(str_replace(['.', '_'], ' ', $code)),
                    'module' => explode('.', $code)[0],
                ]);
            }
        }
    }

    private function seedAdmin(array $input, string $now): void
    {
        $db = db_connect();
        $username = trim((string) $input['admin_username']);
        $existing = $db->table('users')->where('username', $username)->get()->getRowArray();
        $data = [
            'role_id' => 1,
            'group_id' => 3,
            'username' => $username,
            'name' => trim((string) $input['admin_name']),
            'email' => strtolower(trim((string) $input['admin_email'])),
            'phone' => trim((string) ($input['admin_phone'] ?? '')),
            'password_hash' => password_hash((string) $input['admin_password'], PASSWORD_DEFAULT),
            'active' => 1,
            'updated_at' => $now,
            'deleted_at' => null,
        ];
        if ($existing) {
            $db->table('users')->where('id', $existing['id'])->update($data);
        } else {
            $db->table('users')->insert($data + ['created_at' => $now]);
        }
    }

    private function seedDefaults(string $now): void
    {
        $db = db_connect();
        foreach ([
            ['CAR', 'Mobil'], ['MOTOR', 'Motor'], ['WALK', 'Pejalan Kaki'],
        ] as [$code, $name]) {
            if (! $db->table('vehicle_types')->where('code', $code)->countAllResults()) {
                $db->table('vehicle_types')->insert([
                    'code' => $code, 'name' => $name, 'active' => 1, 'created_at' => $now,
                ]);
            }
        }
        foreach ([
            'day_start' => '05:00', 'night_start' => '18:00',
            'day_limit_hours' => '3', 'night_limit_hours' => '6',
        ] as $key => $value) {
            if (! $db->table('settings')->where('setting_key', $key)->countAllResults()) {
                $db->table('settings')->insert([
                    'setting_key' => $key, 'setting_value' => $value, 'updated_at' => $now,
                ]);
            }
        }
    }

    private function saveCompany(array $input, string $now): void
    {
        $db = db_connect();
        $data = [
            'residence_name' => trim((string) $input['company_name']),
            'address' => trim((string) ($input['company_address'] ?? '')),
            'phone' => trim((string) ($input['company_phone'] ?? '')),
            'developer' => trim((string) ($input['company_developer'] ?? '')),
            'email' => strtolower(trim((string) $input['admin_email'])),
            'active' => 1,
            'updated_at' => $now,
            'deleted_at' => null,
        ];
        $company = $db->table('companies')->orderBy('id', 'ASC')->get()->getRowArray();
        if ($company) {
            $db->table('companies')->where('id', $company['id'])->update($data);
        } else {
            $db->table('companies')->insert($data + ['created_at' => $now]);
        }
    }

    private function grantAdministratorAccess(): void
    {
        $db = db_connect();
        foreach ($db->table('menus')->select('id')->where('deleted_at', null)->get()->getResultArray() as $menu) {
            $existing = $db->table('role_menus')->where(['role_id' => 1, 'menu_id' => $menu['id']])->countAllResults();
            $rights = ['can_create' => 1, 'can_read' => 1, 'can_update' => 1, 'can_delete' => 1];
            if ($existing) {
                $db->table('role_menus')->where(['role_id' => 1, 'menu_id' => $menu['id']])->update($rights);
            } else {
                $db->table('role_menus')->insert(['role_id' => 1, 'menu_id' => $menu['id']] + $rights);
            }
        }
        foreach ($db->table('permissions')->select('id')->where('deleted_at', null)->get()->getResultArray() as $permission) {
            $existing = $db->table('role_permissions')->where([
                'role_id' => 1, 'permission_id' => $permission['id'],
            ])->countAllResults();
            $rights = ['can_create' => 1, 'can_read' => 1, 'can_update' => 1, 'can_delete' => 1];
            if ($existing) {
                $db->table('role_permissions')->where([
                    'role_id' => 1, 'permission_id' => $permission['id'],
                ])->update($rights);
            } else {
                $db->table('role_permissions')->insert([
                    'role_id' => 1, 'permission_id' => $permission['id'],
                ] + $rights);
            }
        }
    }
}
