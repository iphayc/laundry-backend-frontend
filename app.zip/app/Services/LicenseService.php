<?php

namespace App\Services;

class LicenseService
{
    public function machineId(): string
    {
        $machineId = '';

        if (PHP_OS_FAMILY === 'Windows' && function_exists('shell_exec')) {
            $output = (string) shell_exec(
                'reg.exe query "HKLM\SOFTWARE\Microsoft\Cryptography" /v MachineGuid 2>NUL'
            );

            if (preg_match('/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i', $output, $matches)) {
                $machineId = trim($matches[1]);
            }
        }

        if ($machineId === '') {
            $machineId = implode('|', array_filter([
                gethostname() ?: null,
                PHP_OS_FAMILY,
                php_uname('m'),
            ]));
        }

        return strtolower(trim($machineId));
    }

    public function machineFingerprint(?string $machineId = null): string
    {
        return hash('sha256', $machineId ?? $this->machineId());
    }

    public function activationCode(string $email, ?string $machineId = null): string
    {
        $payload = ($machineId ?? $this->machineId()) . '|' . strtolower(trim($email));
        $hash = strtoupper(hash('sha256', $payload));

        return implode('-', str_split(substr($hash, 0, 32), 8));
    }

    public function machineMatches(array $registration): bool
    {
        $stored = (string) ($registration['machine_id_hash'] ?? '');

        return $stored !== ''
            && hash_equals($stored, $this->machineFingerprint());
    }

    public function registrationIsValid(array $registration): bool
    {
        if (empty($registration['active']) || ! $this->machineMatches($registration)) {
            return false;
        }

        $email = (string) ($registration['registered_email'] ?? '');
        $storedCodeHash = (string) ($registration['license_code_hash'] ?? '');

        return $email !== ''
            && $storedCodeHash !== ''
            && password_verify($this->activationCode($email), $storedCodeHash);
    }
}
