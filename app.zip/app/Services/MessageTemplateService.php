<?php
namespace App\Services;

class MessageTemplateService
{
    public function render(string $content,array $resident): string
    {
        $name=trim((string)($resident['name']??''));
        $honorific=match($resident['gender']??null){'male'=>'Bapak','female'=>'Ibu',default=>''};
        $displayName=trim($honorific.' '.$name);
        return strtr($content,[
            '{{nama}}'=>$displayName,
            '{{nama_asli}}'=>$name,
            '{{sapaan}}'=>$honorific,
            '{{email}}'=>(string)($resident['email']??''),
            '{{telepon}}'=>(string)($resident['phone']??''),
            '{{unit}}'=>(string)($resident['unit_no']??''),
            '{{cluster}}'=>(string)($resident['cluster_name']??''),
            '{{tanggal}}'=>date('d-m-Y'),
        ]);
    }
}
