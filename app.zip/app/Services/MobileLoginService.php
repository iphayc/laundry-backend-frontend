<?php
namespace App\Services;
use App\Libraries\JwtService;
class MobileLoginService
{
 private $db;private JwtService $jwt;public function __construct(){$this->db=db_connect();$this->jwt=new JwtService();}
 public function password(array $data):array{$user=$this->user($data);if(!$user||!password_verify((string)($data['password']??''),$user['password']))throw new \RuntimeException('Identitas, username, atau password salah.');return $this->login($user,$data);}
 public function sendOtp(array $data):void{$user=$this->user($data);if(!$user)throw new \RuntimeException('Akun tidak ditemukan.');$key='login:'.$user['id'];$last=$this->db->table('ex_otps')->where('email',$key)->where('purpose','LOGIN')->orderBy('id','DESC')->get()->getRowArray();if($last&&time()-strtotime($last['created_at'])<60)throw new \RuntimeException('Tunggu 60 detik sebelum meminta OTP baru.');$this->db->table('ex_otps')->where('email',$key)->where('purpose','LOGIN')->where('consumed_at',null)->update(['consumed_at'=>date('Y-m-d H:i:s')]);$code=(string)random_int(100000,999999);$this->db->table('ex_otps')->insert(['email'=>$key,'purpose'=>'LOGIN','code_hash'=>password_hash($code,PASSWORD_DEFAULT),'expires_at'=>date('Y-m-d H:i:s',strtotime('+5 minutes')),'created_at'=>date('Y-m-d H:i:s')]);$message='Kode login Eksis Laundry: '.$code.'. Berlaku 5 menit.';$channel=strtoupper((string)($data['channel']??'EMAIL'));if($channel==='WHATSAPP'){$result=(new EksisWhatsAppGatewayService())->send((string)$user['phone'],$message);if(!$result['success'])throw new \RuntimeException('OTP WhatsApp gagal dikirim.');}elseif(!(new NotificationService())->email($user['email'],'Kode Login Eksis Laundry','<p>'.$message.'</p>'))throw new \RuntimeException('OTP email gagal dikirim.');}
 public function otp(array $data):array{$user=$this->user($data);if(!$user)throw new \RuntimeException('Akun tidak ditemukan.');$key='login:'.$user['id'];$row=$this->db->table('ex_otps')->where('email',$key)->where('purpose','LOGIN')->where('consumed_at',null)->orderBy('id','DESC')->get()->getRowArray();$valid=$row&&strtotime($row['expires_at'])>=time()&&(int)$row['attempts']<5&&password_verify((string)($data['otp']??''),$row['code_hash']);if(!$valid){if($row)$this->db->table('ex_otps')->where('id',$row['id'])->set('attempts','attempts+1',false)->update();throw new \RuntimeException('OTP tidak valid atau sudah kedaluwarsa.');}$this->db->table('ex_otps')->where('id',$row['id'])->update(['verified_at'=>date('Y-m-d H:i:s'),'consumed_at'=>date('Y-m-d H:i:s')]);return $this->login($user,$data);}

 public function requestDeviceTransfer(array $data):array
 {
  $user=$this->user($data);
  if(!$user) throw new \RuntimeException('Identitas, username, atau akun tidak ditemukan.');
  if(strtoupper((string)$user['role'])!=='OWNER') throw new \RuntimeException('Pindah perangkat hanya dapat dilakukan oleh Owner.');

  $branchId=(int)($user['branch_id']??0);
  if($branchId<=0) throw new \RuntimeException('Owner belum memiliki cabang aktif.');

  $uuid=trim((string)($data['device_uuid']??''));
  if($uuid==='') throw new \InvalidArgumentException('Device UUID wajib diisi.');

  $license=(new EntitlementService())->current((int)$user['company_id']);
  if(!$license||!in_array($license['status'],['ACTIVE','TRIAL'],true))
    throw new \RuntimeException('Lisensi tidak aktif.');

  $quota=$this->deviceQuota($license);
  $active=$this->activeDevices((int)$user['company_id']);

  if(count($active)<$quota)
    throw new \RuntimeException('Slot perangkat masih tersedia. Silakan login kembali.');

  $replaceId=(int)($data['replace_device_id']??0);
  if($replaceId<=0)
    return ['devices'=>$active,'requires_device_selection'=>true];

  $old=$this->findReplaceableDevice((int)$user['company_id'],$branchId,$replaceId);
  if(!$old) throw new \RuntimeException('Perangkat yang akan diganti tidak ditemukan atau bukan perangkat aktif pada cabang Anda.');

  $email=strtolower(trim((string)$user['email']));
  (new OtpService())->send($email,'DEVICE_TRANSFER');

  return ['devices'=>$active,'requires_device_selection'=>false];
 }

 public function confirmDeviceTransfer(array $data):array
 {
  $user=$this->user($data);
  if(!$user) throw new \RuntimeException('Identitas, username, atau akun tidak ditemukan.');
  if(strtoupper((string)$user['role'])!=='OWNER') throw new \RuntimeException('Pindah perangkat hanya dapat dilakukan oleh Owner.');

  $branchId=(int)($user['branch_id']??0);
  if($branchId<=0) throw new \RuntimeException('Owner belum memiliki cabang aktif.');

  $uuid=trim((string)($data['device_uuid']??''));
  if($uuid==='') throw new \InvalidArgumentException('Device UUID wajib diisi.');

  $license=(new EntitlementService())->current((int)$user['company_id']);
  if(!$license||!in_array($license['status'],['ACTIVE','TRIAL'],true))
    throw new \RuntimeException('Lisensi tidak aktif.');

  $quota=$this->deviceQuota($license);
  $replaceId=(int)($data['replace_device_id']??0);
  if($replaceId<=0) throw new \InvalidArgumentException('Perangkat yang akan diganti wajib dipilih.');

  $old=$this->findReplaceableDevice((int)$user['company_id'],$branchId,$replaceId);
  if(!$old) throw new \RuntimeException('Perangkat yang akan diganti tidak ditemukan atau bukan perangkat aktif pada cabang Anda.');

  $email=strtolower(trim((string)$user['email']));
  (new OtpService())->consume($email,'DEVICE_TRANSFER',(string)($data['otp']??''));

  $activeCount=(int)$this->db->table('ex_devices')
    ->where('company_id',$user['company_id'])
    ->where('status','ACTIVE')
    ->where('deleted_at',null)
    ->countAllResults();

  if($activeCount>$quota)
    throw new \RuntimeException('Jumlah perangkat aktif melebihi batas paket. Hubungi administrator.');

  $now=date('Y-m-d H:i:s');
  $db=$this->db;
  $db->transBegin();

  try {
    // Replace exactly the selected device, not every device owned by the Owner.
    $db->table('ex_devices')->where('id',$old['id'])->update([
      'status'=>'REPLACED',
      'updated_at'=>$now
    ]);

    // If this phone was previously known, reuse its history row.
    $new=$db->table('ex_devices')
      ->where('company_id',$user['company_id'])
      ->where('device_uuid',$uuid)
      ->where('deleted_at',null)
      ->get()->getRowArray();

    if($new && (int)$new['id']===(int)$old['id'])
      throw new \RuntimeException('Perangkat baru tidak boleh sama dengan perangkat yang diganti.');

    if($new){
      if($new['status']==='ACTIVE')
        throw new \RuntimeException('Perangkat ini sudah aktif.');

      $db->table('ex_devices')->where('id',$new['id'])->update([
        'branch_id'=>(int)($old['branch_id']??$branchId),
        'device_name'=>$data['device_name']??null,
        'platform'=>$data['platform']??null,
        'app_version'=>$data['app_version']??null,
        'status'=>'ACTIVE',
        'last_login_at'=>$now,
        'updated_at'=>$now
      ]);
      $deviceId=(int)$new['id'];
    }else{
      $db->table('ex_devices')->insert([
        'company_id'=>$user['company_id'],
        'branch_id'=>(int)($old['branch_id']??$branchId),
        'device_uuid'=>$uuid,
        'device_name'=>$data['device_name']??null,
        'platform'=>$data['platform']??null,
        'app_version'=>$data['app_version']??null,
        'status'=>'ACTIVE',
        'last_login_at'=>$now,
        'created_at'=>$now,
        'updated_at'=>$now
      ]);
      $deviceId=(int)$db->insertID();
    }

    // Only sessions on the replaced device are revoked. Other active devices
    // belonging to the same Owner remain usable.
    $db->table('ex_user_tokens')
      ->where('device_id',$old['id'])
      ->where('revoked_at',null)
      ->update(['revoked_at'=>$now]);

    $refresh=$this->jwt->refreshToken();
    $db->table('ex_user_tokens')->insert([
      'user_id'=>$user['id'],
      'device_id'=>$deviceId,
      'token_hash'=>hash('sha256',$refresh),
      'expires_at'=>'9999-12-31 23:59:59',
      'created_at'=>$now
    ]);

    $db->table('ex_users')->where('id',$user['id'])->update([
      'last_login'=>$now,
      'updated_at'=>$now
    ]);

    $db->table('ex_logs')->insert([
      'company_id'=>$user['company_id'],
      'user_id'=>$user['id'],
      'action'=>'DEVICE_TRANSFER',
      'module'=>'AUTH',
      'reference_id'=>$deviceId,
      'ip_address'=>service('request')->getIPAddress(),
      'metadata'=>json_encode([
        'replaced_device_id'=>(int)$old['id'],
        'new_device_id'=>$deviceId,
        'branch_id'=>$branchId
      ]),
      'created_at'=>$now
    ]);

    if(!$db->transStatus()) throw new \RuntimeException('Pindah perangkat gagal.');
    $db->transCommit();

    return [
      'access_token'=>$this->jwt->accessToken($user),
      'refresh_token'=>$refresh,
      'token_type'=>'Bearer',
      'expires_in'=>900,
      'user'=>[
        'id'=>(int)$user['id'],
        'company_id'=>(int)$user['company_id'],
        'fullname'=>$user['fullname'],
        'email'=>$user['email'],
        'role'=>$user['role']
      ],
      'device'=>[
        'registered'=>true,
        'device_uuid'=>$uuid,
        'device_name'=>$data['device_name']??null,
        'replaced_device_id'=>(int)$old['id']
      ]
    ];
  }catch(\Throwable $e){
    $db->transRollback();
    throw $e;
  }
 }

 private function deviceQuota(array $license):int
 {
  return max(1,(int)($license['device_limit']??0));
 }

 private function activeDevices(int $companyId):array
 {
  return $this->db->table('ex_devices d')
    ->select('d.id,d.device_uuid,d.device_name,d.platform,d.os_version,d.app_version,d.branch_id,b.name branch_name,d.status,d.last_login_at,d.created_at')
    ->join('ex_branches b','b.id=d.branch_id','left')
    ->where('d.company_id',$companyId)
    ->where('d.status','ACTIVE')
    ->where('d.deleted_at',null)
    ->orderBy('d.last_login_at','DESC')
    ->orderBy('d.id','DESC')
    ->get()->getResultArray();
 }

 private function findReplaceableDevice(int $companyId,int $branchId,int $deviceId):?array
 {
  return $this->db->table('ex_devices d')
    ->select('d.*,b.name branch_name')
    ->join('ex_branches b','b.id=d.branch_id','left')
    ->where('d.id',$deviceId)
    ->where('d.company_id',$companyId)
    ->where('d.status','ACTIVE')
    ->where('d.deleted_at',null)
    ->get()->getRowArray()?:null;
 }

 private function user(array $data):?array{$identity=strtolower(trim((string)($data['identity']??'')));$username=strtolower(trim((string)($data['username']??'')));$phone=preg_replace('/\D/','',$identity);if($identity===''||$username==='')return null;$builder=$this->db->table('ex_users u')->select('u.*')->join('ex_companies c','c.id=u.company_id')->where('LOWER(u.username)',$username)->where('u.is_active',1)->where('u.deleted_at',null)->where('c.status','ACTIVE')->where('c.deleted_at',null)->groupStart()->where('LOWER(c.email)',$identity)->orWhere('c.phone',$phone);if(str_starts_with($phone,'0'))$builder->orWhere('c.phone','62'.substr($phone,1));return $builder->groupEnd()->get()->getRowArray()?:null;}
 private function login(array $user,array $data):array
 {
  $license=(new EntitlementService())->current((int)$user['company_id']);
  $fresh=$this->db->table('ex_users')->where('id',$user['id'])->where('is_active',1)->where('deleted_at',null)->get()->getRowArray();
  if(!$fresh)throw new \RuntimeException('Akun dinonaktifkan karena paket berlangganan telah berakhir.');
  $user=$fresh;
  if(!empty($license['branch_selection_required'])&&($user['role']??'')!=='OWNER')throw new \RuntimeException('Owner harus memilih cabang yang dinonaktifkan setelah downgrade paket sebelum kasir dapat login.');

  $uuid=trim((string)($data['device_uuid']??''));
  if($uuid==='')throw new \RuntimeException('Device UUID wajib diisi.');

  $branchId=(int)($user['branch_id']??0);
  if($branchId<=0)throw new \RuntimeException('User belum memiliki cabang aktif. Hubungi administrator.');
  $branchActive=$this->db->table('ex_branches')->where('id',$branchId)->where('company_id',$user['company_id'])->where('is_active',1)->where('deleted_at',null)->countAllResults();
  if(!$branchActive)throw new \RuntimeException('Cabang user tidak aktif. Hubungi owner untuk memilih paket atau mengaktifkan cabang.');

  $device=$this->db->table('ex_devices')
    ->where('company_id',$user['company_id'])
    ->where('device_uuid',$uuid)
    ->where('deleted_at',null)
    ->get()->getRowArray();

  if($device&&$device['status']==='DISABLED'){
    if(in_array($device['disabled_reason']??null,['LICENSE_EXPIRED','LICENSE_LIMIT'],true))
      throw new \RuntimeException('Device dinonaktifkan karena batas paket. Gunakan device aktif atau upgrade paket.');
    throw new \RuntimeException('Device dinonaktifkan. Hubungi administrator.');
  }

  if($device&&$device['status']==='ACTIVE'&&(int)$device['branch_id']===$branchId){
    $this->touchDevice($device,$data);
    return $this->issueTokens($user,(int)$device['id']);
  }

  /*
   * Uninstall Android menghapus SecureStore sehingga aplikasi membuat UUID
   * baru. Jika tepat satu perangkat aktif pada cabang yang sama mempunyai
   * nama dan platform identik, perlakukan sebagai instalasi ulang pada HP
   * tersebut, bukan perangkat tambahan. Kondisi "tepat satu" mencegah salah
   * rebind bila perusahaan memiliki dua HP dengan nama/model yang sama.
   */
  if(!$device){
    $deviceName=trim((string)($data['device_name']??''));
    $platform=strtolower(trim((string)($data['platform']??'')));
    if($deviceName!==''&&$platform!==''){
      $matches=$this->db->table('ex_devices')
        ->where('company_id',$user['company_id'])
        ->where('branch_id',$branchId)
        ->where('status','ACTIVE')
        ->where('deleted_at',null)
        ->where('device_name',$deviceName)
        ->where('platform',$platform)
        ->get()->getResultArray();
      if(count($matches)===1){
        $reinstalled=$matches[0];$now=date('Y-m-d H:i:s');
        $this->db->transStart();
        $this->db->table('ex_user_tokens')->where('device_id',$reinstalled['id'])->where('revoked_at',null)->update(['revoked_at'=>$now]);
        $this->db->table('ex_devices')->where('id',$reinstalled['id'])->update([
          'device_uuid'=>$uuid,'device_name'=>$deviceName,'platform'=>$platform,
          'app_version'=>$data['app_version']??null,'last_login_at'=>$now,'updated_at'=>$now
        ]);
        $this->db->table('ex_logs')->insert([
          'company_id'=>$user['company_id'],'user_id'=>$user['id'],'action'=>'DEVICE_REINSTALL',
          'module'=>'AUTH','reference_id'=>$reinstalled['id'],'ip_address'=>service('request')->getIPAddress(),
          'metadata'=>json_encode(['old_device_uuid'=>$reinstalled['device_uuid'],'new_device_uuid'=>$uuid,'device_name'=>$deviceName]),
          'created_at'=>$now
        ]);
        $this->db->transComplete();
        if(!$this->db->transStatus())throw new \RuntimeException('Identitas perangkat gagal diperbarui.');
        return $this->issueTokens($user,(int)$reinstalled['id']);
      }
    }
  }

  $quota=$this->deviceQuota($license?:[]);
  $activeCount=(int)$this->db->table('ex_devices')
    ->where('company_id',$user['company_id'])
    ->where('status','ACTIVE')
    ->where('deleted_at',null)
    ->countAllResults();

  if($activeCount >= $quota){
    $devices=$this->activeDevices((int)$user['company_id']);
    throw new \RuntimeException(
      'DEVICE_LIMIT_REACHED|Batas perangkat pada paket Anda sudah penuh. Pilih perangkat yang hilang atau diganti untuk memindahkan slot ke HP ini.|'.base64_encode(json_encode($devices))
    );
  }

  // A device may only be active on the branch associated with its current user.
  $saved=[
    'branch_id'=>$branchId,
    'device_name'=>$data['device_name']??null,
    'platform'=>$data['platform']??null,
    'app_version'=>$data['app_version']??null,
    'status'=>'ACTIVE',
    'last_login_at'=>date('Y-m-d H:i:s'),
    'updated_at'=>date('Y-m-d H:i:s')
  ];

  if($device){
    $this->db->table('ex_devices')->where('id',$device['id'])->update($saved);
    $deviceId=(int)$device['id'];
  }else{
    $this->db->table('ex_devices')->insert($saved+[
      'company_id'=>$user['company_id'],
      'device_uuid'=>$uuid,
      'created_at'=>date('Y-m-d H:i:s')
    ]);
    $deviceId=(int)$this->db->insertID();
  }

  return $this->issueTokens($user,$deviceId);
 }

 private function touchDevice(array $device,array $data):void
 {
  $this->db->table('ex_devices')->where('id',$device['id'])->update([
    'device_name'=>$data['device_name']??$device['device_name'],
    'platform'=>$data['platform']??$device['platform'],
    'app_version'=>$data['app_version']??$device['app_version'],
    'last_login_at'=>date('Y-m-d H:i:s'),
    'updated_at'=>date('Y-m-d H:i:s')
  ]);
 }

 private function issueTokens(array $user,int $deviceId):array
 {
  $refresh=$this->jwt->refreshToken();
  $this->db->table('ex_user_tokens')->insert([
    'user_id'=>$user['id'],
    'device_id'=>$deviceId,
    'token_hash'=>hash('sha256',$refresh),
    'expires_at'=>'9999-12-31 23:59:59',
    'created_at'=>date('Y-m-d H:i:s')
  ]);

  return [
    'access_token'=>$this->jwt->accessToken($user),
    'refresh_token'=>$refresh,
    'token_type'=>'Bearer',
    'expires_in'=>900,
    'user'=>[
      'id'=>(int)$user['id'],
      'company_id'=>(int)$user['company_id'],
      'fullname'=>$user['fullname'],
      'email'=>$user['email'],
      'role'=>$user['role']
    ]
  ];
 }

}
