<?php
namespace App\Services;

use App\Models\NotificationModel;

class NotificationService
{
    private ?string $lastError = null;

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    public function email(
    string|array $to,
    string $subject,
    string $message,
    ?string $attachment = null,
    string|array $cc = [],
    ?int $retryLogId = null
    ): bool {
        $this->lastError = null;

        $logId = null;

        try {

            /*
            * ============================================================
            * 1. PREPARE RECIPIENT
            * ============================================================
            */
            $recipient = is_array($to)
                ? implode(', ', $to)
                : $to;

            $ccText = is_array($cc)
                ? implode(', ', $cc)
                : $cc;


            /*
            * ============================================================
            * 2. START LOG
            * ============================================================
            */
            $logId = $this->startLog(
                $retryLogId,
                [
                    'channel'        => 'email',
                    'recipient'      => $recipient,
                    'cc'             => $ccText ?: null,
                    'subject'        => $subject,
                    'message'        => $message,
                    'attachment_path'=> $attachment,
                ]
            );


            /*
            * ============================================================
            * 3. GET SMTP CONFIGURATION
            * ============================================================
            */
            $row = db_connect()
                ->table('email_smtp_settings')
                ->where('active', 1)
                ->where('deleted_at', null)
                ->orderBy('is_default', 'DESC')
                ->orderBy('id', 'DESC')
                ->get()
                ->getRowArray();

            if (!$row) {

                $error = 'Konfigurasi SMTP aktif tidak ditemukan.';

                $this->lastError = $error;

                log_message('error', 'Email gagal: ' . $error);

                if ($logId) {
                    $this->finishLog($logId, false, $error);
                }

                return false;
            }


            /*
            * ============================================================
            * 4. DECRYPT SMTP PASSWORD
            * ============================================================
            */
            $password = '';

            if (!empty($row['smtp_password_encrypted'])) {

                try {

                    $password = service('encrypter')->decrypt(
                        base64_decode($row['smtp_password_encrypted'])
                    );

                } catch (\Throwable $e) {

                    $error = 'Dekripsi password SMTP gagal: ' . $e->getMessage();

                    $this->lastError = $error;

                    log_message('error', $error);

                    if ($logId) {
                        $this->finishLog($logId, false, $error);
                    }

                    return false;
                }
            }


            /*
            * ============================================================
            * 5. CONFIGURE EMAIL
            * ============================================================
            */
            $email = service('email');

            $email->clear(true);

            $email->initialize([
                'protocol'   => 'smtp',
                'SMTPHost'   => $row['smtp_host'],
                'SMTPPort'   => (int) $row['smtp_port'],
                'SMTPUser'   => $row['smtp_user'] ?? '',
                'SMTPPass'   => $password,
                'SMTPCrypto' => ($row['smtp_crypto'] ?? 'none') === 'none'
                    ? ''
                    : $row['smtp_crypto'],
                'mailType'   => 'html',
                'charset'    => 'UTF-8',
                'newline'    => "\r\n",
                'CRLF'       => "\r\n",
                'SMTPTimeout'=> 12,
            ]);


            /*
            * ============================================================
            * 6. SET EMAIL
            * ============================================================
            */
            $email->setFrom(
                $row['from_email'],
                $row['from_name'] ?? ''
            );

            $email->setTo($to);

            $email->setSubject($subject);

            $email->setMessage($message);

            if (!empty($cc)) {
                $email->setCC($cc);
            }

            if (!empty($attachment)) {
                $email->attach($attachment);
            }


            /*
            * ============================================================
            * 7. SEND EMAIL
            * ============================================================
            */
            $ok = false;
            $error = null;
            $maxAttempts = 2;
            for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
                try {
                    $ok = $email->send(false);
                    $error = $ok ? null : strip_tags((string) $email->printDebugger());
                } catch (\Throwable $e) {
                    $ok = false;
                    $error = $e->getMessage();
                }
                if ($ok) break;
                log_message('error', 'SMTP attempt {attempt}/{max} gagal: {message}', [
                    'attempt' => $attempt, 'max' => $maxAttempts,
                    'message' => mb_substr(trim((string) $error), 0, 2000),
                ]);
                if ($attempt < $maxAttempts) usleep(750000);
            }


            /*
            * ============================================================
            * 8. HANDLE SEND RESULT
            * ============================================================
            */
            if (!$ok) {

                $this->lastError = mb_substr(
                    trim((string) $error),
                    0,
                    2000
                );

                log_message(
                    'error',
                    'Email gagal: ' . $this->lastError
                );
            }


            /*
            * ============================================================
            * 9. UPDATE LOG
            * ============================================================
            */
            if ($logId) {
                $this->finishLog(
                    $logId,
                    $ok,
                    $error
                );
            }

            return (bool) $ok;


        } catch (\Throwable $e) {

            /*
            * ============================================================
            * GLOBAL ERROR HANDLER
            * ============================================================
            */

            $error = $e->getMessage();

            $this->lastError = mb_substr(
                trim($error),
                0,
                2000
            );

            log_message(
                'error',
                'NotificationService Email Exception: {message} in {file}:{line}',
                [
                    'message' => $error,
                    'file'    => $e->getFile(),
                    'line'    => $e->getLine(),
                ]
            );


            /*
            * Jangan sampai error logging malah
            * menghasilkan exception kedua.
            */
            if ($logId) {

                try {

                    $this->finishLog(
                        $logId,
                        false,
                        $error
                    );

                } catch (\Throwable $logException) {

                    log_message(
                        'error',
                        'Gagal update notification log: {message}',
                        [
                            'message' => $logException->getMessage(),
                        ]
                    );
                }
            }

            return false;
        }
    }
    public function queue(?int $visitId,string $type,string $title,string $message,string $channels='popup'): int
    {
        return (int)(new NotificationModel())->insert(['visit_id'=>$visitId,'type'=>$type,'title'=>$title,'message'=>$message,'channel'=>$channels,'status'=>'pending']);
    }

    private function startLog(?int $id,array $data): int
    {
        $db=db_connect();$now=date('Y-m-d H:i:s');
        if($id){$row=$db->table('notification_logs')->select('attempt_count')->where('id',$id)->get()->getRowArray();$db->table('notification_logs')->where('id',$id)->update($data+['status'=>'failed','error_message'=>null,'attempt_count'=>(int)($row['attempt_count']??0)+1,'last_attempt_at'=>$now,'updated_at'=>$now]);return $id;}
        $db->table('notification_logs')->insert($data+['status'=>'failed','attempt_count'=>1,'last_attempt_at'=>$now,'created_by'=>session('user_id')?:null,'created_at'=>$now]);return (int)$db->insertID();
    }

    private function finishLog(int $id,bool $ok,?string $error=null): void
    {
        db_connect()->table('notification_logs')->where('id',$id)->update(['status'=>$ok?'sent':'failed','error_message'=>$ok?null:mb_substr((string)$error,0,65000),'sent_at'=>$ok?date('Y-m-d H:i:s'):null,'sent_date'=>$ok?date('Y-m-d'):null,'updated_at'=>date('Y-m-d H:i:s')]);
    }
}
