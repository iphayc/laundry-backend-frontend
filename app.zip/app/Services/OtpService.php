<?php
namespace App\Services;
class OtpService
{
 private $db;public function __construct(){$this->db=db_connect();}
 public function send(string $email,string $purpose):void{
  $email=strtolower(trim($email));
  if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new \InvalidArgumentException('Format email tidak valid.');
  if(!in_array($purpose,['REGISTER','RESET_PASSWORD','DEVICE_TRANSFER'],true))throw new \InvalidArgumentException('Tujuan OTP tidak valid.');
  if($purpose==='REGISTER'&&$this->db->table('ex_users')->where('email',$email)->where('deleted_at',null)->countAllResults())throw new \InvalidArgumentException('Email sudah digunakan.');
  if($purpose==='RESET_PASSWORD'&&!$this->db->table('ex_users')->where('email',$email)->where('deleted_at',null)->countAllResults())return;
  $last=$this->db->table('ex_otps')->where('email',$email)->where('purpose',$purpose)->orderBy('id','DESC')->get()->getRowArray();
  if($last&&time()-strtotime($last['created_at'])<60)throw new \RuntimeException('Tunggu 60 detik sebelum meminta OTP baru.');
  $now=date('Y-m-d H:i:s');$code=(string)random_int(100000,999999);
  $this->db->table('ex_otps')->insert(['email'=>$email,'purpose'=>$purpose,'code_hash'=>password_hash($code,PASSWORD_DEFAULT),'expires_at'=>date('Y-m-d H:i:s',strtotime('+5 minutes')),'created_at'=>$now]);
  $otpId=(int)$this->db->insertID();
  $title=$purpose==='REGISTER'?'Verifikasi Pendaftaran Eksis Laundry':($purpose==='DEVICE_TRANSFER'?'Verifikasi Pindah Perangkat Eksis Laundry':'Reset Password Eksis Laundry');
  $body='<div style="font-family:Arial;max-width:520px"><h2>'.$title.'</h2><p>Kode OTP Anda:</p><div style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#168a72">'.$code.'</div><p>Kode berlaku selama <strong>5 menit</strong> dan hanya dapat digunakan satu kali.</p></div>';
  if(!(new NotificationService())->email($email,$title,$body)){$this->db->table('ex_otps')->where('id',$otpId)->delete();throw new \RuntimeException('OTP gagal dikirim. Periksa konfigurasi SMTP.');}
  // OTP baru baru menjadi aktif setelah email benar-benar berhasil diserahkan.
  $this->db->table('ex_otps')->where('email',$email)->where('purpose',$purpose)->where('consumed_at',null)->where('id !=',$otpId)->update(['consumed_at'=>$now]);
 }
 public function consume(string $email,string $purpose,string $code):void{$email=strtolower(trim($email));$row=$this->db->table('ex_otps')->where('email',$email)->where('purpose',$purpose)->where('consumed_at',null)->orderBy('id','DESC')->get()->getRowArray();if(!$row||strtotime($row['expires_at'])<time())throw new \InvalidArgumentException('OTP tidak valid atau sudah kedaluwarsa.');if((int)$row['attempts']>=5)throw new \InvalidArgumentException('Batas percobaan OTP terlampaui. Minta kode baru.');if(!password_verify($code,$row['code_hash'])){$this->db->table('ex_otps')->where('id',$row['id'])->set('attempts','attempts+1',false)->update();throw new \InvalidArgumentException('OTP tidak valid atau sudah kedaluwarsa.');}$this->db->table('ex_otps')->where('id',$row['id'])->update(['verified_at'=>date('Y-m-d H:i:s'),'consumed_at'=>date('Y-m-d H:i:s')]);}
}
