<?php

namespace App\Services;

class PasswordPolicy
{
    public const MIN_LENGTH = 12;

    public function validate(string $password): ?string
    {
        if (strlen($password) < self::MIN_LENGTH) {
            return 'Password minimal ' . self::MIN_LENGTH . ' karakter.';
        }
        if (! preg_match('/[A-Z]/', $password)
            || ! preg_match('/[a-z]/', $password)
            || ! preg_match('/\d/', $password)
            || ! preg_match('/[^A-Za-z0-9]/', $password)) {
            return 'Password harus mengandung huruf besar, huruf kecil, angka, dan simbol.';
        }

        return null;
    }
}
