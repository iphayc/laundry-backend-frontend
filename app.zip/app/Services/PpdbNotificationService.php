<?php
namespace App\Services;

class PpdbNotificationService
{
    public function send(int $registrationId,string $event,string $detail=''):void
    {
        $row=db_connect()->table('ppdb_registrations r')->select('r.registration_no,r.full_name,r.parent_phone,r.parent_email,u.email account_email,u.phone account_phone')->join('users u','u.id=r.parent_user_id','left')->where('r.id',$registrationId)->get()->getRowArray();if(!$row)return;
        $labels=['registered'=>'Pendaftaran berhasil dibuat','payment_uploaded'=>'Bukti pembayaran berhasil diunggah','payment_verified'=>'Pembayaran telah diverifikasi','form_returned'=>'Formulir telah dikembalikan','accepted'=>'Calon siswa dinyatakan diterima','rejected'=>'Calon siswa dinyatakan belum diterima','waiting_list'=>'Calon siswa masuk daftar tunggu'];$label=$labels[$event]??'Status PPDB diperbarui';
        $message=$label."\nNo. Pendaftaran: ".$row['registration_no']."\nNama: ".$row['full_name'].($detail!==''?"\n".$detail:'');$email=$row['parent_email']?:$row['account_email'];$phone=$row['parent_phone']?:$row['account_phone'];
        try{if($email)(new NotificationService())->email($email,'Update PPDB - '.$row['registration_no'],nl2br(esc($message)));}catch(\Throwable $e){log_message('error','PPDB email notification: '.$e->getMessage());}
        try{if($phone)(new WhatsAppService())->send($phone,$message,null,'Update PPDB');}catch(\Throwable $e){log_message('error','PPDB WhatsApp notification: '.$e->getMessage());}
    }
}
