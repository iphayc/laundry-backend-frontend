<?php
namespace App\Services;

class WhatsAppService
{
    public function send(string $to,string $message,?int $retryLogId=null,?string $subject=null): array
    {
        return $this->request('text',$to,$message,null,$retryLogId,$subject);
    }

    public function sendImage(string $to,string $imageUrl,string $caption='',?int $retryLogId=null,?string $subject=null): array
    {
        return $this->request('image',$to,$caption,$imageUrl,$retryLogId,$subject);
    }

    public function sendBulkAnnouncement(array $recipients,string $subject,string $message,?string $imageUrl=null): array
    {
        if(!$recipients||count($recipients)>20)throw new \InvalidArgumentException('Penerima WhatsApp harus berjumlah 1 sampai 20.');
        $sent=0;$failed=0;$details=[];
        foreach($recipients as $recipient){
            $phone=(string)($recipient['phone']??'');$result=$imageUrl?$this->sendImage($phone,$imageUrl,$message,null,$subject):$this->send($phone,$message,null,$subject);
            $result['recipient_name']=$recipient['name']??null;$result['phone']=$phone;$details[]=$result;$result['success']?$sent++:$failed++;
        }
        return compact('sent','failed','details');
    }

    private function request(string $type,string $to,string $message,?string $imageUrl=null,?int $retryLogId=null,?string $subject=null): array
    {
        $logId=$this->startLog($retryLogId,$to,$message,$imageUrl,$subject);
        $db=db_connect();
        $row=$db->table('whatsapp_providers')->where('is_default',1)->where('active',1)->where('deleted_at',null)->orderBy('id','DESC')->get()->getRowArray();
        if(!$row){$result=['success'=>false,'message'=>'WhatsApp provider default aktif belum tersedia'];$this->finishLog($logId,$result);return $result;}
        $provider=strtolower((string)($row['code']??'custom'));
        $authType=(string)($row['auth_type']??'custom');
        $url=$type==='image'?($row['default_url_image']??null):($row['default_url_text']??null);
        if($authType==='meta_official'){
            $version=trim((string)($row['graph_version']??'v25.0'),'/ ');
            $url='https://graph.facebook.com/'.$version.'/'.trim((string)$row['phone_number_id']).'/messages';
        }
        if($provider==='fonnte'&&!$url)$url=$row['default_url_text'];
        if(!$url){$result=['success'=>false,'message'=>'URL pengiriman '.$type.' belum dikonfigurasi'];$this->finishLog($logId,$result);return $result;}
        $apiKey='';
        if($row['api_key_encrypted']){
            try{$apiKey=service('encrypter')->decrypt(base64_decode($row['api_key_encrypted']));}
            catch(\Throwable $e){$result=['success'=>false,'message'=>'API key WhatsApp tidak dapat didekripsi'];$this->finishLog($logId,$result);return $result;}
        }
        $token='';
        if(!empty($row['token_encrypted'])){
            try{$token=trim(service('encrypter')->decrypt(base64_decode($row['token_encrypted'])));}
            catch(\Throwable $e){$result=['success'=>false,'message'=>'Token WhatsApp tidak dapat didekripsi'];$this->finishLog($logId,$result);return $result;}
        }
        if($provider==='custom'){
            if($token!==''&&$apiKey==='')$provider='fonnte';
            elseif($apiKey!==''&&!empty($row['key_number']))$provider='watzap';
        }
        $to=preg_replace('/\D/','',$to?:($row['phone_number']??''));
        if(str_starts_with($to,'0'))$to='62'.substr($to,1);

        if(in_array($authType,['token','meta_official'],true)&&$token===''){
            $result=['success'=>false,'message'=>'Token provider WhatsApp belum dikonfigurasi'];$this->finishLog($logId,$result);return $result;
        }
        if($authType==='api_key_number_key'&&($apiKey===''||empty($row['number_key']))){
            $result=['success'=>false,'message'=>'API Key atau Number Key Watzap belum dikonfigurasi'];$this->finishLog($logId,$result);return $result;
        }

        try{
            if($authType==='meta_official'){
                $result=$this->requestMeta($url,$token,$to,$message,$imageUrl);
                $this->finishLog($logId,$result);
                return $result;
            }elseif($provider==='fonnte'||$authType==='token'){
                $result=$this->requestFonnte($url,$token,$to,$message,$imageUrl);
                $this->finishLog($logId,$result);
                return $result;
            }elseif($provider==='watzap'||$authType==='api_key_number_key'){
                $result=$this->requestWatzap($url,$apiKey,(string)$row['number_key'],$to,$message,$imageUrl);
                $this->finishLog($logId,$result);
                return $result;
            }else{
                $payload=['api_key'=>$apiKey,'key_number'=>$row['number_key'],'phone'=>$to,'message'=>$message];
                if($imageUrl)$payload['image_url']=$imageUrl;
                $options=[
                    'headers'=>['X-API-Key'=>$apiKey,'Authorization'=>'Bearer '.$apiKey,'Accept'=>'application/json'],
                    'json'=>$payload,'http_errors'=>false,'timeout'=>20,
                ];
            }

            $response=service('curlrequest')->post($url,$options);
            $body=(string)$response->getBody();
            $decoded=json_decode($body,true);
            $success=$response->getStatusCode()>=200&&$response->getStatusCode()<300;
            if(is_array($decoded)){
                if(array_key_exists('success',$decoded)&&$decoded['success']===false)$success=false;
                if(array_key_exists('status',$decoded)&&in_array($decoded['status'],[false,0,'0','false','failed','error'],true))$success=false;
            }
            $result=['success'=>$success,'status'=>$response->getStatusCode(),'body'=>$body,'provider'=>$provider];
            if(!$success&&is_array($decoded)){
                $providerMessage=$decoded['message']??$decoded['reason']??$decoded['error']??null;
                if($providerMessage!==null)$result['message']=is_scalar($providerMessage)?(string)$providerMessage:json_encode($providerMessage);
            }
            $this->finishLog($logId,$result);return $result;
        }catch(\Throwable $e){log_message('error','WhatsApp: '.$e->getMessage());$result=['success'=>false,'message'=>$e->getMessage()];$this->finishLog($logId,$result);return $result;}
    }

    private function requestFonnte(string $url,string $token,string $target,string $message,?string $imageUrl=null): array
    {
        if(!function_exists('curl_init'))return ['success'=>false,'message'=>'Ekstensi PHP cURL tidak tersedia','provider'=>'fonnte'];
        $fields=[
            'target'=>$target,
            'message'=>$message,
            'countryCode'=>'62',
        ];
        if($imageUrl){
            $imageUrl=trim($imageUrl);
            if(!$this->isPublicMediaUrl($imageUrl)){
                return ['success'=>false,'message'=>'URL gambar harus berupa URL HTTP/HTTPS publik dan tidak boleh memakai localhost atau IP jaringan lokal.','provider'=>'fonnte'];
            }
            $fields['url']=$imageUrl;
        }
        $curl=curl_init();
        curl_setopt_array($curl,[
            CURLOPT_URL=>$url,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_ENCODING=>'',
            CURLOPT_MAXREDIRS=>10,
            CURLOPT_TIMEOUT=>20,
            CURLOPT_CONNECTTIMEOUT=>10,
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST=>'POST',
            CURLOPT_POSTFIELDS=>$fields,
            CURLOPT_HTTPHEADER=>['Authorization: '.$token,'Accept: application/json'],
        ]);
        $body=curl_exec($curl);
        $curlError=curl_error($curl);
        $status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);
        curl_close($curl);
        if($body===false)return ['success'=>false,'status'=>$status?:null,'message'=>$curlError?:'Fonnte tidak memberikan respons','provider'=>'fonnte'];
        $decoded=json_decode((string)$body,true);
        $success=$status>=200&&$status<300;
        if(is_array($decoded)){
            if(array_key_exists('status',$decoded)&&in_array($decoded['status'],[false,0,'0','false','failed','error'],true))$success=false;
            if(array_key_exists('success',$decoded)&&$decoded['success']===false)$success=false;
        }
        $result=['success'=>$success,'status'=>$status,'body'=>(string)$body,'provider'=>'fonnte'];
        if(!$success&&is_array($decoded)){
            $providerMessage=$decoded['message']??$decoded['reason']??$decoded['error']??null;
            if($providerMessage!==null)$result['message']=is_scalar($providerMessage)?(string)$providerMessage:json_encode($providerMessage);
        }
        return $result;
    }

    private function requestMeta(string $url,string $accessToken,string $to,string $message,?string $imageUrl=null): array
    {
        if(!function_exists('curl_init'))return ['success'=>false,'message'=>'Ekstensi PHP cURL tidak tersedia','provider'=>'meta'];
        $payload=['messaging_product'=>'whatsapp','recipient_type'=>'individual','to'=>$to];
        if($imageUrl){
            if(!$this->isPublicMediaUrl($imageUrl))return ['success'=>false,'message'=>'URL gambar Meta harus berupa URL publik.','provider'=>'meta'];
            $payload+=['type'=>'image','image'=>['link'=>$imageUrl,'caption'=>$message]];
        }else{
            $payload+=['type'=>'text','text'=>['preview_url'=>false,'body'=>$message]];
        }
        $curl=curl_init($url);
        curl_setopt_array($curl,[
            CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$accessToken,'Content-Type: application/json','Accept: application/json'],
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT=>30,
            CURLOPT_CONNECTTIMEOUT=>10,
        ]);
        $body=curl_exec($curl);$error=curl_error($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);
        if($body===false)return ['success'=>false,'status'=>$status?:null,'message'=>$error?:'Meta tidak memberikan respons','provider'=>'meta'];
        $decoded=json_decode((string)$body,true);$success=$status>=200&&$status<300&&!isset($decoded['error']);
        $result=['success'=>$success,'status'=>$status,'body'=>(string)$body,'provider'=>'meta'];
        if(!$success)$result['message']=(string)($decoded['error']['message']??$decoded['message']??('HTTP '.$status));
        return $result;
    }

    private function requestWatzap(string $url,string $apiKey,string $numberKey,string $phone,string $message,?string $imageUrl=null): array
    {
        if(!function_exists('curl_init'))return ['success'=>false,'message'=>'Ekstensi PHP cURL tidak tersedia','provider'=>'watzap'];
        $payload=[
            'api_key'=>$apiKey,
            'number_key'=>$numberKey,
            'phone_no'=>$phone,
            'message'=>$message,
        ];
        if($imageUrl){
            if(!$this->isPublicMediaUrl($imageUrl))return ['success'=>false,'message'=>'URL gambar Watzap harus berupa URL publik.','provider'=>'watzap'];
            $payload['url']=$imageUrl;
            $payload['separate_caption']='';
        }
        $curl=curl_init();
        curl_setopt_array($curl,[
            CURLOPT_URL=>$url,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_ENCODING=>'',
            CURLOPT_MAXREDIRS=>10,
            CURLOPT_TIMEOUT=>30,
            CURLOPT_CONNECTTIMEOUT=>10,
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST=>'POST',
            CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],
        ]);
        $body=curl_exec($curl);$error=curl_error($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);
        if($body===false)return ['success'=>false,'status'=>$status?:null,'message'=>$error?:'Watzap tidak memberikan respons','provider'=>'watzap'];
        $decoded=json_decode((string)$body,true);$success=$status>=200&&$status<300;
        if(is_array($decoded)){
            if(array_key_exists('success',$decoded)&&in_array($decoded['success'],[false,0,'0','false'],true))$success=false;
            if(array_key_exists('status',$decoded)&&in_array($decoded['status'],[false,0,'0','false','failed','error'],true))$success=false;
        }
        $result=['success'=>$success,'status'=>$status,'body'=>(string)$body,'provider'=>'watzap'];
        if(!$success&&is_array($decoded)){
            $providerMessage=$decoded['message']??$decoded['reason']??$decoded['error']??null;
            if($providerMessage!==null)$result['message']=is_scalar($providerMessage)?(string)$providerMessage:json_encode($providerMessage);
        }
        return $result;
    }

    private function isPublicMediaUrl(string $url): bool
    {
        if(filter_var($url,FILTER_VALIDATE_URL)===false)return false;
        $parts=parse_url($url);
        if(!in_array(strtolower((string)($parts['scheme']??'')),['http','https'],true))return false;
        $host=strtolower(trim((string)($parts['host']??''),'[]'));
        if($host===''||$host==='localhost'||str_ends_with($host,'.localhost')||str_ends_with($host,'.local'))return false;
        if(filter_var($host,FILTER_VALIDATE_IP)!==false){
            return filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)!==false;
        }
        return str_contains($host,'.');
    }

    private function startLog(?int $id,string $recipient,string $message,?string $mediaUrl,?string $subject=null): int
    {
        $db=db_connect();$now=date('Y-m-d H:i:s');$data=['channel'=>'whatsapp','recipient'=>$recipient,'message'=>$message,'media_url'=>$mediaUrl];if($subject!==null)$data['subject']=$subject;
        if($id){$row=$db->table('notification_logs')->select('attempt_count')->where('id',$id)->get()->getRowArray();$db->table('notification_logs')->where('id',$id)->update($data+['status'=>'failed','error_message'=>null,'attempt_count'=>(int)($row['attempt_count']??0)+1,'last_attempt_at'=>$now,'updated_at'=>$now]);return $id;}
        $db->table('notification_logs')->insert($data+['status'=>'failed','attempt_count'=>1,'last_attempt_at'=>$now,'created_by'=>session('user_id')?:null,'created_at'=>$now]);return (int)$db->insertID();
    }

    private function finishLog(int $id,array $result): void
    {
        $ok=(bool)($result['success']??false);$error=$ok?null:(string)($result['message']??('HTTP '.($result['status']??'unknown')));
        db_connect()->table('notification_logs')->where('id',$id)->update(['status'=>$ok?'sent':'failed','error_message'=>$error,'response_code'=>$result['status']??null,'response_body'=>isset($result['body'])?mb_substr((string)$result['body'],0,65000):null,'sent_at'=>$ok?date('Y-m-d H:i:s'):null,'sent_date'=>$ok?date('Y-m-d'):null,'updated_at'=>date('Y-m-d H:i:s')]);
    }
}
