<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <label>Pilih Role</label>
        <select class="form-control" onchange="location.href='<?= site_url('access-control') ?>?role_id='+this.value">
          <?php foreach($roles as $r): ?><option value="<?= $r['id'] ?>" <?= $selectedRole==$r['id']?'selected':'' ?>><?= esc($r['name']) ?></option><?php endforeach ?>
        </select>
      </div>
      <form method="post" action="<?= site_url('access-control/save') ?>">
        <input type="hidden" name="role_id" value="<?= $selectedRole ?>">
        <div class="card-body">
          <h5 class="border-bottom pb-2">Akses Menu dan CRUD</h5>
          <p class="text-muted">Aktifkan menu, lalu pilih operasi yang diizinkan. Gunakan tombol <strong>Read</strong> untuk akses lihat saja atau <strong>Semua</strong> untuk CRUD penuh.</p>
          <div class="table-responsive mb-4"><table class="table table-bordered table-sm">
            <thead class="thead-light"><tr><th style="min-width:230px">Menu</th><th class="text-center">Create</th><th class="text-center">Read</th><th class="text-center">Update</th><th class="text-center">Delete</th><th class="text-center">Preset</th></tr></thead>
            <tbody><?php foreach($menus as $menu): $access=$menuAccess[(int)$menu['id']]??[];$enabled=isset($menuAccess[(int)$menu['id']]); ?>
              <tr data-menu-row="<?= $menu['id'] ?>">
                <td><div class="custom-control custom-checkbox" style="margin-left:<?= (int)($menu['depth']??0)*26 ?>px"><input class="custom-control-input menu-check" type="checkbox" name="menus[]" value="<?= $menu['id'] ?>" id="m<?= $menu['id'] ?>" data-parent="<?= $menu['parent_id']??'' ?>" <?= $enabled?'checked':'' ?>><label class="custom-control-label" for="m<?= $menu['id'] ?>"><?= ($menu['depth']??0)>0?'<span class="text-muted mr-1">└</span>':'' ?><i class="<?= esc($menu['icon']) ?> mr-1"></i><?= esc($menu['name']) ?></label></div></td>
                <?php foreach(['create','read','update','delete'] as $operation): ?><td class="text-center"><div class="custom-control custom-checkbox d-inline-block"><input class="custom-control-input crud-check" type="checkbox" name="crud[<?= $menu['id'] ?>][<?= $operation ?>]" value="1" id="<?= $operation ?>-<?= $menu['id'] ?>" <?= !empty($access['can_'.$operation])?'checked':'' ?> <?= !$enabled?'disabled':'' ?>><label class="custom-control-label" for="<?= $operation ?>-<?= $menu['id'] ?>"></label></div></td><?php endforeach ?>
                <td class="text-center text-nowrap"><button type="button" class="btn btn-xs btn-outline-info preset-read" data-menu="<?= $menu['id'] ?>">Read</button> <button type="button" class="btn btn-xs btn-outline-success preset-all" data-menu="<?= $menu['id'] ?>">Semua</button></td>
              </tr>
            <?php endforeach ?></tbody>
          </table></div>
          <h5 class="border-bottom pb-2">Permission aksi dan CRUD</h5>
          <div class="table-responsive"><table class="table table-bordered table-sm">
            <thead class="thead-light"><tr><th style="min-width:230px">Permission</th><th class="text-center">Create</th><th class="text-center">Read</th><th class="text-center">Update</th><th class="text-center">Delete</th><th class="text-center">Preset</th></tr></thead>
            <tbody><?php foreach($permissions as $p): $access=$permissionAccess[(int)$p['id']]??[];$enabled=isset($permissionAccess[(int)$p['id']]); ?><tr data-permission-row="<?= $p['id'] ?>">
              <td><div class="custom-control custom-checkbox"><input class="custom-control-input permission-check" type="checkbox" name="permissions[]" value="<?= $p['id'] ?>" id="p<?= $p['id'] ?>" <?= $enabled?'checked':'' ?>><label class="custom-control-label" for="p<?= $p['id'] ?>"><?= esc($p['name']) ?> <small class="text-muted">(<?= esc($p['module']) ?>)</small></label></div></td>
              <?php foreach(['create','read','update','delete'] as $operation): ?><td class="text-center"><div class="custom-control custom-checkbox d-inline-block"><input class="custom-control-input permission-crud-check" type="checkbox" name="permission_crud[<?= $p['id'] ?>][<?= $operation ?>]" value="1" id="permission-<?= $operation ?>-<?= $p['id'] ?>" <?= !empty($access['can_'.$operation])?'checked':'' ?> <?= !$enabled?'disabled':'' ?>><label class="custom-control-label" for="permission-<?= $operation ?>-<?= $p['id'] ?>"></label></div></td><?php endforeach ?>
              <td class="text-center text-nowrap"><button type="button" class="btn btn-xs btn-outline-info permission-read" data-permission="<?= $p['id'] ?>">Read</button> <button type="button" class="btn btn-xs btn-outline-success permission-all" data-permission="<?= $p['id'] ?>">Semua</button></td>
            </tr><?php endforeach ?></tbody>
          </table></div>
        </div>
        <div class="card-footer"><button class="btn btn-success"><i class="fas fa-save"></i> Simpan Akses Role</button></div>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function syncCrud(menuId,enabled){const row=$('[data-menu-row="'+menuId+'"]');row.find('.crud-check').prop('disabled',!enabled);if(!enabled)row.find('.crud-check').prop('checked',false)}
$('.menu-check').on('change',function(){
  syncCrud(this.value,this.checked);
  if(this.checked&&this.dataset.parent){const parent=$('#m'+this.dataset.parent).prop('checked',true);syncCrud(this.dataset.parent,true);$('#read-'+this.dataset.parent).prop('checked',true)}
  if(!this.checked){$('.menu-check[data-parent="'+this.value+'"]').each(function(){$(this).prop('checked',false);syncCrud(this.value,false)})}
});
$('.preset-read').on('click',function(){const id=this.dataset.menu;$('#m'+id).prop('checked',true);syncCrud(id,true);$('[data-menu-row="'+id+'"] .crud-check').prop('checked',false);$('#read-'+id).prop('checked',true)});
$('.preset-all').on('click',function(){const id=this.dataset.menu;$('#m'+id).prop('checked',true);syncCrud(id,true);$('[data-menu-row="'+id+'"] .crud-check').prop('checked',true)});
function syncPermission(id,enabled){const row=$('[data-permission-row="'+id+'"]');row.find('.permission-crud-check').prop('disabled',!enabled);if(!enabled)row.find('.permission-crud-check').prop('checked',false)}
$('.permission-check').on('change',function(){syncPermission(this.value,this.checked)});
$('.permission-read').on('click',function(){const id=this.dataset.permission;$('#p'+id).prop('checked',true);syncPermission(id,true);$('[data-permission-row="'+id+'"] .permission-crud-check').prop('checked',false);$('#permission-read-'+id).prop('checked',true)});
$('.permission-all').on('click',function(){const id=this.dataset.permission;$('#p'+id).prop('checked',true);syncPermission(id,true);$('[data-permission-row="'+id+'"] .permission-crud-check').prop('checked',true)});
</script>
<?= $this->endSection() ?>
