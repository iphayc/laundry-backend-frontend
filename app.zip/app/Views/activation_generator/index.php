<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="alert alert-warning shadow-sm">
  <i class="fas fa-user-shield mr-2"></i>
  <strong>Halaman internal pemilik.</strong> Kode hanya boleh diberikan kepada pemohon yang identitasnya sudah diverifikasi.
</div>

<div class="card">
  <div class="card-header bg-white d-flex align-items-center">
    <h3 class="card-title font-weight-bold">
      <i class="fas fa-list-alt text-primary mr-2"></i>Daftar Aplikasi Terdaftar
    </h3>
    <button type="button" class="btn btn-success ml-auto" data-toggle="modal" data-target="#activation-modal">
      <i class="fas fa-key mr-1"></i> Generate Aktivasi
    </button>
  </div>
  <div class="card-body table-responsive">
    <table class="table table-bordered table-striped w-100" id="issued-license-table">
      <thead>
        <tr>
          <th>No.</th>
          <th>Email</th>
          <th>Machine ID</th>
          <th>Status</th>
          <th>Tanggal Registrasi</th>
          <th>Generate Terakhir</th>
          <th>Dibuat Oleh</th>
          <th>Aksi</th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<form method="post" id="activation-action-security" class="d-none"></form>

<div class="modal fade" id="activation-modal" tabindex="-1" aria-labelledby="activation-modal-title" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form id="activation-form" method="post" action="<?= site_url('internal/activation-generator/generate') ?>">
        <div class="modal-header bg-success text-white">
          <h5 class="modal-title" id="activation-modal-title">
            <i class="fas fa-key mr-2"></i>Generate Kode Aktivasi
          </h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Tutup">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="activation-email">Email Pemohon</label>
            <input type="email" class="form-control" id="activation-email" name="email"
                   placeholder="nama@perusahaan.com" required autocomplete="email">
            <small class="form-text text-muted">Harus sama persis dengan email pada form Register Aplikasi.</small>
          </div>

          <div class="form-group">
            <label for="activation-machine-id">Machine ID Server Pemohon</label>
            <textarea class="form-control text-monospace" id="activation-machine-id" name="machine_id"
                      rows="3" maxlength="255"
                      placeholder="Tempel Machine ID dari halaman Register Aplikasi" required></textarea>
          </div>

          <div class="callout callout-success mt-4 d-none" id="activation-result">
            <h5><i class="fas fa-check-circle mr-1"></i>Kode Aktivasi Berhasil Dibuat</h5>
            <div class="input-group mt-3">
              <input class="form-control form-control-lg text-monospace font-weight-bold"
                     id="generated-activation-code" readonly>
              <div class="input-group-append">
                <button type="button" class="btn btn-success" id="copy-activation-code">
                  <i class="fas fa-copy mr-1"></i>Salin
                </button>
              </div>
            </div>
            <small class="text-muted">Kode hanya berlaku untuk kombinasi email dan Machine ID tersebut.</small>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-success" id="generate-activation-button">
            <i class="fas fa-cogs mr-1"></i>Generate dan Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="activation-detail-modal" tabindex="-1" aria-labelledby="activation-detail-title" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title" id="activation-detail-title">
          <i class="fas fa-id-card mr-2"></i>Detail Aktivasi
        </h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Tutup">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6 form-group">
            <label>Email Terdaftar</label>
            <input class="form-control" id="detail-email" readonly>
          </div>
          <div class="col-md-3 form-group">
            <label>Status</label>
            <div id="detail-status" class="pt-2"></div>
          </div>
          <div class="col-md-3 form-group">
            <label>Dibuat Oleh</label>
            <input class="form-control" id="detail-creator" readonly>
          </div>
          <div class="col-12 form-group">
            <label>Machine ID</label>
            <textarea class="form-control text-monospace" id="detail-machine-id" rows="2" readonly></textarea>
          </div>
          <div class="col-md-6 form-group">
            <label>Tanggal Registrasi</label>
            <input class="form-control" id="detail-registered-at" readonly>
          </div>
          <div class="col-md-6 form-group">
            <label>Generate Terakhir</label>
            <input class="form-control" id="detail-generated-at" readonly>
          </div>
          <div class="col-12">
            <div class="callout callout-success mb-0">
              <label for="detail-activation-code">Kode Aktivasi</label>
              <div class="input-group">
                <input class="form-control form-control-lg text-monospace font-weight-bold"
                       id="detail-activation-code" readonly>
                <div class="input-group-append">
                  <button type="button" class="btn btn-success" id="copy-detail-code">
                    <i class="fas fa-copy mr-1"></i>Salin
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-info" id="email-detail-code">
          <i class="fas fa-envelope mr-1"></i>Kirim Email
        </button>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
const activationTable=$('#issued-license-table').DataTable({
  ajax:{
    url:<?= json_encode(site_url('internal/activation-generator/data')) ?>,
    dataSrc:'data',
    error:function(){
      window.showAppToast?.('error','Gagal','Daftar registrasi gagal dimuat.');
    }
  },
  columns:[
    {data:null,render:function(data,type,row,meta){return meta.row+meta.settings._iDisplayStart+1}},
    {data:'registered_email',render:$.fn.dataTable.render.text()},
    {data:'machine_id',render:function(data,type){
      if(type!=='display')return data||'';
      return $('<code class="text-break">').text(data||'').prop('outerHTML');
    }},
    {data:'active',render:function(data,type){
      if(type!=='display')return Number(data);
      return Number(data)===1?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-secondary">Tidak Aktif</span>';
    }},
    {data:'registered_at',defaultContent:'-'},
    {data:'last_generated_at',defaultContent:'-'},
    {data:'creator_name',defaultContent:'Sistem',render:$.fn.dataTable.render.text()},
    {data:'id',orderable:false,searchable:false,render:function(id){
      return '<div class="btn-group btn-group-sm" role="group">'
        +'<button type="button" class="btn btn-info view-activation" data-id="'+Number(id)+'" title="Lihat detail"><i class="fas fa-eye"></i></button>'
        +'<button type="button" class="btn btn-primary email-activation" data-id="'+Number(id)+'" title="Kirim kode melalui email"><i class="fas fa-envelope"></i></button>'
        +'</div>';
    }}
  ],
  order:[[4,'desc']],
  dom:'Blfrtip',
  buttons:window.parkingExportButtons('Daftar_Aplikasi_Terdaftar',':not(:last-child)')
});

const activationForm=document.getElementById('activation-form');
const activationButton=document.getElementById('generate-activation-button');
const activationResult=document.getElementById('activation-result');
const activationCode=document.getElementById('generated-activation-code');
const detailModal=$('#activation-detail-modal');
const detailEmailButton=document.getElementById('email-detail-code');
let selectedActivationId=null;

activationForm.addEventListener('submit',async function(event){
  event.preventDefault();
  if(!activationForm.reportValidity())return;

  const originalButton=activationButton.innerHTML;
  activationButton.disabled=true;
  activationButton.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Memproses...';

  try{
    const response=await fetch(activationForm.action,{
      method:'POST',
      body:new FormData(activationForm),
      headers:{'X-Requested-With':'XMLHttpRequest'}
    });
    const result=await response.json();
    if(!response.ok||!result.success)throw new Error(result.message||'Kode aktivasi gagal dibuat.');

    activationCode.value=result.code;
    activationResult.classList.remove('d-none');
    activationTable.ajax.reload(null,false);
    window.showAppToast?.('success','Berhasil',result.message);
  }catch(error){
    window.showAppToast?.('error','Gagal',error.message||'Terjadi kesalahan saat membuat kode aktivasi.');
  }finally{
    activationButton.disabled=false;
    activationButton.innerHTML=originalButton;
  }
});

$('#activation-modal').on('shown.bs.modal',function(){
  document.getElementById('activation-email').focus();
}).on('hidden.bs.modal',function(){
  activationForm.reset();
  activationCode.value='';
  activationResult.classList.add('d-none');
});

document.getElementById('copy-activation-code').addEventListener('click',async function(){
  try{
    await navigator.clipboard.writeText(activationCode.value);
  }catch(error){
    activationCode.select();
    document.execCommand('copy');
  }
  window.showAppToast?.('success','Berhasil','Kode aktivasi berhasil disalin.');
});

async function loadActivationDetail(id){
  try{
    const response=await fetch(<?= json_encode(site_url('internal/activation-generator/detail')) ?>+'/'+id,{
      headers:{'X-Requested-With':'XMLHttpRequest'}
    });
    const result=await response.json();
    if(!response.ok||!result.success)throw new Error(result.message||'Detail aktivasi gagal dimuat.');
    const data=result.data;
    selectedActivationId=Number(data.id);
    document.getElementById('detail-email').value=data.registered_email||'';
    document.getElementById('detail-machine-id').value=data.machine_id||'';
    document.getElementById('detail-creator').value=data.creator_name||'Sistem';
    document.getElementById('detail-registered-at').value=data.registered_at||'-';
    document.getElementById('detail-generated-at').value=data.last_generated_at||'-';
    document.getElementById('detail-activation-code').value=data.activation_code||'';
    document.getElementById('detail-status').innerHTML=Number(data.active)===1
      ?'<span class="badge badge-success px-3 py-2">Aktif</span>'
      :'<span class="badge badge-secondary px-3 py-2">Tidak Aktif</span>';
    detailModal.modal('show');
  }catch(error){
    window.showAppToast?.('error','Gagal',error.message||'Detail aktivasi gagal dimuat.');
  }
}

async function sendActivationEmail(id){
  if(!id||!confirm('Kirim kode aktivasi ke email terdaftar?'))return;
  const rowButton=document.querySelector('.email-activation[data-id="'+id+'"]');
  const original=rowButton?.innerHTML;
  if(rowButton){rowButton.disabled=true;rowButton.innerHTML='<i class="fas fa-spinner fa-spin"></i>'}
  detailEmailButton.disabled=true;

  try{
    const response=await fetch(<?= json_encode(site_url('internal/activation-generator/email')) ?>+'/'+id,{
      method:'POST',
      body:new FormData(document.getElementById('activation-action-security')),
      headers:{'X-Requested-With':'XMLHttpRequest'}
    });
    const result=await response.json();
    if(!response.ok||!result.success)throw new Error(result.message||'Email gagal dikirim.');
    window.showAppToast?.('success','Berhasil',result.message);
  }catch(error){
    window.showAppToast?.('error','Gagal',error.message||'Email gagal dikirim.');
  }finally{
    if(rowButton){rowButton.disabled=false;rowButton.innerHTML=original}
    detailEmailButton.disabled=false;
  }
}

$('#issued-license-table tbody').on('click','.view-activation',function(){
  loadActivationDetail(Number(this.dataset.id));
}).on('click','.email-activation',function(){
  sendActivationEmail(Number(this.dataset.id));
});

detailEmailButton.addEventListener('click',function(){
  sendActivationEmail(selectedActivationId);
});

document.getElementById('copy-detail-code').addEventListener('click',async function(){
  const field=document.getElementById('detail-activation-code');
  try{
    await navigator.clipboard.writeText(field.value);
  }catch(error){
    field.select();
    document.execCommand('copy');
  }
  window.showAppToast?.('success','Berhasil','Kode aktivasi berhasil disalin.');
});
</script>
<?= $this->endSection() ?>
