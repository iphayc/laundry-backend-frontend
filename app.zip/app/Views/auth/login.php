<?php
$companyName = 'Eksis Laundry';
$currentYear = (int) date('Y');
$copyrightYear = '2025' . ($currentYear > 2025 ? '-' . $currentYear : '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login <?= esc($companyName) ?></title>
  <link rel="icon" href="<?= base_url('images/eksis-laundry-logo.png') ?>">
  <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css"
        integrity="sha384-qrt37eUXKQgF1p6OlpdB29OTyKryxbxdJHkvfVN4suujWnn6PibIvbnygcK4uJfA"
        crossorigin="anonymous"
        referrerpolicy="no-referrer">
  <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css"
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm"
        crossorigin="anonymous"
        referrerpolicy="no-referrer">
  <style>
    body{
      background:
        linear-gradient(rgba(10,35,31,.18),rgba(10,35,31,.18)),
        url("<?= base_url('images/background.png') ?>") center center/cover no-repeat fixed;
    }
    .login-box{width:390px}.card{border-radius:18px}
    .card{background:rgba(255,255,255,.96);backdrop-filter:blur(3px)}
    .brand-mark{width:72px;height:72px;border-radius:18px;background:#26a269;color:white;display:grid;place-items:center;margin:auto;overflow:hidden}
    .brand-mark.has-logo{background:#fff;border:1px solid #e4e8ec}
    .brand-mark img{width:100%;height:100%;object-fit:contain;padding:6px}
    @media (max-width:576px){body{background-position:52% center}.login-box{width:calc(100% - 32px)}}
  </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="card shadow-lg">
    <div class="card-body login-card-body p-5">
      <div class="brand-mark has-logo mb-3">
        <img src="<?= base_url('images/eksis-laundry-logo.png') ?>" alt="Logo <?= esc($companyName) ?>">
      </div>
      <h3 class="text-center font-weight-bold"><?= esc($companyName) ?></h3>
      <p class="login-box-msg">Laundry Management System</p>
      <form method="post">
        <?= csrf_field() ?>
        <div class="input-group mb-3">
          <input class="form-control" name="username" placeholder="Username" required autofocus autocomplete="username">
          <div class="input-group-append"><div class="input-group-text"><i class="fas fa-user"></i></div></div>
        </div>
        <div class="input-group mb-4">
          <input type="password" class="form-control" name="password" placeholder="Password" required autocomplete="current-password">
          <div class="input-group-append"><div class="input-group-text"><i class="fas fa-lock"></i></div></div>
        </div>
        <button class="btn btn-success btn-block btn-lg">Masuk</button>
      </form>
      <p class="text-muted text-center mt-4 mb-0"><small>&copy; <?= esc($copyrightYear) ?> <?= esc($companyName) ?></small></p>
    </div>
  </div>
</div>
<?= view('layout/toasts') ?>
</body>
</html>
