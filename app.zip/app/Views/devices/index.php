<?= $this->extend('layout/main') ?><?= $this->section('content') ?>
<div class="card">
  <div class="card-header"><a href="<?= site_url('master/devices/form') ?>" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Device</a></div>
  <div class="card-body table-responsive">
    <table id="grid" class="table table-bordered table-striped">
      <thead><tr><th>Kode</th><th>Nama</th><th>Jenis</th><th>Merek / Model</th><th>Serial Number</th><th>IP / Port</th><th>Koneksi</th><th>Gate</th><th>Status</th><th>Aktif</th><th>Aksi</th></tr></thead>
      <tbody><?php foreach($rows as $row): ?><tr>
        <td><?= esc($row['code']) ?></td><td><?= esc($row['name']) ?></td><td><?= esc(strtoupper($row['device_type'])) ?></td>
        <td><?= esc(trim(($row['brand']??'').' '.($row['model']??''))?:'-') ?></td><td><?= esc($row['serial_number']??'-') ?></td>
        <td><?= esc(($row['ip_address']??'-').($row['port']?':'.$row['port']:'')) ?></td><td><?= esc(strtoupper($row['connection_mode'])) ?></td>
        <td><?= esc($row['gate_names']) ?></td><td><span class="badge badge-<?= $row['connection_status']==='online'?'success':($row['connection_status']==='offline'?'danger':'secondary') ?>"><?= esc(strtoupper($row['connection_status'])) ?></span></td>
        <td><?= $row['active']?'Ya':'Tidak' ?></td><td class="text-nowrap"><a class="btn btn-sm btn-primary" href="<?= site_url('master/devices/form/'.$row['id']) ?>" title="Edit"><i class="fas fa-edit"></i></a> <form method="post" action="<?= site_url('master/devices/delete/'.$row['id']) ?>" class="d-inline" onsubmit="return confirm('Arsipkan device ini?')"><button class="btn btn-sm btn-danger" title="Soft delete / arsip"><i class="fas fa-archive"></i></button></form></td>
      </tr><?php endforeach ?></tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?><?= $this->section('scripts') ?><script>$('#grid').DataTable({dom:'Blfrtip',buttons:parkingExportButtons('Master Device RFID',':not(:last-child)')});</script><?= $this->endSection() ?>
