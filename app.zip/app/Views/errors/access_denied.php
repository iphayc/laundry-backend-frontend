<?php
$companyName=$company['residence_name']??'Residence One';
$roleName=$roleName??'User';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>403 - Akses Ditolak | <?= esc($companyName) ?></title>
  <?php if(!empty($company['logo'])): ?><link rel="icon" href="<?= base_url($company['logo']) ?>"><?php endif ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
  <style>
    body{min-height:100vh;margin:0;background:linear-gradient(135deg,#f8fafc 0%,#eef7f1 50%,#edf4ff 100%);color:#273444}
    .access-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:30px}
    .access-panel{width:min(1040px,100%);background:#fff;border-radius:28px;box-shadow:0 22px 65px rgba(31,45,61,.16);overflow:hidden;border:1px solid rgba(148,163,184,.2)}
    .access-content{display:grid;grid-template-columns:1.05fr .95fr;align-items:center}
    .access-copy{padding:58px 60px}
    .access-visual{padding:40px;background:#f8fbf9;display:flex;align-items:center;justify-content:center;min-height:520px}
    .access-visual img{width:100%;max-width:480px;height:auto}
    .status-badge{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border-radius:30px;background:#fff1f2;color:#be123c;font-weight:700;font-size:14px;margin-bottom:18px}
    .access-copy h1{font-size:48px;font-weight:800;line-height:1.08;margin:0 0 18px;color:#172033}
    .access-copy .lead{font-size:20px;line-height:1.65;color:#5f6b7a;margin-bottom:24px}
    .role-box{background:#f7f9fc;border-left:4px solid #28a745;border-radius:10px;padding:16px 18px;margin-bottom:28px}
    .role-box small{display:block;text-transform:uppercase;letter-spacing:.08em;color:#7b8794;font-weight:700}
    .role-box strong{display:block;font-size:18px;margin-top:3px}
    .btn{border-radius:10px;padding:11px 20px;font-weight:600}
    .brand{position:absolute;left:30px;top:25px;display:flex;align-items:center;gap:10px;font-weight:700;color:#344054}
    .brand img{width:38px;height:38px;object-fit:contain;border-radius:9px}
    @media(max-width:850px){.access-content{grid-template-columns:1fr}.access-visual{order:-1;min-height:270px;padding:25px}.access-visual img{max-width:330px}.access-copy{padding:38px 30px}.access-copy h1{font-size:36px}.brand{position:static;margin:18px 24px 0}}
  </style>
</head>
<body>
  <div class="brand">
    <?php if(!empty($company['logo'])): ?><img src="<?= base_url($company['logo']) ?>" alt="Logo"><?php else: ?><i class="fas fa-parking fa-2x text-success"></i><?php endif ?>
    <span><?= esc($companyName) ?></span>
  </div>
  <main class="access-page">
    <section class="access-panel">
      <div class="access-content">
        <div class="access-copy">
          <div class="status-badge"><i class="fas fa-ban"></i> HTTP 403 · Access Denied</div>
          <h1>Anda tidak memiliki akses.</h1>
          <p class="lead"><?= esc($message) ?></p>
          <div class="role-box"><small>Role yang sedang digunakan</small><strong><i class="fas fa-user-shield mr-2 text-success"></i><?= esc($roleName) ?></strong></div>
          <p class="text-muted mb-4">Hubungi Administrator apabila menu atau izin ini diperlukan untuk pekerjaan Anda.</p>
          <a href="<?= site_url('dashboard') ?>" class="btn btn-success mr-2"><i class="fas fa-home mr-1"></i> Kembali ke Dashboard</a>
          <button type="button" class="btn btn-outline-secondary mr-2" onclick="history.back()"><i class="fas fa-arrow-left mr-1"></i> Kembali</button>
          <a href="<?= site_url('logout') ?>" class="btn btn-link text-danger"><i class="fas fa-sign-out-alt mr-1"></i> Log Out</a>
        </div>
        <div class="access-visual"><img src="<?= base_url('images/access-denied.svg') ?>" alt="Ilustrasi akses ditolak"></div>
      </div>
    </section>
  </main>
</body>
</html>
