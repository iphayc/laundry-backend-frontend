<?php
$companyName = $companyProfile['residence_name'] ?? 'Residence One';
$currentYear = (int) date('Y');
$copyrightYear = '2025' . ($currentYear > 2025 ? '-' . $currentYear : '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Gate Console - <?= esc($companyName) ?></title>
  <?php if(!empty($companyProfile['logo'])): ?><link rel="icon" href="<?= base_url($companyProfile['logo']) ?>"><?php endif ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
  <style>
    html,body{min-height:100%}body{background:#071522;color:#fff;display:flex;flex-direction:column}
    .shell{width:100%;max-width:1100px;margin:auto}.tap-card{background:#11283d;border:1px solid #25445c;border-radius:24px}
    .rfid{width:140px;height:140px;border:4px solid #39d98a;border-radius:50%;display:grid;place-items:center;margin:auto;box-shadow:0 0 35px #39d98a55}
    .result{min-height:110px;border-radius:16px}.clock-card{height:70px;background:#11283d;border:1px solid #25445c;border-radius:16px;display:flex;align-items:center;justify-content:center}.clock{font-size:2rem;font-weight:600;letter-spacing:2px;font-variant-numeric:tabular-nums;text-align:center}
    .gate-brand{display:flex;align-items:center;gap:12px}.gate-logo{width:54px;height:54px;border-radius:12px;background:#fff;object-fit:contain;padding:4px}
    .camera-panel{border-radius:16px}.camera-frame{position:relative;background:#02070b;border:1px solid #25445c;border-radius:10px;overflow:hidden;min-height:190px}.gate-camera{display:block;width:100%;height:210px;object-fit:contain;background:#02070b}.camera-label{position:absolute;left:0;right:0;bottom:0;padding:5px 9px;background:rgba(0,0,0,.68);font-size:.85rem;font-weight:600}
    .evidence-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:10px}.evidence-grid img{width:100%;height:120px;object-fit:cover;border-radius:8px;border:1px solid rgba(255,255,255,.4)}.evidence-label{font-size:.75rem;margin-top:3px}
    .gate-footer{margin-top:auto;border-top:1px solid #25445c;color:#9eafbd;text-align:center;padding:18px}
  </style>
</head>
<body>
  <main class="shell p-4">
    <div class="row align-items-center mb-4">
      <div class="col-lg-7">
        <div class="gate-brand">
        <?php if(!empty($companyProfile['logo'])): ?>
          <img src="<?= base_url($companyProfile['logo']) ?>" alt="Logo <?= esc($companyName) ?>" class="gate-logo">
        <?php else: ?>
          <i class="fas fa-parking fa-3x text-success"></i>
        <?php endif ?>
        <div><h2 class="mb-0"><?= esc($companyName) ?> Gate</h2><span class="text-muted">RFID Access Console</span></div>
        </div>
      </div>
      <div class="col-lg-5 mt-3 mt-lg-0"><div class="clock-card"><div class="clock" id="clock"></div></div></div>
    </div>
    <div class="row">
      <div class="col-lg-7">
        <div class="tap-card p-5 text-center">
          <div class="rfid mb-4"><i class="fas fa-id-card fa-4x text-success"></i></div>
          <h3>Tempelkan Kartu Penghuni</h3>
          <p class="text-muted">Reader RFID dapat mengisi nomor kartu secara otomatis</p>
          <input id="card" class="form-control form-control-lg text-center mb-3" placeholder="Nomor kartu" autofocus>
          <div class="alert alert-dark border border-secondary mb-3">
            <strong><i class="fas fa-door-open mr-2"></i><?= esc($gate['name']) ?></strong>
            <span class="badge badge-<?= $gate['direction']==='in'?'success':($gate['direction']==='out'?'info':'warning') ?> ml-2"><?= esc(strtoupper($gate['direction']==='in'?'MASUK':($gate['direction']==='out'?'KELUAR':'ARAH BELUM DITETAPKAN'))) ?></span>
          </div>
          <button id="tap" class="btn btn-success btn-lg btn-block mt-3">PROSES TAP</button>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="tap-card camera-panel p-2 mb-3">
          <h6 class="px-1"><i class="fas fa-video mr-2 text-info"></i>Camera Gate</h6>
          <div class="row mx-n1"><?php if($cameras): foreach($cameras as $camera): ?><div class="col-<?= count($cameras)>1?'6':'12' ?> px-1"><?php if($camera['camera_type']==='usb'): ?><div class="camera-frame"><video id="usb-video-<?= $camera['id'] ?>" class="gate-camera usb-camera" data-camera-id="<?= $camera['id'] ?>" autoplay playsinline muted></video><div class="camera-label"><?= esc($camera['name']) ?> · USB</div></div><div class="input-group input-group-sm mt-1"><select class="custom-select usb-device-select" data-camera-id="<?= $camera['id'] ?>" aria-label="Pilih kamera USB"></select><div class="input-group-append"><button type="button" class="btn btn-info start-usb-camera" data-camera-id="<?= $camera['id'] ?>" title="Aktifkan kamera"><i class="fas fa-play"></i></button></div></div><small id="usb-status-<?= $camera['id'] ?>" class="d-block text-muted mt-1">Menghubungkan kamera...</small><?php else: ?><div class="camera-frame"><img class="gate-camera" data-refresh="<?= (int)$camera['refresh_seconds'] ?>" src="<?= site_url('gate/camera/'.$camera['id']).'?console_slug='.urlencode($gate['console_slug']) ?>" alt="<?= esc($camera['name']) ?>"><div class="camera-label"><?= esc($camera['name']) ?></div></div><?php endif ?></div><?php endforeach; else: ?><div class="col-12 py-3 text-center text-warning"><small>Camera belum dikonfigurasi.</small></div><?php endif ?></div>
        </div>
        <div id="result" class="result bg-secondary p-4"><h3>Menunggu kartu...</h3><p>Hasil akses akan tampil di sini.</p></div>
        <div class="tap-card p-3 mt-3">
          <h5><i class="fas fa-road mr-2 text-warning"></i>Barrier Gate</h5>
          <?php if($barriers): foreach($barriers as $barrier): ?><div class="d-flex justify-content-between border-top border-secondary py-2"><span><?= esc($barrier['name']) ?></span><span class="badge badge-<?= $barrier['connection_status']==='online'?'success':($barrier['connection_status']==='offline'?'danger':'secondary') ?>"><?= esc(strtoupper($barrier['connection_status'])) ?></span></div><?php endforeach; else: ?><small class="text-warning">Barrier belum dikonfigurasi untuk gate ini.</small><?php endif ?>
        </div>
      </div>
    </div>
  </main>
  <footer class="gate-footer">&copy; <?= esc($copyrightYear) ?> <strong><?= esc($companyName) ?></strong>. All rights reserved. <span class="ml-2">v1.0</span></footer>
  <?= view('layout/toasts') ?>
  <script>
    function updateClock(){const now=new Date();clock.textContent=[now.getHours(),now.getMinutes(),now.getSeconds()].map(value=>String(value).padStart(2,'0')).join(':')}
    updateClock();setInterval(updateClock,1000);
    const usbStreams=new Map();
    async function startUsbCamera(cameraId){
      const video=document.getElementById('usb-video-'+cameraId),select=document.querySelector('.usb-device-select[data-camera-id="'+cameraId+'"]'),status=document.getElementById('usb-status-'+cameraId);
      if(!navigator.mediaDevices?.getUserMedia){status.textContent='Browser tidak mendukung akses kamera USB.';showAppToast('error','Camera USB','Browser tidak mendukung akses kamera.');return}
      try{
        usbStreams.get(cameraId)?.getTracks().forEach(track=>track.stop());
        const storageKey='gate-usb-camera-<?= esc($gate['console_slug'],'js') ?>-'+cameraId;
        const saved=select.value||localStorage.getItem(storageKey)||'';
        const stream=await navigator.mediaDevices.getUserMedia({video:saved?{deviceId:{exact:saved},width:{ideal:1280},height:{ideal:720}}:{width:{ideal:1280},height:{ideal:720}},audio:false});
        usbStreams.set(cameraId,stream);video.srcObject=stream;await video.play();
        const devices=(await navigator.mediaDevices.enumerateDevices()).filter(device=>device.kind==='videoinput');
        const activeId=stream.getVideoTracks()[0]?.getSettings().deviceId||saved;select.innerHTML='';
        devices.forEach((device,index)=>{const option=document.createElement('option');option.value=device.deviceId;option.textContent=device.label||'Camera '+(index+1);option.selected=device.deviceId===activeId;select.appendChild(option)});
        if(activeId)localStorage.setItem(storageKey,activeId);
        status.textContent='Live - '+(stream.getVideoTracks()[0]?.label||'USB Camera');status.className='d-block text-success mt-1';
      }catch(error){status.textContent='Camera belum aktif. Klik play dan izinkan akses kamera.';status.className='d-block text-warning mt-1';showAppToast('warning','Camera USB','Izinkan akses kamera pada browser untuk menampilkan gambar live.')}
    }
    function captureUsbFrame(){
      const video=document.querySelector('.usb-camera');
      if(!video)return {};
      if(!video.srcObject||video.readyState<2||!video.videoWidth)throw new Error('Camera USB belum siap.');
      const width=Math.min(video.videoWidth,1280),height=Math.round(video.videoHeight*(width/video.videoWidth)),canvas=document.createElement('canvas');
      canvas.width=width;canvas.height=height;canvas.getContext('2d').drawImage(video,0,0,width,height);
      return {camera_id:Number(video.dataset.cameraId),camera_image:canvas.toDataURL('image/jpeg',.85)};
    }
    document.querySelectorAll('.start-usb-camera').forEach(button=>button.addEventListener('click',()=>startUsbCamera(Number(button.dataset.cameraId))));
    document.querySelectorAll('.usb-device-select').forEach(select=>select.addEventListener('change',()=>{localStorage.setItem('gate-usb-camera-<?= esc($gate['console_slug'],'js') ?>-'+select.dataset.cameraId,select.value);startUsbCamera(Number(select.dataset.cameraId))}));
    document.querySelectorAll('.usb-camera').forEach(video=>startUsbCamera(Number(video.dataset.cameraId)));
    async function tap(){
      const cardNo=card.value.trim();
      if(!cardNo){showAppToast('warning','Peringatan','Nomor kartu wajib diisi.');return}
      let cameraPayload={};try{cameraPayload=captureUsbFrame()}catch(error){showAppToast('warning','Camera Belum Siap','Aktifkan camera USB dan pastikan gambar live sudah tampil sebelum tap.');return}
      result.className='result bg-warning p-4';result.innerHTML='<h3>Memproses...</h3>';
      try{
        const response=await fetch('<?= site_url('gate/tap') ?>',{method:'POST',headers:{'Content-Type':'application/json','<?= config('Security')->headerName ?>':<?= json_encode(csrf_hash()) ?>},body:JSON.stringify({card_no:cardNo,console_slug:<?= json_encode($gate['console_slug']) ?>,...cameraPayload})});
        if(!response.ok)throw new Error('HTTP '+response.status);
        const data=await response.json();
        const barrierOpened=!!data.barrier?.opened;
        result.className='result p-4 '+(data.granted?(barrierOpened?'bg-success':'bg-warning'):'bg-danger');
        const barrierMessage=data.barrier?.message||'';
        const accessTitle=data.granted?(barrierOpened?'AKSES DIBERIKAN':'KARTU VALID - BARRIER DITAHAN'):'AKSES DITOLAK';
        const accessIcon=data.granted?(barrierOpened?'check-circle':'exclamation-triangle'):'times-circle';
        const entryEvidence=data.entry_image?`<div><img src="${data.entry_image}" alt="Foto masuk"><div class="evidence-label">Foto Saat Masuk${data.entry_time?' · '+data.entry_time:''}</div></div>`:'';
        const currentEvidence=data.current_image?`<div><img src="${data.current_image}" alt="Foto saat ini"><div class="evidence-label">${<?= json_encode($gate['direction']) ?>==='out'?'Foto Saat Keluar':'Foto Saat Masuk'}</div></div>`:'';
        const evidence=(entryEvidence||currentEvidence)?`<div class="evidence-grid">${entryEvidence}${currentEvidence}</div>`:'';
        result.innerHTML=`<h2><i class="fas fa-${accessIcon}"></i> ${accessTitle}</h2><h4>${data.resident||''}</h4><p>${data.message}</p>${barrierMessage?`<small><i class="fas fa-road mr-1"></i>${barrierMessage}</small>`:''}${evidence}`;
        const captureMessage=data.capture?.message||'';
        showAppToast(data.granted?(data.barrier&&!data.barrier.opened?'warning':'success'):'error',data.granted?'Akses Diberikan':'Akses Ditolak',(data.message||'Proses tap selesai.')+(captureMessage?' '+captureMessage:'')+(barrierMessage?' '+barrierMessage:''));
        card.value='';card.focus();
      }catch(error){
        result.className='result bg-danger p-4';result.innerHTML='<h3>Terjadi error</h3><p>Proses tap gagal. Silakan coba lagi.</p>';
        showAppToast('error','Error','Proses tap gagal. Periksa koneksi aplikasi.');
      }
    }
    document.querySelectorAll('img.gate-camera').forEach(image=>setInterval(()=>{const url=new URL(image.src);url.searchParams.set('t',Date.now());image.src=url.toString()},Math.max(1,parseInt(image.dataset.refresh||'3'))*1000));
    document.getElementById('tap').onclick=tap;
    card.onkeydown=event=>{if(event.key==='Enter')tap()};
  </script>
</body>
</html>
