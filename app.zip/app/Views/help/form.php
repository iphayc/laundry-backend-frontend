<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="card">
  <form method="post" action="<?= site_url('help/manual/save') ?>" enctype="multipart/form-data">
    <div class="card-body">
      <input type="hidden" name="id" value="<?= esc($row['id']??'') ?>">
      <div class="row">
        <div class="form-group col-md-6"><label>Menu / Modul</label><input class="form-control" name="module" value="<?= old('module',$row['module']??'') ?>" required></div>
        <div class="form-group col-md-6"><label>Judul</label><input class="form-control" name="title" value="<?= old('title',$row['title']??'') ?>" required></div>
        <div class="form-group col-md-12"><label>Isi Panduan</label><textarea class="form-control" name="content" rows="18" required><?= old('content',$row['content']??'') ?></textarea><small class="text-muted">Gunakan baris kosong untuk paragraf, awali langkah dengan angka, dan daftar dengan tanda “-”.</small></div>
        <div class="form-group col-md-6"><label>Screenshot Tampilan</label><input type="file" class="form-control-file border rounded p-2" name="screenshot" accept="image/jpeg,image/png,image/webp"><small class="text-muted">Opsional; JPG, PNG, atau WebP maksimal 3 MB.</small><?php if(!empty($row['screenshot_path'])): ?><img src="<?= base_url($row['screenshot_path']) ?>" class="img-fluid img-thumbnail mt-2" style="max-height:240px" alt="Screenshot saat ini"><?php endif ?></div>
        <div class="form-group col-md-3"><label>Urutan</label><input type="number" class="form-control" name="sort_order" value="<?= old('sort_order',$row['sort_order']??0) ?>"></div>
        <div class="form-group col-md-3"><label>Aktif</label><?= view('layout/switch_button',['name'=>'active','checked'=>old('active',$row['active']??1),'onText'=>'Aktif','offText'=>'Nonaktif']) ?></div>
      </div>
    </div>
    <div class="card-footer"><button class="btn btn-success"><i class="fas fa-save"></i> Simpan</button> <a href="<?= site_url('help/manual') ?>" class="btn btn-secondary">Kembali</a></div>
  </form>
</div>
<?= $this->endSection() ?>
