<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<style>
.manual-shell{display:grid;grid-template-columns:280px minmax(0,1fr);gap:24px;align-items:start}
.manual-toc{position:sticky;top:74px;max-height:calc(100vh - 110px);overflow:auto}
.manual-paper{max-width:900px;min-height:1120px;margin:0 auto;background:#fff;padding:72px 82px;box-shadow:0 4px 22px rgba(0,0,0,.12);border:1px solid #dfe3e8}
.manual-paper h2{font-family:Georgia,serif;font-size:30px;color:#1f2937;border-bottom:2px solid #2f80ed;padding-bottom:14px}
.manual-paper .module-label{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#2f80ed;font-weight:700}
.manual-content{font-family:Calibri,Arial,sans-serif;font-size:17px;line-height:1.75;color:#252525}
.manual-content h3{font-size:20px;font-weight:700;margin:26px 0 10px;color:#1f3a5f}
.manual-content ol,.manual-content ul{padding-left:28px}.manual-content li{margin-bottom:7px}
.manual-shot{margin:28px 0}.manual-shot img{width:100%;border:1px solid #cfd6dd;box-shadow:0 2px 8px rgba(0,0,0,.12)}.manual-shot figcaption{text-align:center;color:#6c757d;font-size:13px;margin-top:8px}
@media(max-width:991px){.manual-shell{grid-template-columns:1fr}.manual-toc{position:static;max-height:260px}.manual-paper{padding:36px 28px;min-height:0}}
@media print{.main-header,.main-sidebar,.content-header,.main-footer,.manual-toc,.manual-toolbar{display:none!important}.content-wrapper{margin:0!important;background:#fff}.manual-shell{display:block}.manual-paper{box-shadow:none;border:0;max-width:none;padding:15mm}.manual-paper h2{font-size:24pt}}
</style>
<?php
$lines=preg_split('/\R/',trim($article['content']));$html='';$list=null;
foreach($lines as $line){$line=trim($line);if($line===''){if($list){$html.="</$list>";$list=null;}continue;}
if(str_ends_with($line,':')){if($list){$html.="</$list>";$list=null;}$html.='<h3>'.esc(rtrim($line,':')).'</h3>';continue;}
if(preg_match('/^\d+\.\s+(.+)$/u',$line,$m)){if($list!=='ol'){if($list)$html.="</$list>";$html.='<ol>';$list='ol';}$html.='<li>'.esc($m[1]).'</li>';continue;}
if(preg_match('/^-\s+(.+)$/u',$line,$m)){if($list!=='ul'){if($list)$html.="</$list>";$html.='<ul>';$list='ul';}$html.='<li>'.esc($m[1]).'</li>';continue;}
if($list){$html.="</$list>";$list=null;}$html.='<p>'.esc($line).'</p>';}if($list)$html.="</$list>";
?>
<div class="manual-toolbar mb-3 d-flex flex-wrap">
  <a href="<?= site_url('help/manual') ?>" class="btn btn-secondary mr-2 mb-2"><i class="fas fa-arrow-left"></i> Daftar Panduan</a>
  <button type="button" onclick="window.print()" class="btn btn-outline-primary mr-2 mb-2"><i class="fas fa-print"></i> Cetak / Simpan PDF</button>
  <?php if($isAdmin): ?><a href="<?= site_url('help/manual/form/'.$article['id']) ?>" class="btn btn-primary mb-2"><i class="fas fa-edit"></i> Edit Panduan</a><?php endif ?>
</div>
<div class="manual-shell">
  <aside class="card manual-toc"><div class="card-header font-weight-bold"><i class="fas fa-list mr-2"></i>Daftar Isi</div><div class="list-group list-group-flush"><?php foreach($articles as $item): ?><a class="list-group-item list-group-item-action <?= (int)$item['id']===(int)$article['id']?'active':'' ?>" href="<?= site_url('help/manual/read/'.$item['id']) ?>"><small class="d-block <?= (int)$item['id']===(int)$article['id']?'text-white-50':'text-muted' ?>"><?= esc($item['module']) ?></small><?= esc($item['title']) ?></a><?php endforeach ?></div></aside>
  <article class="manual-paper">
    <div class="module-label"><?= esc($article['module']) ?></div>
    <h2><?= esc($article['title']) ?></h2>
    <?php if(!empty($article['screenshot_path'])&&is_file(FCPATH.$article['screenshot_path'])): ?><figure class="manual-shot"><img src="<?= base_url($article['screenshot_path']) ?>" alt="Tampilan <?= esc($article['module']) ?>"><figcaption>Contoh tampilan modul <?= esc($article['module']) ?></figcaption></figure><?php endif ?>
    <div class="manual-content"><?= $html ?></div>
    <hr class="mt-5">
    <div class="d-flex justify-content-between manual-toolbar">
      <div><?php if($previous): ?><a href="<?= site_url('help/manual/read/'.$previous['id']) ?>" class="btn btn-light"><i class="fas fa-chevron-left"></i> <?= esc($previous['title']) ?></a><?php endif ?></div>
      <div><?php if($next): ?><a href="<?= site_url('help/manual/read/'.$next['id']) ?>" class="btn btn-light"><?= esc($next['title']) ?> <i class="fas fa-chevron-right"></i></a><?php endif ?></div>
    </div>
  </article>
</div>
<?= $this->endSection() ?>
