<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Instalasi Sistem Parkir Cluster</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
  <style>
    body{background:#f4f7fb;color:#172033}.install-shell{max-width:1080px;margin:35px auto}
    .hero{background:linear-gradient(135deg,#102a43,#147a34);color:#fff;border-radius:18px 18px 0 0}
    .card{border:0;border-radius:18px}.step{display:flex;align-items:center;gap:12px}
    .step-no{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#21a447;color:#fff;font-weight:700}
    .status-row{border:1px solid #e1e6ee;border-radius:10px;padding:11px 14px;margin-bottom:9px;background:#fff}
    .form-section{border-top:1px solid #e4e8ef;padding-top:24px;margin-top:24px}
  </style>
</head>
<body>
<main class="install-shell px-3">
  <div class="card shadow-lg">
    <div class="hero p-4 p-md-5">
      <div class="d-flex align-items-center">
        <div class="mr-3"><i class="fas fa-parking fa-3x"></i></div>
        <div>
          <div class="text-uppercase small font-weight-bold text-success">First-run setup</div>
          <h1 class="h2 mb-1">Wizard Instalasi Sistem Parkir Cluster</h1>
          <p class="mb-0 text-light">Migrasi database, profil perumahan, dan akun administrator.</p>
        </div>
      </div>
    </div>
    <div class="card-body p-4 p-md-5">
      <div class="row">
        <div class="col-lg-4 mb-4">
          <div class="step mb-3"><span class="step-no">1</span><h5 class="mb-0">Pemeriksaan server</h5></div>
          <?php foreach ($requiredExtensions as $extension => $ready): ?>
            <div class="status-row d-flex justify-content-between">
              <span>PHP <?= esc($extension) ?></span>
              <i class="fas <?= $ready ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' ?>"></i>
            </div>
          <?php endforeach ?>
          <div class="status-row d-flex justify-content-between">
            <span>Folder writable</span>
            <i class="fas <?= $writableReady ? 'fa-check-circle text-success' : 'fa-times-circle text-danger' ?>"></i>
          </div>
          <div class="status-row">
            <small class="text-muted d-block">Database dari .env</small>
            <strong><?= esc($status['hostname']) ?>:<?= esc((string) $status['port']) ?>/<?= esc($status['database'] ?: '-') ?></strong>
            <div class="mt-1 <?= $status['connected'] ? 'text-success' : 'text-danger' ?>">
              <i class="fas <?= $status['connected'] ? 'fa-link' : 'fa-unlink' ?>"></i>
              <?= $status['connected'] ? 'Terhubung' : 'Belum terhubung' ?>
            </div>
          </div>
          <?php if (! $status['connected'] && $status['message']): ?>
            <div class="alert alert-danger small"><?= esc($status['message']) ?></div>
          <?php endif ?>
        </div>
        <div class="col-lg-8">
          <form method="post" action="<?= site_url('install') ?>">
            <?= csrf_field() ?>
            <div class="step mb-4"><span class="step-no">2</span><h5 class="mb-0">Profil aplikasi</h5></div>
            <div class="form-group">
              <label>Nama Company / Perumahan</label>
              <input type="text" name="company_name" class="form-control" value="<?= old('company_name') ?>" required>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6"><label>Telepon</label><input type="text" name="company_phone" class="form-control" value="<?= old('company_phone') ?>"></div>
              <div class="form-group col-md-6"><label>Pengembang</label><input type="text" name="company_developer" class="form-control" value="<?= old('company_developer') ?>"></div>
            </div>
            <div class="form-group"><label>Alamat</label><textarea name="company_address" class="form-control" rows="2"><?= old('company_address') ?></textarea></div>

            <div class="form-section">
              <div class="step mb-4"><span class="step-no">3</span><h5 class="mb-0">Akun administrator</h5></div>
              <div class="form-row">
                <div class="form-group col-md-6"><label>Nama Administrator</label><input type="text" name="admin_name" class="form-control" value="<?= old('admin_name', 'Administrator') ?>" required></div>
                <div class="form-group col-md-6"><label>Username</label><input type="text" name="admin_username" class="form-control" value="<?= old('admin_username', 'admin') ?>" required></div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-7"><label>Email Administrator</label><input type="email" name="admin_email" class="form-control" value="<?= old('admin_email') ?>" required></div>
                <div class="form-group col-md-5"><label>Telepon</label><input type="text" name="admin_phone" class="form-control" value="<?= old('admin_phone') ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-6"><label>Password</label><input type="password" name="admin_password" class="form-control" minlength="12" required><small class="text-muted">Minimal 12 karakter dengan huruf besar, kecil, angka dan simbol.</small></div>
                <div class="form-group col-md-6"><label>Konfirmasi Password</label><input type="password" name="admin_password_confirm" class="form-control" minlength="12" required></div>
              </div>
            </div>

            <div class="form-section">
              <div class="step mb-4"><span class="step-no">4</span><h5 class="mb-0">Aktivasi server</h5></div>
              <div class="form-group">
                <label>Email untuk Aktivasi</label>
                <input type="email" name="activation_email" class="form-control" value="<?= old('activation_email', 'iphayc@gmail.com') ?>" required>
                <small class="text-muted">Setelah instalasi selesai, aplikasi langsung diarahkan ke form registrasi Machine ID server.</small>
              </div>
            </div>
            <button class="btn btn-success btn-lg btn-block mt-4" <?= ! $status['connected'] || ! $writableReady || in_array(false, $requiredExtensions, true) ? 'disabled' : '' ?>>
              <i class="fas fa-cogs mr-2"></i>Pasang Aplikasi
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>
<?= view('layout/toasts') ?>
</body>
</html>
