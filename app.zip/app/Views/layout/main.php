<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc($title??'Eksis Laundry Admin') ?></title>
<link rel="icon" href="<?= base_url('images/eksis-laundry-logo.png') ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="<?= base_url('vendor/datatables/dataTables.bootstrap4.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('vendor/datatables/buttons.bootstrap4.min.css') ?>">
<style>:root{--green:#26a269}.brand-link{background:#fff!important;border-bottom:1px solid #e5e7eb!important;color:#273444!important}.main-sidebar{background:#fff!important}.content-wrapper{background:#f7f9fc}.brand-text{font-weight:700;color:#273444!important}.stat-icon{border-radius:14px}.nav-treeview{padding-left:10px}.sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link{color:#495057}.sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link:hover{background:#f0f3f6;color:#212529}.sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link.active{background:#28a745;color:#fff}.sidebar-dark-primary .nav-treeview>.nav-item>.nav-link{color:#5f6b76}.sidebar-dark-primary .nav-treeview>.nav-item>.nav-link.active{background:#e8f5ec;color:#1f7a35}.sidebar .user-panel{border-bottom-color:#e5e7eb!important}.sidebar .user-panel .info a,.sidebar .user-panel .image i{color:#495057!important}.card{border:0;box-shadow:0 1px 5px rgba(31,45,61,.12)}.main-header{border-bottom:1px solid #e5e7eb}</style></head>
<style>
.brand-link>i.fa-tshirt{display:none}.brand-link:before{content:'';display:inline-block;width:34px;height:34px;margin-left:1rem;margin-right:.5rem;vertical-align:middle;border-radius:8px;background:#fff url("<?= base_url('images/eksis-laundry-logo.png') ?>") center/contain no-repeat}
.sidebar-dark-primary .nav-sidebar>.nav-item.menu-open>.nav-link,.sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link[aria-expanded="true"]{background:#e8f5ec!important;color:#1f7a35!important}
.sidebar-dark-primary .nav-sidebar>.nav-item.menu-open>.nav-link p,.sidebar-dark-primary .nav-sidebar>.nav-item.menu-open>.nav-link i{color:#1f7a35!important}
.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover{background:#e8f5ec!important;color:#1f7a35!important}
.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover p,.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover i{color:#1f7a35!important}
.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link.active:hover{background:#28a745!important;color:#fff!important}
.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link.active:hover p,.sidebar-dark-primary .nav-sidebar .nav-item>.nav-link.active:hover i{color:#fff!important}
.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active,.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover{background:#dff3e5!important;color:#146c2e!important}
.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active p,.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active i,.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover p,.sidebar-dark-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover i{color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-item>.nav-link{color:#5f6b76!important}
.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active,.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active:hover{background:#e8f5ec!important;color:#146c2e!important}
.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active p,.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active i,.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active:hover p,.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active:hover i{color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:hover,.sidebar-light-primary .nav-sidebar .nav-item>.nav-link.active:hover{background:#e8f5ec!important;color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:hover p,.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:hover i,.sidebar-light-primary .nav-sidebar .nav-item>.nav-link.active:hover p,.sidebar-light-primary .nav-sidebar .nav-item>.nav-link.active:hover i{color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover,.sidebar-light-primary .nav-sidebar>.nav-item.menu-open>.nav-link{background:#e8f5ec!important;color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover p,.sidebar-light-primary .nav-sidebar .nav-item>.nav-link:not(.active):hover i,.sidebar-light-primary .nav-sidebar>.nav-item.menu-open>.nav-link p,.sidebar-light-primary .nav-sidebar>.nav-item.menu-open>.nav-link i{color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active,.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover{background:#dff3e5!important;color:#146c2e!important}
.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active p,.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active i,.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover p,.sidebar-light-primary .nav-sidebar .nav-treeview .nav-item>.nav-link.active:hover i{color:#146c2e!important}
.custom-switch-lg{min-height:34px;padding-left:3.35rem}.custom-switch-lg .custom-control-label{font-weight:600;line-height:1.8;padding-left:.2rem;cursor:pointer}
.custom-switch-lg .custom-control-label:before{left:-3.35rem;width:2.8rem;height:1.55rem;border-radius:1rem;background:#cbd5df}
.custom-switch-lg .custom-control-label:after{left:calc(-3.35rem + 3px);top:calc(.25rem + 3px);width:calc(1.55rem - 6px);height:calc(1.55rem - 6px);border-radius:50%;background:#fff}
.custom-switch-lg .custom-control-input:checked~.custom-control-label:before{background:#28a745;border-color:#28a745}
.custom-switch-lg .custom-control-input:checked~.custom-control-label:after{transform:translateX(1.25rem)}
</style>
<body class="hold-transition sidebar-mini layout-fixed"><div class="wrapper">
<nav class="main-header navbar navbar-expand navbar-white navbar-light"><ul class="navbar-nav"><li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a></li></ul><ul class="navbar-nav ml-auto">
<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-user-circle"></i> Profile</a><div class="dropdown-menu dropdown-menu-right">
<button class="dropdown-item" type="button" data-toggle="modal" data-target="#profile-modal"><i class="fas fa-user-edit mr-2 text-primary"></i> Profile</button>
<button class="dropdown-item" type="button" data-toggle="modal" data-target="#password-modal"><i class="fas fa-key mr-2 text-warning"></i> Change Password</button>
</div></li>
<li class="nav-item"><a class="nav-link" href="<?= site_url('logout') ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a></li>
</ul></nav>
<aside class="main-sidebar sidebar-light-primary elevation-2"><a href="<?= site_url('dashboard') ?>" class="brand-link"><i class="fas fa-tshirt ml-3 mr-2 text-success"></i><span class="brand-text">Eksis Laundry</span></a><div class="sidebar"><div class="user-panel mt-3 pb-3 mb-3 d-flex"><div class="image"><i class="fas fa-user-circle fa-2x text-secondary"></i></div><div class="info"><a href="#" class="d-block"><?= esc(session('user_name')) ?></a><small class="text-muted">Eksis Admin</small></div></div>
<nav><ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview">
<?= view('layout/sidebar_nodes',['nodes'=>$sidebarMenus??[]]) ?>
</ul></nav></div></aside>
<div class="content-wrapper"><section class="content-header"><div class="container-fluid"><div class="d-flex justify-content-between align-items-center"><h1 class="font-weight-bold text-dark mb-0"><?= esc($title??'') ?></h1><small class="text-muted"><?= date('d M Y') ?></small></div></div></section><section class="content"><div class="container-fluid">
<?= $this->renderSection('content') ?></div></section></div><footer class="main-footer"><strong>&copy; <?= date('Y') ?> Eksis Software Technology.</strong><span class="float-right">Eksis Laundry v1.0</span></footer></div>

<div class="modal fade" id="profile-modal" tabindex="-1" aria-hidden="true"><div class="modal-dialog"><div class="modal-content">
<form method="post" action="<?= site_url('account/profile') ?>"><div class="modal-header bg-primary"><h5 class="modal-title"><i class="fas fa-user-edit mr-2"></i>Profile</h5><button type="button" class="close text-white" data-dismiss="modal">&times;</button></div>
<div class="modal-body">
<div class="form-group"><label>Username</label><input class="form-control" value="<?= esc($accountUser['username']??'') ?>" readonly></div>
<div class="form-group"><label>Nama</label><input class="form-control" name="name" value="<?= esc($accountUser['name']??'') ?>" required></div>
<div class="form-group"><label>Email</label><input type="email" class="form-control" name="email" value="<?= esc($accountUser['email']??'') ?>"></div>
<div class="form-group"><label>Role</label><input class="form-control" value="<?= esc($accountUser['role_name']??'') ?>" readonly></div>
<div class="form-group"><label>Telepon</label><input class="form-control" name="phone" value="<?= esc($accountUser['phone']??'') ?>"></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button><button class="btn btn-primary"><i class="fas fa-save"></i> Simpan Profile</button></div></form>
</div></div></div>

<div class="modal fade" id="password-modal" tabindex="-1" aria-hidden="true"><div class="modal-dialog"><div class="modal-content">
<form method="post" action="<?= site_url('account/change-password') ?>"><div class="modal-header bg-warning"><h5 class="modal-title"><i class="fas fa-key mr-2"></i>Change Password</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
<div class="modal-body">
<?php foreach([['current_password','Password Lama','current-account-password'],['password','Password Baru','new-account-password'],['password_confirm','Konfirmasi Password Baru','confirm-account-password']] as $field): ?>
<div class="form-group"><label><?= $field[1] ?></label><div class="input-group"><input type="password" class="form-control account-password" id="<?= $field[2] ?>" name="<?= $field[0] ?>" <?= $field[0]!=='current_password'?'minlength="8"':'' ?> required autocomplete="<?= $field[0]==='current_password'?'current-password':'new-password' ?>"><div class="input-group-append"><button type="button" class="btn btn-outline-secondary account-password-toggle" data-target="<?= $field[2] ?>"><i class="fas fa-eye"></i></button></div></div></div>
<?php endforeach ?>
<small class="text-muted">Password baru minimal 8 karakter.</small>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button><button class="btn btn-warning"><i class="fas fa-key"></i> Ubah Password</button></div></form>
</div></div></div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script><script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="<?= base_url('vendor/datatables/jquery.dataTables.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/dataTables.bootstrap4.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/dataTables.buttons.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/buttons.bootstrap4.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/jszip.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/pdfmake.min.js') ?>"></script><script src="<?= base_url('vendor/datatables/vfs_fonts.js') ?>"></script><script src="<?= base_url('vendor/datatables/buttons.html5.min.js') ?>"></script>
<?= view('layout/toasts') ?>
<script>
document.querySelectorAll('form').forEach(function(form){
  if((form.getAttribute('method')||'GET').toUpperCase()!=='POST'||form.querySelector('input[name="<?= csrf_token() ?>"]'))return;
  const token=document.createElement('input');
  token.type='hidden';token.name=<?= json_encode(csrf_token()) ?>;token.value=<?= json_encode(csrf_hash()) ?>;
  form.prepend(token);
});
$.extend(true,$.fn.dataTable.defaults,{
  pageLength:10,
  lengthMenu:[[10,20,50,100,-1],[10,20,50,100,'All']]
});
window.parkingExportButtons=function(title,columns){
  const exportOptions={columns:columns??':visible'};
  return [
    {extend:'excelHtml5',text:'<i class="fas fa-file-excel"></i> Excel',className:'btn-success',title:title,filename:title.replace(/[^a-z0-9]+/gi,'_'),exportOptions:exportOptions},
    {extend:'pdfHtml5',text:'<i class="fas fa-file-pdf"></i> PDF',className:'btn-danger',title:title,filename:title.replace(/[^a-z0-9]+/gi,'_'),orientation:'landscape',pageSize:'A4',exportOptions:exportOptions}
  ];
};
$('.account-password-toggle').on('click',function(){const input=document.getElementById(this.dataset.target);input.type=input.type==='password'?'text':'password';$(this).find('i').toggleClass('fa-eye fa-eye-slash')});
<?php if(session('open_modal')): ?>$('#<?= esc(session('open_modal'),'js') ?>').modal('show');<?php endif ?>
$(document).on('change','.switch-button',function(){$(this).siblings('.custom-control-label').find('.switch-state').text(this.checked?this.dataset.on:this.dataset.off)});
function syncHouseholdHead(){const head=document.querySelector('input[name="is_household_head"][type="checkbox"]'),group=document.querySelector('select[name="household_head_id"]');if(!head||!group)return;group.disabled=head.checked;if(head.checked)group.value='';group.closest('.form-group')?.classList.toggle('text-muted',head.checked)}
$(document).on('change','input[name="is_household_head"][type="checkbox"]',syncHouseholdHead);syncHouseholdHead();
</script>
<?= $this->renderSection('scripts') ?></body></html>
