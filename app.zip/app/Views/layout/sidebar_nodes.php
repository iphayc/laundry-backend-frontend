<?php
$currentMenuPath = $currentMenuPath ?? trim(service('uri')->getPath(), '/');
$routeMatchesPath = static function (?string $route) use ($currentMenuPath): bool {
    $route = trim((string) $route, '/');

    if ($route === '' || $route === '#') {
        return false;
    }

    return $currentMenuPath === $route
        || str_starts_with($currentMenuPath, $route . '/');
};

if (! isset($activeMenuRoute)) {
    $activeMenuRoute = '';
    $findMostSpecificRoute = function (array $items) use (&$findMostSpecificRoute, $routeMatchesPath, &$activeMenuRoute): void {
        foreach ($items as $item) {
            $route = trim((string) ($item['route'] ?? ''), '/');
            if ($routeMatchesPath($route) && strlen($route) > strlen($activeMenuRoute)) {
                $activeMenuRoute = $route;
            }
            $findMostSpecificRoute($item['children'] ?? []);
        }
    };
    $findMostSpecificRoute($nodes);
}

$routeIsActive = static function (?string $route) use ($activeMenuRoute): bool {
    $route = trim((string) $route, '/');
    return $route !== '' && $route === $activeMenuRoute;
};
$branchIsActive = function (array $node) use (&$branchIsActive, $routeIsActive): bool {
    if ($routeIsActive($node['route'] ?? null)) {
        return true;
    }

    foreach ($node['children'] ?? [] as $child) {
        if ($branchIsActive($child)) {
            return true;
        }
    }

    return false;
};
?>
<?php foreach($nodes as $node):
    $children = $node['children'] ?? [];
    $isActive = $routeIsActive($node['route'] ?? null);
    $isOpen = $children && $branchIsActive($node);
    $badgeCount = (int) (($sidebarBadges ?? [])[trim((string)($node['route'] ?? ''), '/')] ?? 0);
?>
<li class="nav-item <?= $children?'has-treeview ':'' ?><?= $isOpen?'menu-open':'' ?>">
  <a href="<?= $children?'#':site_url($node['route']?:'#') ?>" class="nav-link <?= $isActive?'active':'' ?>">
    <i class="nav-icon <?= esc($node['icon']?:'far fa-circle') ?>"></i>
    <p><?= esc($node['name']) ?><?php if($badgeCount>0): ?><span class="right badge badge-danger ml-2"><?= $badgeCount>999?'999+':$badgeCount ?></span><?php endif ?><?php if($children): ?><i class="right fas fa-angle-left"></i><?php endif ?></p>
  </a>
  <?php if($children): ?><ul class="nav nav-treeview"<?= $isOpen?' style="display:block"':'' ?>><?= view('layout/sidebar_nodes',['nodes'=>$children,'currentMenuPath'=>$currentMenuPath,'activeMenuRoute'=>$activeMenuRoute]) ?></ul><?php endif ?>
</li>
<?php endforeach ?>
