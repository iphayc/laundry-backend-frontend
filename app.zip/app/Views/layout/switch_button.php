<?php
$switchId=$id??('switch-'.preg_replace('/[^a-z0-9_-]+/i','-',$name));
$isChecked=(int)($checked??0)===1;
$onText=$onText??'Ya';
$offText=$offText??'Tidak';
?>
<input type="hidden" name="<?= esc($name) ?>" value="0">
<div class="custom-control custom-switch custom-switch-lg pt-2">
  <input type="checkbox" class="custom-control-input switch-button" id="<?= esc($switchId) ?>" name="<?= esc($name) ?>" value="1" data-on="<?= esc($onText) ?>" data-off="<?= esc($offText) ?>" <?= $isChecked?'checked':'' ?>>
  <label class="custom-control-label" for="<?= esc($switchId) ?>"><span class="switch-state"><?= esc($isChecked?$onText:$offText) ?></span></label>
</div>
