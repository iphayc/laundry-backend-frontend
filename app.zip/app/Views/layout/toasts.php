<?php
$toastMessages = [];
foreach ([
    'success' => ['Berhasil', 'fa-check-circle'],
    'warning' => ['Peringatan', 'fa-exclamation-triangle'],
    'error'   => ['Gagal', 'fa-times-circle'],
    'info'    => ['Informasi', 'fa-info-circle'],
] as $type => [$title, $icon]) {
    $message = session($type);
    if ($message !== null && $message !== '') {
        $toastMessages[] = compact('type', 'title', 'icon', 'message');
    }
}
$validationErrors = session('errors');
if (is_array($validationErrors) && $validationErrors !== []) {
    $toastMessages[] = [
        'type' => 'warning',
        'title' => 'Periksa Data',
        'icon' => 'fa-exclamation-triangle',
        'message' => implode("\n", $validationErrors),
    ];
}
?>
<style>
.app-toast-container{position:fixed;top:70px;right:18px;z-index:10800;width:min(380px,calc(100vw - 36px))}
.app-toast{display:flex;align-items:flex-start;color:#fff;border-radius:8px;box-shadow:0 6px 22px rgba(0,0,0,.22);margin-bottom:12px;overflow:hidden;opacity:0;transform:translateX(30px);transition:.25s ease}
.app-toast.show{opacity:1;transform:translateX(0)}
.app-toast-success{background:#28a745}.app-toast-warning{background:#f39c12}.app-toast-error{background:#dc3545}.app-toast-info{background:#17a2b8}
.app-toast-icon{font-size:1.3rem;padding:17px 8px 0 16px}.app-toast-body{flex:1;padding:12px 8px}.app-toast-title{display:block;margin-bottom:2px}.app-toast-message{line-height:1.35;white-space:pre-line}
.app-toast-close{border:0;background:transparent;color:#fff;font-size:1.35rem;padding:8px 13px;opacity:.8}.app-toast-close:hover{opacity:1}
</style>
<div id="app-toast-container" class="app-toast-container" aria-live="polite" aria-atomic="true"></div>
<script>
(function(){
  const container=document.getElementById('app-toast-container');
  window.showAppToast=function(type,title,message,delay){
    type=['success','warning','error','info'].includes(type)?type:'info';
    const icons={success:'fa-check-circle',warning:'fa-exclamation-triangle',error:'fa-times-circle',info:'fa-info-circle'};
    const toast=document.createElement('div');
    toast.className='app-toast app-toast-'+type;
    toast.setAttribute('role',type==='error'?'alert':'status');
    toast.innerHTML='<i class="fas '+icons[type]+' app-toast-icon"></i><div class="app-toast-body"><strong class="app-toast-title"></strong><div class="app-toast-message"></div></div><button type="button" class="app-toast-close" aria-label="Tutup">&times;</button>';
    toast.querySelector('.app-toast-title').textContent=title;
    toast.querySelector('.app-toast-message').textContent=message;
    const remove=()=>{toast.classList.remove('show');setTimeout(()=>toast.remove(),250)};
    toast.querySelector('.app-toast-close').addEventListener('click',remove);
    container.appendChild(toast);
    requestAnimationFrame(()=>toast.classList.add('show'));
    setTimeout(remove,delay||5000);
  };
  const queued=<?= json_encode($toastMessages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  queued.forEach((item,index)=>setTimeout(()=>showAppToast(item.type,item.title,item.message),index*180));
})();
</script>
