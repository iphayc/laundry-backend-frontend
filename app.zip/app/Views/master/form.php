<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="card">
  <form method="post" action="<?= site_url("master/$module/save") ?>" <?= $module==='residents'?'enctype="multipart/form-data"':'' ?>>
    <div class="card-body">
      <input type="hidden" name="id" value="<?= esc($row['id']??'') ?>">
      <div class="row">
        <?php foreach($config['fields'] as $field=>$label): ?>
          <div class="form-group <?= ($module==='notification-templates'&&in_array($field,['body','remark'],true))||($module==='residents'&&$field==='address')?'col-md-12':'col-md-6' ?>">
            <label><?= esc($label) ?></label>
            <?php if($module==='notification-templates'&&$field==='status'): ?>
              <?= view('layout/switch_button',['name'=>'status','checked'=>old('status',($row['status']??'active')==='active'?1:0),'onText'=>'Aktif','offText'=>'Nonaktif']) ?>
            <?php elseif(isset($options[$field])): ?>
              <select class="form-control" name="<?= $field ?>" <?= in_array($field,['role_id','unit_id','vehicle_type_id','type','status','gate_type','direction'],true)||($field==='template_id'&&$module==='email-recipients')||($field==='cluster_id'&&$module==='units')||($field==='resident_id'&&$module!=='visitors')?'required':'' ?>>
                <?php if(!in_array('',array_column($options[$field],'value'),true)): ?><option value="" <?= (string)($row[$field]??'')===''?'selected':'' ?>>- Pilih <?= esc($label) ?> -</option><?php endif ?>
                <?php foreach($options[$field] as $option): ?><option value="<?= esc($option['value']) ?>" <?= (string)($row[$field]??'')===(string)$option['value']?'selected':'' ?>><?= esc($option['label']) ?></option><?php endforeach ?>
              </select>
            <?php elseif(($module==='notification-templates'&&in_array($field,['body','remark'],true))||($module==='residents'&&$field==='address')): ?>
              <textarea class="form-control" name="<?= $field ?>" rows="<?= $field==='body'?8:3 ?>" <?= $field==='body'?'required':'' ?> placeholder="<?= $field==='body'?'Gunakan placeholder seperti {{nama}}, {{tanggal}}, atau {{nopol}}':'' ?>"><?= esc($row[$field]??'') ?></textarea>
            <?php elseif(in_array($field,['active','suspended','blacklist','is_household_head'],true)): ?>
              <?= view('layout/switch_button',['name'=>$field,'checked'=>old($field,$row[$field]??($field==='active'?1:0)),'onText'=>$field==='active'?'Aktif':'Ya','offText'=>$field==='active'?'Nonaktif':'Tidak']) ?>
            <?php else: ?>
              <input class="form-control" name="<?= $field ?>" value="<?= esc($row[$field]??'') ?>"
                <?= in_array($field,['name','code','username','identity_no','card_no','plate_no','template_name','console_slug'],true)||($module==='email-recipients'&&$field==='email')?'required':'' ?>
                <?= in_array($field,['birth_date','expires_at'],true)?'type="date"':'' ?>
                <?= in_array($field,['email'],true)?'type="email"':'' ?>
                <?= $module==='email-recipients'&&in_array($field,['email','cc'],true)?'placeholder="email1@domain.com, email2@domain.com"':'' ?>
                <?= $module==='gates'&&$field==='console_slug'?'placeholder="main-in" pattern="[a-z0-9]+(?:-[a-z0-9]+)*"':'' ?>>
            <?php endif ?>
          </div>
          <?php if($module==='gates'&&$field==='console_slug'): ?><small class="form-text text-muted mt-n3 mb-3 col-12">URL publik: <?= site_url('') ?><strong id="gate-url-preview"><?= esc($row[$field]??'main-in') ?></strong></small><?php endif ?>
        <?php endforeach ?>

        <?php if($module==='users'): ?>
          <div class="form-group col-md-6"><label>Password <?= isset($row['id'])?'<small class="text-muted">(kosongkan jika tidak diubah)</small>':'' ?></label><div class="input-group"><input type="password" class="form-control" id="user-password" name="password" minlength="8" autocomplete="new-password" <?= empty($row['id'])?'required':'' ?>><div class="input-group-append"><button type="button" class="btn btn-outline-secondary toggle-password" data-target="user-password"><i class="fas fa-eye"></i></button></div></div><small class="form-text text-muted">Minimal 8 karakter.</small></div>
          <div class="form-group col-md-6"><label>Konfirmasi Password</label><div class="input-group"><input type="password" class="form-control" id="user-password-confirm" name="password_confirm" minlength="8" autocomplete="new-password" <?= empty($row['id'])?'required':'' ?>><div class="input-group-append"><button type="button" class="btn btn-outline-secondary toggle-password" data-target="user-password-confirm"><i class="fas fa-eye"></i></button></div></div></div>
        <?php endif ?>

        <?php if($module==='residents'): ?>
          <div class="col-12"><hr><h5><i class="fas fa-paperclip mr-2"></i>Dokumen Pendukung</h5><p class="text-muted">Unggah KTP, KK, atau dokumen lain. Maksimal 5 MB per file; format JPG, PNG, WebP, atau PDF.</p></div>
          <div class="col-12" id="document-rows">
            <div class="row document-row">
              <div class="form-group col-md-3"><label>Jenis Dokumen</label><select class="form-control" name="document_type[]"><option value="ktp">KTP</option><option value="kk">KK</option><option value="other">Lainnya</option></select></div>
              <div class="form-group col-md-4"><label>File</label><input type="file" class="form-control-file border rounded p-2" name="supporting_files[]" accept=".jpg,.jpeg,.png,.webp,.pdf"></div>
              <div class="form-group col-md-4"><label>Remark</label><input class="form-control" name="document_remark[]" placeholder="Keterangan dokumen"></div>
              <div class="form-group col-md-1 d-flex align-items-end"><button type="button" class="btn btn-outline-danger remove-document-row" title="Hapus baris"><i class="fas fa-times"></i></button></div>
            </div>
          </div>
          <div class="col-12 mb-3"><button type="button" class="btn btn-outline-info btn-sm" id="add-document-row"><i class="fas fa-plus"></i> Tambah Dokumen</button></div>
        <?php endif ?>
      </div>
    </div>
    <div class="card-footer"><button class="btn btn-success"><i class="fas fa-save"></i> Simpan</button> <a class="btn btn-secondary" href="<?= site_url("master/$module") ?>">Kembali</a></div>
  </form>
</div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
$('.toggle-password').on('click',function(){const input=document.getElementById(this.dataset.target);input.type=input.type==='password'?'text':'password';$(this).find('i').toggleClass('fa-eye fa-eye-slash')});
const gateSlug=document.querySelector('input[name="console_slug"]');if(gateSlug)gateSlug.addEventListener('input',()=>{document.getElementById('gate-url-preview').textContent=gateSlug.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')});
$('#add-document-row').on('click',function(){const row=$('.document-row').first().clone();row.find('input').val('');row.find('select').val('other');$('#document-rows').append(row)});
$(document).on('click','.remove-document-row',function(){if($('.document-row').length>1)$(this).closest('.document-row').remove();else $(this).closest('.document-row').find('input').val('')});
</script>
<?= $this->endSection() ?>
