<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<style>
.menu-tree,.menu-tree ul{list-style:none;margin:0;padding-left:0}.menu-tree ul{padding-left:34px;border-left:1px dashed #c8d1dc;margin-left:17px}.menu-node{display:flex;align-items:center;gap:10px;padding:10px 12px;margin:6px 0;border:1px solid #e1e6eb;border-radius:8px;background:#fff}.menu-node:hover{background:#f7fafc}.menu-toggle{width:24px;text-align:center;cursor:pointer}.menu-name{font-weight:600}.menu-meta{font-size:12px;color:#77808a}.menu-actions{margin-left:auto;white-space:nowrap}.menu-children.collapsed{display:none}
</style>
<div class="card">
  <div class="card-header d-flex align-items-center">
    <a href="<?= site_url('master/menus/form') ?>" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Menu</a>
    <span class="text-muted ml-3">Klik nama menu untuk mengubah data.</span>
  </div>
  <div class="card-body">
    <?php if(!$menuTree): ?><div class="alert alert-info mb-0">Belum ada menu aktif.</div><?php endif ?>
    <?= view('master/menu_tree_nodes',['nodes'=>$menuTree]) ?>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>$(document).on('click','.menu-toggle[data-target]',function(){const child=$('#'+this.dataset.target);child.toggleClass('collapsed');$(this).find('i').toggleClass('fa-caret-down fa-caret-right')});</script>
<?= $this->endSection() ?>
