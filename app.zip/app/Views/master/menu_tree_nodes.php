<?php if($nodes): ?><ul class="menu-tree"><?php foreach($nodes as $node): ?>
<li>
  <div class="menu-node">
    <?php if($node['children']): ?><span class="menu-toggle" data-target="children-<?= $node['id'] ?>"><i class="fas fa-caret-down"></i></span><?php else: ?><span class="menu-toggle text-muted"><i class="far fa-circle"></i></span><?php endif ?>
    <i class="<?= esc($node['icon']?:'far fa-circle') ?> text-primary"></i>
    <div>
      <a class="menu-name" href="<?= site_url('master/menus/form/'.$node['id']) ?>"><?= esc($node['name']) ?></a>
      <div class="menu-meta"><?= esc($node['route']?:'Menu induk') ?> · urutan <?= (int)$node['sort_order'] ?> · <?= $node['active']?'aktif':'nonaktif' ?></div>
    </div>
    <div class="menu-actions">
      <a class="btn btn-sm btn-primary" title="Edit" href="<?= site_url('master/menus/form/'.$node['id']) ?>"><i class="fas fa-edit"></i></a>
      <form method="post" action="<?= site_url('master/menus/delete/'.$node['id']) ?>" class="d-inline" onsubmit="return confirm('Arsipkan menu <?= esc($node['name'],'js') ?><?= $node['children']?' beserta seluruh turunannya':'' ?>?')"><button class="btn btn-sm btn-danger" title="Soft delete"><i class="fas fa-archive"></i></button></form>
    </div>
  </div>
  <?php if($node['children']): ?><div class="menu-children" id="children-<?= $node['id'] ?>"><?= view('master/menu_tree_nodes',['nodes'=>$node['children']]) ?></div><?php endif ?>
</li>
<?php endforeach ?></ul><?php endif ?>
