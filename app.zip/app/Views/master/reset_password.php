<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="row justify-content-center">
  <div class="col-md-7">
    <div class="card card-warning">
      <div class="card-header"><h3 class="card-title"><i class="fas fa-key mr-2"></i>Reset Password</h3></div>
      <form method="post">
        <div class="card-body">
          <div class="alert alert-light border">
            <strong><?= esc($user['name']) ?></strong><br>
            <span class="text-muted">Username: <?= esc($user['username']) ?></span>
          </div>
          <div class="form-group">
            <label>Password Baru</label>
            <div class="input-group">
              <input type="password" class="form-control" id="reset-password" name="password" minlength="8" autocomplete="new-password" required autofocus>
              <div class="input-group-append"><button type="button" class="btn btn-outline-secondary toggle-password" data-target="reset-password"><i class="fas fa-eye"></i></button></div>
            </div>
            <small class="form-text text-muted">Minimal 8 karakter.</small>
          </div>
          <div class="form-group">
            <label>Konfirmasi Password Baru</label>
            <div class="input-group">
              <input type="password" class="form-control" id="reset-password-confirm" name="password_confirm" minlength="8" autocomplete="new-password" required>
              <div class="input-group-append"><button type="button" class="btn btn-outline-secondary toggle-password" data-target="reset-password-confirm"><i class="fas fa-eye"></i></button></div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-warning" onclick="return confirm('Reset password pengguna ini?')"><i class="fas fa-key"></i> Reset Password</button>
          <a class="btn btn-secondary" href="<?= site_url('master/users') ?>">Kembali</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>$('.toggle-password').on('click',function(){const input=document.getElementById(this.dataset.target);input.type=input.type==='password'?'text':'password';$(this).find('i').toggleClass('fa-eye fa-eye-slash')});</script>
<?= $this->endSection() ?>
