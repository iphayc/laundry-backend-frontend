<div class="row">
<?php foreach(['Nama'=>$resident['name'],'Jenis Kelamin'=>$resident['gender']==='male'?'Laki-laki':($resident['gender']==='female'?'Perempuan':'-'),'Tanggal Lahir'=>$resident['birth_date']?:'-','No. KTP'=>$resident['identity_no']?:'-','Alamat Lengkap'=>$resident['address']?:'-','Telepon'=>$resident['phone']?:'-','Email'=>$resident['email']?:'-','Cluster'=>$resident['cluster_name']?:'-','Unit'=>$resident['unit_no']?:'-','Grup / Kepala Rumah Tangga'=>(int)$resident['is_household_head']===1?$resident['name'].' (Kepala)':($resident['household_head_name']?:'-')] as $label=>$value): ?>
<div class="col-md-6 mb-3"><small class="text-muted d-block"><?= esc($label) ?></small><strong><?= esc($value) ?></strong></div>
<?php endforeach ?></div>
<hr><h5><i class="fas fa-images mr-2"></i>Dokumen Pendukung</h5>
<?php if(!$documents): ?><div class="alert alert-light border text-center text-muted">Belum ada dokumen pendukung yang diunggah.</div><?php else: ?><div class="row">
<?php foreach($documents as $document): $url=site_url('master/residents/documents/view/'.$document['id']);$isImage=str_starts_with((string)$document['mime_type'],'image/'); ?>
<div class="col-md-6 col-lg-4 mb-3"><div class="card h-100 border shadow-none">
<?php if($isImage): ?><a href="<?= $url ?>" target="_blank" rel="noopener"><img src="<?= $url ?>" class="card-img-top" alt="<?= esc($document['original_name']) ?>" style="height:180px;object-fit:contain;background:#f4f6f9"></a><?php else: ?><div class="text-center py-5 bg-light"><i class="fas fa-file-pdf fa-4x text-danger"></i></div><?php endif ?>
<div class="card-body p-3"><span class="badge badge-info"><?= strtoupper(esc($document['document_type'])) ?></span><div class="font-weight-bold text-truncate mt-2" title="<?= esc($document['original_name']) ?>"><?= esc($document['original_name']) ?></div><small class="text-muted"><?= esc($document['remark']?:'Tanpa keterangan') ?> · <?= number_format(((int)$document['file_size'])/1024,1) ?> KB</small></div>
<div class="card-footer bg-white p-2"><a class="btn btn-sm btn-outline-primary btn-block" href="<?= $url ?>" target="_blank" rel="noopener"><i class="fas fa-external-link-alt"></i> Buka Dokumen</a></div>
</div></div><?php endforeach ?></div><?php endif ?>
