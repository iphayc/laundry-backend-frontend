<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= esc($title??'Home') ?> | Eksis Laundry</title>
  <link rel="icon" href="<?= base_url('images/eksis-laundry-logo.png') ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
  <style>
    :root{--primary:#168a72;--dark:#0d5547;--ink:#17332d;--soft:#eff9f6;--line:#dceae6}
    html{scroll-behavior:smooth}body{font-family:Arial,sans-serif;color:var(--ink);padding-top:76px}
    .site-nav{min-height:76px;background:rgba(255,255,255,.97);box-shadow:0 3px 22px rgba(17,66,55,.09);backdrop-filter:blur(10px)}
    .navbar-brand{font-size:1.3rem;font-weight:800;color:var(--ink)!important}.brand-icon{width:42px;height:42px;border-radius:13px;background:var(--primary);color:#fff;display:grid;place-items:center}
    .nav-link{font-weight:700;color:#46645d!important;padding:.75rem 1rem!important}.nav-link:hover{color:var(--primary)!important}
    .btn-eksis{background:var(--primary);border-color:var(--primary);color:#fff;border-radius:999px;font-weight:700;padding:.72rem 1.4rem}.btn-eksis:hover{background:var(--dark);color:#fff}
    .section{padding:84px 0}.section-soft{background:var(--soft)}.section-title{font-weight:800;font-size:2.35rem}.section-kicker{color:var(--primary);font-weight:800;text-transform:uppercase;letter-spacing:.12em}
    .content-card{height:100%;border:1px solid var(--line);border-radius:22px;box-shadow:0 10px 35px rgba(18,74,61,.08);background:#fff}.feature-icon{width:58px;height:58px;border-radius:17px;background:#e5f5f1;color:var(--primary);display:grid;place-items:center;font-size:24px}
    .site-footer{background:#0d332c;color:#cfe1dc;padding:55px 0 24px}.site-footer a{color:#fff}.form-control{border-radius:12px;border-color:var(--line);min-height:48px}
    @media(max-width:991px){body{padding-top:68px}.navbar-collapse{padding:1rem 0}.section{padding:60px 0}}
  </style>
  <?= $this->renderSection('styles') ?>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light fixed-top site-nav"><div class="container">
    <a class="navbar-brand d-flex align-items-center" href="<?= site_url('/') ?>"><span class="brand-icon mr-2"><i class="fas fa-tshirt"></i></span>Eksis Laundry</a>
    <button class="navbar-toggler" data-toggle="collapse" data-target="#publicNav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="publicNav"><ul class="navbar-nav ml-auto align-items-lg-center">
      <?php foreach([['/','Home'],['profil','Profil'],['paket','Paket'],['panduan','Panduan'],['kontak','Kontak']] as $menu): ?><li class="nav-item"><a class="nav-link" href="<?= site_url($menu[0]) ?>"><?= $menu[1] ?></a></li><?php endforeach ?>
    </ul></div>
  </div></nav>
  <?= $this->renderSection('content') ?>
  <footer class="site-footer"><div class="container"><div class="row">
    <div class="col-lg-5 mb-4"><h4 class="font-weight-bold text-white"><i class="fas fa-tshirt mr-2"></i>Eksis Laundry</h4><p class="mt-3">Sistem pengelolaan laundry modern untuk usaha yang ingin bekerja lebih rapi, cepat, dan terukur.</p></div>
    <div class="col-lg-4 mb-4"><h5 class="font-weight-bold text-white">Hubungi Kami</h5><p><i class="fas fa-phone mr-2"></i><?= esc($company['phone']??'-') ?></p><p><i class="fas fa-envelope mr-2"></i><?= esc($company['email']??'-') ?></p></div>
    <div class="col-lg-3"><h5 class="font-weight-bold text-white">Menu</h5><?php foreach([['/','Home'],['profil','Profil'],['paket','Paket'],['panduan','Panduan'],['kontak','Kontak']] as $menu): ?><a class="d-block mb-2" href="<?= site_url($menu[0]) ?>"><?= $menu[1] ?></a><?php endforeach ?></div>
  </div><hr style="border-color:rgba(255,255,255,.15)"><small>&copy; <?= date('Y') ?> Eksis Software Technology. All rights reserved.</small></div></footer>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <?= view('layout/toasts') ?><?= $this->renderSection('scripts') ?>
</body></html>
