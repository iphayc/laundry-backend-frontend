<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<?php if(!$smtpReady): ?><div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> SMTP aktif belum dikonfigurasi. <a href="<?= site_url('settings/email') ?>">Buka Setting SMTP</a>.</div><?php endif ?>
<div class="card card-info"><form method="post"><div class="card-body">
  <div class="row"><div class="form-group col-md-6"><label>Dari</label><input type="date" name="from" class="form-control" value="<?= esc($from) ?>" required></div><div class="form-group col-md-6"><label>Sampai</label><input type="date" name="to" class="form-control" value="<?= esc($to) ?>" required></div></div>
  <label>Penerima</label>
  <?php if(!$recipients): ?><div class="alert alert-light border">Belum ada penerima aktif. <a href="<?= site_url('master/email-recipients/form') ?>">Tambah penerima email</a>.</div><?php endif ?>
  <div class="row"><?php foreach($recipients as $recipient): ?><div class="col-md-6"><div class="custom-control custom-checkbox mb-3"><input type="checkbox" class="custom-control-input" name="recipient_ids[]" value="<?= $recipient['id'] ?>" id="recipient-<?= $recipient['id'] ?>"><label class="custom-control-label" for="recipient-<?= $recipient['id'] ?>"><?= esc($recipient['name']) ?><br><small class="text-muted">To: <?= esc($recipient['email']) ?></small><?php if($recipient['cc']): ?><br><small class="text-muted">CC: <?= esc($recipient['cc']) ?></small><?php endif ?></label></div></div><?php endforeach ?></div>
</div><div class="card-footer"><button class="btn btn-info" <?= (!$smtpReady||!$recipients)?'disabled':'' ?>><i class="fas fa-paper-plane"></i> Kirim Laporan</button> <a class="btn btn-secondary" href="<?= site_url('reports') ?>">Kembali</a></div></form></div>
<?= $this->endSection() ?>
