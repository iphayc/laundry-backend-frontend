<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="alert alert-info">
    <i class="fas fa-info-circle mr-1"></i>
    Konfigurasi <b>Admin</b> khusus OTP dan pesan platform.
    Konfigurasi <b>Customer</b> dipakai untuk QR linked device serta pengiriman struk dari aplikasi laundry.
</div>

<?php
$adminConnection = $adminConnection ?? [
    'connection' => 'unknown',
    'connected' => false,
    'phone' => $admin['phone_number'] ?? null,
    'gateway_available' => false,
];
$adminQr = $adminQr ?? null;
?>

<div class="row">

    <!-- ========================= ADMIN ========================= -->
    <div class="col-xl-6">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    Gateway Admin / OTP
                </h3>
            </div>

            <div class="card-body">
                <p class="text-muted">
                    OTP registrasi, login, dan notifikasi platform.
                    WhatsApp Admin didaftarkan melalui Linked Device di bawah ini.
                </p>

                <?php if (!empty($adminMessage)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle mr-1"></i>
                        <?= esc($adminMessage) ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($adminError)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle mr-1"></i>
                        <?= esc($adminError) ?>
                    </div>
                <?php endif; ?>

                <!-- ADMIN WHATSAPP CONNECTION -->
                <div class="border rounded p-3 mb-4 bg-light">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h5 class="font-weight-bold mb-1">
                                <i class="fab fa-whatsapp text-success mr-1"></i>
                                WhatsApp Admin
                            </h5>
                            <small class="text-muted">
                                Digunakan untuk OTP dan notifikasi platform.
                            </small>
                        </div>

                        <span id="admin-wa-badge"
                              class="badge <?= !empty($adminConnection['connected']) ? 'badge-success' : 'badge-secondary' ?> p-2">
                            <?= !empty($adminConnection['connected']) ? 'TERHUBUNG' : 'BELUM TERHUBUNG' ?>
                        </span>
                    </div>

                    <div id="admin-wa-phone-wrap"
                         class="<?= !empty($adminConnection['phone']) ? '' : 'd-none' ?>">
                        <div class="alert alert-success py-2 mb-3">
                            <i class="fas fa-check-circle mr-1"></i>
                            Nomor:
                            <strong id="admin-wa-phone">
                                <?= esc($adminConnection['phone'] ?? '') ?>
                            </strong>
                        </div>
                    </div>

                    <div id="admin-wa-qr-wrap"
                         class="<?= $adminQr ? '' : 'd-none' ?>">
                        <div class="text-center">
                            <div class="font-weight-bold mb-2">
                                Scan QR menggunakan WhatsApp Admin
                            </div>

                            <div class="d-inline-block bg-white border rounded p-3 shadow-sm">
                                <img id="admin-wa-qr"
                                     src="<?= esc($adminQr ?? '') ?>"
                                     alt="QR WhatsApp Admin"
                                     style="width:280px;height:280px;object-fit:contain;">
                            </div>

                            <div class="text-muted mt-2 small">
                                Buka WhatsApp di HP →
                                <b>Perangkat Tertaut</b> →
                                <b>Tautkan Perangkat</b> →
                                scan QR di atas.
                            </div>
                        </div>
                    </div>

                    <div id="admin-wa-connecting"
                         class="<?= ($adminConnection['connection'] ?? '') === 'connecting' ? '' : 'd-none' ?>">
                        <div class="alert alert-warning py-2 mb-3">
                            <i class="fas fa-spinner fa-spin mr-1"></i>
                            Menunggu WhatsApp Admin melakukan scan QR...
                        </div>
                    </div>

                    <div class="d-flex flex-wrap" style="gap:8px;">
                        <?php if (!empty($adminConnection['connected'])): ?>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="profile" value="ADMIN">
                                <input type="hidden" name="action" value="logout-admin">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-sign-out-alt mr-1"></i>
                                    Logout WhatsApp Admin
                                </button>
                            </form>
                        <?php else: ?>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="profile" value="ADMIN">
                                <input type="hidden" name="action" value="connect-admin">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-qrcode mr-1"></i>
                                    <?= $adminQr ? 'Refresh QR WhatsApp' : 'Tampilkan QR WhatsApp' ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- TECHNICAL ADMIN CONFIG -->
                <form method="post">
                    <input type="hidden" name="profile" value="ADMIN">

                    <div class="form-group">
                        <label>URL Node Engine</label>
                        <input type="url"
                               class="form-control"
                               name="node_engine_url"
                               required
                               value="<?= esc($admin['node_engine_url'] ?? 'https://gateway.eksissoftware.com') ?>"
                               placeholder="http://localhost:3000">
                    </div>

                    <div class="form-group">
                        <label>URL Send</label>
                        <input type="url"
                               class="form-control"
                               name="send_url"
                               required
                               value="<?= esc($admin['send_url'] ?? 'https://gateway.eksissoftware.com/index.php/wa/send-message') ?>"
                               placeholder="http://localhost:3000/wa/send-message">
                        <small class="text-muted">
                            Payload JSON: number, message. Header: x-api-key.
                        </small>
                    </div>

                    <div class="form-group">
                        <label>URL QR</label>
                        <input type="url"
                               class="form-control"
                               name="qr_url"
                               required
                               value="<?= esc($admin['qr_url'] ?? 'https://gateway.eksissoftware.com/index.php/wa/qr') ?>"
                               placeholder="https://gateway.eksissoftware.com/index.php/wa/qr">
                        <small class="text-muted">
                            Session Admin otomatis menggunakan <code>ADMIN-WA-1</code>.
                        </small>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>No. HP Admin</label>
                            <input class="form-control"
                                   name="phone_number"
                                   value="<?= esc($admin['phone_number'] ?? '') ?>"
                                   placeholder="Otomatis setelah WhatsApp terhubung">
                            <small class="text-muted">
                                Terisi otomatis setelah QR berhasil discan.
                            </small>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Jeda Pengiriman (detik)</label>
                            <input type="number"
                                   min="0"
                                   max="3600"
                                   class="form-control"
                                   name="send_delay_seconds"
                                   value="<?= esc($admin['send_delay_seconds'] ?? 2) ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>
                            API Key
                            <small class="text-muted">(kosongkan jika tidak diubah)</small>
                        </label>
                        <input type="password"
                               class="form-control"
                               name="api_key"
                               autocomplete="new-password">
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox"
                               class="custom-control-input"
                               id="active-admin"
                               name="is_active"
                               value="1"
                               <?= !empty($admin['is_active']) ? 'checked' : '' ?>>
                        <label class="custom-control-label" for="active-admin">
                            Gateway admin aktif
                        </label>
                    </div>

                    <div class="mt-3 d-flex flex-wrap" style="gap:8px;">
                        <button name="action"
                                value="save"
                                class="btn btn-success">
                            <i class="fas fa-save mr-1"></i>
                            Simpan Admin
                        </button>

                        <button name="action"
                                value="test"
                                class="btn btn-outline-primary">
                            <i class="fab fa-whatsapp mr-1"></i>
                            Test WhatsApp
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ========================= CUSTOMER ========================= -->
    <div class="col-xl-6">
        <div class="card card-outline card-success">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    Gateway Customer / Linked Device
                </h3>
            </div>

            <form method="post">
                <input type="hidden" name="profile" value="CUSTOMER">

                <div class="card-body">
                    <p class="text-muted">
                        Hubungkan WhatsApp outlet/customer melalui Linked Device.
                        Session WhatsApp customer digunakan untuk mengirim struk dan notifikasi pesanan.
                    </p>

                    <div class="alert alert-info py-2">
                        <i class="fas fa-info-circle mr-1"></i>
                        <b>Format struk WhatsApp</b> menggunakan formatter backend yang sama
                        untuk Linked Device dan WhatsApp dari aplikasi mobile.
                        Jika format struk ingin diubah, cukup ubah template/formatter di backend.
                    </div>

                    <div class="border rounded p-3 mb-4 bg-light">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h5 class="font-weight-bold mb-1">
                                    <i class="fab fa-whatsapp text-success mr-1"></i>
                                    Linked Device Customer
                                </h5>
                                <small class="text-muted">
                                    Scan QR dengan WhatsApp yang digunakan oleh outlet.
                                </small>
                            </div>

                            <span id="customer-wa-badge"
                                  class="badge badge-secondary p-2">
                                CEK STATUS
                            </span>
                        </div>

                        <div id="customer-wa-phone-wrap" class="d-none">
                            <div class="alert alert-success py-2 mb-3">
                                <i class="fas fa-check-circle mr-1"></i>
                                Nomor:
                                <strong id="customer-wa-phone"></strong>
                            </div>
                        </div>

                        <div id="customer-wa-qr-wrap" class="d-none">
                            <div class="text-center">
                                <div class="font-weight-bold mb-2">
                                    Scan QR WhatsApp Customer
                                </div>

                                <div class="d-inline-block bg-white border rounded p-3 shadow-sm">
                                    <img id="customer-wa-qr"
                                         src=""
                                         alt="QR WhatsApp Customer"
                                         style="width:280px;height:280px;object-fit:contain;">
                                </div>

                                <div class="text-muted mt-2 small">
                                    Buka WhatsApp di HP →
                                    <b>Perangkat Tertaut</b> →
                                    <b>Tautkan Perangkat</b> →
                                    scan QR di atas.
                                </div>
                            </div>
                        </div>

                        <div id="customer-wa-connecting" class="d-none">
                            <div class="alert alert-warning py-2 mb-3">
                                <i class="fas fa-spinner fa-spin mr-1"></i>
                                Menunggu WhatsApp Customer melakukan scan QR...
                            </div>
                        </div>

                        <div id="customer-wa-message" class="small text-muted"></div>
                    </div>

                    <div class="form-group">
                        <label>URL Node Engine</label>
                        <input type="url"
                               class="form-control"
                               name="node_engine_url"
                               required
                               value="<?= esc($customer['node_engine_url'] ?? 'https://gateway.eksissoftware.com') ?>"
                               placeholder="http://localhost:3000">
                    </div>

                    <div class="form-group">
                        <label>URL Send</label>
                        <input type="url"
                               class="form-control"
                               name="send_url"
                               required
                               value="<?= esc($customer['send_url'] ?? 'https://gateway.eksissoftware.com/index.php/wa/send-message') ?>"
                               placeholder="http://localhost:3000/wa/send-message">
                        <small class="text-muted">
                            Payload JSON: number, message, session_key. Header: x-api-key.
                        </small>
                    </div>

                    <div class="form-group">
                        <label>URL QR</label>
                        <input type="url"
                               class="form-control"
                               name="qr_url"
                               required
                               value="<?= esc($customer['qr_url'] ?? 'https://gateway.eksissoftware.com/index.php/wa/qr') ?>"
                               placeholder="https://gateway.eksissoftware.com/index.php/wa/qr">
                        <small class="text-muted">
                            Session customer ditentukan otomatis dari company.
                        </small>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>No. HP Test</label>
                            <input class="form-control"
                                   name="phone_number"
                                   value="<?= esc($customer['phone_number'] ?? '') ?>"
                                   placeholder="Tidak digunakan - nomor berasal dari session customer"
                                   readonly>
                            <small class="text-muted">
                                Nomor WhatsApp customer disimpan pada ex_whatsapp_sessions.phone.
                            </small>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Jeda Pengiriman (detik)</label>
                            <input type="number"
                                   min="0"
                                   max="3600"
                                   class="form-control"
                                   name="send_delay_seconds"
                                   value="<?= esc($customer['send_delay_seconds'] ?? 2) ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>
                            API Key
                            <small class="text-muted">(kosongkan jika tidak diubah)</small>
                        </label>
                        <input type="password"
                               class="form-control"
                               name="api_key"
                               autocomplete="new-password">
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox"
                               class="custom-control-input"
                               id="active-customer"
                               name="is_active"
                               value="1"
                               <?= !empty($customer['is_active']) ? 'checked' : '' ?>>
                        <label class="custom-control-label" for="active-customer">
                            Gateway customer aktif
                        </label>
                    </div>
                </div>

                <div class="card-footer d-flex flex-wrap" style="gap:8px;">
                    <button name="action"
                            value="save"
                            class="btn btn-success">
                        <i class="fas fa-save mr-1"></i>
                        Simpan Customer
                    </button>

                    <button name="action"
                            value="test"
                            class="btn btn-outline-primary">
                        <i class="fab fa-whatsapp mr-1"></i>
                        Test WhatsApp
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
(function () {
    const statusUrl = <?= json_encode(site_url('settings/eksis-whatsapp/admin-status')) ?>;
    const qrUrl = <?= json_encode(site_url('settings/eksis-whatsapp/admin-qr')) ?>;

    // Endpoint CUSTOMER sengaja hanya diaktifkan jika controller menyediakan
    // customer-status/customer-qr. Dengan demikian halaman tidak melakukan
    // request ke URL yang belum tersedia.
    const customerStatusUrl = <?= json_encode(site_url('settings/eksis-whatsapp/customer-status')) ?>;
    const customerQrUrl = <?= json_encode(site_url('settings/eksis-whatsapp/customer-qr')) ?>;

    const badge = document.getElementById('admin-wa-badge');
    const phoneWrap = document.getElementById('admin-wa-phone-wrap');
    const phone = document.getElementById('admin-wa-phone');
    const qrWrap = document.getElementById('admin-wa-qr-wrap');
    const qrImage = document.getElementById('admin-wa-qr');
    const connecting = document.getElementById('admin-wa-connecting');

    if (!badge) return;

    function setStatus(data) {
        if (!data || !data.success) return;

        const connected = !!data.connected;
        const state = data.connection || (connected ? 'connected' : 'disconnected');

        badge.textContent = connected ? 'TERHUBUNG' :
            (state === 'connecting' ? 'MENUNGGU SCAN' : 'BELUM TERHUBUNG');

        badge.className = 'badge p-2 ' +
            (connected ? 'badge-success' :
                state === 'connecting' ? 'badge-warning' : 'badge-secondary');

        if (data.phone) {
            phone.textContent = data.phone;
            phoneWrap.classList.remove('d-none');
        } else if (!connected) {
            phoneWrap.classList.add('d-none');
        }

        if (connected) {
            qrWrap.classList.add('d-none');
            connecting.classList.add('d-none');
        } else if (state === 'connecting') {
            connecting.classList.remove('d-none');
        }
    }

    async function pollStatus() {
        try {
            const response = await fetch(statusUrl, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {'Accept': 'application/json'}
            });

            const data = await response.json();
            setStatus(data);

            // Jika session sedang menunggu scan dan QR belum ada,
            // minta QR terbaru melalui backend tanpa mengekspos API key.
            if (data.success && data.connection === 'connecting' &&
                qrWrap.classList.contains('d-none')) {
                const qrResponse = await fetch(qrUrl, {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });

                const qrData = await qrResponse.json();

                if (qrData.success && qrData.qr) {
                    qrImage.src = qrData.qr;
                    qrWrap.classList.remove('d-none');
                }

                setStatus(qrData);
            }
        } catch (e) {
            // Jangan mengganggu halaman jika gateway sedang restart.
        }
    }

    const customerBadge = document.getElementById('customer-wa-badge');
    const customerPhoneWrap = document.getElementById('customer-wa-phone-wrap');
    const customerPhone = document.getElementById('customer-wa-phone');
    const customerQrWrap = document.getElementById('customer-wa-qr-wrap');
    const customerQrImage = document.getElementById('customer-wa-qr');
    const customerConnecting = document.getElementById('customer-wa-connecting');
    const customerMessage = document.getElementById('customer-wa-message');

    function setCustomerStatus(data) {
        if (!customerBadge || !data || !data.success) return;

        const connected = !!data.connected;
        const state = data.connection || (connected ? 'connected' : 'disconnected');

        customerBadge.textContent = connected ? 'TERHUBUNG' :
            (state === 'connecting' ? 'MENUNGGU SCAN' : 'BELUM TERHUBUNG');

        customerBadge.className = 'badge p-2 ' +
            (connected ? 'badge-success' :
                state === 'connecting' ? 'badge-warning' : 'badge-secondary');

        if (data.phone) {
            customerPhone.textContent = data.phone;
            customerPhoneWrap.classList.remove('d-none');
        } else if (!connected) {
            customerPhoneWrap.classList.add('d-none');
        }

        if (connected) {
            customerQrWrap.classList.add('d-none');
            customerConnecting.classList.add('d-none');
        } else if (state === 'connecting') {
            customerConnecting.classList.remove('d-none');
        }
    }

    async function pollCustomerStatus() {
        try {
            const response = await fetch(customerStatusUrl, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {'Accept': 'application/json'}
            });

            // Controller customer-status harus mengembalikan success=false/404
            // sampai endpoint customer benar-benar tersedia.
            if (!response.ok) return;

            const data = await response.json();
            setCustomerStatus(data);

            if (data.success && data.connection === 'connecting' &&
                customerQrWrap.classList.contains('d-none')) {

                const qrResponse = await fetch(customerQrUrl, {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });

                if (!qrResponse.ok) return;

                const qrData = await qrResponse.json();

                if (qrData.success && qrData.qr) {
                    customerQrImage.src = qrData.qr;
                    customerQrWrap.classList.remove('d-none');
                }

                setCustomerStatus(qrData);
            }
        } catch (e) {
            // Jangan mengganggu halaman jika gateway customer sedang restart.
        }
    }

    pollCustomerStatus();
    setInterval(pollCustomerStatus, 5000);

    setInterval(pollStatus, 5000);
})();
</script>

<?= $this->endSection() ?>