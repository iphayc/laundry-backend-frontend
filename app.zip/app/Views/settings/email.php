<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<div class="card card-primary">
  <form method="post" id="email-setting-form">
    <div class="card-body"><div class="row">
      <div class="form-group col-md-6"><label>Nama Akun</label><input class="form-control" name="account_name" value="<?= esc(old('account_name',$setting['account_name']??'Eksis Laundry SMTP')) ?>" placeholder="Eksis Laundry SMTP" required></div>
      <div class="form-group col-md-6"><label>SMTP Host</label><input class="form-control" name="smtp_host" value="<?= esc(old('smtp_host',$setting['smtp_host']??'')) ?>" placeholder="smtp.gmail.com" required></div>
      <div class="form-group col-md-3"><label>SMTP Port</label><input type="number" class="form-control" name="smtp_port" value="<?= esc(old('smtp_port',$setting['smtp_port']??587)) ?>" required></div>
      <div class="form-group col-md-3"><label>Enkripsi</label><select class="form-control" name="smtp_crypto"><?php foreach(['tls'=>'TLS','ssl'=>'SSL','none'=>'Tanpa Enkripsi'] as $value=>$label): ?><option value="<?= $value ?>" <?= old('smtp_crypto',$setting['smtp_crypto']??'tls')===$value?'selected':'' ?>><?= $label ?></option><?php endforeach ?></select></div>
      <div class="form-group col-md-6"><label>SMTP Username</label><input class="form-control" name="smtp_user" value="<?= esc(old('smtp_user',$setting['smtp_user']??'')) ?>" autocomplete="off"></div>
      <div class="form-group col-md-6"><label>SMTP Password <small class="text-muted"><?= $setting?'(kosongkan jika tidak diubah)':'' ?></small></label><div class="input-group"><input type="password" class="form-control" id="smtp-password" name="smtp_password" autocomplete="new-password"><div class="input-group-append"><button type="button" class="btn btn-outline-secondary" id="toggle-smtp"><i class="fas fa-eye"></i></button></div></div><small class="text-muted">Password disimpan terenkripsi.</small></div>
      <div class="form-group col-md-6"><label>Email Pengirim</label><input type="email" class="form-control" name="from_email" value="<?= esc(old('from_email',$setting['from_email']??'')) ?>" required></div>
      <div class="form-group col-md-6"><label>Nama Pengirim</label><input class="form-control" name="from_name" value="<?= esc(old('from_name',$setting['from_name']??'Eksis Laundry')) ?>" required></div>
      <div class="form-group col-md-6"><label>Status</label><?= view('layout/switch_button',['name'=>'active','checked'=>old('active',$setting['active']??1),'onText'=>'Aktif','offText'=>'Nonaktif']) ?></div>
    </div></div>
    <div class="card-footer">
      <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan SMTP</button>
      <button type="button" class="btn btn-info ml-1" id="test-email-button">
        <i class="fas fa-paper-plane"></i> Test Email
      </button>
      <small class="text-muted ml-2">Simpan konfigurasi terlebih dahulu sebelum melakukan test.</small>
    </div>
  </form>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
$('#toggle-smtp').on('click',function(){
  const i=document.getElementById('smtp-password');
  i.type=i.type==='password'?'text':'password';
  $(this).find('i').toggleClass('fa-eye fa-eye-slash');
});
document.getElementById('test-email-button').addEventListener('click',async function(){
  const button=this;
  const original=button.innerHTML;
  button.disabled=true;
  button.innerHTML='<i class="fas fa-spinner fa-spin"></i> Mengirim...';
  try{
    const response=await fetch(<?= json_encode(site_url('settings/email/test')) ?>,{
      method:'POST',
      body:new FormData(document.getElementById('email-setting-form')),
      headers:{'X-Requested-With':'XMLHttpRequest'}
    });
    const result=await response.json();
    if(!response.ok||!result.success)throw new Error(result.message||'Email testing gagal dikirim.');
    window.showAppToast?.('success','Berhasil',result.message);
  }catch(error){
    window.showAppToast?.('error','Gagal',error.message||'Email testing gagal dikirim.');
  }finally{
    button.disabled=false;
    button.innerHTML=original;
  }
});
</script>
<?= $this->endSection() ?>
