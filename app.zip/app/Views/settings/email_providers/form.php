<?= $this->extend('layout/main') ?><?= $this->section('content') ?>
<div class="card card-primary"><form method="post" action="<?= site_url('master/email-providers/save') ?>"><input type="hidden" name="id" value="<?= esc($row['id']??'') ?>"><div class="card-body"><div class="row">
<div class="form-group col-md-6"><label>Nama Akun</label><input class="form-control" name="account_name" required value="<?= esc(old('account_name',$row['account_name']??'')) ?>"></div>
<div class="form-group col-md-6"><label>SMTP Host</label><input class="form-control" name="smtp_host" required value="<?= esc(old('smtp_host',$row['smtp_host']??'')) ?>"></div>
<div class="form-group col-md-3"><label>SMTP Port</label><input type="number" class="form-control" name="smtp_port" required value="<?= esc(old('smtp_port',$row['smtp_port']??587)) ?>"></div>
<div class="form-group col-md-3"><label>Enkripsi</label><select class="form-control" name="smtp_crypto"><?php foreach(['tls'=>'TLS','ssl'=>'SSL','none'=>'Tanpa Enkripsi'] as $v=>$l): ?><option value="<?= $v ?>" <?= old('smtp_crypto',$row['smtp_crypto']??'tls')===$v?'selected':'' ?>><?= $l ?></option><?php endforeach ?></select></div>
<div class="form-group col-md-6"><label>SMTP Username</label><input class="form-control" name="smtp_user" value="<?= esc(old('smtp_user',$row['smtp_user']??'')) ?>"></div>
<div class="form-group col-md-6"><label>SMTP Password <small class="text-muted"><?= $row?'(kosongkan jika tidak diubah)':'' ?></small></label><input type="password" class="form-control" name="smtp_password" autocomplete="new-password" <?= $row?'':'required' ?>></div>
<div class="form-group col-md-6"><label>Email Pengirim</label><input type="email" class="form-control" name="from_email" required value="<?= esc(old('from_email',$row['from_email']??'')) ?>"></div>
<div class="form-group col-md-6"><label>Nama Pengirim</label><input class="form-control" name="from_name" required value="<?= esc(old('from_name',$row['from_name']??'')) ?>"></div>
<div class="form-group col-md-3"><label>Provider Default</label><?= view('layout/switch_button',['name'=>'is_default','checked'=>old('is_default',$row['is_default']??0),'onText'=>'Default','offText'=>'Bukan Default']) ?></div>
<div class="form-group col-md-3"><label>Status</label><?= view('layout/switch_button',['name'=>'active','checked'=>old('active',$row['active']??1),'onText'=>'Aktif','offText'=>'Nonaktif']) ?></div>
</div></div><div class="card-footer"><button class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button> <a class="btn btn-secondary" href="<?= site_url('master/email-providers') ?>">Kembali</a></div></form></div>
<?= $this->endSection() ?>
