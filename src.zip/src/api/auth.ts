import { api } from './client';
export type LoginPayload={identity:string;username:string;password:string;device_uuid:string;device_name:string;platform:string;app_version:string};
export type AuthResult={access_token:string;refresh_token:string;expires_in:number;user:{id:number;company_id:number;fullname:string;email:string;role:'OWNER'|'CASHIER'};device?:{registered:boolean;device_uuid?:string;device_name?:string};};
export const loginPassword=(data:LoginPayload)=>api<AuthResult>('/auth/login',{method:'POST',auth:false,body:JSON.stringify(data)});
export const sendLoginOtp=(data:{identity:string;username:string;channel:'EMAIL'|'WHATSAPP'})=>api<null>('/auth/login/send-otp',{method:'POST',auth:false,body:JSON.stringify(data)});
export const loginOtp=(data:Omit<LoginPayload,'password'>&{otp:string})=>api<AuthResult>('/auth/login/otp',{method:'POST',auth:false,body:JSON.stringify(data)});
export type RegisterPayload={fullname:string;username:string;company_name:string;email:string;phone:string;password:string;otp:string;terms_accepted:boolean;device_uuid?:string;device_name?:string;platform?:string;app_version?:string};
export const sendRegistrationOtp=(email:string)=>api<null>('/auth/send-otp',{method:'POST',auth:false,body:JSON.stringify({email,purpose:'REGISTER'})});
export const registerOwner=(data:RegisterPayload)=>api<{user_id:number;company_id:number;company_code:string}>('/auth/register',{method:'POST',auth:false,body:JSON.stringify(data)});
export const sendResetPasswordOtp=(email:string)=>api<null>('/auth/forgot-password',{method:'POST',auth:false,body:JSON.stringify({email})});
export const resetPassword=(data:{email:string;otp:string;password:string})=>api<null>('/auth/reset-password',{method:'POST',auth:false,body:JSON.stringify(data)});
export const changeOwnPassword=(data:{old_password:string;new_password:string;new_password_confirmation:string})=>api<null>('/me/password',{method:'PATCH',body:JSON.stringify(data)});

export type DeviceTransferDevice={id:number;device_uuid?:string;device_name?:string;platform?:string;branch_id?:number;branch_name?:string;last_login_at?:string|null;status?:string};
export type DeviceTransferPayload={
  identity:string;
  username:string;
  device_uuid:string;
  device_name:string;
  platform:string;
  app_version:string;
  replace_device_id?:number;
};
export const requestDeviceTransferOtp=(data:DeviceTransferPayload)=>
  api<{devices?:DeviceTransferDevice[];requires_device_selection?:boolean}>('/auth/device-transfer/request',{method:'POST',auth:false,body:JSON.stringify(data)});
export const confirmDeviceTransfer=(data:DeviceTransferPayload&{otp:string})=>
  api<AuthResult>('/auth/device-transfer/confirm',{method:'POST',auth:false,body:JSON.stringify(data)});
