import {Platform} from 'react-native';
import Constants from 'expo-constants';
import {tokenStorage} from '@/services/token-storage';
 
const defaultApiUrl=Platform.OS==='android'?'http://10.0.2.2:8080/api/v1':'http://localhost:8080/api/v1';
const API_URL=process.env.EXPO_PUBLIC_API_URL??defaultApiUrl;
 
type Options=RequestInit&{auth?:boolean};
type ApiBody<T>={success:boolean;message?:string;data:T;errors?:{reason?:string}};
 
export class ApiError extends Error {
 status:number; data:any;
 constructor(message:string,status:number,data:any=null){super(message);this.name="ApiError";this.status=status;this.data=data;}
}
 
// Dilempar secara internal ketika access token tidak lagi bisa dipulihkan
// (tidak ada refresh token, atau refresh ditolak backend). Tidak pernah
// dilempar keluar dari modul ini secara langsung — selalu ditangani di
// dalam api() sesuai jenis request (baca vs tulis).
class SessionExpiredSignal extends Error {}
 
let refreshRequest:Promise<string>|null=null;
let sessionExpiredHandler:(()=>void)|null=null;
let expirationNotified=false;
let sessionExpired=false;
 
export function setSessionExpiredHandler(handler:(()=>void)|null){
  sessionExpiredHandler=handler;
  if(handler){
    expirationNotified=false;
    // Pada web, request anak dapat berjalan sebelum effect AuthProvider
    // memasang handler. Proses expiry yang sudah terjadi tetap harus diproses.
    if(sessionExpired){expirationNotified=true;handler();}
  }
}
 
export function isApiSessionExpired(){
  return sessionExpired;
}
 
export function clearApiSessionExpired(){
  sessionExpired=false;
  expirationNotified=false;
}
 
function notifySessionExpired(){
  sessionExpired=true;
  if(expirationNotified) return;
  expirationNotified=true;
  sessionExpiredHandler?.();
}
 
async function clearSession(){
  // Pembersihan token dan navigasi dilakukan oleh AuthProvider melalui
  // sessionExpiredHandler agar seluruh aplikasi kembali ke form login.
}
 
async function markExpiredSession(){
  await clearSession();
  notifySessionExpired();
}
 
async function refreshAccessToken(){
  if(refreshRequest) return refreshRequest;
 
  refreshRequest=(async()=>{
    const refreshToken=await tokenStorage.get('refresh_token');
 
    // Refresh token tidak ada berarti memang tidak ada sesi yang
    // dapat dipulihkan.
    if(!refreshToken){await markExpiredSession();throw new SessionExpiredSignal();}
 
    let response:Response;
    try{
      const deviceUuid=await tokenStorage.get('device_uuid');
      response=await fetch(`${API_URL}/auth/refresh`,{
        method:'POST',
        headers:{Accept:'application/json','Content-Type':'application/json'},
        body:JSON.stringify({
          refresh_token:refreshToken,
          device_uuid:deviceUuid,
          app_version:Constants.expoConfig?.version??'1.0.0'
        })
      });
    }catch{
      // Jangan mengakhiri session hanya karena jaringan/backend
      // sementara tidak dapat dihubungi.
      throw new Error(`Backend tidak dapat dihubungi di ${API_URL}. Session tetap dipertahankan.`);
    }
 
    const body:ApiBody<{access_token:string;refresh_token:string;user:unknown}>=
      await response.json().catch(()=>({
        success:false,
        message:'Respons server tidak valid',
        data:null as never
      }));
 
    /* Hanya reason terminal eksplisit dari backend yang boleh logout.
     * Timeout, HTML proxy, 5xx, dan 401 generik tetap mempertahankan sesi. */
    const terminalReason=body.errors?.reason;
    const legacyRevoked=response.status===401 && body.message?.trim()==='Refresh token tidak valid.';
    const legacyVersionChanged=body.message?.includes('Versi aplikasi Anda sudah usang')===true;
    if((response.status===401 && (terminalReason==='SESSION_REVOKED'||legacyRevoked)) || terminalReason==='APP_VERSION_CHANGED' || legacyVersionChanged){
      await markExpiredSession();
      throw new SessionExpiredSignal();
    }
 
    if(!response.ok || !body.success){
      throw new Error(body.message || `Refresh session gagal (HTTP ${response.status}). Session tetap dipertahankan.`);
    }
 
    if(!body.data?.access_token || !body.data?.refresh_token){
      throw new Error('Respons refresh session tidak lengkap. Session tetap dipertahankan.');
    }
 
    await Promise.all([
      tokenStorage.set('access_token',body.data.access_token),
      tokenStorage.set('refresh_token',body.data.refresh_token),
      tokenStorage.set('user',JSON.stringify(body.data.user))
    ]);
 
    sessionExpired=false;
    expirationNotified=false;
    return body.data.access_token;
  })().finally(()=>{refreshRequest=null});
 
  return refreshRequest;
}
 
async function request<T>(path:string,options:Options,token:string|null){
  const headers=new Headers(options.headers);
  headers.set('Accept','application/json');
  if(!(options.body instanceof FormData)) headers.set('Content-Type','application/json');
  if(token) headers.set('Authorization',`Bearer ${token}`);
 
  let response:Response;
  try{
    response=await fetch(`${API_URL}${path}`,{
      cache:options.method&&options.method!=='GET'?options.cache:'no-store',
      ...options,
      headers
    });
  }catch(error){
    const detail=error instanceof Error&&error.message?` Detail: ${error.message}`:'';
    throw new Error(`Request ke ${API_URL} gagal sebelum server memberikan respons.${detail}`);
  }
 
  const raw=await response.text();
  let body:ApiBody<T>;
  try{
    body=JSON.parse(raw) as ApiBody<T>;
  }catch{
    const contentType=response.headers.get('content-type')??'tidak diketahui';
    const detail=raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);
    body={success:false,message:`Respons server tidak valid (HTTP ${response.status}, ${contentType}).${detail?` ${detail}`:''}`,data:null as T};
  }
 
  return {response,body};
}
 
function isWriteMethod(method?:string){
  const m=(method??'GET').toUpperCase();
  return m!=='GET' && m!=='HEAD' && m!=='OPTIONS';
}
 
// Sesi habis pada request BACA (GET dsb): jangan pernah melempar error yang
// bisa lolos jadi unhandled rejection di layar manapun. Data yang sudah
// tampil di UI tetap dipakai; request ini sengaja dibiarkan menggantung
// (tidak pernah resolve/reject) sehingga pemanggil yang lupa memasang
// .catch() tidak membuat aplikasi crash. Loading state terkait cukup
// berhenti berputar secara alami karena promise-nya tidak pernah selesai.
function pendingForever<T>():Promise<T>{
  return new Promise<T>(()=>{});
}
 
export async function api<T>(path:string,options:Options={}):Promise<T>{
  const needsAuth=options.auth!==false;
  const write=isWriteMethod(options.method);
 
  // Sesi sudah diketahui habis dari request sebelumnya: jangan kirim
  // operasi tulis baru sama sekali. Request baca tetap boleh dicoba
  // (misalnya untuk data publik) dan akan ditangani sesuai hasilnya.
  if(needsAuth && sessionExpired && write){
    throw new Error('Sesi telah berakhir. Data yang sudah tampil masih dapat digunakan, tetapi penyimpanan transaksi dinonaktifkan. Silakan login kembali untuk melanjutkan.');
  }
 
  let token=needsAuth?await tokenStorage.get('access_token'):null;
  let result=await request<T>(path,options,token);
 
  if(needsAuth && result.response.status===401 && !path.startsWith('/auth/')){
    try{
      token=await refreshAccessToken();
    }catch(e){
      if(e instanceof SessionExpiredSignal){
        if(write){
          throw new Error('Sesi telah berakhir. Data yang sudah tampil masih dapat digunakan, tetapi penyimpanan transaksi dinonaktifkan. Silakan login kembali untuk melanjutkan.');
        }
        return pendingForever<T>();
      }
      throw e;
    }
    result=await request<T>(path,options,token);
  }
 
  if(!result.response.ok || !result.body.success){
    const message=result.body.message||`Permintaan gagal (HTTP ${result.response.status})`;
 
    // Jangan logout hanya karena respons 401 generik/proxy. Logout hanya
    // untuk alasan terminal eksplisit dari backend.
    if(needsAuth && result.response.status===401){
      const reason=result.body.errors?.reason;
      if(reason==='SESSION_REVOKED'||reason==='APP_VERSION_CHANGED'){
        await markExpiredSession();
        if(write){
          throw new Error('Sesi telah berakhir karena akun, perangkat, paket, atau versi aplikasi berubah. Silakan login kembali.');
        }
        return pendingForever<T>();
      }
      throw new ApiError(message,result.response.status,result.body.data);
    }
 
    throw new ApiError(message,result.response.status,result.body.data);
  }
 
  if(needsAuth) expirationNotified=false;
 
  return result.body.data;
}
 
export {API_URL};
