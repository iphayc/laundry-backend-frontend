import {api} from './client';
import {buildImageForm} from '@/utils/upload-file';
export type Company={id:number;company_name:string;owner_name:string;email:string;phone:string;address:string|null;city:string|null;province:string|null;theme_color:string;logo:string|null;logo_url:string|null;receipt_header:string|null;receipt_footer:string|null};
export const getCompany=()=>api<Company>('/company');
export const updateCompany=(data:Partial<Company>)=>api<Partial<Company>>('/company',{method:'PUT',body:JSON.stringify(data)});
export const uploadLogo=async(uri:string)=>{const form=await buildImageForm('logo',uri,'logo');return api<{logo:string;logo_url:string}>('/company/logo',{method:'POST',body:form});};
