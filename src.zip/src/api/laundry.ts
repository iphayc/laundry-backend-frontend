import { api } from "./client";
export type CustomerWhatsAppStatus = {
  connection: "connected" | "connecting" | "disconnected";
  connected: boolean;
  phone: string | null;
  updated_at: string;
};
export type CustomerWhatsAppQr = {
  qr: string | null;
  connection: CustomerWhatsAppStatus["connection"] | "waiting_scan" | "authenticating";
  connected: boolean;
  phone: string | null;
  session_key?: string | null;
  updated_at: string;
};

export const getCustomerWhatsAppStatus = () =>
  api<CustomerWhatsAppStatus>("/customer-whatsapp/status");

/**
 * Memulai / memastikan session WhatsApp milik company yang sedang login
 * dan meminta QR baru dari gateway.
 *
 * Mobile tidak mengirim company_id, session_key, atau API key.
 * Semua identitas tersebut ditentukan oleh API berdasarkan JWT user.
 */
export const connectCustomerWhatsApp = () =>
  api<CustomerWhatsAppQr>("/customer-whatsapp/connect", {
    method: "POST",
    body: "{}",
  });

export const logoutCustomerWhatsApp = () =>
  api<CustomerWhatsAppStatus>("/customer-whatsapp/logout", {
    method: "POST",
    body: "{}",
  });
export type WhatsAppDeliveryConfiguration={method:"APP"|"LINKED";terms_accepted:boolean};
export const getWhatsAppDeliveryConfiguration=()=>api<WhatsAppDeliveryConfiguration>("/customer-whatsapp/configuration");
export const saveWhatsAppDeliveryConfiguration=(data:{method:"APP"|"LINKED";accept_terms?:boolean})=>api<WhatsAppDeliveryConfiguration>("/customer-whatsapp/configuration",{method:"PATCH",body:JSON.stringify(data)});
export type Customer = {
  id: number;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  branch_id?: number | null;
  branch_name?: string | null;
  visit_count?: number;
  total_items?: number;
  total_spent?: number;
};
export type Order = {
  id: number;
  invoice_number: string;
  customer_id: number;
  customer_name: string;
  customer_phone?: string | null;
  customer_email?: string | null;
  branch_name: string | null;
  branch_address?: string | null;
  branch_phone?: string | null;
  main_branch_address?: string | null;
  main_branch_phone?: string | null;
  cashier_name?: string | null;
  service_name: string;
  item_count: number;
  status: string;
  subtotal: number;
  discount_amount: number;
  discount_id?: number | null;
  total: number;
  paid_amount: number;
  dp_amount?: number;
  payment_status: "UNPAID"|"PARTIAL"|"PAID";
  outstanding_amount: number;
  payment_method: string;
  estimated_days: number;
  fulfillment_type: string;
  is_priority: number;
  notes: string | null;
  due_at: string;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
  deletion_reason?: string | null;
  branch_id?: number;
  cash_received?: number;
  service_status_label?: string;
  public_note_url?: string;
  items?: {id:number;product_id:number;product_name:string;unit:string;qty:number;price:number;subtotal:number}[];
};
export type Branch = { id: number; name: string };
export type Product = {
  id: number;
  name: string;
  category_id: number;
  category_code: string;
  category_name: string;
  unit: string;
  price: number;
  description: string | null;
  branch_settings?: {branch_id:number;branch_name:string;price:number;is_active:number}[];
};
export type ProductCategory = {
  id: number;
  code: string;
  name: string;
  unit: string;
  description: string | null;
};
export type Discount = {
  id: number;
  name: string;
  type: "PERCENT" | "FIXED";
  value: number;
  min_transaction: number;
  starts_at: string | null;
  ends_at: string | null;
  is_active: number;
  branch_settings?: {branch_id:number;branch_name:string;is_active:number}[];
};
export const getCustomers = (q = "", branchId = 0) =>
  api<Customer[]>(`/customers?q=${encodeURIComponent(q)}&branch_id=${branchId}`);
export const addCustomer = (data: Partial<Customer>) =>
  api<Customer>("/customers", { method: "POST", body: JSON.stringify(data) });
export const updateCustomer = (id: number, data: Partial<Customer>) =>
  api<Customer>(`/customers/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const disableCustomer = (id: number) =>
  api<null>(`/customers/${id}`, { method: "DELETE" });
export type OrderPage = {
  rows: Order[];
  page: number;
  limit: number;
  total: number;
  has_more: boolean;
  status_counts: Record<"ALL"|"RECEIVED"|"PROCESSING"|"READY"|"COMPLETED"|"DELETED",number>;
  today_transaction_count: number;
  daily_transaction_limit: number | null;
  can_create_transaction: boolean;
};
export const getOrders = (
  params: {
    page?: number;
    limit?: number;
    q?: string;
    status?: string;
    branch_id?: number;
  } = {},
) =>
  api<OrderPage>(
    `/orders?page=${params.page ?? 1}&limit=${params.limit ?? 20}&q=${encodeURIComponent(params.q ?? "")}&status=${encodeURIComponent(params.status ?? "")}&branch_id=${params.branch_id ?? 0}`,
  );
export const getBranches = () => api<Branch[]>("/company/branches");
export const addOrder = (data: {
  customer_id: number;
  item_count: number;
  items: { product_id: number; qty: number }[];
  payment_method: "CASH" | "BANK_TRANSFER" | "QRIS";
  payment_choice: "UNPAID"|"DP"|"FULL";
  cash_received?: number;
  discount_id?: number;
  estimated_days: number;
  fulfillment_type: "DROP_OFF" | "PICKUP" | "DELIVERY";
  is_priority: boolean;
  notes?: string;
  branch_id?: number;
}) => api<Order>("/orders", { method: "POST", body: JSON.stringify(data) });
export const getProducts = (manage=false,branchId=0) => api<Product[]>(`/products?manage=${manage?1:0}&branch_id=${branchId}`);
export const getProductCategories = async () => {
  const raw = await api<any>("/product-categories");
  const list = Array.isArray(raw) ? raw : Array.isArray(raw?.items) ? raw.items : Array.isArray(raw?.data) ? raw.data : [];
  return list as ProductCategory[];
};
export const addProduct = (data: {
  name: string;
  category_id: number;
  price: number;
  branch_settings?: {branch_id:number;price:number;is_active:boolean}[];
}) => api<Product>("/products", { method: "POST", body: JSON.stringify(data) });
export const updateProduct = (id:number,data:{name:string;category_id:number;price:number;branch_settings?:{branch_id:number;price:number;is_active:boolean}[]}) => api<Product>(`/products/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const disableProduct = (id:number) => api<null>(`/products/${id}`, { method: "DELETE" });
export const getDiscounts = (manage=false,branchId=0) => api<Discount[]>(`/discounts?manage=${manage?1:0}&branch_id=${branchId}`);
export const addDiscount = (data: {
  name: string;
  type: "PERCENT" | "FIXED";
  value: number;
  min_transaction: number;
  starts_at?: string;
  ends_at?: string;
  branch_settings?: {branch_id:number;is_active:boolean}[];
}) =>
  api<Discount>("/discounts", { method: "POST", body: JSON.stringify(data) });
export const updateDiscount = (id:number,data:{name:string;type:"PERCENT"|"FIXED";value:number;min_transaction:number;starts_at?:string;ends_at?:string;branch_settings?:{branch_id:number;is_active:boolean}[]}) => api<Discount>(`/discounts/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const disableDiscount = (id:number) => api<null>(`/discounts/${id}`, { method: "DELETE" });
export const updateOrder = (id:number,data:{is_priority:boolean;payment_choice:'UNPAID'|'PAID';payment_method:'CASH'|'BANK_TRANSFER'|'QRIS';paid_amount:number;notes:string;discount_id?:number|null;fulfillment_type?:string}) =>
  api<Order>(`/orders/${id}`,{method:'PUT',body:JSON.stringify(data)});
export const deleteOrder = (id:number,reason:string) =>
  api<null>(`/orders/${id}`,{method:'DELETE',body:JSON.stringify({reason})});

export const updateOrderStatus = (
  id: number,
  status: "PROCESSING" | "READY" | "COMPLETED",
) =>
  api(`/orders/${id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status }),
  });
export const settleOrder=(id:number,data:{cash_received:number;payment_method:"CASH"|"BANK_TRANSFER"|"QRIS"})=>api<Order>(`/orders/${id}/settle`,{method:"POST",body:JSON.stringify(data)});
export type Dashboard = {
  today_transactions: number;
  today_revenue: number;
  received: number;
  processing: number;
  ready: number;
  active_branch_id: number;
  active_branch_name: string;
  receivable_total: number;
  receivable_orders: number;
  setup: Record<string, boolean>;
};
export const getDashboard = (branchId = 0) =>
  api<Dashboard>(`/dashboard-summary?branch_id=${branchId}`);
export type Employee={
  id:number;nik:string;name:string;gender:"MALE"|"FEMALE";birth_date:string|null;
  marital_status:"MARRIED"|"SINGLE";religion:"ISLAM"|"CATHOLIC"|"PROTESTANT"|"HINDU"|"BUDDHIST"|"CONFUCIAN"|"BELIEF";
  address:string|null;phone:string|null;email:string|null;salary:number;allowance:number;
  meal_allowance:number;transport_allowance:number;attendance_rate:number;is_active:number;
};
export type EmployeePayload=Omit<Employee,"id"|"is_active">;
export const getEmployees=()=>api<Employee[]>("/employees");
export const addEmployee=(data:EmployeePayload)=>api<Employee>("/employees",{method:"POST",body:JSON.stringify(data)});
export const updateEmployee=(id:number,data:EmployeePayload)=>api<Employee>(`/employees/${id}`,{method:"PUT",body:JSON.stringify(data)});
export const disableEmployee=(id:number)=>api<null>(`/employees/${id}`,{method:"DELETE"});
export type Asset={id:number;branch_id?:number|null;branch_name?:string|null;asset_number:string;input_date:string;acquisition_date:string;asset_name:string;description:string|null;qty:number;unit_value:number;total_value:number;depreciation_years:number;annual_depreciation:number;depreciated_years?:number;accumulated_depreciation?:number;book_value?:number};
export type AssetPayload={branch_id?:number;acquisition_date:string;asset_name:string;description?:string;qty:number;unit_value:number;depreciation_years:number;annual_depreciation:number};
export type AssetReport={assets:Asset[];total_asset_value:number;total_annual_depreciation:number;total_accumulated_depreciation:number;total_book_value:number;as_of:string};
export const getAssets=async(branchId=0)=>(await api<Asset[]>(`/assets?branch_id=${branchId}`)).map(x=>({...x,qty:Math.round(Number(x.qty))}));
export const addAsset=(data:AssetPayload)=>api<Asset>("/assets",{method:"POST",body:JSON.stringify({...data,qty:Math.round(Number(data.qty))})});
export const updateAsset=(id:number,data:AssetPayload)=>api<Asset>(`/assets/${id}`,{method:"PUT",body:JSON.stringify({...data,qty:Math.round(Number(data.qty))})});
export const deleteAsset=(id:number)=>api<null>(`/assets/${id}`,{method:"DELETE"});
export const getAssetReport=(branchId=0)=>api<AssetReport>(`/reports/assets?branch_id=${branchId}`);
export type Expense={id:number;category:'SALARY'|'RENT'|'OPERATIONAL'|'OTHER';qty:number;unit_amount:number;total_amount:number;notes:string|null;expense_date:string;branch_name?:string;employee_id?:number|null;employee_name?:string|null;employee_nik?:string|null;employee_phone?:string|null;employee_email?:string|null;payroll_period?:string|null;base_salary?:number;allowance?:number;meal_allowance_rate?:number;meal_allowance?:number;transport_allowance?:number;attendance_days?:number;attendance_rate?:number;attendance_allowance?:number;deduction?:number;bonus?:number;thr?:number};
export type ExpenseReport={from:string;to:string;expense:number;manual_expense:number;inventory_expense:number;revenue:number;net:number;daily:{label:string;total:number}[];monthly:{month:number;total:number}[];yearly:{year:number;total:number}[]};
export const getExpenses=()=>api<Expense[]>('/expenses');
export const addExpense=(data:{category:Expense['category'];qty:number;unit_amount:number;notes?:string;employee_id?:number;payroll_period?:string;attendance_days?:number;deduction?:number;bonus?:number;thr?:number})=>api<Expense>('/expenses',{method:'POST',body:JSON.stringify(data)});
export const updatePayroll=(id:number,data:{employee_id:number;payroll_period:string;attendance_days:number;deduction:number;bonus:number;thr:number;notes?:string})=>api<Expense>(`/expenses/${id}`,{method:'PUT',body:JSON.stringify(data)});
export const deletePayroll=(id:number)=>api<null>(`/expenses/${id}`,{method:'DELETE'});
export const getExpenseReport=(p:{from:string;to:string;year:number;branch_id?:number})=>api<ExpenseReport>(`/expenses/report?from=${p.from}&to=${p.to}&year=${p.year}&branch_id=${p.branch_id??0}`);
export type FinancialRecap={from:string;to:string;branch_id:number;branch_name:string;income:{order_number:string;date:string;customer_name:string;total_qty:number;price:number;discount:number;amount:number}[];expenses:{transaction_number:string;date:string;description:string;qty:number;price:number;amount:number}[];total_income:number;total_expense:number;profit_loss:number};
export const getFinancialRecap=(from:string,to:string,branchId=0)=>api<FinancialRecap>(`/reports/financial-recap?from=${from}&to=${to}&branch_id=${branchId}`);
export type InventoryItem={id:number;branch_id?:number;branch_name?:string|null;item_code:string;name:string;unit:string;description:string|null;min_stock:number;current_stock:number;average_cost:number};
export type InventoryHistoryRow={id:number;movement_date:string;created_at:string|null;direction:'IN'|'OUT';qty:number;unit_cost:number;total_cost:number;reference_type:string|null;reference_id:number|null;movement_number:string;item_code:string;item_name:string;unit:string;branch_name:string|null;input_user_name:string|null};
export type InventoryHistoryChartRow={item_id:number;item_name:string;unit:string;qty_in:number;qty_out:number};
export type InventoryHistory={rows:InventoryHistoryRow[];page:number;limit:number;total:number;total_pages:number;from:string;to:string;summary:{qty_in:number;qty_out:number;value_in:number;value_out:number};monthly:{label:string;rows:InventoryHistoryChartRow[]};yearly:{label:string;rows:InventoryHistoryChartRow[]}};
export type InventoryReport={from:string;to:string;summary:{qty_in:number;value_in:number;qty_out:number;value_out:number};items:(InventoryItem&{stock_value:number})[]};
export const getInventoryItems=(branchId=0)=>api<InventoryItem[]>(`/inventory/items?branch_id=${branchId}`);
export const addInventoryItem=(data:{branch_id?:number;name:string;unit:string;description?:string;min_stock:number})=>api<InventoryItem>('/inventory/items',{method:'POST',body:JSON.stringify(data)});
export const updateInventoryItem=(id:number,data:{branch_id?:number;name:string;unit:string;description?:string;min_stock:number})=>api<InventoryItem>(`/inventory/items/${id}`,{method:'PUT',body:JSON.stringify(data)});
export const deleteInventoryItem=(id:number,branchId=0)=>api<null>(`/inventory/items/${id}?branch_id=${branchId}`,{method:'DELETE'});
export const addInventoryStock=(data:{branch_id?:number;item_id:number;qty:number;total_amount:number;notes?:string})=>api<{movement_number:string;unit_cost:number;current_stock:number}>('/inventory/stock-in',{method:'POST',body:JSON.stringify(data)});
export const consumeOrderInventory=(order_id:number,items:{item_id:number;qty:number}[])=>api<null>('/inventory/consume',{method:'POST',body:JSON.stringify({order_id,items})});
export const getInventoryReport=(from:string,to:string,branchId=0)=>api<InventoryReport>(`/inventory/report?from=${from}&to=${to}&branch_id=${branchId}`);
export const getInventoryHistory=(params:{from:string;to:string;branch_id?:number;q?:string;page?:number;limit?:number})=>api<InventoryHistory>(`/inventory/history?from=${encodeURIComponent(params.from)}&to=${encodeURIComponent(params.to)}&branch_id=${params.branch_id??0}&q=${encodeURIComponent(params.q??'')}&page=${params.page??1}&limit=${params.limit??10}`);
export type Report = {
  range: string;
  transactions: number;
  revenue: number;
  customers: number;
  daily: { day: string; transactions: number; revenue: number }[];
};
export const getReport = (range: string) =>
  api<Report>(`/reports/summary?range=${range}`);
export type ReportLookups = {
  branches: { id: number; name: string }[];
  cashiers: { id: number; fullname: string; username: string; role: string }[];
  years: number[];
};
export type Analytics = {
  year: number;
  daily: {
    label: string;
    income: number;
    revenue: number;
    transactions: number;
  }[];
  annual: {
    month: number;
    income: number;
    revenue: number;
    transactions: number;
  }[];
  yearly: {
    year: number;
    income: number;
    revenue: number;
    transactions: number;
  }[];
  products: {
    product_id: number;
    product_name: string;
    unit: string;
    qty: number;
    revenue: number;
    orders: number;
  }[];
  cashiers: {
    created_by: number;
    fullname: string;
    username: string;
    transactions: number;
    revenue: number;
    income: number;
  }[];
};
export const getReportLookups = () => api<ReportLookups>("/reports/lookups");
export const getAnalytics = (params: {
  year: number;
  branch_id?: number;
  cashier_id?: number;
}) =>
  api<Analytics>(
    `/reports/analytics?year=${params.year}&branch_id=${params.branch_id ?? 0}&cashier_id=${params.cashier_id ?? 0}`,
  );
