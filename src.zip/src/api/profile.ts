import {api} from "./client";
import {buildImageForm} from "@/utils/upload-file";
export type UserProfile={id:number;fullname:string;email:string;phone:string|null;role:"OWNER"|"CASHIER";photo:string|null;photo_url:string|null};
export const getMyProfile=()=>api<UserProfile>("/me/profile");
export const uploadMyPhoto=async(uri:string)=>api<{user_id:number;photo:string;photo_url:string}>("/me/photo",{method:"POST",body:await buildImageForm('photo',uri,'profile')});
export const uploadUserPhoto=async(id:number,uri:string)=>api<{user_id:number;photo:string;photo_url:string}>(`/company/users/${id}/photo`,{method:"POST",body:await buildImageForm('photo',uri,'profile')});
