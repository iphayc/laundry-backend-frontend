import { useEffect, useState } from "react";
import { router, Tabs, usePathname } from "expo-router";
import { Text } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors } from "@/theme";
import { getDashboard } from "@/api/laundry";
import { subscribeOrdersChanged } from "@/utils/order-events";
import { api } from "@/api/client";
import { useAuth } from "@/store/auth-context";
const icons: Record<string, string> = {
  index: "⌂",
  orders: "▤",
  customers: "♙",
  reports: "▥",
  account: "⚙",
};
export default function TabsLayout() {
  const [received, setReceived] = useState(0),
    pathname = usePathname();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  function refreshBadge() {
    getDashboard()
      .then((x) => setReceived(Number(x.received)))
      .catch(() => {});
  }
  useEffect(() => {
    refreshBadge();
    const timer = setInterval(refreshBadge, 20000);
    const unsubscribe = subscribeOrdersChanged(refreshBadge);
    return () => {
      clearInterval(timer);
      unsubscribe();
    };
  }, [pathname]);
  useEffect(() => {
    if (String(user?.role ?? "").toUpperCase() !== "OWNER") return;
    api<{ branch_selection_required?: boolean } | null>("/license")
      .then((license) => {
        if (license?.branch_selection_required) router.replace({ pathname: "/account-feature", params: { feature: "branches" } });
      })
      .catch(() => {});
  }, [user?.role]);
  const badge = received > 999 ? "999+" : received || undefined;
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: "#8A9995",
        tabBarStyle: {
          height: 72 + Math.max(insets.bottom, 0),
          paddingTop: 8,
          paddingBottom: 10 + Math.max(insets.bottom, 0),
          borderTopColor: colors.line,
          backgroundColor: "#fff",
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "700" },
        tabBarIcon: ({ color }) => (
          <Text style={{ fontSize: 22, color }}>{icons[route.name]}</Text>
        ),
      })}
    >
      <Tabs.Screen name="index" options={{ title: "Beranda" }} />
      <Tabs.Screen
        name="orders"
        options={{
          title: "Pesanan",
          tabBarBadge: badge,
          tabBarBadgeStyle: {
            backgroundColor: "#DC2626",
            color: "#fff",
            fontSize: 10,
            fontWeight: "900",
            minWidth: 20,
            height: 20,
            lineHeight: 20,
            top: -4,
          },
        }}
      />
      <Tabs.Screen name="customers" options={{ title: "Pelanggan" }} />
      <Tabs.Screen name="reports" options={{ title: "Laporan" }} />
      <Tabs.Screen name="account" options={{ title: "Pengaturan" }} />
    </Tabs>
  );
}
