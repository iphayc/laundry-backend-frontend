import { useEffect, useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Screen } from "@/components/screen";
import { Button, Card, Field, ScreenTitle } from "@/components/ui";
import { colors } from "@/theme";
import { addCustomer, Branch, Customer, disableCustomer, getBranches, getCustomers, updateCustomer } from "@/api/laundry";
import { downloadCustomers, uploadCustomers } from "@/utils/customer-excel";
import { useToast } from "@/components/toast";
import { useAuth } from "@/store/auth-context";
export default function Customers() {
  const { showToast } = useToast();
  const { user } = useAuth();
  const isOwner=String(user?.role??"").toUpperCase()==="OWNER";
  const [rows, setRows] = useState<Customer[]>([]);
  const [branches,setBranches]=useState<Branch[]>([]);
  const [selectedBranch,setSelectedBranch]=useState(0);
  const [search,setSearch]=useState("");
  const [form, setForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [selected, setSelected] = useState<Customer | null>(null);
  const [editingId, setEditingId] = useState(0);
  const [data, setData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  function load(q=search,branchId=selectedBranch) {
    getCustomers(q,branchId)
      .then(setRows)
      .catch((e) => setMessage(e.message));
  }
  useEffect(()=>{
    getBranches().then(items=>{
      setBranches(items);
      const branchId=isOwner?0:Number(items[0]?.id??0);
      setSelectedBranch(branchId);
      load("",branchId);
    }).catch(e=>{setMessage(e instanceof Error?e.message:"Cabang gagal dimuat");load("",0)});
  },[isOwner]);
  async function save() {
    const isEditing = editingId > 0;
    try {
      setBusy(true);
      if (editingId) await updateCustomer(editingId, data);
      else await addCustomer(data);
      setData({ name: "", phone: "", email: "", address: "" });
      setForm(false);
      setEditingId(0);
      setSelected(null);
      const text=isEditing ? "Pelanggan berhasil diperbarui." : "Pelanggan berhasil ditambahkan.";
      setMessage(text);
      showToast(text);
      load();
    } catch (e) {
      const text=e instanceof Error ? e.message : "Gagal menyimpan pelanggan";
      setMessage(text);
      showToast(text,"error");
    } finally {
      setBusy(false);
    }
  }
  function startAdd(){setEditingId(0);setSelected(null);setData({name:"",phone:"",email:"",address:""});setForm(true)}
  function startEdit(row:Customer){setEditingId(row.id);setData({name:row.name,phone:row.phone??"",email:row.email??"",address:row.address??""});setForm(true);setSelected(row)}
  function cancelForm(){setForm(false);setEditingId(0);setData({name:"",phone:"",email:"",address:""})}
  function customerForm(inline=false){
    const content=<>
      <Text style={s.formTitle}>{editingId ? "Edit pelanggan" : "Pelanggan baru"}</Text>
      <Field label="Nama pelanggan" value={data.name} onChangeText={(name)=>setData((x)=>({...x,name}))}/>
      <Field label="Nomor HP" value={data.phone} onChangeText={(phone)=>setData((x)=>({...x,phone}))} keyboardType="phone-pad"/>
      <Field label="Email" value={data.email} onChangeText={(email)=>setData((x)=>({...x,email}))}/>
      <Field label="Alamat" value={data.address} onChangeText={(address)=>setData((x)=>({...x,address}))} multiline/>
      <View style={s.formButtons}>
        <Button title={busy?"Menyimpan...":editingId?"Simpan perubahan":"Simpan pelanggan"} disabled={busy||!data.name} onPress={save}/>
        <Button title="Batal" variant="danger" disabled={busy} onPress={cancelForm}/>
      </View>
    </>;
    return inline?<View style={s.inlineForm}>{content}</View>:<Card>{content}</Card>;
  }
  function remove(row:Customer){const action=async()=>{try{setBusy(true);await disableCustomer(row.id);setSelected(null);load();setMessage("Pelanggan dinonaktifkan. Histori transaksi tetap tersimpan.")}catch(e){setMessage(e instanceof Error?e.message:"Pelanggan gagal dinonaktifkan")}finally{setBusy(false)}};const text=`Pelanggan ${row.name} tidak akan muncul untuk transaksi baru, tetapi histori tetap disimpan.`;if(Platform.OS==="web"){if(window.confirm(text))action()}else Alert.alert("Hapus pelanggan",text,[{text:"Batal",style:"cancel"},{text:"Hapus",style:"destructive",onPress:action}])}
  async function download() {
    try {
      await downloadCustomers();
      setMessage("File pelanggan berhasil dibuat.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Download gagal.");
    }
  }
  async function upload() {
    try {
      const result = await uploadCustomers();
      if (result) {
        setMessage(
          `Import selesai: ${result.inserted} baru, ${result.updated} diperbarui.`,
        );
        load();
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Upload gagal.");
    }
  }
  return (
    <Screen>
      <View style={s.head}>
        <View style={s.headTitle}><ScreenTitle title="Pelanggan" subtitle="Data pelanggan laundry" /></View>
        <View style={s.actions}>
          <Pressable onPress={()=>load()} style={s.refresh}>
            <Text>↻</Text>
          </Pressable>
          <Pressable onPress={() => form ? cancelForm() : startAdd()} style={s.add}>
            <Text style={s.addText}>{form ? "Tutup" : "＋ Baru"}</Text>
          </Pressable>
        </View>
      </View>
      <View style={s.excel}>
        <Pressable onPress={download} style={s.excelButton}>
          <Text style={s.excelText}>↓ Download Excel</Text>
        </Pressable>
        <Pressable onPress={upload} style={s.excelButton}>
          <Text style={s.excelText}>↑ Upload Excel</Text>
        </Pressable>
      </View>
      <Text style={s.help}>
        Upload harus menggunakan susunan kolom dari file hasil download.
      </Text>
      {message ? <Text style={s.message}>{message}</Text> : null}
      {form && !editingId ? customerForm() : null}
      <View style={s.search}>
        <Text>⌕</Text>
        <TextInput
          placeholder="Cari nama atau nomor HP"
          style={{ flex: 1 }}
          value={search}
          onChangeText={(q) => {setSearch(q);getCustomers(q,selectedBranch).then(setRows)}}
        />
      </View>
      <Text style={s.total}>Total {rows.length.toLocaleString("id-ID")} pelanggan</Text>
      <View style={s.branchFilter}>
        {isOwner?<Pressable onPress={()=>{setSelectedBranch(0);load(search,0)}} style={[s.branchChip,selectedBranch===0&&s.branchChipOn]}><Text style={[s.branchChipText,selectedBranch===0&&s.branchChipTextOn]}>Semua cabang</Text></Pressable>:null}
        {branches.map(branch=><Pressable key={branch.id} disabled={!isOwner} onPress={()=>{setSelectedBranch(branch.id);load(search,branch.id)}} style={[s.branchChip,selectedBranch===branch.id&&s.branchChipOn]}><Text style={[s.branchChipText,selectedBranch===branch.id&&s.branchChipTextOn]}>{branch.name}</Text></Pressable>)}
      </View>
      {rows.map((row) => (
        <Card key={row.id}>
          <Pressable onPress={() => setSelected(selected?.id === row.id ? null : row)}>
            <Text style={s.title}>{row.name}</Text>
          <Text style={s.muted}>
              {row.phone || "-"} · {row.address || "Alamat belum diisi"}
          </Text>
          <Text style={s.branchInfo}>Cabang : {row.branch_name||"Belum ditentukan"}</Text>
          <View style={s.summaryRow}>
            <View style={s.summaryTopRow}>
              <View style={s.summaryItem}><Text style={s.summaryValue}>{Number(row.visit_count ?? 0).toLocaleString("id-ID")}</Text><Text style={s.summaryLabel}>Kunjungan</Text></View>
              <View style={s.summaryItem}><Text style={s.summaryValue}>{Number(row.total_items ?? 0).toLocaleString("id-ID")}</Text><Text style={s.summaryLabel}>Barang</Text></View>
            </View>
            <View style={s.transactionItem}><Text style={s.summaryValue}>Rp {Number(row.total_spent ?? 0).toLocaleString("id-ID")}</Text><Text style={s.summaryLabel}>Transaksi</Text></View>
          </View>
          </Pressable>
          {selected?.id === row.id ? (
            <View style={s.customerActions}>
              <Text style={s.detail}>{row.email || "Email belum diisi"}</Text>
              <View style={s.actionRow}>
                <View style={{ flex: 1 }}><Button title="Edit" variant="soft" onPress={() => startEdit(row)} /></View>
                <View style={{ flex: 1 }}><Button title="Hapus" variant="danger" onPress={() => remove(row)} /></View>
              </View>
            </View>
          ) : null}
          {form && editingId === row.id ? customerForm(true) : null}
        </Card>
      ))}
    </Screen>
  );
}
const s = StyleSheet.create({
  head: {
    flexDirection: "row",
    gap: 10,
    justifyContent: "space-between",
    alignItems: "center",
  },
  headTitle:{flex:1,minWidth:0},
  actions: { flexDirection: "row", gap: 8, flexShrink:0 },
  refresh: {
    padding: 11,
    borderRadius: 12,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.line,
  },
  add: { backgroundColor: colors.primary, padding: 12, borderRadius: 14 },
  addText: { color: "#fff", fontWeight: "800" },
  excel: { flexDirection: "row", gap: 8 },
  excelButton: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
  },
  excelText: { fontWeight: "800", color: colors.primary },
  help: { fontSize: 11, color: colors.muted },
  search: {
    height: 50,
    borderRadius: 16,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.line,
    paddingHorizontal: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  total:{color:colors.ink,fontWeight:"800",marginTop:-8},
  branchFilter:{flexDirection:"row",flexWrap:"wrap",gap:8,marginTop:-8},
  branchChip:{paddingHorizontal:13,paddingVertical:9,borderRadius:999,backgroundColor:colors.primarySoft,borderWidth:1,borderColor:colors.line},
  branchChipOn:{backgroundColor:colors.primary,borderColor:colors.primary},
  branchChipText:{color:colors.primary,fontWeight:"700",fontSize:12},
  branchChipTextOn:{color:"#fff"},
  title: { fontSize: 17, fontWeight: "900", color: colors.ink },
  formTitle: { fontSize: 17, fontWeight: "900", color: colors.ink },
  muted: { color: colors.muted, lineHeight: 20 },
  branchInfo:{color:colors.primary,fontSize:12,fontWeight:"700",marginTop:3},
  summaryRow:{marginTop:10,paddingTop:10,borderTopWidth:1,borderTopColor:colors.line},
  summaryTopRow:{flexDirection:"row"},
  summaryItem:{flex:1,alignItems:"center"},
  transactionItem:{alignItems:"center",marginTop:10},
  summaryValue:{fontSize:14,fontWeight:"800",color:colors.ink},
  summaryLabel:{fontSize:11,color:colors.muted,marginTop:2},
  customerActions: { marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.line },
  inlineForm:{marginTop:14,paddingTop:14,borderTopWidth:1,borderTopColor:colors.line,gap:14},
  formButtons:{gap:12,marginTop:6},
  detail: { color: colors.muted, marginBottom: 10 },
  actionRow: { flexDirection: "row", gap: 9 },
  message: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    color: colors.primary,
    fontWeight: "700",
  },
});
