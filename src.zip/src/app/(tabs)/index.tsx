import { useCallback, useState } from "react";
import { Alert, BackHandler, Image, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { Screen } from "@/components/screen";
import { Card, ScreenTitle } from "@/components/ui";
import { useAuth } from "@/store/auth-context";
import { colors } from "@/theme";
import { Branch, Dashboard, getBranches, getDashboard } from "@/api/laundry";
import { api } from "@/api/client";
import {getMyProfile,UserProfile} from "@/api/profile";
import {SymbolView} from "expo-symbols";
type Message = { id: number; read_at: string | null };
const setupLabels: Record<string, string> = {
  logo: "Upload logo",
  address: "Isi alamat",
  service: "Tambah layanan",
  whatsapp: "Hubungkan WhatsApp",
  receipt: "Cetak struk pertama",
};
export default function Home() {
  const { user } = useAuth();
  const [data, setData] = useState<Dashboard | null>(null),
    [unread, setUnread] = useState(0),
    [branches, setBranches] = useState<Branch[]>([]),
    [branchId, setBranchId] = useState(0),
    [profile,setProfile]=useState<UserProfile|null>(null);
  useFocusEffect(
    useCallback(() => {
      getDashboard(branchId).then(setData);
      if (user?.role === "OWNER") getBranches().then(setBranches);
      api<Message[]>("/notifications").then((x) =>
        setUnread(x.filter((m) => !m.read_at).length),
      );
      getMyProfile().then(setProfile).catch(()=>{});
      return () => {};
    }, [branchId, user?.role]),
  );
  const checks = data?.setup ?? {},
    percent = Math.round(
      (Object.values(checks).filter(Boolean).length / 5) * 100,
    );
  function exitApplication() {
    if (Platform.OS === "android") {
      Alert.alert(
        "Keluar dari aplikasi",
        "Apakah Anda yakin ingin menutup aplikasi? Session login akan tetap tersimpan.",
        [
          { text: "Tidak", style: "cancel" },
          { text: "Ya", onPress: () => BackHandler.exitApp() },
        ],
      );
      return;
    }
    if (Platform.OS === "web") {
      if (window.confirm("Apakah Anda yakin ingin menutup aplikasi? Session login akan tetap tersimpan.")) window.close();
      return;
    }
    Alert.alert("Tutup aplikasi", "Gunakan gesture Home untuk menutup aplikasi pada iPhone.");
  }
  return (
    <Screen>
      <View style={s.top}>
        <View style={s.userIdentity}>
          {profile?.photo_url?<Image source={{uri:profile.photo_url}} style={s.profilePhoto}/>:<View style={s.profileEmpty}><Text style={{fontSize:22}}>👤</Text></View>}
          <View>
          <Text style={s.greeting}>Selamat datang,</Text>
          <Text style={s.name}>{user?.fullname ?? "Pengguna"}</Text>
          <View style={s.activeBranch}>
            <Text style={s.activeBranchIcon}>⌖</Text>
            <Text style={s.activeBranchText}>
              Cabang aktif: {data?.active_branch_name ?? "Memuat..."}
            </Text>
          </View>
          </View>
        </View>
        <View style={s.topActions}>
          <Pressable onPress={() => router.push("/messages")} style={s.messageButton}>
            <Text style={{ fontSize: 22 }}>✉</Text>
            {unread ? (
              <View style={s.badge}>
                <Text style={s.badgeText}>{unread > 99 ? "99+" : unread}</Text>
              </View>
            ) : null}
          </Pressable>
          <Pressable accessibilityLabel="Tutup aplikasi tanpa logout" onPress={exitApplication} style={s.logoutButton}>
            <View style={s.logoutIcon}>
              <View style={s.logoutDoor}><View style={s.logoutKnob} /></View>
              <Text style={s.logoutArrow}>→</Text>
            </View>
          </Pressable>
        </View>
      </View>
      {user?.role === "OWNER" ? (
        <View>
          <Text style={s.branchLabel}>Tampilkan omzet</Text>
          <ScrollView horizontal contentContainerStyle={s.branchFilters} showsHorizontalScrollIndicator={false}>
            <BranchChip label="Semua cabang" active={branchId === 0} onPress={() => setBranchId(0)} />
            {branches.map((branch) => (
              <BranchChip key={branch.id} label={branch.name} active={branchId === branch.id} onPress={() => setBranchId(branch.id)} />
            ))}
          </ScrollView>
        </View>
      ) : null}
      <Pressable onPress={() => router.push("/(tabs)/reports")}>
        <Card style={s.revenue}>
          <Text style={s.revenueLabel}>Omzet hari ini</Text>
          <Text style={s.revenueValue}>
            Rp {Number(data?.today_revenue ?? 0).toLocaleString("id-ID")}
          </Text>
          <View style={s.revenueMeta}>
            <Text style={s.whiteSoft}>
              {data?.today_transactions ?? 0} transaksi
            </Text>
            <Text style={s.whiteSoft}>Lihat laporan ›</Text>
          </View>
        </Card>
      </Pressable>
      <Card style={s.receivable}>
        <View><Text style={s.receivableLabel}>Piutang aktif</Text><Text style={s.receivableValue}>Rp {Number(data?.receivable_total??0).toLocaleString("id-ID")}</Text></View>
        <View style={s.receivableCount}><Text style={s.receivableCountValue}>{data?.receivable_orders??0}</Text><Text style={s.receivableCountLabel}>pesanan</Text></View>
      </Card>
      <ScreenTitle eyebrow="RINGKASAN HARI INI" title="Operasional laundry" />
      <View style={s.metrics}>
        {[
          ["Pesanan baru", data?.received ?? 0, "#EAF3FF"],
          ["Diproses", data?.processing ?? 0, "#FFF5DF"],
          ["Siap diambil", data?.ready ?? 0, "#E8F6F2"],
        ].map((x) => (
          <Card
            key={String(x[0])}
            style={{ ...s.metric, backgroundColor: String(x[2]) }}
          >
            <Text style={s.metricNumber}>{x[1]}</Text>
            <Text style={s.metricLabel}>{x[0]}</Text>
          </Card>
        ))}
      </View>
      <Text style={s.section}>Aksi cepat</Text>
      <View style={s.actions}>
        {[
          {ios:"plus.circle.fill",android:"add_circle",fallback:"＋",label:"Pesanan baru",path:"/(tabs)/orders?new=1",tint:"#0F766E",soft:"#CCFBF1"},
          {ios:"magnifyingglass.circle.fill",android:"search",fallback:"⌕",label:"Cari pesanan",path:"/(tabs)/orders",tint:"#2563EB",soft:"#DBEAFE"},
          {ios:"person.2.fill",android:"groups",fallback:"●",label:"Pelanggan",path:"/(tabs)/customers",tint:"#7C3AED",soft:"#EDE9FE"},
          {ios:"banknote.fill",android:"payments",fallback:"Rp",label:"Pengeluaran",path:"/expenses",tint:"#EA580C",soft:"#FFEDD5"},
          {ios:"shippingbox.fill",android:"inventory_2",fallback:"□",label:"Inventory",path:"/inventory",tint:"#0891B2",soft:"#CFFAFE"},
          {ios:"chart.xyaxis.line",android:"monitoring",fallback:"↗",label:"Laporan",path:"/(tabs)/reports",tint:"#DB2777",soft:"#FCE7F3"},
        ].map((x) => (
          <Pressable
            key={x.label}
            onPress={() => router.push(x.path as never)}
            style={s.action}
          >
            <View style={[s.actionIcon,{backgroundColor:x.soft}]}> 
              <SymbolView name={{ios:x.ios,android:x.android,web:x.android} as never} size={25} tintColor={x.tint} fallback={<Text style={[s.actionFallback,{color:x.tint}]}>{x.fallback}</Text>}/>
            </View>
            <Text style={s.actionText}>{x.label}</Text>
          </Pressable>
        ))}
      </View>
      <Card>
        <View style={s.setupHead}>
          <View>
            <Text style={s.setupTitle}>Setup Laundry</Text>
            <Text style={s.muted}>Lengkapi agar siap digunakan</Text>
          </View>
          <Text style={s.percent}>{percent}%</Text>
        </View>
        <View style={s.progress}>
          <View style={[s.progressValue, { width: `${percent}%` } as object]} />
        </View>
        {Object.entries(setupLabels).map(([key, label]) => (
          <View key={key} style={s.check}>
            <Text style={{ color: checks[key] ? colors.primary : "#A9B5B2" }}>
              {checks[key] ? "●" : "○"}
            </Text>
            <Text style={s.checkText}>{label}</Text>
          </View>
        ))}
      </Card>
    </Screen>
  );
}
function BranchChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[s.branchChip, active && s.branchChipOn]}><Text style={[s.branchChipText, active && s.branchChipTextOn]}>{label}</Text></Pressable>;
}
const s = StyleSheet.create({
  top: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  greeting: { color: colors.muted },
  userIdentity:{flexDirection:"row",alignItems:"center",gap:10,flex:1},
  profilePhoto:{width:48,height:48,borderRadius:24,resizeMode:"cover",borderWidth:2,borderColor:"#fff"},
  profileEmpty:{width:48,height:48,borderRadius:24,backgroundColor:colors.primarySoft,alignItems:"center",justifyContent:"center"},
  name: { fontSize: 22, fontWeight: "900", color: colors.ink },
  activeBranch: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginTop: 6,
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 10,
    backgroundColor: colors.primarySoft,
  },
  activeBranchIcon: { color: colors.primary, fontSize: 14, fontWeight: "900" },
  activeBranchText: { color: colors.primary, fontSize: 11, fontWeight: "800" },
  topActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  messageButton: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  logoutButton: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: "#FDECEC",
    alignItems: "center",
    justifyContent: "center",
  },
  logoutIcon: { width: 29, height: 28, justifyContent: "center" },
  logoutDoor: {
    position: "absolute",
    left: 1,
    width: 16,
    height: 24,
    borderWidth: 2.5,
    borderColor: colors.danger,
    borderRadius: 3,
  },
  logoutKnob: {
    position: "absolute",
    right: 2,
    top: 9,
    width: 3,
    height: 3,
    borderRadius: 2,
    backgroundColor: colors.danger,
  },
  logoutArrow: {
    position: "absolute",
    right: -1,
    fontSize: 20,
    lineHeight: 22,
    fontWeight: "900",
    color: colors.danger,
  },
  badge: {
    position: "absolute",
    right: -5,
    top: -5,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.danger,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 4,
  },
  badgeText: { fontSize: 10, color: "#fff", fontWeight: "900" },
  branchLabel: { fontSize: 12, fontWeight: "800", color: colors.muted, marginBottom: 7 },
  branchFilters: { gap: 8, paddingRight: 18 },
  branchChip: { paddingHorizontal: 13, paddingVertical: 9, borderRadius: 12, backgroundColor: "#fff", borderWidth: 1, borderColor: colors.line },
  branchChipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  branchChipText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  branchChipTextOn: { color: "#fff" },
  revenue: { backgroundColor: colors.primary, borderColor: colors.primary },
  receivable:{backgroundColor:"#FFF7ED",borderColor:"#FED7AA",flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  receivableLabel:{fontSize:12,fontWeight:"800",color:"#9A3412"},
  receivableValue:{fontSize:24,fontWeight:"900",color:"#C2410C",marginTop:5},
  receivableCount:{alignItems:"center",paddingHorizontal:13,paddingVertical:8,borderRadius:12,backgroundColor:"#FFEDD5"},
  receivableCountValue:{fontSize:20,fontWeight:"900",color:"#C2410C"},
  receivableCountLabel:{fontSize:10,color:"#9A3412"},
  revenueLabel: { color: "#D8F0EA", fontWeight: "700" },
  revenueValue: {
    fontSize: 34,
    fontWeight: "900",
    color: "#fff",
    marginVertical: 10,
  },
  revenueMeta: { flexDirection: "row", justifyContent: "space-between" },
  whiteSoft: { color: "#D8F0EA", fontSize: 13 },
  metrics: { flexDirection: "row", gap: 10 },
  metric: { flex: 1, padding: 13, borderWidth: 0 },
  metricNumber: { fontSize: 24, fontWeight: "900", color: colors.ink },
  metricLabel: { fontSize: 11, color: colors.muted, marginTop: 5 },
  section: { fontSize: 18, fontWeight: "900", color: colors.ink },
  actions: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  action: { width: "29%", alignItems: "center", gap: 9, paddingVertical: 4 },
  actionIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#173D35",
    shadowOpacity: 0.09,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  actionFallback: { fontSize: 20, fontWeight: "900" },
  actionText: {
    fontSize: 11,
    fontWeight: "700",
    color: colors.ink,
    textAlign: "center",
  },
  setupHead: { flexDirection: "row", justifyContent: "space-between" },
  setupTitle: { fontSize: 18, fontWeight: "900", color: colors.ink },
  muted: { color: colors.muted, fontSize: 13 },
  percent: { fontSize: 20, fontWeight: "900", color: colors.primary },
  progress: {
    height: 8,
    borderRadius: 8,
    backgroundColor: "#E7EFED",
    marginVertical: 15,
  },
  progressValue: {
    height: 8,
    borderRadius: 8,
    backgroundColor: colors.primary,
  },
  check: { flexDirection: "row", gap: 10, paddingVertical: 6 },
  checkText: { color: colors.ink },
});
