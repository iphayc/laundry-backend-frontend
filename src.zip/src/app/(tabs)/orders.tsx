import { useEffect, useMemo, useRef, useState } from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Screen } from "@/components/screen";
import { router, useLocalSearchParams } from "expo-router";
import { Button, Card, Field, ScreenTitle } from "@/components/ui";
import { colors } from "@/theme";
import {
  addCustomer,
  addOrder,
  updateOrder,
  deleteOrder,
  Branch,
  Customer,
  Discount,
  getBranches,
  getCustomers,
  getDiscounts,
  getOrders,
  getProducts,
  getInventoryItems,
  InventoryItem,
  consumeOrderInventory,
  Order,
  Product,
  updateOrderStatus,
  settleOrder,
} from "@/api/laundry";
import { useAuth } from "@/store/auth-context";
import { Company, getCompany } from "@/api/company";
import { emailReceipt, printPdf, printReceipt, printLabel, whatsappReceipt, whatsappReminder } from "@/utils/receipt-output";
import { selectedPrinter } from "@/services/bluetooth-printer";
import { notifyOrdersChanged } from "@/utils/order-events";
type Method = "CASH" | "BANK_TRANSFER" | "QRIS";
type Fulfillment = "DROP_OFF" | "PICKUP" | "DELIVERY";
type Lookup = "customer" | "product" | "inventory" | null;
type Item = { product: Product; qty: string };
type InventoryUse = { item: InventoryItem; qty: string };
export default function Orders() {
  const outputLock = useRef(false);
  const { user } = useAuth();
  const params = useLocalSearchParams<{ new?: string }>();
  const [rows, setRows] = useState<Order[]>([]),
    [customers, setCustomers] = useState<Customer[]>([]),
    [products, setProducts] = useState<Product[]>([]),
    [discounts, setDiscounts] = useState<Discount[]>([]),
    [branches, setBranches] = useState<Branch[]>([]),
    [branchId, setBranchId] = useState(0),
    [items, setItems] = useState<Item[]>([]),
    [inventory, setInventory] = useState<InventoryItem[]>([]),
    [inventoryUses, setInventoryUses] = useState<InventoryUse[]>([]),
    [companyInfo, setCompanyInfo] = useState<Partial<Company>>({}),
    [outputOrder, setOutputOrder] = useState<Order | null>(null);
  const [settleTarget,setSettleTarget]=useState<Order|null>(null),[settleCash,setSettleCash]=useState(""),[settleMethod,setSettleMethod]=useState<Method>("CASH");
  const [editTarget,setEditTarget]=useState<Order|null>(null),[deleteTarget,setDeleteTarget]=useState<Order|null>(null),[deleteReason,setDeleteReason]=useState(""),[editBusy,setEditBusy]=useState(false);
  const [editPaymentPreset,setEditPaymentPreset]=useState<"DP"|"FULL"|"AMOUNT"|null>(null);
  const [editData,setEditData]=useState({
    is_priority:false,
    payment_choice:"PAID" as "UNPAID"|"PAID",
    payment_method:"CASH" as Method,
    paid_amount:"",
    notes:"",
    discount_id:0,
    fulfillment_type:"DROP_OFF" as Fulfillment,
  });
  const [form, setForm] = useState(false),
    [lookup, setLookup] = useState<Lookup>(null),
    [query, setQuery] = useState(""),
    [search, setSearch] = useState(""),
    [filter, setFilter] = useState("ALL"),
    [message, setMessage] = useState(""),
    [toast, setToast] = useState<{text:string;type:"success"|"error"}|null>(null),
    [outputBusy, setOutputBusy] = useState<string|null>(null),
    [busy, setBusy] = useState(false),
    [listBusy, setListBusy] = useState(false),
    [newForm, setNewForm] = useState(false),
    [page, setPage] = useState(1),
    [hasMore, setHasMore] = useState(false),
    [totalRows, setTotalRows] = useState(0),
    [todayTransactionCount, setTodayTransactionCount] = useState(0),
    [dailyTransactionLimit, setDailyTransactionLimit] = useState<number|null|undefined>(undefined),
    [statusCounts, setStatusCounts] = useState<Record<string,number>>({ALL:0,RECEIVED:0,PROCESSING:0,READY:0,COMPLETED:0,DELETED:0});
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });
  const [data, setData] = useState({
    customer_id: 0,
    item_count: "",
    discount_id: 0,
    estimated_days: "1",
    payment_method: "CASH" as Method,
    payment_choice: "FULL" as "UNPAID"|"DP"|"FULL",
    cash_received: "",
    fulfillment_type: "DROP_OFF" as Fulfillment,
    is_priority: false,
    notes: "",
  });
  async function load(resetList = true, nextPage = 1, searchValue = search) {
    try {
      setListBusy(true);
      const result = await getOrders({
        page: nextPage,
        limit: 20,
        q: searchValue,
        status: filter === "ALL" ? "" : filter,
        branch_id: branchId,
      });
      setRows((current) =>
        resetList ? result.rows : [...current, ...result.rows],
      );
      setPage(result.page);
      setHasMore(result.has_more);
      setTotalRows(result.total);
      setStatusCounts(result.status_counts);
      setTodayTransactionCount(result.today_transaction_count);
      setDailyTransactionLimit(result.daily_transaction_limit);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Pesanan gagal dimuat");
    } finally {
      setListBusy(false);
    }
  }
  function clearSearch() {
    setSearch("");
    load(true, 1, "");
  }
  useEffect(() => {
    getCustomers().then(setCustomers);
    getInventoryItems().then(setInventory);
    getCompany().then(setCompanyInfo);
    if (user?.role === "OWNER") getBranches().then(setBranches);
  }, [user?.role]);
  useEffect(()=>{
    getProducts(false,branchId).then(setProducts);
    getDiscounts(false,branchId).then(setDiscounts);
    setItems([]);setData(x=>({...x,discount_id:0}));
  },[branchId]);
  useEffect(() => {
    load(true, 1);
  }, [filter, branchId]);
  const customer = customers.find((x) => x.id === data.customer_id),
    discount = discounts.find((x) => x.id === data.discount_id);
  const subtotal = items.reduce(
    (n, x) => n + Number(x.qty || 0) * Number(x.product.price),
    0,
  );
  const eligible = !!discount && subtotal >= Number(discount.min_transaction);
  const discountAmount = eligible
      ? Math.min(
          subtotal,
          discount!.type === "PERCENT"
            ? (subtotal * Number(discount!.value)) / 100
            : Number(discount!.value),
        )
      : 0,
    total = subtotal - discountAmount,
    received = data.payment_choice === "UNPAID" ? 0 : Number(data.cash_received || 0),
    paidNow = data.payment_choice === "UNPAID" ? 0 : data.payment_choice === "DP" ? Math.min(total,received) : total,
    outstanding = Math.max(0,total-paidNow),
    change = data.payment_choice === "FULL" ? Math.max(0, received - total) : 0;
  const shown = rows;
  useEffect(() => {
    if (params.new === "1") {
      void openCreateForm();
      router.setParams({ new: undefined });
    }
  }, [params.new]);
  const lookupRows = useMemo(() => {
    const q = query.toLowerCase();
    return lookup === "customer"
      ? customers.filter((x) =>
          `${x.name} ${x.phone ?? ""} ${x.address ?? ""}`
            .toLowerCase()
            .includes(q),
        )
      : lookup === "product" ? products.filter((x) =>
          `${x.name} ${x.category_name ?? ""}`.toLowerCase().includes(q),
        ) : inventory.filter((x) => `${x.item_code} ${x.name}`.toLowerCase().includes(q));
  }, [lookup, query, customers, products, inventory]);
  function reset() {
    setForm(false);
    setItems([]);
    setInventoryUses([]);
    setData({
      customer_id: 0,
      item_count: "",
      discount_id: 0,
      estimated_days: "1",
      payment_method: "CASH",
      payment_choice: "FULL",
      cash_received: "",
      fulfillment_type: "DROP_OFF",
      is_priority: false,
      notes: "",
    });
    setNewForm(false);
    setMessage("");
  }
  function addProduct(product: Product) {
    setItems((x) => {
      const found = x.find((v) => v.product.id === product.id);
      return found
        ? x.map((v) =>
            v.product.id === product.id
              ? { ...v, qty: String(Number(v.qty || 0) + 1) }
              : v,
          )
        : [...x, { product, qty: "1" }];
    });
    setLookup(null);
  }
  function addInventory(item: InventoryItem) {
    setInventoryUses((rows) => {
      const found = rows.find((x) => x.item.id === item.id);
      return found
        ? rows.map((x) => x.item.id === item.id ? {...x, qty:String(Number(x.qty || 0) + 1)} : x)
        : [...rows, {item, qty:"1"}];
    });
    setLookup(null);
  }
  async function saveCustomer() {
    try {
      setBusy(true);
      const x = await addCustomer(newCustomer);
      // Refresh master pelanggan setelah insert agar lookup Pesanan selalu memakai data terbaru.
      const refreshed = await getCustomers();
      const created = refreshed.find((row) => row.id === x.id) ?? x;
      // Beberapa backend membutuhkan sedikit waktu sebelum hasil query
      // pelanggan terbaru memuat record baru. Tetap masukkan hasil insert
      // agar pelanggan langsung terpilih pada form pesanan.
      setCustomers((current) => [
        created,
        ...refreshed.filter((row) => row.id !== created.id),
        ...current.filter((row) => row.id !== created.id && !refreshed.some((fresh) => fresh.id === row.id)),
      ]);
      setData((v) => ({ ...v, customer_id: created.id }));
      setNewForm(false);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Pelanggan gagal disimpan");
    } finally {
      setBusy(false);
    }
  }
  async function openCustomerLookup() {
    setQuery("");
    setLookup("customer");
    try {
      // Lookup Pelanggan harus selalu memakai master terbaru, karena data
      // dapat baru saja ditambah dari tab Pelanggan.
      const refreshed = await getCustomers();
      setCustomers(refreshed);
    } catch (e) {
      const text = e instanceof Error ? e.message : "Data pelanggan gagal dimuat ulang";
      setMessage(text);
      showToast(text, "error");
    }
  }
  async function save() {
    try {
      setBusy(true);
      if (!customer) throw new Error("Pelanggan wajib dipilih.");
      const invalidInventory = inventoryUses.find((x) => Number(x.qty) <= 0 || Number(x.qty) > Number(x.item.current_stock));
      if (invalidInventory) throw new Error(`Stok ${invalidInventory.item.name} tidak mencukupi atau qty tidak valid.`);
      const order = await addOrder({
        ...data,
        branch_id:branchId||undefined,
        item_count: Number(data.item_count),
        items: items.map((x) => ({
          product_id: x.product.id,
          qty: Number(x.qty),
        })),
        discount_id: data.discount_id || undefined,
        estimated_days: Number(data.estimated_days),
        cash_received: received,
      });
      if (inventoryUses.length) await consumeOrderInventory(order.id, inventoryUses.map((x) => ({item_id:x.item.id, qty:Number(x.qty)})));
      const success = `Pesanan berhasil disimpan. Kembalian Rp ${change.toLocaleString("id-ID")}.`;
      reset();
      setMessage(success);
      showToast(`✓ ${success}`);
      await load(true, 1);
      notifyOrdersChanged();
    } catch (e) {
      const text=e instanceof Error ? e.message : "Pesanan gagal dibuat";
      setMessage(text);
      if(text.toLowerCase().includes("limit")||text.toLowerCase().includes("batas transaksi"))showToast("Transaksi sudah mencapai limit per hari!","error");
    } finally {
      setBusy(false);
    }
  }
  function showToast(text:string,type:"success"|"error"="success"){setToast({text,type});setTimeout(()=>setToast(null),3500)}
  async function openCreateForm(){
    if(form){reset();return}
    let count=todayTransactionCount,limit=dailyTransactionLimit;
    if(limit===undefined){
      try{
        const fresh=await getOrders({page:1,limit:10,branch_id:branchId});
        count=fresh.today_transaction_count;
        limit=fresh.daily_transaction_limit;
        setTodayTransactionCount(count);
        setDailyTransactionLimit(limit);
      }catch(e){
        const text=e instanceof Error?e.message:"Status limit transaksi gagal diperiksa.";
        showToast(text,"error");
        return;
      }
    }
    if(limit!==null&&count>=limit){
      showToast("Transaksi sudah mencapai limit per hari!","error");
      return;
    }
    setForm(true);
  }
  async function output(action:(company:Partial<Company>,order?:Order)=>Promise<void>,order:Order){
  const actionName=action===emailReceipt?"email":action===whatsappReceipt?"whatsapp":action===printReceipt?"receipt":action===printLabel?"label":"pdf";
  const busyKey=`${order.id}:${actionName}`;
  if(outputLock.current)return;
  outputLock.current=true;
  try{
    setOutputBusy(busyKey);
    setMessage("");
    if(action===printReceipt || action===printLabel){
      const printer=await selectedPrinter();
      if(!printer){
        setOutputOrder(null);
        setMessage("Printer Bluetooth belum diatur. Membuka pengaturan printer...");
        router.push("/receipt-settings");
        return;
      }
    }
    await action(companyInfo,order);
    if(action===emailReceipt){const text=`Nota pesanan berhasil dikirim ke ${order.customer_email}.`;setMessage(text);showToast(`✓ ${text}`)}
    else if(action===whatsappReceipt){const success=`Struk WhatsApp berhasil dikirim ke ${order.customer_phone}.`;setMessage(success);showToast(`✓ ${success}`)}
    else if(action===printReceipt){const text=`Struk ${order.invoice_number} berhasil dicetak.`;setMessage(text);showToast(`✓ ${text}`)}
    else if(action===printLabel){const text=`Label ${order.invoice_number} berhasil dicetak.`;setMessage(text);showToast(`✓ ${text}`)}
  }catch(e){const text=e instanceof Error?e.message:"Output struk gagal";setMessage(text);showToast(`✕ ${text}`,"error")}finally{outputLock.current=false;setOutputBusy(null)}
}
  async function reminder(order:Order){const key=`${order.id}:reminder`;if(outputBusy)return;try{setOutputBusy(key);await whatsappReminder(companyInfo,order);const text=`Reminder WhatsApp berhasil dikirim ke ${order.customer_phone}.`;setMessage(text);showToast(`✓ ${text}`)}catch(e){const text=e instanceof Error?e.message:"Reminder WhatsApp gagal dikirim";setMessage(text);showToast(`✕ ${text}`,"error")}finally{setOutputBusy(null)}}
  async function status(
    id: number,
    next: "PROCESSING" | "READY" | "COMPLETED",
  ) {
    try {
      const current=rows.find(x=>x.id===id);
      if(next==="COMPLETED"&&current&&Number(current.outstanding_amount)>0){setSettleTarget(current);setSettleCash("");setSettleMethod("CASH");return}
      await updateOrderStatus(id, next);
      await load(true, 1);
      notifyOrdersChanged();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Status gagal diperbarui");
    }
  }
  async function completePayment(){if(!settleTarget)return;try{setBusy(true);const due=Number(settleTarget.outstanding_amount);const cash=settleMethod==="CASH"?Number(settleCash):due;if(cash<due)throw new Error("Uang diterima kurang dari sisa piutang.");const completed=await settleOrder(settleTarget.id,{cash_received:cash,payment_method:settleMethod});setSettleTarget(null);setSettleCash("");setOutputOrder({...settleTarget,...completed,status:"COMPLETED",outstanding_amount:0,payment_status:"PAID"});setMessage(`Pembayaran lunas. Kembalian Rp ${Math.max(0,cash-due).toLocaleString("id-ID")}.`);await load(true,1);notifyOrdersChanged()}catch(e){setMessage(e instanceof Error?e.message:"Pelunasan gagal")}finally{setBusy(false)}}
  function openEdit(order:Order){
    if(order.status==='COMPLETED')return;
    const paid=Number(order.paid_amount??0);
    const isPaid=paid>0;
    setEditTarget(order);
    setEditPaymentPreset(isPaid ? (paid===Number(order.total) ? "FULL" : "DP") : null);
    setEditData({
      is_priority: Number(order.is_priority)===1,
      payment_choice:isPaid?'PAID':'UNPAID',
      payment_method:(isPaid && order.payment_method ? order.payment_method as Method : 'CASH'),
      paid_amount:isPaid ? String(paid) : '',
      notes:order.notes??'',
      discount_id:Number(order.discount_id??0),
      fulfillment_type:(order.fulfillment_type as Fulfillment)||'DROP_OFF',
    });
  }
  async function saveEdit(){
    if(!editTarget)return;
    try{setEditBusy(true);const saved=await updateOrder(editTarget.id,{
      ...editData,
      paid_amount:editData.payment_choice==='UNPAID'?0:Number(editData.paid_amount||0),
      discount_id:editData.discount_id||null,
      fulfillment_type:editData.fulfillment_type,
    });setEditTarget(null);setMessage('Pesanan berhasil diperbarui.');load(true,1);}catch(e){setMessage(e instanceof Error?e.message:'Pesanan gagal diperbarui')}finally{setEditBusy(false)}
  }
  async function removeOrder(){
    if(!deleteTarget||!deleteReason.trim())return;
    try{setEditBusy(true);await deleteOrder(deleteTarget.id,deleteReason.trim());setDeleteTarget(null);setDeleteReason('');setMessage('Pesanan berhasil dihapus.');await load(true,1);notifyOrdersChanged();}catch(e){setMessage(e instanceof Error?e.message:'Pesanan gagal dihapus')}finally{setEditBusy(false)}
  }

  function chooseMethod(v: Method) {
    setData((x) => ({
      ...x,
      payment_method: v,
      cash_received: v === "CASH" ? "" : String(total),
    }));
  }
  const filters = [
    ["ALL", "Semua"],
    ["RECEIVED", "Diterima"],
    ["PROCESSING", "Diproses"],
    ["READY", "Selesai"],
    ["COMPLETED", "Diambil"],
    ...(user?.role === "OWNER" ? [["DELETED", "Dihapus"]] : []),
  ];
  return (
    <Screen overlay={toast ? <View pointerEvents="none" style={[s.toast,toast.type==="error"&&s.toastError]}><Text style={s.toastText}>{toast.text}</Text></View> : null}>
      <View style={s.head}>
        <View style={s.headTitle}><ScreenTitle title="Pesanan" subtitle="Pantau semua cucian pelanggan" /></View>
        <View style={s.actions}>
          <Pressable onPress={() => load(true, 1)} style={s.icon}>
            <Text>↻</Text>
          </Pressable>
          <Pressable
            onPress={openCreateForm}
            style={s.add}
          >
            <Text style={s.addText}>{form ? "Tutup" : "＋ Baru"}</Text>
          </Pressable>
        </View>
      </View>
      {message ? <Text style={s.message}>{message}</Text> : null}
      {outputOrder ? <ReceiptActions order={outputOrder} run={output} busyKey={outputBusy} close={()=>setOutputOrder(null)}/> : null}
      <Modal visible={!!settleTarget} transparent animationType="fade" onRequestClose={()=>setSettleTarget(null)}>{settleTarget?<View style={s.modalBackdrop}><View style={s.settleModal}><Text style={s.bold}>Pelunasan saat pengambilan</Text><Text style={s.small}>{settleTarget.invoice_number} · {settleTarget.customer_name}</Text><Money label="Sisa piutang" value={Number(settleTarget.outstanding_amount)}/><Text style={s.settleLabel}>METODE PEMBAYARAN</Text><View style={s.chips}>{([['CASH','Cash'],['BANK_TRANSFER','Transfer'],['QRIS','QRIS']] as [Method,string][]).map(([value,label])=><Chip key={value} label={label} active={settleMethod===value} onPress={()=>{setSettleMethod(value);if(value!=="CASH")setSettleCash(String(settleTarget.outstanding_amount))}}/>)}</View>{settleMethod==="CASH"?<><Text style={s.settleLabel}>NILAI UANG</Text><View style={s.chips}><Chip label="Uang pas" active={Number(settleCash)===Number(settleTarget.outstanding_amount)} onPress={()=>setSettleCash(String(settleTarget.outstanding_amount))}/>{[20000,50000,100000].map(x=><Chip key={x} label={x.toLocaleString("id-ID")} active={Number(settleCash)===x} onPress={()=>setSettleCash(String(x))}/>)}</View><Field label="Uang diterima" value={settleCash} keyboardType="number-pad" onChangeText={x=>setSettleCash(x.replace(/\D/g,""))}/><Money label="Kembalian" value={Math.max(0,Number(settleCash)-Number(settleTarget.outstanding_amount))}/></>:<Text style={s.transferHint}>Nilai pembayaran otomatis sama dengan sisa piutang.</Text>}<View style={s.modalButtons}><Button title={busy?"Memproses...":"Bayar & tandai diambil"} disabled={busy||(settleMethod==="CASH"&&Number(settleCash)<Number(settleTarget.outstanding_amount))} onPress={completePayment}/><Button title="Batal" variant="danger" disabled={busy} onPress={()=>setSettleTarget(null)}/></View></View></View>:null}</Modal>
      <Modal visible={!!editTarget} transparent animationType="slide" onRequestClose={()=>setEditTarget(null)}>
        {editTarget?<View style={s.modalBackdrop}><View style={s.editModal}><View style={s.head}><View><Text style={s.bold}>Detail Pesanan</Text><Text style={s.small}>{editTarget.invoice_number} · {editTarget.customer_name}</Text></View><Pressable onPress={()=>setEditTarget(null)}><Text style={{fontSize:28}}>×</Text></Pressable></View><ScrollView keyboardShouldPersistTaps="handled" style={{maxHeight:520}}>
          <Label text="Prioritas"/><View style={s.chips}><Chip label="Tidak" active={!editData.is_priority} onPress={()=>setEditData(x=>({...x,is_priority:false}))}/><Chip label="Ya" active={editData.is_priority} onPress={()=>setEditData(x=>({...x,is_priority:true}))}/></View>
          <Label text="Diskon"/><View style={s.chips}><Chip label="Tanpa diskon" active={!editData.discount_id} onPress={()=>setEditData(x=>({...x,discount_id:0}))}/>{discounts.map(d=><Chip key={d.id} label={d.name} active={editData.discount_id===d.id} onPress={()=>setEditData(x=>({...x,discount_id:d.id}))}/>)}</View>
          <Label text="Jemput / antar"/><View style={s.chips}>{([["DROP_OFF","Datang sendiri"],["PICKUP","Jemput"],["DELIVERY","Antar"]] as const).map(([v,l])=><Chip key={v} label={l} active={editData.fulfillment_type===v} onPress={()=>setEditData(x=>({...x,fulfillment_type:v}))}/>)}</View>
          <Label text="Jenis bayar"/><View style={s.chips}>
            <Chip label="Bayar" active={editData.payment_choice==='PAID'} onPress={()=>setEditData(x=>({...x,payment_choice:'PAID',payment_method:x.payment_method||'CASH'}))}/>
            <Chip label="Belum bayar" active={editData.payment_choice==='UNPAID'} onPress={()=>{setEditPaymentPreset(null);setEditData(x=>({...x,payment_choice:'UNPAID',paid_amount:''}))}}/>
          </View>
          {editData.payment_choice==='PAID'?<>
            <Label text="Metode pembayaran"/><View style={s.chips}>{([['CASH','Cash'],['BANK_TRANSFER','Transfer'],['QRIS','QRIS']] as [Method,string][]).map(([v,l])=><Chip key={v} label={l} active={editData.payment_method===v} onPress={()=>setEditData(x=>({...x,payment_method:v}))}/>)}</View>
            <Label text="Pembayaran"/><View style={s.chips}>
              <Chip label="DP" active={editPaymentPreset==='DP'} onPress={()=>{setEditPaymentPreset('DP');setEditData(x=>({...x,paid_amount:String(Number(x.paid_amount||editTarget?.paid_amount||0))}))}}/>
              <Chip label="Uang Pas" active={editPaymentPreset==='FULL'} onPress={()=>{setEditPaymentPreset('FULL');setEditData(x=>({...x,paid_amount:String(Number(editTarget?.total??0))}))}}/>
              {[20000,50000,100000].map(v=><Chip key={v} label={v.toLocaleString("id-ID")} active={editPaymentPreset==='AMOUNT' && Number(editData.paid_amount)===v} onPress={()=>{setEditPaymentPreset('AMOUNT');setEditData(x=>({...x,paid_amount:String(v)}))}}/>)}
            </View>
            <Field label="Jumlah bayar" value={editData.paid_amount} keyboardType="decimal-pad" onChangeText={v=>{setEditPaymentPreset(null);setEditData(x=>({...x,paid_amount:v.replace(',','.')}))}}/>
          </>:null}
          <Label text="Layanan / Pesanan"/>
          <View style={s.orderSummary}>
            {(editTarget?.items?.length?editTarget.items:null)?.map(it=>(
              <View key={it.id} style={s.itemRow}>
                <Text style={s.itemName}>{it.product_name}</Text>
                <View style={s.itemLine}>
                  <Text style={s.small}>{Number(it.qty).toLocaleString('id-ID')} x Rp {Number(it.price).toLocaleString('id-ID')}</Text>
                  <Text style={s.summaryValue}>Rp {Number(it.subtotal).toLocaleString('id-ID')}</Text>
                </View>
              </View>
            )) ?? <View style={s.summaryRow}><Text style={s.small}>Layanan</Text><Text style={s.summaryValue}>{editTarget?.service_name || '-'}</Text></View>}
            <View style={s.summaryDivider}/>
            <View style={s.summaryRow}><Text style={s.small}>Subtotal</Text><Text style={s.summaryValue}>Rp {Number(editTarget?.subtotal ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.small}>Diskon</Text><Text style={s.summaryValue}>Rp {Number(editTarget?.discount_amount ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.bold}>Total</Text><Text style={s.summaryValueBold}>Rp {Number(editTarget?.total ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.small}>DP</Text><Text style={s.summaryValue}>Rp {Number(editTarget?.dp_amount ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.small}>Nilai Bayar</Text><Text style={s.summaryValue}>Rp {Number(editTarget?.paid_amount ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.small}>Sisa Pembayaran</Text><Text style={s.summaryValue}>Rp {Number(editTarget?.outstanding_amount ?? 0).toLocaleString('id-ID')}</Text></View>
            <View style={s.summaryRow}><Text style={s.small}>Estimasi</Text><Text style={s.summaryValue}>{Number(editTarget?.estimated_days ?? 0)} hari</Text></View>
          </View>
          <Field label="Catatan" value={editData.notes} multiline style={{height:90,textAlignVertical:'top',paddingTop:12}} onChangeText={v=>setEditData(x=>({...x,notes:v}))}/>
          <View style={s.modalButtons}><Button title={editBusy?"Menyimpan...":"Simpan perubahan"} disabled={editBusy} onPress={saveEdit}/><Button title="Batal" variant="danger" disabled={editBusy} onPress={()=>setEditTarget(null)}/></View>
        </ScrollView></View></View>:null}
      </Modal>
      <Modal visible={!!deleteTarget} transparent animationType="fade" onRequestClose={()=>setDeleteTarget(null)}>
        {deleteTarget?<View style={s.modalBackdrop}><View style={s.editModal}><Text style={s.bold}>Hapus Pesanan</Text><Text style={s.small}>{deleteTarget.invoice_number} · {deleteTarget.customer_name}</Text><Text style={s.small}>Masukkan alasan penghapusan. Histori tetap dicatat di audit log.</Text><Field label="Alasan wajib" value={deleteReason} multiline style={{height:100,textAlignVertical:'top',paddingTop:12}} onChangeText={setDeleteReason}/><View style={s.modalButtons}><Button title={editBusy?"Menghapus...":"Hapus transaksi"} variant="danger" disabled={editBusy||!deleteReason.trim()} onPress={removeOrder}/><Button title="Batal" variant="soft" disabled={editBusy} onPress={()=>{setDeleteTarget(null);setDeleteReason('')}}/></View></View></View>:null}
      </Modal>
      {form ? (
        <Card>
          <Label text="Pelanggan" />
          <View style={s.two}>
            <Action
              title={customer ? "Cari pelanggan lain" : "Cari pelanggan"}
              onPress={openCustomerLookup}
            />
            <Action
              title={newForm ? "Tutup form" : "＋ Pelanggan baru"}
              primary
              onPress={() => setNewForm((x) => !x)}
            />
          </View>
          {newForm ? (
            <View style={s.inline}>
              <Field
                label="Nama"
                value={newCustomer.name}
                onChangeText={(name) => setNewCustomer((x) => ({ ...x, name }))}
              />
              <Field
                label="No. HP"
                value={newCustomer.phone}
                onChangeText={(phone) =>
                  setNewCustomer((x) => ({ ...x, phone }))
                }
              />
              <Field
                label="Email"
                value={newCustomer.email}
                onChangeText={(email) =>
                  setNewCustomer((x) => ({ ...x, email }))
                }
              />
              <Field
                label="Alamat"
                value={newCustomer.address}
                onChangeText={(address) =>
                  setNewCustomer((x) => ({ ...x, address }))
                }
              />
              <Button
                title="Simpan & pilih"
                disabled={busy || !newCustomer.name}
                onPress={saveCustomer}
              />
            </View>
          ) : null}
          {customer ? (
            <Selected
              title={customer.name}
              detail={`${customer.phone || "-"} · ${customer.address || "-"}`}
            />
          ) : null}
          <Label text="Produk / layanan" />
          <Button
            title="Cari produk"
            variant="soft"
            onPress={() => setLookup("product")}
          />
          {items.map((x, i) => (
            <View key={x.product.id} style={s.item}>
              <View style={{ flex: 1 }}>
                <Text style={s.bold}>{x.product.name}</Text>
                <Text style={s.small}>
                  Rp {Number(x.product.price).toLocaleString("id-ID")}/
                  {x.product.unit}
                </Text>
              </View>
              <TextInput
                value={x.qty}
                keyboardType="numeric"
                onChangeText={(qty) =>
                  setItems((v) =>
                    v.map((z, j) => (j === i ? { ...z, qty } : z)),
                  )
                }
                style={s.qty}
              />
              <Pressable
                onPress={() => setItems((v) => v.filter((_, j) => j !== i))}
                style={s.trash}
              >
                <Text>🗑</Text>
              </Pressable>
            </View>
          ))}
          <Label text="Inventory yang digunakan (opsional)" />
          <Button title="Cari item inventory" variant="soft" onPress={() => setLookup("inventory")} />
          {inventoryUses.map((x, i) => (
            <View key={x.item.id} style={s.item}>
              <View style={{flex:1}}><Text style={s.bold}>{x.item.name}</Text><Text style={s.small}>Stok {Number(x.item.current_stock).toLocaleString("id-ID")} {x.item.unit}</Text></View>
              <TextInput value={x.qty} keyboardType="decimal-pad" onChangeText={(qty) => setInventoryUses((v) => v.map((z,j) => j === i ? {...z,qty:qty.replace(",", ".")} : z))} style={s.qty}/>
              <Pressable onPress={() => setInventoryUses((v) => v.filter((_,j) => j !== i))} style={s.trash}><Text>🗑</Text></Pressable>
            </View>
          ))}
          <Field
            label="Jumlah barang diterima"
            value={data.item_count}
            onChangeText={(item_count) =>
              setData((x) => ({
                ...x,
                item_count: item_count.replace(/\D/g, ""),
              }))
            }
            keyboardType="number-pad"
            placeholder="Hitung jumlah fisik barang"
          />
          <Field
            label="Estimasi pengerjaan (hari)"
            value={data.estimated_days}
            onChangeText={(estimated_days) =>
              setData((x) => ({
                ...x,
                estimated_days: estimated_days
                  .replace(/[^0-9.,]/g, "")
                  .replace(",", "."),
              }))
            }
            keyboardType="decimal-pad"
          />
          <Label text="Diskon" />
          <View style={s.chips}>
            <Chip
              label="Tanpa diskon"
              active={!data.discount_id}
              onPress={() => setData((x) => ({ ...x, discount_id: 0 }))}
            />
            {discounts.map((x) => (
              <Chip
                key={x.id}
                label={x.name}
                active={data.discount_id === x.id}
                onPress={() => setData((v) => ({ ...v, discount_id: x.id }))}
              />
            ))}
          </View>
          {discount ? (
            <View style={s.discountInfo}>
              <Text style={s.bold}>{discount.name}</Text>
              <Text style={s.discountValue}>
                {discount.type === "PERCENT"
                  ? `${Number(discount.value)}%`
                  : `Rp ${Number(discount.value).toLocaleString("id-ID")}`}{" "}
                · Potongan Rp {discountAmount.toLocaleString("id-ID")}
              </Text>
              {!eligible ? (
                <Text style={s.small}>
                  Minimal transaksi Rp{" "}
                  {Number(discount.min_transaction).toLocaleString("id-ID")}
                </Text>
              ) : null}
            </View>
          ) : null}
          <Label text="Jemput / antar" />
          <View style={s.chips}>
            {(
              [
                ["DROP_OFF", "Datang sendiri"],
                ["PICKUP", "Jemput"],
                ["DELIVERY", "Antar"],
              ] as const
            ).map((x) => (
              <Chip
                key={x[0]}
                label={x[1]}
                active={data.fulfillment_type === x[0]}
                onPress={() =>
                  setData((v) => ({ ...v, fulfillment_type: x[0] }))
                }
              />
            ))}
          </View>
          <Label text="Prioritas" />
          <View style={s.chips}>
            <Chip
              label="Tidak"
              active={!data.is_priority}
              onPress={() => setData((x) => ({ ...x, is_priority: false }))}
            />
            <Chip
              label="Ya"
              active={data.is_priority}
              onPress={() => setData((x) => ({ ...x, is_priority: true }))}
            />
          </View>
          <Field
            label="Catatan"
            value={data.notes}
            onChangeText={(notes) => setData((x) => ({ ...x, notes }))}
            multiline
          />
          <View style={s.summary}>
            <Money label="Subtotal" value={subtotal} />
            <Money label="Diskon" value={-discountAmount} />
            <Money label="Total" value={total} />
          </View>
          <View style={s.payment}>
            <Label text="Pembayaran" />
            <View style={s.chips}>
              <Chip label="Bayar" active={data.payment_choice!=="UNPAID"} onPress={()=>setData(x=>({...x,payment_choice:"FULL",cash_received:""}))}/>
              <Chip label="Belum bayar" active={data.payment_choice==="UNPAID"} onPress={()=>setData(x=>({...x,payment_choice:"UNPAID",cash_received:""}))}/>
            </View>
            {data.payment_choice!=="UNPAID" ? (
              <>
                <View style={s.chips}>
                  <Chip label="DP" active={data.payment_choice==="DP"} onPress={()=>setData(x=>({...x,payment_choice:"DP",cash_received:""}))}/>
                  <Chip
                    label="Uang pas"
                    active={data.payment_choice==="FULL"&&received === total && total > 0}
                    onPress={() =>
                      setData((x) => ({ ...x,payment_choice:"FULL", cash_received: String(total) }))
                    }
                  />
                  {[20000, 50000, 100000].map((x) => (
                    <Chip
                      key={x}
                      label={x.toLocaleString("id-ID")}
                      active={data.payment_choice==="FULL"&&received === x}
                      onPress={() =>
                        setData((v) => ({ ...v,payment_choice:"FULL", cash_received: String(x) }))
                      }
                    />
                  ))}
                </View>
                <Field
                  label="Uang diterima"
                  value={data.cash_received}
                  onChangeText={(cash_received) =>
                    setData((x) => ({ ...x, cash_received }))
                  }
                  keyboardType="number-pad"
                />
              </>
            ) : (
              <Selected
                title={`Piutang Rp ${total.toLocaleString("id-ID")}`}
                detail="Pembayaran diselesaikan paling lambat saat pengambilan"
              />
            )}
            <Money label="Dibayar sekarang" value={paidNow}/>
            <Money label="Sisa piutang" value={outstanding}/>
            <Money label="Kembalian" value={change} />
          </View>
          <Button
            title={busy ? "Menyimpan..." : "Simpan"}
            disabled={
              busy ||
              !customer ||
              !items.length ||
              Number(data.item_count) < 1 ||
              (data.payment_choice==="FULL"&&received < total) ||
              (data.payment_choice==="DP"&&(received<=0||received>=total))
            }
            onPress={save}
          />
          <View style={s.cancel}>
            <Button title="Batal" variant="danger" onPress={reset} />
          </View>
        </Card>
      ) : (
        <>
          {user?.role === "OWNER" ? (
            <>
              <Label text="Cabang" />
              <ScrollView horizontal contentContainerStyle={s.filters}>
                <Chip label="Semua cabang" active={branchId === 0} onPress={() => setBranchId(0)} />
                {branches.map((branch) => (
                  <Chip key={branch.id} label={branch.name} active={branchId === branch.id} onPress={() => setBranchId(branch.id)} />
                ))}
              </ScrollView>
            </>
          ) : null}
          <View style={s.searchBox}>
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Cari nomor order atau customer"
              style={s.searchInput}
              onSubmitEditing={() => load(true, 1)}
            />
            {search ? (
              <Pressable accessibilityLabel="Reset pencarian" onPress={clearSearch} style={s.searchReset}>
                <Text style={s.searchResetText}>×</Text>
              </Pressable>
            ) : null}
            <Pressable onPress={() => load(true, 1)} style={s.searchButton}>
              <Text style={s.searchText}>Cari</Text>
            </Pressable>
          </View>
          <ScrollView horizontal contentContainerStyle={s.filters}>
            {filters.map((x) => {
              const count = statusCounts[x[0]] ?? 0;
              return (
                <Chip
                  key={x[0]}
                  label={`${x[1]} (${count})`}
                  active={filter === x[0]}
                  onPress={() => setFilter(x[0])}
                />
              );
            })}
          </ScrollView>
          <Text style={s.resultInfo}>
            Menampilkan {rows.length} dari {totalRows} pesanan
          </Text>
          {shown.map((x) => (
            <Card key={x.id}>
              <View style={s.head}>
                <View style={s.invoiceRow}>
                  <Text style={s.invoiceNumber} numberOfLines={1} ellipsizeMode="tail">{x.invoice_number}</Text>
                  <Text style={Number(x.is_priority)===1?s.priorityStarOn:s.priorityStarOff}>★</Text>
                </View>
                <Text style={s.status}>{statusLabel(x.status)}</Text>
              </View>
              <Text style={s.bold}>{x.customer_name}</Text>
              <Text style={s.small}>
                {x.service_name} · {Number(x.item_count || 0)} barang · Rp{" "}
                {Number(x.total).toLocaleString("id-ID")}
              </Text>
              <Text style={s.small}>{formatOrderDate(x.created_at)}</Text>
              {x.status==="DELETED"?<><Text style={s.deletedLabel}>Alasan dihapus</Text><Text style={s.deletedReason}>{x.deletion_reason||"Alasan tidak tersedia"}</Text><Text style={s.small}>Dihapus: {formatOrderDate(x.deleted_at??x.updated_at)}</Text></>:null}
              {Number(x.outstanding_amount)>0?<>
                <Text style={[s.paymentState,s.paymentDue]}>{x.payment_status==="PARTIAL"?`DP Rp ${Number(x.paid_amount).toLocaleString("id-ID")}`:"Belum bayar"}</Text>
                <Text style={[s.paymentState,s.paymentDue]}>Piutang Rp {Number(x.outstanding_amount).toLocaleString("id-ID")}</Text>
              </>:<Text style={[s.paymentState,s.paymentPaid]}>Lunas</Text>}
              {user?.role === "OWNER" && !["COMPLETED","DELETED"].includes(x.status) ? <View style={s.ownerOrderActions}><View style={{flex:1}}><Button title="Detail" variant="soft" onPress={()=>openEdit(x)}/></View><View style={{flex:1}}><Button title="Hapus" variant="danger" onPress={()=>{setDeleteTarget(x);setDeleteReason('')}}/></View></View> : null}
              {!["COMPLETED","DELETED"].includes(x.status) ? (
                <><Button
                  title={
                    x.status === "RECEIVED"
                      ? "Mulai proses"
                      : x.status === "PROCESSING"
                        ? "Tandai selesai"
                        : "Sudah diambil"
                  }
                  onPress={() =>
                    status(
                      x.id,
                      x.status === "RECEIVED"
                        ? "PROCESSING"
                        : x.status === "PROCESSING"
                          ? "READY"
                          : "COMPLETED",
                    )
                  }
                />{x.status==="READY"?<View style={s.reminderGap}><Button title={outputBusy===`${x.id}:reminder`?"Mengirim reminder...":"🔔 Kirim Reminder"} disabled={outputBusy!==null} variant="soft" onPress={()=>reminder(x)}/></View>:null}<ReceiptActions order={x} run={output} busyKey={outputBusy}/></>
              ) : null}
            </Card>
          ))}
          {hasMore ? (
            <Button
              title={listBusy ? "Memuat..." : "Muat 20 berikutnya"}
              disabled={listBusy}
              variant="soft"
              onPress={() => load(false, page + 1)}
            />
          ) : null}
        </>
      )}
      <LookupModal
        type={lookup}
        rows={lookupRows}
        query={query}
        setQuery={setQuery}
        close={() => setLookup(null)}
        choose={(x) =>
          lookup === "customer"
            ? (setData((v) => ({ ...v, customer_id: x.id })), setLookup(null))
            : lookup === "product" ? addProduct(x) : addInventory(x)
        }
      />
    </Screen>
  );
}
function ReceiptActions({order,run,busyKey,close}:{order:Order;run:(action:(company:Partial<Company>,order?:Order)=>Promise<void>,order:Order)=>void;busyKey:string|null;close?:()=>void}){const key=(name:string)=>`${order.id}:${name}`,blocked=busyKey!==null;return <View style={s.receiptActions}><View style={s.receiptHead}><View><Text style={s.bold}>Output</Text></View>{close?<Pressable disabled={blocked} onPress={close}><Text style={s.receiptClose}>×</Text></Pressable>:null}</View><View style={s.outputGrid}><ReceiptAction title={busyKey===key("receipt")?"Mencetak...":"Struk"} disabled={blocked} onPress={()=>run(printReceipt,order)}/><ReceiptAction title={busyKey===key("label")?"Mencetak...":"Label"} disabled={blocked} onPress={()=>run(printLabel,order)}/><ReceiptAction title={busyKey===key("pdf")?"Memproses...":"PDF"} disabled={blocked} onPress={()=>run(printPdf,order)}/><ReceiptAction title={busyKey===key("email")?"Mengirim...":"Email"} disabled={blocked} onPress={()=>run(emailReceipt,order)}/><ReceiptAction title={busyKey===key("whatsapp")?"Mengirim...":"WhatsApp"} disabled={blocked} onPress={()=>run(whatsappReceipt,order)}/></View></View>}
function ReceiptAction({title,onPress,disabled=false}:{title:string;onPress:()=>void;disabled?:boolean}){return <Pressable disabled={disabled} onPress={onPress} style={[s.outputButton,disabled&&s.outputButtonDisabled]}><Text style={s.outputText}>{title}</Text></Pressable>}
function Action({
  title,
  onPress,
  primary = false,
}: {
  title: string;
  onPress: () => void;
  primary?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={[s.action, primary && s.actionOn]}>
      <Text style={[s.actionText, primary && { color: "#fff" }]}>{title}</Text>
    </Pressable>
  );
}
function Selected({ title, detail }: { title: string; detail: string }) {
  return (
    <View style={s.selected}>
      <Text style={s.bold}>{title}</Text>
      <Text style={s.small}>{detail}</Text>
    </View>
  );
}
function Label({ text }: { text: string }) {
  return <Text style={s.label}>{text}</Text>;
}
function Chip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const badge = label.match(/^(.*?)\s+\((\d+)\)$/);
  return (
    <View
      style={{
        position: "relative",
        overflow: "visible",
        marginTop: badge ? 7 : 0,
        marginRight: badge ? 4 : 0,
      }}
    >
      <Pressable
        onPress={onPress}
        style={[
          s.chip,
          active && s.chipOn,
          badge && { minWidth: 76, alignItems: "center" },
        ]}
      >
        <Text style={[s.chipText, active && { color: "#fff" }]}>
          {badge ? badge[1] : label}
        </Text>
      </Pressable>
      {badge && Number(badge[2]) > 0 ? (
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            right: -7,
            top: -9,
            minWidth: 22,
            height: 22,
            borderRadius: 11,
            paddingHorizontal: 5,
            backgroundColor: "#DC2626",
            borderWidth: 2,
            borderColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 20,
            elevation: 6,
          }}
        >
          <Text
            style={{
              color: "#fff",
              fontSize: 10,
              fontWeight: "900",
              lineHeight: 14,
            }}
          >
            {Number(badge[2]) > 999 ? "999+" : badge[2]}
          </Text>
        </View>
      ) : null}
    </View>
  );
}
function Money({ label, value }: { label: string; value: number }) {
  return (
    <View style={s.money}>
      <Text>{label}</Text>
      <Text style={s.total}>Rp {value.toLocaleString("id-ID")}</Text>
    </View>
  );
}
function formatOrderDate(value:string|undefined){
  if(!value)return "-";
  const m=value.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if(!m)return value;
  const months=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agt","Sep","Okt","Nov","Des"];
  return `${m[3]} ${months[Math.max(0,Number(m[2])-1)]} ${m[1]} ${m[4]}:${m[5]}:${m[6]??"00"}`;
}
function statusLabel(x: string) {
  return (
    (
      {
        RECEIVED: "Diterima",
        PROCESSING: "Diproses",
        READY: "Selesai",
        COMPLETED: "Diambil",
        DELETED: "Dihapus",
      } as Record<string, string>
    )[x] ?? x
  );
}
function LookupModal({
  type,
  rows,
  query,
  setQuery,
  close,
  choose,
}: {
  type: Lookup;
  rows: any[];
  query: string;
  setQuery: (x: string) => void;
  close: () => void;
  choose: (x: any) => void;
}) {
  return (
    <Modal visible={!!type} transparent animationType="slide">
      <View style={s.overlay}>
        <View style={s.modal}>
          <View style={s.head}>
            <Text style={s.modalTitle}>
              Pilih {type === "customer" ? "Pelanggan" : type === "product" ? "Produk" : "Item Inventory"}
            </Text>
            <Pressable onPress={close}>
              <Text style={{ fontSize: 30 }}>×</Text>
            </Pressable>
          </View>
          <TextInput
            style={s.search}
            value={query}
            onChangeText={setQuery}
            placeholder="Cari..."
          />
          <ScrollView>
            {rows.map((x) => (
              <Pressable
                key={x.id}
                style={s.lookupRow}
                onPress={() => choose(x)}
              >
                <Text style={s.bold}>{x.name}</Text>
                <Text style={s.small}>
                  {type === "customer"
                    ? `${x.address || "-"} · ${x.phone || "-"}`
                    : type === "product" ? `${x.category_name} · Rp ${Number(x.price).toLocaleString("id-ID")}` : `${x.item_code} · Stok ${Number(x.current_stock).toLocaleString("id-ID")} ${x.unit}`}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
const s = StyleSheet.create({
  head: {
    flexDirection: "row",
    gap: 10,
    justifyContent: "space-between",
    alignItems: "center",
  },
  headTitle:{flex:1,minWidth:0},
  invoiceRow:{flex:1,minWidth:0,flexDirection:"row",alignItems:"center",gap:6},
  invoiceNumber:{flexShrink:1,fontSize:12,fontWeight:"900",color:colors.ink},
  priorityStarOn:{fontSize:16,color:"#F5B301"},
  priorityStarOff:{fontSize:16,color:"#C7CDCB"},
  actions: { flexDirection: "row", gap: 8, flexShrink:0 },
  receiptActions:{marginTop:10,padding:12,borderRadius:14,backgroundColor:"#F0F9F6",borderWidth:1,borderColor:"#BFE3D9"},
  receiptHead:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:9},
  receiptClose:{fontSize:25,color:colors.muted,paddingHorizontal:6},
  outputGrid:{flexDirection:"row",flexWrap:"wrap",gap:8},
  outputButton:{width:"48%",paddingVertical:11,paddingHorizontal:8,borderRadius:11,backgroundColor:"#fff",borderWidth:1,borderColor:"#BFE3D9",alignItems:"center"},
  outputText:{fontSize:12,fontWeight:"800",color:colors.primary},
  reminderGap:{marginTop:10},
  icon: { padding: 11, borderRadius: 12, backgroundColor: "#fff" },
  add: { backgroundColor: colors.primary, padding: 12, borderRadius: 14 },
  addText: { color: "#fff", fontWeight: "800" },
  message: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    color: colors.primary,
    fontWeight: "700",
  },
  toast:{position:"absolute",zIndex:50,top:14,right:18,maxWidth:"82%",paddingHorizontal:14,paddingVertical:12,borderRadius:13,backgroundColor:"#047857",shadowColor:"#000",shadowOpacity:.18,shadowRadius:10,elevation:20},
  toastError:{backgroundColor:"#DC2626"},
  toastText:{color:"#fff",fontWeight:"800",textAlign:"center"},
  outputButtonDisabled:{opacity:.5},
  two: { flexDirection: "row", gap: 9 },
  action: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
  },
  actionOn: { backgroundColor: colors.primary },
  actionText: { fontWeight: "800", color: colors.primary },
  inline: {
    padding: 12,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 14,
  },
  label: { fontSize: 13, fontWeight: "800", color: colors.ink },
  selected: { padding: 12, borderRadius: 12, backgroundColor: "#F3F8F6" },
  item: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 13,
  },
  qty: {
    width: 58,
    padding: 9,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 9,
    textAlign: "center",
  },
  trash: { padding: 9, backgroundColor: "#FEF2F2", borderRadius: 9 },
  bold: { fontSize: 15, fontWeight: "900", color: colors.ink },
  small: { fontSize: 12, color: colors.muted, lineHeight: 18 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  chip: {
    padding: 10,
    borderRadius: 10,
    backgroundColor: colors.primarySoft,
    borderWidth: 1,
    borderColor: colors.line,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontWeight: "700", fontSize: 12, color: colors.ink },
  discountInfo: { padding: 12, borderRadius: 12, backgroundColor: "#FFF7ED" },
  discountValue: { color: "#C2410C", fontWeight: "900", marginTop: 4 },
  summary: { padding: 12, borderRadius: 12, backgroundColor: "#F7FAF9" },
  payment: { marginVertical: 14, gap: 12 },
  money: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 5,
  },
  total: { fontWeight: "900", color: colors.primary },
  cancel: { marginTop: 10 },
  searchBox: {
    height: 50,
    flexDirection: "row",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 14,
    overflow: "hidden",
  },
  searchInput: { flex: 1, paddingHorizontal: 14, color: colors.ink },
  searchReset: { paddingHorizontal: 12, alignItems: "center", justifyContent: "center" },
  searchResetText: { fontSize: 24, color: colors.muted, fontWeight: "700" },
  searchButton: {
    paddingHorizontal: 18,
    backgroundColor: colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  searchText: { color: "#fff", fontWeight: "900" },
  resultInfo: { fontSize: 12, color: colors.muted },
  filters: { gap: 8, paddingRight: 18 },
  status: { flexShrink:0,fontSize: 11, fontWeight: "800", color: colors.primary },
  paymentState:{alignSelf:"flex-start",marginTop:7,marginBottom:4,paddingHorizontal:9,paddingVertical:5,borderRadius:9,fontSize:11,fontWeight:"800"},
  paymentDue:{backgroundColor:"#FFEDD5",color:"#C2410C"},
  paymentPaid:{backgroundColor:"#DCFCE7",color:"#15803D"},
  deletedLabel:{marginTop:10,fontSize:11,fontWeight:"800",color:"#991B1B",textTransform:"uppercase"},
  deletedReason:{marginTop:4,padding:10,borderRadius:10,backgroundColor:"#FEE2E2",color:"#7F1D1D",fontWeight:"700",lineHeight:19},
  modalBackdrop:{flex:1,backgroundColor:"rgba(10,30,25,.45)",justifyContent:"center",padding:20},
  settleModal:{backgroundColor:"#fff",borderRadius:20,padding:18,gap:12},
  editModal:{backgroundColor:"#fff",borderRadius:20,padding:18,gap:12,maxHeight:"90%"},
  ownerOrderActions:{flexDirection:"row",gap:12,marginTop:10,marginBottom:10},
  settleLabel:{fontSize:11,fontWeight:"900",color:colors.primary,marginTop:4},
  transferHint:{padding:12,borderRadius:11,backgroundColor:colors.primarySoft,color:colors.primary,lineHeight:19},
  modalButtons:{gap:10,marginTop:4},
  orderSummary:{borderWidth:1,borderColor:"#dce9e5",borderRadius:14,padding:12,marginBottom:12,backgroundColor:"#f7fbfa"},
  summaryRow:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",paddingVertical:5,gap:12},
  summaryValue:{flex:1,textAlign:"right",color:"#536d67"},
  summaryValueBold:{flex:1,textAlign:"right",fontWeight:"800",color:"#168f78"},
  itemRow:{paddingVertical:5},
  itemName:{fontWeight:"700",color:"#18332d",marginBottom:2},
  itemLine:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",gap:12},
  summaryDivider:{height:1,backgroundColor:"#dce9e5",marginVertical:6},

  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,.35)",
    justifyContent: "flex-end",
  },
  modal: {
    maxHeight: "80%",
    backgroundColor: "#fff",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 18,
  },
  modalTitle: { fontSize: 20, fontWeight: "900" },
  search: {
    height: 48,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 12,
    paddingHorizontal: 14,
    marginVertical: 14,
  },
  lookupRow: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
  },
});
