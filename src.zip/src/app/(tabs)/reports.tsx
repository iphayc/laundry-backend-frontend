import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/screen";
import { Card, Field, ScreenTitle } from "@/components/ui";
import { colors } from "@/theme";
import {useAuth} from '@/store/auth-context';
import {
  Analytics,
  ExpenseReport,
  getAnalytics,
  getExpenseReport,
  getInventoryReport,
  InventoryReport,
  getReportLookups,
  ReportLookups,
} from "@/api/laundry";
const months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "Mei",
  "Jun",
  "Jul",
  "Agu",
  "Sep",
  "Okt",
  "Nov",
  "Des",
];
export default function Reports() {
  const{user}=useAuth();
  const [lookups, setLookups] = useState<ReportLookups>({
      branches: [],
      cashiers: [],
      years: [new Date().getFullYear()],
    }),
    [year, setYear] = useState(new Date().getFullYear()),
    [branch, setBranch] = useState(0),
    [cashier, setCashier] = useState(0),
    [data, setData] = useState<Analytics | null>(null),
    [error, setError] = useState(""),
    [from,setFrom]=useState(`${new Date().getFullYear()}-01-01`),
    [to,setTo]=useState(new Date().toISOString().slice(0,10)),
    [expense,setExpense]=useState<ExpenseReport|null>(null),
    [inventory,setInventory]=useState<InventoryReport|null>(null);
  function load() {
    setError("");
    getAnalytics({ year, branch_id: branch, cashier_id: cashier })
      .then(setData)
      .catch((e) => setError(e.message));
  }
  useEffect(() => {
    getReportLookups()
      .then((x) => {
        setLookups(x);
        setYear(x.years[0] ?? new Date().getFullYear());
        if(user?.role!=='OWNER'){setBranch(x.branches[0]?.id??0);setCashier(x.cashiers[0]?.id??0)}
      })
      .catch((e) => setError(e.message));
  }, [user?.role]);
  useEffect(load, [year, branch, cashier]);
  useEffect(()=>{if(user?.role==='OWNER')getExpenseReport({from,to,year,branch_id:branch}).then(setExpense).catch(e=>setError(e.message))},[from,to,year,branch,user?.role]);
  useEffect(()=>{getInventoryReport(from,to,branch).then(setInventory).catch(e=>setError(e.message))},[from,to,branch]);
  const annual = months.map((label, i) => ({
      label,
      ...(data?.annual.find((x) => Number(x.month) === i + 1) ?? {
        income: 0,
        revenue: 0,
        transactions: 0,
      }),
    })),
    yearly = (data?.yearly ?? []).map((x) => ({
      label: String(x.year),
      value: Number(x.revenue),
    }));
  return (
    <Screen>
      <View style={s.head}>
        <ScreenTitle
          title="Laporan"
          subtitle="Analitik tren, omzet, produk, dan kasir"
        />
        <Pressable onPress={load} style={s.refresh}>
          <Text>↻</Text>
        </Pressable>
      </View>
      {error ? <Text style={s.error}>{error}</Text> : null}
      {user?.role==='OWNER'?<Pressable onPress={()=>router.push('/financial-report')} style={s.recapButton}><Text style={s.recapText}>▤ Rekap Laporan Keuangan</Text><Text style={s.recapArrow}>›</Text></Pressable>:null}
      {user?.role==='OWNER'?<Pressable onPress={()=>router.push('/asset-report')} style={s.recapButton}><Text style={s.recapText}>🏷 Rekap Aset</Text><Text style={s.recapArrow}>›</Text></Pressable>:null}
      <Text style={s.label}>Tahun</Text>
      <ScrollView horizontal contentContainerStyle={s.chips}>
        {lookups.years.map((x) => (
          <Chip
            key={x}
            label={String(x)}
            active={year === x}
            onPress={() => setYear(x)}
          />
        ))}
      </ScrollView>
      <Text style={s.label}>Cabang</Text>
      <ScrollView horizontal contentContainerStyle={s.chips}>
        {user?.role==='OWNER'?<Chip
          label="Semua cabang"
          active={!branch}
          onPress={() => setBranch(0)}
        />:null}
        {lookups.branches.map((x) => (
          <Chip
            key={x.id}
            label={x.name}
            active={branch === x.id}
            onPress={() => setBranch(x.id)}
          />
        ))}
      </ScrollView>
      <Text style={s.label}>Kasir</Text>
      <ScrollView horizontal contentContainerStyle={s.chips}>
        {user?.role==='OWNER'?<Chip
          label="Semua kasir"
          active={!cashier}
          onPress={() => setCashier(0)}
        />:null}
        {lookups.cashiers.map((x) => (
          <Chip
            key={x.id}
            label={x.fullname}
            active={cashier === x.id}
            onPress={() => setCashier(x.id)}
          />
        ))}
      </ScrollView>
      <Card>
        <Text style={s.title}>Periode Laporan Inventory & Pengeluaran</Text>
        <View style={s.dateRow}><View style={{flex:1}}><Field label="Dari tanggal" value={from} onChangeText={setFrom}/></View><View style={{flex:1}}><Field label="Sampai tanggal" value={to} onChangeText={setTo}/></View></View>
      </Card>
      {user?.role==='OWNER'?<Card>
        <Text style={s.title}>Laporan Keuangan</Text>
        <Summary label="Omzet" value={expense?.revenue??0} color={colors.primary}/><Summary label="Pengeluaran" value={expense?.expense??0} color={colors.danger}/><Summary label="Selisih" value={expense?.net??0} color={(expense?.net??0)>=0?colors.primary:colors.danger}/>
        <Text style={s.small}>Pengeluaran manual: Rp {Number(expense?.manual_expense??0).toLocaleString('id-ID')} · Pemakaian inventory: Rp {Number(expense?.inventory_expense??0).toLocaleString('id-ID')}</Text>
      </Card>:null}
      {user?.role==='OWNER'?<LineChart title={`Pengeluaran Periode ${from} s/d ${to}`} rows={(expense?.daily??[]).map(x=>({label:x.label.slice(5),value:Number(x.total)}))}/>:null}
      <Card>
        <Text style={s.title}>Laporan Inventory</Text>
        <Summary label="Stok masuk (qty)" value={Number(inventory?.summary.qty_in??0)} color={colors.primary}/>
        <Summary label="Nilai stok masuk" value={Number(inventory?.summary.value_in??0)} color={colors.primary}/>
        <Summary label="Stok keluar (qty)" value={Number(inventory?.summary.qty_out??0)} color={colors.danger}/>
        <Summary label="Nilai stok keluar" value={Number(inventory?.summary.value_out??0)} color={colors.danger}/>
        <Summary label="Akumulasi nilai" value={Number(inventory?.summary.value_in??0)-Number(inventory?.summary.value_out??0)} color={colors.primary}/>
        {(inventory?.items??[]).map((x)=><View key={x.id} style={s.reportRow}><View><Text style={s.rowTitle}>{x.name}</Text><Text style={s.small}>{Number(x.current_stock).toLocaleString('id-ID')} {x.unit} · min. {Number(x.min_stock).toLocaleString('id-ID')}</Text></View><Text style={s.value}>Rp {Number(x.stock_value).toLocaleString('id-ID')}</Text></View>)}
      </Card>
      {user?.role==='OWNER'?<>
      <BarChart title="Bar Pengeluaran Periode Terpilih" rows={(expense?.daily??[]).map(x=>({label:x.label.slice(5),value:Number(x.total)}))}/>
      <LineChart title={`Pengeluaran Bulanan ${year}`} rows={months.map((label,i)=>({label,value:Number(expense?.monthly.find(x=>Number(x.month)===i+1)?.total??0)}))}/>
      <LineChart title="Pengeluaran Per Tahun" rows={(expense?.yearly??[]).map(x=>({label:String(x.year),value:Number(x.total)}))}/></>:null}
      <LineChart
        title={`Tren Omzet Bulanan ${year}`}
        rows={annual.map((x) => ({ label: x.label, value: Number(x.revenue) }))}
      />
      <LineChart title="Tren Omzet Per Tahun" rows={yearly} />
      <BarChart
        title="Income Harian"
        rows={(data?.daily ?? []).map((x) => ({
          label: x.label.slice(5),
          value: Number(x.income),
        }))}
      />
      <BarChart
        title="Omzet Harian"
        rows={(data?.daily ?? []).map((x) => ({
          label: x.label.slice(5),
          value: Number(x.revenue),
        }))}
      />
      <Card>
        <Text style={s.title}>Produk Terlaris</Text>
        {(data?.products??[]).length ? (
          (data?.products??[]).map((x, i) => (
            <View key={`${x.product_id}-${i}`} style={s.reportRow}>
              <View>
                <Text style={s.rowTitle}>
                  {i + 1}. {x.product_name}
                </Text>
                <Text style={s.small}>
                  {Number(x.qty).toLocaleString("id-ID")} {x.unit} · {x.orders}{" "}
                  pesanan
                </Text>
              </View>
              <Text style={s.value}>
                Rp {Number(x.revenue).toLocaleString("id-ID")}
              </Text>
            </View>
          ))
        ) : (
          <Text style={s.empty}>Belum ada data.</Text>
        )}
      </Card>
      <Card>
        <Text style={s.title}>Laporan Kasir</Text>
        {(data?.cashiers??[]).length ? (
          (data?.cashiers??[]).map((x) => (
            <View key={x.created_by} style={s.reportRow}>
              <View>
                <Text style={s.rowTitle}>{x.fullname || "Kasir"}</Text>
                <Text style={s.small}>
                  {x.transactions} transaksi · @{x.username}
                </Text>
              </View>
              <Text style={s.value}>
                Rp {Number(x.income).toLocaleString("id-ID")}
              </Text>
            </View>
          ))
        ) : (
          <Text style={s.empty}>Belum ada data.</Text>
        )}
      </Card>
    </Screen>
  );
}
function Summary({label,value,color}:{label:string;value:number;color:string}){return <View style={s.summary}><Text style={s.small}>{label}</Text><Text style={{fontWeight:'900',color}}>Rp {Number(value).toLocaleString('id-ID')}</Text></View>}
function Chip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={[s.chip, active && s.chipOn]}>
      <Text style={[s.chipText, active && { color: "#fff" }]}>{label}</Text>
    </Pressable>
  );
}
function LineChart({
  title,
  rows,
}: {
  title: string;
  rows: { label: string; value: number }[];
}) {
  const width = Math.max(300, (rows.length - 1) * 58 + 32),
    height = 150,
    max = Math.max(1, ...rows.map((x) => x.value)),
    points = rows.map((x, i) => ({
      x: 16 + i * 58,
      y: 12 + (1 - x.value / max) * (height - 32),
      ...x,
    }));
  return (
    <Card>
      <Text style={s.title}>{title}</Text>
      {rows.length ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{ width, height: height + 34 }}>
            {[0, 0.25, 0.5, 0.75, 1].map((x) => (
              <View
                key={x}
                style={[s.grid, { top: 12 + x * (height - 32), width }]}
              />
            ))}
            {points.slice(0, -1).map((p, i) => {
              const q = points[i + 1],
                length = Math.hypot(q.x - p.x, q.y - p.y),
                angle = (Math.atan2(q.y - p.y, q.x - p.x) * 180) / Math.PI;
              return (
                <View
                  key={i}
                  style={[
                    s.segment,
                    {
                      width: length,
                      left: (p.x + q.x - length) / 2,
                      top: (p.y + q.y) / 2,
                      transform: [{ rotate: `${angle}deg` }],
                    },
                  ]}
                />
              );
            })}
            {points.map((p) => (
              <View key={p.label}>
                <View style={[s.point, { left: p.x - 5, top: p.y - 5 }]} />
                <Text
                  style={[
                    s.lineValue,
                    { left: p.x - 24, top: Math.max(0, p.y - 22) },
                  ]}
                >
                  {p.value ? compact(p.value) : "0"}
                </Text>
                <Text
                  style={[s.lineLabel, { left: p.x - 24, top: height + 5 }]}
                >
                  {p.label}
                </Text>
              </View>
            ))}
          </View>
        </ScrollView>
      ) : (
        <Text style={s.empty}>Belum ada transaksi.</Text>
      )}
    </Card>
  );
}
function BarChart({
  title,
  rows,
}: {
  title: string;
  rows: { label: string; value: number }[];
}) {
  const max = Math.max(1, ...rows.map((x) => x.value));
  return (
    <Card>
      <Text style={s.title}>{title}</Text>
      {rows.length ? (
        <ScrollView horizontal>
          <View style={s.chart}>
            {rows.map((x) => (
              <View key={x.label} style={s.barWrap}>
                <Text style={s.barValue}>{compact(x.value)}</Text>
                <View
                  style={[
                    s.bar,
                    { height: Math.max(3, (x.value / max) * 105) },
                  ]}
                />
                <Text style={s.barLabel}>{x.label}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      ) : (
        <Text style={s.empty}>Belum ada transaksi.</Text>
      )}
    </Card>
  );
}
function compact(v: number) {
  return v >= 1000000
    ? `${(v / 1000000).toFixed(1)}jt`
    : v >= 1000
      ? `${Math.round(v / 1000)}rb`
      : String(v);
}
const s = StyleSheet.create({
  head: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  refresh: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.line,
  },
  error: { color: colors.danger },
  reportSearch:{height:48,flexDirection:"row",alignItems:"center",borderWidth:1,borderColor:colors.line,borderRadius:12,backgroundColor:"#fff",paddingHorizontal:12,marginBottom:10},
  reportSearchInput:{flex:1,color:colors.ink},
  reportSearchClear:{fontSize:24,color:colors.muted,paddingHorizontal:8},
  label: { fontWeight: "800", color: colors.ink },
  chips: { gap: 8, paddingRight: 18 },
  chip: {
    paddingHorizontal: 13,
    paddingVertical: 10,
    borderRadius: 99,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.line,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontWeight: "700", fontSize: 12, color: colors.ink },
  title: {
    fontSize: 17,
    fontWeight: "900",
    color: colors.ink,
    marginBottom: 12,
  },
  grid: {
    position: "absolute",
    left: 0,
    height: 1,
    backgroundColor: "#E8EFED",
  },
  segment: {
    position: "absolute",
    height: 3,
    backgroundColor: colors.primary,
    borderRadius: 2,
  },
  point: {
    position: "absolute",
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#fff",
    borderWidth: 3,
    borderColor: colors.primary,
    zIndex: 3,
  },
  lineValue: {
    position: "absolute",
    width: 48,
    textAlign: "center",
    fontSize: 9,
    color: colors.muted,
  },
  lineLabel: {
    position: "absolute",
    width: 48,
    textAlign: "center",
    fontSize: 10,
    color: colors.muted,
  },
  chart: { height: 155, flexDirection: "row", alignItems: "flex-end", gap: 9 },
  barWrap: { width: 46, alignItems: "center" },
  bar: {
    width: 25,
    backgroundColor: colors.primary,
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  barValue: { fontSize: 9, color: colors.muted },
  barLabel: { fontSize: 9, color: colors.muted, marginTop: 5 },
  reportRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
  },
  rowTitle: { fontWeight: "800", color: colors.ink },
  small: { fontSize: 11, color: colors.muted, marginTop: 3 },
  value: { fontWeight: "900", color: colors.primary },
  empty: { textAlign: "center", color: colors.muted, paddingVertical: 20 },
  dateRow:{flexDirection:"row",gap:8},
  recapButton:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",paddingHorizontal:16,paddingVertical:15,borderRadius:14,backgroundColor:colors.primary},
  recapText:{color:"#fff",fontWeight:"900",fontSize:15},
  recapArrow:{color:"#fff",fontSize:25},
  summary:{flexDirection:"row",justifyContent:"space-between",paddingVertical:7},
});
