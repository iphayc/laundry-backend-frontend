import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { AuthProvider } from '@/store/auth-context';
import { ToastProvider } from '@/components/toast';
import SplashOverlay from './splash-overlay';

// Keep the native splash visible only while the React tree is starting.
SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  const [showCustomSplash, setShowCustomSplash] = useState(true);

  useEffect(() => {
    let mounted = true;
    SplashScreen.hideAsync().catch(() => {});

    const timer = setTimeout(() => {
      if (mounted) setShowCustomSplash(false);
    }, 2500);

    return () => {
      mounted = false;
      clearTimeout(timer);
    };
  }, []);

  return (
    <AuthProvider>
      <ToastProvider>
        <View style={{ flex: 1 }}>
          <StatusBar style={showCustomSplash ? 'light' : 'dark'} hidden={showCustomSplash} />
          <Stack screenOptions={{ headerShown: false }} />
          {showCustomSplash ? <SplashOverlay /> : null}
        </View>
      </ToastProvider>
    </AuthProvider>
  );
}
