import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  Image,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import { router, useLocalSearchParams, useNavigation } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { api } from "@/api/client";
import { Button, Card, Field } from "@/components/ui";
import { colors } from "@/theme";
import { useAuth } from "@/store/auth-context";
import {uploadUserPhoto} from "@/api/profile";
import {useToast} from "@/components/toast";
import {buildFileForm} from "@/utils/upload-file";
import {
  CustomerWhatsAppStatus,
  connectCustomerWhatsApp,
  getCustomerWhatsAppStatus,
  getWhatsAppDeliveryConfiguration,
  logoutCustomerWhatsApp,
  saveWhatsAppDeliveryConfiguration,
  WhatsAppDeliveryConfiguration,
} from "@/api/laundry";
const meta: Record<string, [string, string]> = {
  packages: ["Paket & Lisensi", "Pilih paket dan selesaikan pembayaran."],
  whatsapp: [
    "Hubungkan WhatsApp",
    "Hubungkan nomor WhatsApp melalui QR gateway.",
  ],
  users: ["Pengguna & Kasir", "Kelola akses owner dan kasir."],
  branches: ["Cabang", "Kelola lokasi operasional laundry."],
  devices: ["Perangkat", "Perangkat yang pernah digunakan untuk login."],
  settings: ["Pengaturan", "Preferensi aplikasi laundry."],
};
const linkedTerms=`Syarat dan Ketentuan Penggunaan WhatsApp Linked Device

Sebelum menggunakan fitur WhatsApp Linked Device pada Eksis Laundry, harap membaca dan memahami ketentuan berikut.

Dengan mengaktifkan fitur ini, Anda menyatakan bahwa Anda adalah pemilik nomor WhatsApp yang digunakan atau memiliki kewenangan yang sah untuk menghubungkan dan menggunakan akun WhatsApp tersebut.

Tanggung Jawab Pengguna
Penggunaan WhatsApp Linked Device merupakan keputusan dan tanggung jawab pengguna. Kami tidak mengambil alih kepemilikan, kontrol, maupun tanggung jawab atas akun WhatsApp yang dihubungkan.

Pengguna bertanggung jawab atas seluruh aktivitas, pesan, komunikasi, file, maupun informasi yang dikirim atau diterima melalui akun WhatsApp yang telah dihubungkan.

Jangan Menghubungkan Nomor WhatsApp Orang Lain
Pengguna dilarang menghubungkan nomor WhatsApp milik orang lain tanpa izin atau kewenangan yang sah.

Jangan gunakan fitur ini untuk menghubungkan:
• Nomor WhatsApp milik pelanggan tanpa persetujuan.
• Nomor WhatsApp milik karyawan tanpa izin.
• Nomor WhatsApp milik pihak lain.
• Nomor WhatsApp yang bukan berada dalam kendali atau kewenangan Anda.

Keamanan Akun
Pengguna bertanggung jawab untuk menjaga keamanan perangkat dan akun WhatsApp yang telah terhubung.

Jangan memberikan:
• QR Code WhatsApp;
• Kode OTP;
• PIN WhatsApp;
• Password;
• Informasi autentikasi;
ke pihak lain yang tidak berwenang.

Kami tidak pernah meminta kode OTP atau PIN WhatsApp Anda melalui fitur ini.

4. Penggunaan yang Dilarang
Fitur WhatsApp Linked Device tidak boleh digunakan untuk:
• Mengirim spam.
• Mengirim pesan massal yang tidak diinginkan.
• Melakukan penipuan.
• Mengirim konten ilegal.
• Mengirim konten yang melanggar hukum.
• Mengirim pesan yang mengandung ancaman, pelecehan, atau intimidasi.
• Melakukan aktivitas yang dapat merugikan pihak lain.
• Melakukan aktivitas yang melanggar ketentuan WhatsApp.

Pengguna wajib menggunakan WhatsApp secara wajar dan bertanggung jawab serta mematuhi ketentuan dan kebijakan WhatsApp yang berlaku.

Risiko Pemblokiran Akun
Penggunaan WhatsApp yang dianggap melanggar kebijakan WhatsApp dapat menyebabkan akun WhatsApp mendapatkan pembatasan, logout, penangguhan, atau pemblokiran oleh WhatsApp.

Kami tidak dapat menjamin bahwa akun WhatsApp pengguna akan selalu terhindar dari pembatasan atau pemblokiran oleh WhatsApp.

Kami tidak bertanggung jawab atas tindakan pembatasan atau pemblokiran yang dilakukan oleh WhatsApp sebagai akibat dari aktivitas pengguna.

Akses Perangkat
Dengan menghubungkan WhatsApp sebagai Linked Device, pengguna memahami bahwa akun WhatsApp tersebut dapat digunakan melalui perangkat yang telah dihubungkan.

Pastikan perangkat yang digunakan adalah perangkat yang aman dan berada dalam kendali pengguna atau pihak yang diberi kewenangan.

Apabila perangkat hilang, berpindah tangan, atau tidak lagi digunakan, pengguna wajib segera melakukan logout atau menghapus perangkat tersebut dari daftar Linked Devices WhatsApp.

Privasi dan Data
Kami berkomitmen menjaga keamanan data yang diproses melalui sistem Kami.

Namun, pengguna tetap bertanggung jawab atas isi komunikasi yang dilakukan melalui akun WhatsApp miliknya, termasuk data pelanggan, nomor telepon, alamat, informasi order, dan informasi lainnya yang dikirim melalui WhatsApp.

Pengguna wajib memastikan bahwa penggunaan dan pengiriman data tersebut dilakukan sesuai dengan ketentuan hukum dan persetujuan yang diperlukan.

Persetujuan
Dengan mencentang kotak "Saya telah membaca dan menyetujui Disclaimer WhatsApp Linked Device" dan melanjutkan proses penghubungan perangkat, Anda menyatakan bahwa:
• Anda memiliki hak atau kewenangan untuk menggunakan nomor WhatsApp tersebut.
• Anda memahami risiko penggunaan WhatsApp Linked Device.
• Anda bertanggung jawab atas aktivitas yang dilakukan melalui akun WhatsApp tersebut.
• Anda bersedia menggunakan fitur ini secara bertanggung jawab.
• Anda memahami bahwa Eksis Laundry tidak bertanggung jawab atas pembatasan atau pemblokiran akun WhatsApp yang disebabkan oleh aktivitas pengguna.

Gunakan fitur WhatsApp Linked Device hanya untuk nomor WhatsApp yang Anda miliki atau yang penggunaannya telah mendapatkan izin dari pemiliknya.`;
type Package = {
  id: number;
  code: string;
  name: string;
  price: number;
  description: string;
  max_branches: number;
  users_per_branch: number;
  daily_transaction_limit: number | null;
};
type Payment = {
  id: number;
  type: string;
  bank_name: string | null;
  account_number: string | null;
  account_name: string | null;
  qris_image: string | null;
  instructions: string | null;
};
type Invoice = {
  id: number;
  invoice_number: string;
  package_name: string;
  base_amount: number;
  voucher_code: string | null;
  discount_amount: number;
  unique_code: number;
  amount: number;
  status: string;
  due_at: string;
  payment_method: string;
  payment_account: Payment;
};
type License = {
  package_name: string;
  package_code: string;
  status: string;
  expires_at: string | null;
  max_branches: number;
  users_per_branch: number;
  branch_selection_required?: boolean;
  branches_to_disable?: number;
};
function qrImageSource(value:string|null){
  if(!value)return null;
  const v=value.trim();
  if(v.startsWith("data:image/" )||v.startsWith("http://")||v.startsWith("https://")||v.startsWith("file://")||v.startsWith("content://"))return v;
  // Gateway may return raw base64 instead of a data URI.
  if(/^[A-Za-z0-9+/=\r\n]+$/.test(v))return `data:image/png;base64,${v.replace(/\s/g,"")}`;
  return v;
}

export default function AccountFeature() {
  const { feature = "settings" } = useLocalSearchParams<{ feature?: string }>();
  const navigation=useNavigation();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [rows, setRows] = useState<any[]>([]),
    [accounts, setAccounts] = useState<Payment[]>([]),
    [branchOptions, setBranchOptions] = useState<any[]>([]),
    [selected, setSelected] = useState<Package | null>(null),
    [payment, setPayment] = useState<Payment | null>(null),
    [invoice, setInvoice] = useState<Invoice | null>(null),
    [license, setLicense] = useState<License | null>(null),
    [loading, setLoading] = useState(false),
    [message, setMessage] = useState(""),
    [messageIsError, setMessageIsError] = useState(false),
    [uploading, setUploading] = useState(false),
    [userForm, setUserForm] = useState(false),
    [branchForm, setBranchForm] = useState(false),
    [voucherCode, setVoucherCode] = useState(""),
    [voucher, setVoucher] = useState<{voucher_code:string;discount_amount:number;remaining:number}|null>(null),
    [paymentGuide, setPaymentGuide] = useState<Payment | null>(null),
    [resetUserId, setResetUserId] = useState(0),
    [whatsapp, setWhatsapp] = useState<CustomerWhatsAppStatus | null>(null),
    [whatsappQr, setWhatsappQr] = useState<string | null>(null),
    [whatsappLoading, setWhatsappLoading] = useState(false),
    [waConfig,setWaConfig]=useState<WhatsAppDeliveryConfiguration>({method:"APP",terms_accepted:false}),
    [waTermsChecked,setWaTermsChecked]=useState(false);
  const [resetData, setResetData] = useState({ password: "", confirm: "" });
  const [cashier, setCashier] = useState({
    fullname: "",
    username: "",
    email: "",
    phone: "",
    password: "",
    branch_id: 0,
  });
  const [branch, setBranch] = useState({ name: "", address: "", phone: "" });
  const info = meta[feature] ?? meta.settings;
  async function load() {
    setLoading(true);
    setMessage("");
    try {
      const path =
        feature === "packages"
          ? "/packages"
          : feature === "devices"
            ? "/devices"
            : feature === "users"
              ? "/company/users"
              : feature === "branches"
                ? "/company/branches?include_inactive=1"
                : null;
      const tasks: Promise<any>[] = [api<License | null>("/license")];
      if (path) tasks.push(api<any[]>(path));
      if (feature === "packages")
        tasks.push(api<Payment[]>("/config/payment-accounts"));
      if (feature === "users") tasks.push(api<any[]>("/company/branches"));
      const result = await Promise.all(tasks);
      setLicense(result[0]);
      if (path) setRows(result[1]);
      if (feature === "packages") setAccounts(result[2]);
      if (feature === "users") {
        const activeBranchOptions=(result[2]??[]).filter((branch:any)=>Number(branch.is_active)===1);
        setBranchOptions(activeBranchOptions);
        setCashier((current) => ({ ...current, branch_id: current.branch_id || Number(activeBranchOptions[0]?.id || 0) }));
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Data gagal dimuat");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    load();
  }, [feature]);
  const branchSelectionLocked=feature==="branches"&&Boolean(license?.branch_selection_required);
  useEffect(()=>{
    if(!branchSelectionLocked)return;
    const subscription=BackHandler.addEventListener("hardwareBackPress",()=>{
      showToast("Pilih cabang yang dinonaktifkan terlebih dahulu.","error");
      return true;
    });
    return()=>subscription.remove();
  },[branchSelectionLocked,showToast]);
  useEffect(()=>{
    if(!branchSelectionLocked)return;
    return navigation.addListener("beforeRemove",(event)=>{
      event.preventDefault();
      showToast("Pilih cabang yang dinonaktifkan terlebih dahulu.","error");
    });
  },[branchSelectionLocked,navigation,showToast]);
  /**
   * Status hanya membaca status session milik company yang sedang login.
   * Jangan meminta QR pada polling karena endpoint QR/connect dapat membuat
   * atau mengganti QR session.
   */
  async function loadWhatsAppStatus() {
    try {
      const status = await getCustomerWhatsAppStatus();
      setWhatsapp(status);
      // Status berhasil dibaca; hapus pesan error lama seperti "Permintaan gagal".
      setMessage("");

      if (status.connected) {
        // Jika WhatsApp sudah terhubung, Linked Devices menjadi metode aktif.
        // Disclaimer/checkbox hanya diperlukan saat pertama kali melakukan linking.
        setWaConfig((current) => ({ ...current, method: "LINKED" }));
        setWaTermsChecked(false);
        setWhatsappQr(null);
      }
      return status;
    } catch (e) {
      setWhatsapp(null);
      throw e;
    }
  }

  /**
   * Meminta API Eksis membuat/mengambil session WhatsApp customer dan
   * mengembalikan QR. Mobile tidak mengetahui API key, company_id, maupun
   * session_key gateway.
   */
  async function requestWhatsAppQr() {
    setWhatsappLoading(true);
    try {
      const result = await connectCustomerWhatsApp();
      setWhatsapp({
        connection: result.connected
          ? "connected"
          : result.connection === "connecting" || result.connection === "authenticating" || result.connection === "waiting_scan"
            ? "connecting"
            : "disconnected",
        connected: result.connected,
        phone: result.phone,
        updated_at: result.updated_at,
      });

      if (result.connected) {
        setWhatsappQr(null);
        setMessage("WhatsApp sudah terhubung.");
      } else if (result.qr) {
        setWhatsappQr(qrImageSource(result.qr));
        setMessage("QR WhatsApp siap. Scan QR menggunakan WhatsApp Anda.");
      } else {
        setWhatsappQr(null);
        setMessage("QR belum tersedia. Silakan coba Refresh QR.");
      }
    } catch (e) {
      setWhatsappQr(null);
      setMessage(e instanceof Error ? e.message : "QR WhatsApp gagal dimuat");
    } finally {
      setWhatsappLoading(false);
    }
  }

  /**
   * Saat halaman dibuka:
   * 1. baca konfigurasi delivery,
   * 2. cek status session,
   * 3. bila Linked Device sudah disetujui dan belum terhubung, minta QR.
   */
  async function loadWhatsApp() {
    setWhatsappLoading(true);
    try {
      const config = await getWhatsAppDeliveryConfiguration();

      // Selalu cek status session terlebih dahulu. Jangan berhenti hanya
      // karena konfigurasi lama masih APP, karena session Linked Device
      // bisa sudah CONNECTED.
      let status: CustomerWhatsAppStatus | null = null;
      try {
        status = await loadWhatsAppStatus();
      } catch {
        status = null;
      }

      if (status?.connected) {
        // Jika session Linked Device benar-benar CONNECTED tetapi setting
        // delivery lama masih APP, sinkronkan setting ke backend. Ini penting
        // karena endpoint pengiriman struk membaca konfigurasi server,
        // bukan state tampilan halaman.
        let effectiveConfig = config;
        if (config.method !== "LINKED" && config.terms_accepted) {
          try {
            effectiveConfig = await saveWhatsAppDeliveryConfiguration({
              method: "LINKED",
              accept_terms: false,
            });
          } catch {
            // Session tetap ditampilkan sebagai Linked Device. Backend
            // pengiriman juga memiliki guard berdasarkan session CONNECTED.
            effectiveConfig = { ...config, method: "LINKED" };
          }
        } else {
          effectiveConfig = { ...config, method: "LINKED" };
        }

        setWaConfig(effectiveConfig);
        setWaTermsChecked(false);
        setWhatsappQr(null);
        setWhatsapp(status);
        setMessage("");
        return;
      }

      setWaConfig(config);
      setWhatsapp(status);

      if (config.method !== "LINKED") {
        setWhatsappQr(null);
        return;
      }

      if (config.terms_accepted) {
        const result = await connectCustomerWhatsApp();

        setWhatsapp({
          connection: result.connected
            ? "connected"
            : result.connection === "connecting" || result.connection === "authenticating" || result.connection === "waiting_scan"
              ? "connecting"
              : "disconnected",
          connected: result.connected,
          phone: result.phone,
          updated_at: result.updated_at,
        });

        if (result.connected) {
          setWhatsappQr(null);
        } else if (result.qr) {
          setWhatsappQr(qrImageSource(result.qr));
          setMessage("QR WhatsApp siap. Scan menggunakan WhatsApp Anda.");
        } else {
          setWhatsappQr(null);
        }
      } else {
        setWhatsappQr(null);
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Status WhatsApp gagal dimuat");
    } finally {
      setWhatsappLoading(false);
    }
  }

  async function selectWhatsAppMethod(method:"APP"|"LINKED"){
    if(method==="LINKED"&&!waConfig.terms_accepted&&!waTermsChecked){
      setWaConfig(x=>({...x,method:"LINKED"}));
      setMessage("Baca lalu centang persetujuan untuk melanjutkan Linked Device.");
      return;
    }

    try{
      setWhatsappLoading(true);
      const config=await saveWhatsAppDeliveryConfiguration({
        method,
        accept_terms:method==="LINKED"&&waTermsChecked,
      });
      setWaConfig(config);

      if(method==="APP"){
        setWhatsappQr(null);
        setWhatsapp(null);
        setMessage("Pengiriman memakai aplikasi WhatsApp perangkat.");
        return;
      }

      setMessage("Linked Device dipilih. Menyiapkan QR...");
      const result = await connectCustomerWhatsApp();

      setWhatsapp({
        connection: result.connected
          ? "connected"
          : result.connection === "connecting" || result.connection === "authenticating" || result.connection === "waiting_scan"
            ? "connecting"
            : "disconnected",
        connected: result.connected,
        phone: result.phone,
        updated_at: result.updated_at,
      });

      if(result.connected){
        setWhatsappQr(null);
        setMessage("WhatsApp sudah terhubung.");
      }else if(result.qr){
        setWhatsappQr(qrImageSource(result.qr));
        setMessage("QR WhatsApp siap. Scan menggunakan WhatsApp Anda.");
      }else{
        setWhatsappQr(null);
        setMessage("QR belum tersedia. Silakan coba Refresh QR.");
      }
    }catch(e){
      setMessage(e instanceof Error?e.message:"Pengaturan WhatsApp gagal disimpan");
    }finally{
      setWhatsappLoading(false);
    }
  }

  useEffect(() => {
    if (feature !== "whatsapp") return;

    loadWhatsApp();

    // Polling hanya status. Jangan request QR setiap interval.
    const poll = setInterval(async () => {
      try {
        const status = await getCustomerWhatsAppStatus();
        setWhatsapp(status);
        // Polling berhasil; jangan tampilkan error dari request sebelumnya.
        setMessage("");
        if (status.connected) {
          // Selalu tampilkan metode Linked Devices ketika session aktif.
          setWaConfig((current) => ({ ...current, method: "LINKED" }));
          setWaTermsChecked(false);
          setWhatsappQr(null);
        }
      } catch {
        // Jangan menghapus QR hanya karena satu polling gagal.
      }
    }, 4000);

    return () => clearInterval(poll);
  }, [feature]);

  function confirmWhatsappLogout() {
    const action = async () => {
      try {
        setWhatsappLoading(true);
        await logoutCustomerWhatsApp();
        setWhatsappQr(null);
        setWhatsapp(null);
        setMessage("WhatsApp telah dikeluarkan dari perangkat ini.");
        try {
          await loadWhatsAppStatus();
        } catch {
          // Session sudah di-logout; abaikan kegagalan refresh status.
        }
      } catch (e) {
        setMessage(e instanceof Error ? e.message : "WhatsApp gagal dikeluarkan");
      } finally {
        setWhatsappLoading(false);
      }
    };

    if (Platform.OS === "web") {
      if (window.confirm("Logout / reset sesi WhatsApp?")) action();
    } else {
      Alert.alert(
        "Logout WhatsApp",
        "Logout / reset sesi WhatsApp?",
        [
          { text: "Batal", style: "cancel" },
          { text: "Logout", style: "destructive", onPress: action },
        ],
      );
    }
  }

  async function createInvoice() {
    if (!selected || !payment) return;
    try {
      setLoading(true);
      const x = await api<Invoice>("/payments/invoice", {
        method: "POST",
        body: JSON.stringify({
          package_id: selected.id,
          payment_account_id: payment.id,
          voucher_code: voucher?.voucher_code ?? "",
        }),
      });
      setInvoice(x);
      const text=`Invoice ${x.invoice_number} dibuat dan dikirim ke email.`;setMessage(text);showToast(text);
    } catch (e) {
      const text=e instanceof Error ? e.message : "Invoice gagal dibuat";setMessage(text);showToast(text,"error");
    } finally {
      setLoading(false);
    }
  }
  async function checkVoucher() {
    if (!selected) return;
    if (!voucherCode.trim()) {
      const text="Masukkan kode voucher terlebih dahulu.";setMessage(text);showToast(`✕ ${text}`,"error");return;
    }
    try {
      setLoading(true);
      setMessage("");
      const result = await api<{voucher_code:string;discount_amount:number;remaining:number}>("/vouchers/validate", {method:"POST",body:JSON.stringify({package_id:selected.id,voucher_code:voucherCode})});
      setVoucher(result);
      setVoucherCode(result.voucher_code);
      const text=`Voucher valid. Potongan Rp ${Number(result.discount_amount).toLocaleString("id-ID")}.`;setMessage(text);showToast(`✓ ${text}`);
    } catch (e) {
      setVoucher(null);
      const text=e instanceof Error ? e.message : "Voucher tidak valid";setMessage(text);showToast(`✕ ${text}`,"error");
    } finally { setLoading(false); }
  }
  async function uploadProof() {
    if (!invoice) return;
    try {
      const picked = await DocumentPicker.getDocumentAsync({
        type: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
        copyToCacheDirectory: true,
      });
      if (picked.canceled) return;
      setUploading(true);
      const asset = picked.assets[0];
      const form = await buildFileForm("proof",asset.uri,asset.name,asset.mimeType??"image/jpeg");
      form.append("invoice_id", String(invoice.id));
      await api("/payments/upload", { method: "POST", body: form });
      setInvoice(null);
      setSelected(null);
      setPayment(null);
      await load();
      const text="Bukti transfer berhasil diupload. Menunggu konfirmasi Admin.";setMessage(text);showToast(text);
    } catch (e) {
      const text=e instanceof Error ? e.message : "Bukti pembayaran gagal dikirim. Silakan pilih dan upload kembali.";setMessage(text);showToast(text,"error");
    } finally {
      setUploading(false);
    }
  }
  async function addCashier() {
    try {
      setLoading(true);
      await api("/company/users", {
        method: "POST",
        body: JSON.stringify(cashier),
      });
      setCashier({
        fullname: "",
        username: "",
        email: "",
        phone: "",
        password: "",
        branch_id: branchOptions[0]?.id ?? 0,
      });
      setUserForm(false);
      setMessage("Kasir berhasil ditambahkan.");showToast("Kasir berhasil ditambahkan.");
      await load();
    } catch (e) {
      const text=e instanceof Error ? e.message : "Kasir gagal ditambahkan";setMessage(text);showToast(text,"error");
    } finally {
      setLoading(false);
    }
  }
  async function addBranch() {
    try {
      setLoading(true);
      await api("/company/branches", {
        method: "POST",
        body: JSON.stringify(branch),
      });
      setBranch({ name: "", address: "", phone: "" });
      setBranchForm(false);
      await load();
      setMessage("Cabang berhasil ditambahkan.");showToast("Cabang berhasil ditambahkan.");
    } catch (e) {
      const text=e instanceof Error ? e.message : "Cabang gagal ditambahkan";setMessage(text);showToast(text,"error");
    } finally {
      setLoading(false);
    }
  }
  function confirmAction(title: string, message: string, action: () => void) {
    if (Platform.OS === "web") {
      if (window.confirm(message)) action();
      return;
    }
    Alert.alert(title, message, [
      { text: "Batal", style: "cancel" },
      { text: "Nonaktifkan", style: "destructive", onPress: action },
    ]);
  }
  async function disableUser(id: number) {
    try {
      setLoading(true);
      await api(`/company/users/${id}`, { method: "DELETE" });
      await load();
      setMessage("Kasir dinonaktifkan. Histori transaksi tetap tersimpan.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Kasir gagal dinonaktifkan");
    } finally {
      setLoading(false);
    }
  }
  async function disableBranch(id: number) {
    try {
      setLoading(true);
      await api(`/company/branches/${id}`, { method: "DELETE" });
      await load();
      setMessage("Cabang dinonaktifkan. Histori transaksi tetap tersimpan.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Cabang gagal dinonaktifkan");
    } finally {
      setLoading(false);
    }
  }
  async function activateBranch(id: number) {
    try {
      setLoading(true);
      await api(`/company/branches/${id}/activate`, { method: "PATCH", body: JSON.stringify({}) });
      await load();
      setMessage("Cabang berhasil diaktifkan sesuai kuota paket.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Cabang gagal diaktifkan");
    } finally {
      setLoading(false);
    }
  }
  async function resetCashierPassword(id: number) {
    if (resetData.password !== resetData.confirm) {
      setMessage("Konfirmasi password kasir tidak sama.");
      return;
    }
    try {
      setLoading(true);
      await api(`/company/users/${id}/password`, { method: "PATCH", body: JSON.stringify({ password: resetData.password }) });
      setResetUserId(0);
      setResetData({ password: "", confirm: "" });
      setMessage("Password kasir berhasil direset. Kasir harus login kembali.");showToast("Password kasir berhasil direset. Kasir harus login kembali.");
    } catch (e) {
      const text=e instanceof Error ? e.message : "Password kasir gagal direset";setMessage(text);showToast(text,"error");
    } finally {
      setLoading(false);
    }
  }
  async function changeUserPhoto(id:number){
    if(Platform.OS!=="web"){const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();if(!permission.granted){const text="Izin galeri belum diberikan. Izinkan akses foto lalu coba lagi.";setMessage(text);setMessageIsError(true);showToast(text,"error");return;}}
    const picked=await ImagePicker.launchImageLibraryAsync({mediaTypes:["images"],allowsEditing:true,aspect:[1,1],quality:.8});
    if(picked.canceled)return;
    try{setUploading(true);await uploadUserPhoto(id,picked.assets[0].uri);await load();const text="Foto pengguna berhasil diperbarui.";setMessage(text);setMessageIsError(false);showToast(text)}catch(e){const text=e instanceof Error?e.message:"Foto pengguna gagal disimpan";setMessage(text);setMessageIsError(true);showToast(text,"error")}finally{setUploading(false)}
  }
  const userLimit =
      (license?.max_branches ?? 1) * (license?.users_per_branch ?? 1),
    activeUsers = rows.filter((x) => Number(x.is_active)).length,
    branchLimit = license?.max_branches ?? 1,
    activeBranches = rows.filter((x) => Number(x.is_active)).length;
  return (
    <SafeAreaView style={s.page}>
      <View style={s.header}>
        <Pressable disabled={branchSelectionLocked} onPress={() => branchSelectionLocked?showToast("Pilih cabang yang dinonaktifkan terlebih dahulu.","error"):router.back()} style={branchSelectionLocked?s.backLocked:undefined}>
          <Text style={s.back}>‹</Text>
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={s.title}>{info[0]}</Text>
          <Text style={s.subtitle}>{info[1]}</Text>
        </View>
        <Pressable onPress={feature === "whatsapp" ? loadWhatsApp : load} disabled={feature === "whatsapp" ? whatsappLoading : loading} style={s.refresh}>
          <Text>{(feature === "whatsapp" ? whatsappLoading : loading) ? "…" : "↻"}</Text>
        </Pressable>
      </View>
      <ScrollView contentContainerStyle={s.body}>
        {message ? (
          <View style={[s.notice,messageIsError&&s.noticeError]}>
            <Text style={[s.noticeText,messageIsError&&s.noticeErrorText]}>{message}</Text>
          </View>
        ) : null}
        {loading ? <ActivityIndicator color={colors.primary} /> : null}
        {feature === "packages" ? (
          <Card>
            <Text style={s.label}>PAKET AKTIF SAAT INI</Text>
            <Text style={s.cardTitle}>
              {license?.package_name ?? "Tidak tersedia"}
            </Text>
            <Text style={s.copy}>
              {license?.status ?? "-"}
              {license?.expires_at
                ? ` · aktif sampai ${license.expires_at}`
                : " · tanpa tanggal berakhir"}
            </Text>
            <Text style={s.copy}>
              {license?.max_branches ?? 1} cabang ·{" "}
              {license?.users_per_branch ?? 1} user/cabang
            </Text>
          </Card>
        ) : null}
        {feature === "packages"
          ? rows.map((x: Package) => (
              <Card
                key={x.id}
                style={selected?.id === x.id ? s.selected : undefined}
              >
                <View style={s.row}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.cardTitle}>{x.name}</Text>
                    <Text style={s.price}>
                      {x.price
                        ? `Rp ${Number(x.price).toLocaleString("id-ID")}`
                        : "Gratis"}
                    </Text>
                  </View>
                  <Text style={s.badge}>
                    {selected?.id === x.id ? "DIPILIH" : x.code}
                  </Text>
                </View>
                <Text style={s.copy}>{x.description}</Text>
                <Text style={s.copy}>
                  {x.max_branches} cabang · {x.users_per_branch} user/cabang ·{" "}
                  {x.daily_transaction_limit ?? "Unlimited"} transaksi/hari
                </Text>
                {x.code !== "FREE" ? (
                  <Button
                    title={
                      selected?.id === x.id
                        ? "Paket sedang dipilih"
                        : "Pilih paket"
                    }
                    onPress={() => {
                      setSelected(x);
                      setPayment(null);
                      setInvoice(null);
                      setVoucherCode("");
                      setVoucher(null);
                    }}
                  />
                ) : null}
              </Card>
            ))
          : null}
        {feature === "packages" && selected && !invoice ? (
          <Card>
            <Text style={s.cardTitle}>Konfirmasi {selected.name}</Text>
            <Text style={s.copy}>
              Harga Rp {Number(selected.price).toLocaleString("id-ID")} + kode
              unik 3 digit. Invoice berlaku 12 jam.
            </Text>
            <Field label="Kode voucher (opsional)" value={voucherCode} autoCapitalize="characters" onChangeText={(value)=>{setVoucherCode(value.toUpperCase());setVoucher(null)}} placeholder="Masukkan kode voucher"/>
            {voucher?<View style={s.voucherOk}><Text style={s.voucherText}>✓ {voucher.voucher_code} · Potongan Rp {Number(voucher.discount_amount).toLocaleString("id-ID")}</Text></View>:null}
            <Button title={loading?"Memeriksa...":"Cek voucher"} variant="soft" disabled={loading} onPress={checkVoucher}/>
            <Text style={s.paymentSection}>Pilih Metode Pembayaran</Text>
            {accounts.map((x) => (
              <Pressable
                key={x.id}
                onPress={() => setPayment(x)}
                style={[s.payment, payment?.id === x.id && s.paymentOn]}
              >
                <Text style={s.paymentTitle}>
                  {x.type === "QRIS" ? "QRIS" : x.bank_name || "Transfer Bank"}
                </Text>
                {x.account_number ? (
                  <Text style={s.copy}>
                    {x.account_number} · {x.account_name}
                  </Text>
                ) : null}
                {x.qris_image ? (
                  <Image source={{ uri: x.qris_image }} style={s.qris} />
                ) : null}
                {x.instructions?.trim()?<Pressable onPress={()=>setPaymentGuide(x)} hitSlop={8}><Text style={s.paymentGuideLink}>Cara Pembayaran</Text></Pressable>:null}
              </Pressable>
            ))}
            <Button
              title="Konfirmasi pembelian"
              disabled={!payment || (!!voucherCode && !voucher)}
              onPress={createInvoice}
            />
          </Card>
        ) : null}
        {feature === "packages" && invoice ? (
          <Card>
            <Text style={s.cardTitle}>Invoice {invoice.invoice_number}</Text>
            <Line label="Harga paket" value={invoice.base_amount} />
            {invoice.voucher_code?<Line label={`Voucher ${invoice.voucher_code}`} value={-Number(invoice.discount_amount)}/>:null}
            <View style={s.row}>
              <Text>Kode unik</Text>
              <Text style={s.code}>{invoice.unique_code}</Text>
            </View>
            <Line label="Total pembayaran" value={invoice.amount} />
            <Text style={s.deadline}>
              Selesaikan sebelum {invoice.due_at} WIB
            </Text>
            <Button
              title={
                uploading ? "Mengunggah..." : "Upload bukti & konfirmasi bayar"
              }
              disabled={uploading}
              onPress={uploadProof}
            />
          </Card>
        ) : null}
        {feature === "users" ? (
          <Card>
            <View style={s.row}>
              <View>
                <Text style={s.cardTitle}>Kuota pengguna</Text>
                <Text style={s.copy}>
                  {activeUsers} dari {userLimit} user aktif ·{" "}
                  {license?.package_name}
                </Text>
              </View>
              {user?.role === "OWNER" && activeUsers < userLimit ? (
                <Pressable onPress={() => setUserForm((x) => !x)} style={s.add}>
                  <Text style={s.addText}>
                    {userForm ? "Batal" : "＋ Tambah kasir"}
                  </Text>
                </Pressable>
              ) : null}
            </View>
            {activeUsers >= userLimit ? (
              <Text style={s.warning}>
                Kuota user paket sudah penuh. Upgrade paket untuk menambah
                kasir.
              </Text>
            ) : null}
            {userForm ? (
              <View style={s.form}>
                <Text style={s.label}>CABANG KASIR</Text>
                <View style={s.branchChoices}>
                  {branchOptions.map((option) => (
                    <Pressable
                      key={option.id}
                      onPress={() => setCashier((x) => ({ ...x, branch_id: Number(option.id) }))}
                      style={[s.branchChoice, cashier.branch_id === Number(option.id) && s.branchChoiceOn]}
                    >
                      <Text style={[s.branchChoiceText, cashier.branch_id === Number(option.id) && s.branchChoiceTextOn]}>{option.name}</Text>
                    </Pressable>
                  ))}
                </View>
                <Field
                  label="Nama kasir"
                  value={cashier.fullname}
                  onChangeText={(fullname) =>
                    setCashier((x) => ({ ...x, fullname }))
                  }
                />
                <Field
                  label="Username"
                  value={cashier.username}
                  onChangeText={(username) =>
                    setCashier((x) => ({
                      ...x,
                      username: username.toLowerCase(),
                    }))
                  }
                />
                <Field
                  label="Email"
                  value={cashier.email}
                  onChangeText={(email) => setCashier((x) => ({ ...x, email }))}
                />
                <Field
                  label="No. HP"
                  value={cashier.phone}
                  onChangeText={(phone) => setCashier((x) => ({ ...x, phone }))}
                />
                <Field
                  label="Password"
                  secureTextEntry
                  value={cashier.password}
                  onChangeText={(password) =>
                    setCashier((x) => ({ ...x, password }))
                  }
                />
                <View style={s.buttonGap}><Button
                  title="Simpan kasir"
                  disabled={
                    !cashier.fullname ||
                    !cashier.username ||
                    !cashier.email ||
                    !cashier.branch_id ||
                    cashier.password.length < 8
                  }
                  onPress={addCashier}
                /></View>
              </View>
            ) : null}
          </Card>
        ) : null}
        {feature === "branches" ? (
          <Card>
            <View style={s.row}>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTitle}>Kuota cabang</Text>
                <Text style={s.copy}>
                  {activeBranches} dari {branchLimit} cabang aktif · {license?.package_name}
                </Text>
              </View>
              {user?.role === "OWNER" && activeBranches < branchLimit ? (
                <Pressable onPress={() => setBranchForm((x) => !x)} style={s.add}>
                  <Text style={s.addText}>{branchForm ? "Batal" : "＋ Tambah cabang"}</Text>
                </Pressable>
              ) : null}
            </View>
            {user?.role !== "OWNER" ? (
              <Text style={s.warning}>Hanya owner yang dapat menambah cabang.</Text>
            ) : license?.branch_selection_required ? (
              <Text style={s.warning}>Paket hanya mengizinkan {branchLimit} cabang. Pilih {license.branches_to_disable} cabang non-utama untuk dinonaktifkan permanen pada paket ini. User dan device pada cabang pilihan akan dinonaktifkan.</Text>
            ) : activeBranches >= branchLimit ? (
              <Text style={s.warning}>Kuota cabang paket sudah penuh. Upgrade paket untuk menambah cabang.</Text>
            ) : null}
            {branchForm && user?.role === "OWNER" ? (
              <View style={s.form}>
                <Field label="Nama cabang" value={branch.name} onChangeText={(name) => setBranch((x) => ({ ...x, name }))} />
                <Field label="Alamat" value={branch.address} onChangeText={(address) => setBranch((x) => ({ ...x, address }))} multiline />
                <Field label="No. HP cabang" value={branch.phone} onChangeText={(phone) => setBranch((x) => ({ ...x, phone }))} keyboardType="phone-pad" />
                <Button title={loading ? "Menyimpan..." : "Simpan cabang"} disabled={loading || !branch.name.trim()} onPress={addBranch} />
              </View>
            ) : null}
          </Card>
        ) : null}
        {["users", "branches", "devices"].includes(feature)
          ? rows.map((x) => (
              <Card key={x.id}>
                {feature === "users" ? <View style={s.userHead}>{x.photo_url?<Image source={{uri:x.photo_url}} style={s.userPhoto}/>:<View style={s.userPhotoEmpty}><Text>👤</Text></View>}<View style={{flex:1}}><Text style={s.cardTitle}>
                  {x.fullname || x.name || x.device_name || "Perangkat"}
                </Text><Text style={s.copy}>{x.role === "OWNER" ? "Owner" : "Kasir"}</Text></View></View>:<Text style={s.cardTitle}>{x.fullname || x.name || x.device_name || "Perangkat"}</Text>}
                <Text style={s.copy}>
                  {x.username || x.address || x.platform || "-"}
                  {x.branch_name ? ` · ${x.branch_name}` : ""}
                  {x.status ? ` · ${String(x.status).toUpperCase()}` : ""}
                  {x.last_login_at ? ` · terakhir ${x.last_login_at}` : ""}
                  {Number(x.is_active) === 0 ? " · NONAKTIF" : ""}
                </Text>
                {user?.role === "OWNER" && feature === "users" && Number(x.is_active) === 1 ? <View style={s.buttonGap}><Button title={uploading?"Mengupload...":"Upload foto pengguna"} variant="soft" disabled={uploading} onPress={()=>changeUserPhoto(Number(x.id))}/></View>:null}
                {user?.role === "OWNER" && feature === "users" && x.role === "CASHIER" && Number(x.is_active) === 1 ? (
                  <>
                    <View style={s.buttonGap}><Button title={resetUserId === Number(x.id) ? "Batal reset password" : "Reset password"} variant="soft" onPress={() => {setResetUserId(resetUserId === Number(x.id) ? 0 : Number(x.id));setResetData({password:"",confirm:""})}} /></View>
                    {resetUserId === Number(x.id) ? <View style={s.resetForm}><Field label="Password baru" value={resetData.password} onChangeText={(password) => setResetData(v => ({...v,password}))} secureTextEntry/><Field label="Konfirmasi password" value={resetData.confirm} onChangeText={(confirm) => setResetData(v => ({...v,confirm}))} secureTextEntry/><Button title={loading ? "Menyimpan..." : "Simpan password"} disabled={loading || resetData.password.length < 8 || !resetData.confirm} onPress={() => resetCashierPassword(Number(x.id))}/></View> : null}
                    <View style={s.buttonGap}><Button title="Hapus kasir" variant="danger" onPress={() => confirmAction("Hapus kasir", `Kasir ${x.fullname} akan dinonaktifkan dan tidak dapat login lagi, tetapi histori tetap disimpan.`, () => disableUser(Number(x.id)))} /></View>
                  </>
                ) : null}
                {user?.role === "OWNER" && feature === "branches" && Number(x.is_active) === 1 && Number(x.id) !== Number(rows[0]?.id) ? (
                  <Button title={license?.branch_selection_required ? "Pilih nonaktifkan untuk downgrade" : "Nonaktifkan cabang"} variant="danger" onPress={() => confirmAction("Nonaktifkan cabang", `Cabang ${x.name}, user, dan device di dalamnya akan dinonaktifkan. Histori tetap disimpan.`, () => disableBranch(Number(x.id)))} />
                ) : null}
                {user?.role === "OWNER" && feature === "branches" && Number(x.id) === Number(rows[0]?.id) ? <Text style={s.mainBranch}>Cabang utama · wajib aktif</Text> : null}
                {user?.role === "OWNER" && feature === "branches" && Number(x.is_active) === 0 ? <View style={s.buttonGap}><Button title="Aktifkan cabang" variant="soft" disabled={activeBranches >= branchLimit} onPress={() => activateBranch(Number(x.id))}/>{x.disabled_reason==="PACKAGE_DOWNGRADE"&&activeBranches>=branchLimit?<Text style={s.warning}>Terkunci oleh paket. Upgrade paket untuk mengaktifkan kembali.</Text>:null}</View> : null}
              </Card>
            ))
          : null}
        {feature === "devices" ? (
          <Card>
            <Text style={s.cardTitle}>Perangkat Saya</Text>
            <Text style={s.copy}>
              Untuk keamanan, perangkat aktif mengikuti batas perangkat paket Anda.
              Batas perangkat mengikuti paket dan pengaturan cabang Anda. Jika batas perangkat sudah penuh,
              Anda dapat mengganti salah satu perangkat lama melalui proses verifikasi OTP Owner.
            </Text>
            <View style={s.deviceGuide}>
              <Text style={s.deviceGuideTitle}>📱 Jika HP lama rusak / diganti</Text>
              <Text style={s.deviceGuideText}>
                1. Install Eksis Laundry di HP baru.{`\n`}
                2. Login menggunakan akun Owner.{`\n`}
                3. Jika terdeteksi perangkat lama, tekan <Text style={{fontWeight:"900"}}>Pindah ke HP Ini</Text>.{`\n`}
                4. Masukkan OTP yang dikirim ke kontak Owner.{`\n`}
                5. Device yang dipilih menjadi REPLACED dan HP baru menjadi perangkat aktif.
              </Text>
            </View>
            <Text style={s.copy}>
              Jika HP lama hilang dan Anda tidak dapat mengaksesnya, proses tetap dapat dilakukan dari HP baru melalui verifikasi OTP Owner.
            </Text>
          </Card>
        ) : null}
        {feature === "whatsapp" ? (
          <Card>
            <View style={s.waHead}>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTitle}>Hubungkan WhatsApp</Text>
                <Text style={s.copy}>Hubungkan nomor WhatsApp usaha untuk mengirim struk dan notifikasi pelanggan.</Text>
              </View>
              <View style={[s.waStatus, whatsapp?.connected ? s.waConnected : s.waWaiting]}>
                <Text style={[s.waStatusText, whatsapp?.connected ? s.waConnectedText : s.waWaitingText]}>{whatsapp?.connected ? "TERHUBUNG" : whatsapp?.connection === "connecting" ? "MENUNGGU SCAN" : "BELUM TERHUBUNG"}</Text>
              </View>
            </View>
            <Text style={s.waSection}>METODE PENGIRIMAN</Text>
            <Pressable
              onPress={()=>selectWhatsAppMethod("APP")}
              disabled={!!whatsapp?.connected}
              style={[s.waMethod,waConfig.method==="APP"&&s.waMethodOn,whatsapp?.connected&&{opacity:0.55}]}
            >
              <Text style={s.waMethodTitle}>📱 Aplikasi WhatsApp</Text>
              <Text style={s.waMethodCopy}>Default · membuka chat WhatsApp yang terpasang di perangkat.</Text>
            </Pressable>
            <Pressable onPress={()=>{setWaConfig(x=>({...x,method:"LINKED"}));setWaTermsChecked(!!waConfig.terms_accepted);}} style={[s.waMethod,waConfig.method==="LINKED"&&s.waMethodOn]}>
              <Text style={s.waMethodTitle}>🔗 WhatsApp Linked Devices</Text>
              <Text style={s.waMethodCopy}>Mengirim melalui perangkat WhatsApp yang dihubungkan dengan QR.</Text>
            </Pressable>
            {waConfig.method==="LINKED" ? <>
            {!whatsapp?.connected && !waConfig.terms_accepted?<><Text style={s.waConsentTitle}>Persetujuan WhatsApp Linked Device</Text><Text style={s.waConsentIntro}>Baca dan pahami Syarat dan Ketentuan berikut sebelum menghubungkan WhatsApp.</Text><ScrollView style={s.waTerms} nestedScrollEnabled><Text style={s.waTermsText}>{linkedTerms}</Text></ScrollView><Pressable onPress={()=>setWaTermsChecked(x=>!x)} style={s.waCheck}><Text style={s.waCheckBox}>{waTermsChecked?"☑":"☐"}</Text><Text style={s.waCheckText}>Saya telah membaca dan menyetujui Disclaimer WhatsApp Linked Device.</Text></Pressable><View style={s.buttonGap}><Button title="Setuju & hubungkan Linked Device" disabled={!waTermsChecked||whatsappLoading} onPress={()=>selectWhatsAppMethod("LINKED")}/></View></>:null}
            <Card style={s.waGuide}><Text style={s.waGuideTitle}>Cara menggunakan Linked Device</Text><Text style={s.waGuideCopy}>Buka WhatsApp di HP → Tap titik tiga di pojok kanan atas → Pilih Perangkat Tertaut → Tautkan Perangkat, lalu scan gambar di atas.</Text></Card>
            {whatsapp?.connected ? <>
              <Text style={s.waSuccess}>✓ WhatsApp berhasil terhubung{whatsapp.phone ? ` · ${whatsapp.phone}` : ""}</Text>
              <Button title="Logout WhatsApp" variant="danger" disabled={whatsappLoading} onPress={confirmWhatsappLogout} />
            </> : <>
              <View style={s.qrBox}>{whatsappLoading && !whatsappQr ? <ActivityIndicator color={colors.primary} /> : whatsappQr ? <Image source={{ uri: whatsappQr }} style={s.qrImage} /> : <Text style={s.copy}>QR belum tersedia. Tekan "Refresh QR WhatsApp" untuk membuat QR.</Text>}</View>
              <Button title={whatsappLoading ? "Memuat QR..." : "Refresh QR WhatsApp"} variant="soft" disabled={whatsappLoading} onPress={requestWhatsAppQr} />
              <Text style={s.waHint}>Status koneksi diperiksa otomatis setiap beberapa detik setelah QR dipindai.</Text>
            </>}</>:null}
          </Card>
        ) : null}
        {feature === "settings" ? (
          <Card>
            <Button
              title="Kelola produk & layanan"
              onPress={() => router.push("/products")}
            />
          </Card>
        ) : null}
      </ScrollView>
      <Modal visible={!!paymentGuide} transparent animationType="fade" onRequestClose={()=>setPaymentGuide(null)}>
        <View style={s.paymentGuideBackdrop}>
          <View style={s.paymentGuideModal}>
            <View style={s.paymentGuideHead}>
              <Text style={s.cardTitle}>Cara Pembayaran</Text>
              <Pressable onPress={()=>setPaymentGuide(null)} hitSlop={10}><Text style={s.paymentGuideClose}>×</Text></Pressable>
            </View>
            <Text style={s.paymentGuideBank}>{paymentGuide?.type==='QRIS'?'QRIS':paymentGuide?.bank_name||'Transfer Bank'}</Text>
            <ScrollView style={s.paymentGuideScroll}><Text style={s.paymentGuideText}>{paymentGuide?.instructions}</Text></ScrollView>
            <Button title="Tutup" variant="soft" onPress={()=>setPaymentGuide(null)}/>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
function Line({ label, value }: { label: string; value: number }) {
  return (
    <View style={s.row}>
      <Text>{label}</Text>
      <Text style={s.total}>Rp {Number(value).toLocaleString("id-ID")}</Text>
    </View>
  );
}
const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.background },
  header: {
    padding: 18,
    backgroundColor: "#fff",
    flexDirection: "row",
    gap: 14,
    alignItems: "center",
  },
  back: { fontSize: 34 },
  backLocked: { opacity: 0.25 },
  title: { fontSize: 20, fontWeight: "900", color: colors.ink },
  subtitle: { fontSize: 12, color: colors.muted },
  refresh: {
    padding: 10,
    borderRadius: 10,
    backgroundColor: colors.primarySoft,
  },
  body: { padding: 18, gap: 14, paddingBottom: 44 },
  notice: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: colors.primarySoft,
  },
  noticeText: { color: colors.primary, fontWeight: "700" },
  noticeError: { backgroundColor: "#FEF2F2", borderColor: "#FECACA" },
  noticeErrorText: { color: colors.danger },
  toast:{position:"absolute",zIndex:99,top:14,right:18,maxWidth:390,padding:14,borderRadius:13,backgroundColor:"#047857",shadowColor:"#000",shadowOpacity:.18,shadowRadius:10,elevation:8},
  toastError:{backgroundColor:"#DC2626"},toastText:{color:"#fff",fontWeight:"800",textAlign:"center"},
  label: { fontSize: 11, fontWeight: "900", color: colors.primary },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardTitle: { fontSize: 17, fontWeight: "900", color: colors.ink },
  price: {
    fontSize: 21,
    fontWeight: "900",
    color: colors.primary,
    marginVertical: 5,
  },
  badge: {
    backgroundColor: colors.primarySoft,
    color: colors.primary,
    fontWeight: "800",
    padding: 8,
    borderRadius: 10,
  },
  selected: {
    borderWidth: 2,
    borderColor: "#2563EB",
    backgroundColor: "#EFF6FF",
  },
  copy: { color: colors.muted, lineHeight: 20, marginVertical: 6 },
  payment: {
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    marginBottom: 10,
  },
  paymentOn: {
    borderColor: colors.primary,
    backgroundColor: colors.primarySoft,
  },
  paymentTitle: { fontWeight: "900" },
  paymentSection:{fontSize:14,fontWeight:"900",color:colors.ink,marginTop:18,marginBottom:10},
  paymentGuideLink:{color:colors.primary,fontWeight:"900",marginTop:8,textDecorationLine:"underline"},
  paymentGuideBackdrop:{flex:1,backgroundColor:"rgba(10,30,25,.45)",justifyContent:"center",padding:20},
  paymentGuideModal:{maxHeight:"78%",backgroundColor:"#fff",borderRadius:20,padding:18,gap:12},
  paymentGuideHead:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},
  paymentGuideClose:{fontSize:30,color:colors.muted,paddingHorizontal:5},
  paymentGuideBank:{fontWeight:"900",color:colors.primary},
  paymentGuideScroll:{maxHeight:360},
  paymentGuideText:{color:colors.ink,lineHeight:22},
  qris: { width: 190, height: 190, resizeMode: "contain", alignSelf: "center" },
  code: { fontWeight: "900", color: "#DC2626" },
  total: { fontWeight: "900", color: colors.primary },
  deadline: {
    padding: 12,
    backgroundColor: "#FEF2F2",
    color: "#B91C1C",
    marginVertical: 10,
  },
  voucherOk:{padding:11,borderRadius:10,backgroundColor:"#ECFDF5",marginBottom:8},
  voucherText:{color:"#047857",fontWeight:"800"},
  add: { padding: 10, borderRadius: 10, backgroundColor: colors.primary },
  addText: { color: "#fff", fontWeight: "800" },
  warning: { color: "#B45309", marginTop: 8 },
  form: { marginTop: 12 },
  branchChoices: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 8 },
  branchChoice: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 11, borderWidth: 1, borderColor: colors.line, backgroundColor: "#fff" },
  branchChoiceOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  branchChoiceText: { color: colors.ink, fontWeight: "800", fontSize: 12 },
  branchChoiceTextOn: { color: "#fff" },
  mainBranch: { color: colors.primary, fontWeight: "900", fontSize: 12, marginTop: 10 },
  resetForm: { padding: 12, borderRadius: 12, backgroundColor: colors.primarySoft, marginVertical: 8 },
  userHead:{flexDirection:"row",alignItems:"center",gap:11},
  userPhoto:{width:50,height:50,borderRadius:25,resizeMode:"cover",borderWidth:1,borderColor:colors.line},
  userPhotoEmpty:{width:50,height:50,borderRadius:25,backgroundColor:colors.primarySoft,alignItems:"center",justifyContent:"center"},
  buttonGap:{marginTop:12},
  deviceGuide:{marginTop:12,padding:14,borderRadius:12,backgroundColor:'#EFF6FF',borderWidth:1,borderColor:'#BFDBFE'},deviceGuideTitle:{fontWeight:'900',color:'#1D4ED8'},deviceGuideText:{marginTop:7,color:colors.ink,lineHeight:21},waHead:{flexDirection:"row",alignItems:"flex-start",gap:8},
  waStatus:{paddingHorizontal:8,paddingVertical:6,borderRadius:9},
  waStatusText:{fontSize:10,fontWeight:"900"},
  waConnected:{backgroundColor:"#DCFCE7"}, waConnectedText:{color:"#15803D"},
  waWaiting:{backgroundColor:"#FEF3C7"}, waWaitingText:{color:"#B45309"},
  waSuccess:{marginVertical:16,padding:12,borderRadius:12,backgroundColor:"#ECFDF5",color:"#047857",fontWeight:"800"},
  qrBox:{minHeight:230,marginVertical:14,alignItems:"center",justifyContent:"center",borderRadius:14,backgroundColor:"#fff",borderWidth:1,borderColor:colors.line,padding:12},
  qrImage:{width:205,height:205,resizeMode:"contain"},
  waHint:{color:colors.muted,fontSize:12,lineHeight:18,textAlign:"center",marginTop:10},
  waSection:{fontSize:11,fontWeight:"900",color:colors.primary,marginTop:18,marginBottom:8},waConsentTitle:{fontSize:15,fontWeight:"900",color:colors.ink,marginTop:8},waConsentIntro:{fontSize:12,lineHeight:18,color:colors.muted,marginTop:4},
  waMethod:{padding:13,borderWidth:1,borderColor:colors.line,borderRadius:12,marginBottom:9,backgroundColor:"#fff"},waMethodOn:{borderColor:colors.primary,backgroundColor:colors.primarySoft},
  waMethodTitle:{fontWeight:"900",color:colors.ink},waMethodCopy:{fontSize:12,color:colors.muted,lineHeight:17,marginTop:4},
  waCheck:{flexDirection:"row",gap:9,alignItems:"flex-start",marginTop:8,padding:10,backgroundColor:"#FFFBEB",borderRadius:10},waCheckBox:{fontSize:20,color:colors.primary,lineHeight:21},waCheckText:{flex:1,fontSize:12,lineHeight:18,color:colors.ink},
  waTerms:{maxHeight:230,marginTop:8,padding:12,borderRadius:11,borderWidth:1,borderColor:colors.line,backgroundColor:"#fff"},waTermsText:{color:colors.ink,fontSize:12,lineHeight:19},
  waGuide:{marginTop:12,backgroundColor:"#F0F9F6",borderColor:"#BFE3D9"},waGuideTitle:{fontWeight:"900",color:colors.ink},waGuideCopy:{color:colors.muted,lineHeight:20,marginTop:6},
});
