import {useEffect,useState} from "react";
import {Image,Platform,Pressable,ScrollView,StyleSheet,Text,View} from "react-native";
import {router} from "expo-router";
import * as ImagePicker from "expo-image-picker";
import {SafeAreaView} from "react-native-safe-area-context";
import {Company,getCompany,updateCompany,uploadLogo} from "@/api/company";
import {getMyProfile,uploadMyPhoto,UserProfile} from "@/api/profile";
import {Button,Card,Field} from "@/components/ui";
import {colors} from "@/theme";
import {useToast} from "@/components/toast";

export default function CompanyProfile(){
 const {showToast}=useToast();
 const[data,setData]=useState<Partial<Company>>({}),[profile,setProfile]=useState<UserProfile|null>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState(""),[success,setSuccess]=useState(false);
 useEffect(()=>{getCompany().then(setData).catch(e=>show(e.message,false));getMyProfile().then(setProfile).catch(()=>{})},[]);
 function set<K extends keyof Company>(key:K,value:Company[K]){setData(x=>({...x,[key]:value}))}
 function show(text:string,ok:boolean){setMessage(text);setSuccess(ok);showToast(text,ok?'success':'error')}
 async function choose(handler:(uri:string)=>Promise<void>){
  if(Platform.OS!=='web'){
    const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();
    if(!permission.granted)throw new Error('Izin galeri belum diberikan. Izinkan akses foto lalu coba lagi.');
  }
  const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:false,quality:.8});
  if(!result.canceled&&result.assets?.length)await handler(result.assets[0].uri);
}

 async function pickLogo(){try{setBusy(true);await choose(async uri=>{const logo=await uploadLogo(uri);setData(x=>({...x,...logo}))});show("Logo usaha berhasil disimpan.",true)}catch(e){show(e instanceof Error?e.message:"Logo gagal disimpan.",false)}finally{setBusy(false)}}
 async function pickOwner(){try{setBusy(true);
  if(Platform.OS!=="web"){const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();if(!permission.granted)throw new Error("Izin galeri belum diberikan. Izinkan akses foto lalu coba lagi.");}
  const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:["images"],allowsEditing:true,aspect:[1,1],quality:.8});
  if(result.canceled||!result.assets?.length)return;
  const photo=await uploadMyPhoto(result.assets[0].uri);
  setProfile(x=>x?{...x,...photo}:x);show("Foto profil owner berhasil disimpan.",true)
 }catch(e){show(e instanceof Error?e.message:"Foto profil gagal disimpan.",false)}finally{setBusy(false)}}
 async function save(){try{setBusy(true);await updateCompany(data);show("Profil usaha berhasil disimpan.",true)}catch(e){show(e instanceof Error?e.message:"Profil usaha gagal disimpan.",false)}finally{setBusy(false)}}
 return <SafeAreaView style={s.page}><View style={s.header}><Pressable onPress={()=>router.back()}><Text style={s.back}>‹</Text></Pressable><Text style={s.headerTitle}>Profil Usaha</Text><View style={{width:30}}/></View><ScrollView contentContainerStyle={s.body}>
  {message?<View style={[s.notice,success?s.noticeOk:s.noticeError]}><Text style={[s.noticeText,{color:success?"#047857":colors.danger}]}>{message}</Text></View>:null}
  <Card><Text style={s.section}>Foto Profil Owner</Text><View style={s.logoWrap}>{profile?.photo_url?<Image source={{uri:profile.photo_url}} style={s.ownerPhoto}/>:<View style={[s.logoEmpty,s.ownerPhoto]}><Text style={{fontSize:32}}>👤</Text></View>}<Button title={busy?"Memproses...":"Upload foto owner"} variant="soft" onPress={pickOwner}/><Text style={s.hint}>Foto ini tampil sebagai avatar owner. JPG, PNG, atau WebP maksimal 2 MB.</Text></View></Card>
  <Card><Text style={s.section}>Logo Usaha</Text><View style={s.logoWrap}>{data.logo_url?<Image source={{uri:data.logo_url}} style={s.logo}/>:<View style={s.logoEmpty}><Text style={{fontSize:30}}>🧺</Text></View>}<Button title={busy?"Memproses...":"Ganti logo"} variant="soft" onPress={pickLogo}/><Text style={s.hint}>Logo digunakan pada struk dan PDF. Maksimal 2 MB.</Text></View></Card>
  <Card><Field label="Nama laundry" value={data.company_name??""} onChangeText={v=>set("company_name",v)}/><Field label="Nama pemilik" value={data.owner_name??""} onChangeText={v=>set("owner_name",v)}/><Field label="Email" value={data.email??""} onChangeText={v=>set("email",v)} autoCapitalize="none" keyboardType="email-address"/><Field label="Nomor HP" value={data.phone??""} onChangeText={v=>set("phone",v)} keyboardType="phone-pad"/><Field label="Alamat" value={data.address??""} onChangeText={v=>set("address",v)} multiline/><Field label="Kota" value={data.city??""} onChangeText={v=>set("city",v)}/><Field label="Provinsi" value={data.province??""} onChangeText={v=>set("province",v)}/></Card><Button title={busy?"Menyimpan...":"Simpan profil"} disabled={busy} onPress={save}/>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.background},header:{height:58,flexDirection:"row",alignItems:"center",justifyContent:"space-between",paddingHorizontal:18,backgroundColor:"#fff",borderBottomWidth:1,borderBottomColor:colors.line},back:{fontSize:34,color:colors.ink},headerTitle:{fontSize:17,fontWeight:"900",color:colors.ink},body:{padding:18,gap:16,paddingBottom:36},notice:{padding:14,borderRadius:14,borderWidth:1},noticeOk:{backgroundColor:"#ECFDF5",borderColor:"#A7F3D0"},noticeError:{backgroundColor:"#FEF2F2",borderColor:"#FECACA"},noticeText:{fontWeight:"800"},section:{fontSize:17,fontWeight:"900",color:colors.ink,marginBottom:12},logoWrap:{alignItems:"center",gap:12},logo:{width:100,height:100,borderRadius:24,borderWidth:1,borderColor:colors.line,resizeMode:"cover"},ownerPhoto:{width:112,height:112,borderRadius:56},logoEmpty:{width:100,height:100,borderRadius:24,backgroundColor:colors.primarySoft,alignItems:"center",justifyContent:"center"},hint:{fontSize:11,color:colors.muted,textAlign:"center"}});
