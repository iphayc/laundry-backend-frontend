import { useEffect, useState } from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { addDiscount, Branch, Discount, disableDiscount, getBranches, getDiscounts, updateDiscount } from "@/api/laundry";
import { Button, Card, Field } from "@/components/ui";
import { colors } from "@/theme";
export default function Discounts() {
  const [rows, setRows] = useState<Discount[]>([]);
  const [branches,setBranches]=useState<Branch[]>([]);
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const[selected,setSelected]=useState(0),[editingId,setEditingId]=useState(0),[branchFilter,setBranchFilter]=useState(0);
  const [data, setData] = useState({
    name: "",
    type: "PERCENT" as "PERCENT" | "FIXED",
    value: "",
    min_transaction: "0",
    branch_settings:[] as {branch_id:number;branch_name:string;is_active:boolean}[],
  });
  function load() {
    getDiscounts(true).then(setRows).catch(e=>setMessage(e.message));
    getBranches().then(setBranches).catch(e=>setMessage(e.message));
  }
  useEffect(load, []);
  async function save() {
    try {
      const payload={
        name: data.name,
        type: data.type,
        value: Number(data.value),
        min_transaction: Number(data.min_transaction),
        branch_settings:data.branch_settings.map(x=>({branch_id:x.branch_id,is_active:x.is_active})),
      };if(editingId)await updateDiscount(editingId,payload);else await addDiscount(payload);
      setShow(false);
      setEditingId(0);setSelected(0);setMessage(editingId?"Diskon berhasil diperbarui.":"Diskon berhasil disimpan.");
      load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Diskon gagal disimpan");
    }
  }
  function edit(d:Discount){setEditingId(d.id);setData({name:d.name,type:d.type,value:String(d.value),min_transaction:String(d.min_transaction),branch_settings:(d.branch_settings??branches.map(b=>({branch_id:b.id,branch_name:b.name,is_active:1}))).map(x=>({...x,is_active:!!x.is_active}))});setShow(true);setSelected(d.id)}
  function openNew(){setEditingId(0);setData({name:"",type:"PERCENT",value:"",min_transaction:"0",branch_settings:branches.map(b=>({branch_id:b.id,branch_name:b.name,is_active:true}))});setShow(true)}
  function remove(d:Discount){const run=async()=>{try{await disableDiscount(d.id);setSelected(0);load();setMessage("Diskon dinonaktifkan. Histori transaksi tetap tersimpan.")}catch(e){setMessage(e instanceof Error?e.message:"Diskon gagal dinonaktifkan")}};const text=`Diskon ${d.name} tidak akan muncul untuk transaksi baru.`;if(Platform.OS==='web'){if(window.confirm(text))run()}else Alert.alert('Hapus diskon',text,[{text:'Batal',style:'cancel'},{text:'Hapus',style:'destructive',onPress:run}])}
  return (
    <SafeAreaView style={s.page}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()}>
          <Text style={s.back}>‹</Text>
        </Pressable>
        <Text style={s.title}>Master Diskon</Text>
        <Pressable onPress={() => show?setShow(false):openNew()} style={s.add}>
          <Text style={s.addText}>{show?'Tutup':'＋ Tambah'}</Text>
        </Pressable>
      </View>
      <ScrollView contentContainerStyle={s.body}>
        {message ? <Text style={s.message}>{message}</Text> : null}
        <Card><Text style={s.branchTitle}>Filter cabang</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.branchFilters}><Pressable onPress={()=>setBranchFilter(0)} style={[s.filterChip,branchFilter===0&&s.filterChipOn]}><Text style={[s.filterChipText,branchFilter===0&&s.filterChipTextOn]}>Semua cabang</Text></Pressable>{branches.map(branch=><Pressable key={branch.id} onPress={()=>setBranchFilter(branch.id)} style={[s.filterChip,branchFilter===branch.id&&s.filterChipOn]}><Text style={[s.filterChipText,branchFilter===branch.id&&s.filterChipTextOn]}>{branch.name}</Text></Pressable>)}</ScrollView></Card>
        {show ? (
          <Card>
            <Text style={s.discount}>{editingId?"Edit diskon":"Diskon baru"}</Text>
            <Field
              label="Nama diskon/event"
              value={data.name}
              onChangeText={(name) => setData((x) => ({ ...x, name }))}
            />
            <View style={s.row}>
              <Pressable
                onPress={() => setData((x) => ({ ...x, type: "PERCENT" }))}
                style={[s.type, data.type === "PERCENT" && s.on]}
              >
                <Text>Persen (%)</Text>
              </Pressable>
              <Pressable
                onPress={() => setData((x) => ({ ...x, type: "FIXED" }))}
                style={[s.type, data.type === "FIXED" && s.on]}
              >
                <Text>Potongan harga</Text>
              </Pressable>
            </View>
            <Field
              label={data.type === "PERCENT" ? "Persentase" : "Nominal diskon"}
              value={data.value}
              onChangeText={(value) => setData((x) => ({ ...x, value }))}
              keyboardType="numeric"
            />
            <Field
              label="Minimal transaksi"
              value={data.min_transaction}
              onChangeText={(min_transaction) =>
                setData((x) => ({ ...x, min_transaction }))
              }
              keyboardType="numeric"
            />
            <Text style={s.branchTitle}>Status diskon per cabang</Text>
            {data.branch_settings.map((setting,index)=><View key={setting.branch_id} style={s.branchRow}><Text style={s.branchName}>{setting.branch_name}</Text><Pressable onPress={()=>setData(v=>({...v,branch_settings:v.branch_settings.map((x,i)=>i===index?{...x,is_active:!x.is_active}:x)}))} style={[s.toggle,setting.is_active?s.toggleOn:s.toggleOff]}><Text style={s.toggleText}>{setting.is_active?'ON':'OFF'}</Text></Pressable></View>)}
            <Button title={editingId?"Simpan perubahan":"Simpan diskon"} onPress={save} />
          </Card>
        ) : null}
        {rows.filter(d=>!branchFilter||(d.branch_settings??[]).some(x=>x.branch_id===branchFilter&&x.is_active)).map((d) => (
          <Card key={d.id}>
            <Pressable onPress={()=>setSelected(selected===d.id?0:d.id)}>
            <Text style={s.discount}>{d.name}</Text>
            <Text style={s.copy}>
              {d.type === "PERCENT"
                ? `${Number(d.value)}%`
                : `Rp ${Number(d.value).toLocaleString("id-ID")}`}{" "}
              · Min. Rp {Number(d.min_transaction).toLocaleString("id-ID")}
            </Text>
            </Pressable>
            {(d.branch_settings??[]).map(x=><View key={x.branch_id} style={s.branchRow}><Text style={s.branchCopy}>{x.branch_name}</Text><Text style={x.is_active?s.branchOn:s.branchOff}>{x.is_active?'ON':'OFF'}</Text></View>)}
            {selected===d.id?<View style={s.actionRow}><View style={{flex:1}}><Button title="Edit" variant="soft" onPress={()=>edit(d)}/></View><View style={{flex:1}}><Button title="Hapus" variant="danger" onPress={()=>remove(d)}/></View></View>:null}
          </Card>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.background },
  header: {
    padding: 16,
    backgroundColor: "#fff",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  back: { fontSize: 34 },
  title: { fontSize: 20, fontWeight: "900", color: colors.ink },
  add: { backgroundColor: colors.primary, padding: 10, borderRadius: 12 },
  addText: { color: "#fff", fontWeight: "800" },
  body: { padding: 18, gap: 14 },
  message: {
    padding: 12,
    backgroundColor: colors.primarySoft,
    color: colors.primary,
    borderRadius: 12,
  },
  row: { flexDirection: "row", gap: 8 },
  type: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
  },
  on: { borderWidth: 2, borderColor: colors.primary },
  discount: { fontSize: 17, fontWeight: "900", color: colors.ink },
  copy: { color: colors.muted, marginTop: 6 },
  actionRow:{flexDirection:"row",gap:8,marginTop:10},branchFilters:{gap:8,paddingTop:8},filterChip:{paddingHorizontal:12,paddingVertical:8,borderRadius:999,backgroundColor:colors.primarySoft},filterChipOn:{backgroundColor:colors.primary},filterChipText:{fontSize:12,fontWeight:"800",color:colors.primary},filterChipTextOn:{color:"#fff"},
  branchTitle:{fontWeight:"900",color:colors.ink,marginTop:12},branchRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",paddingVertical:8,borderTopWidth:1,borderTopColor:colors.line},branchName:{fontWeight:"800",color:colors.ink},branchCopy:{fontSize:12,color:colors.muted},branchOn:{fontWeight:"900",color:colors.primary},branchOff:{fontWeight:"900",color:colors.danger},toggle:{paddingHorizontal:14,paddingVertical:8,borderRadius:10},toggleOn:{backgroundColor:colors.primary},toggleOff:{backgroundColor:"#9CA3AF"},toggleText:{fontWeight:"900",color:"#fff"},
});
