import {useState} from 'react';
import {KeyboardAvoidingView,Platform,ScrollView,StyleSheet,Text,View} from 'react-native';
import {router} from 'expo-router';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Button,Card,Field} from '@/components/ui';
import {resetPassword,sendResetPasswordOtp} from '@/api/auth';
import {colors} from '@/theme';
import {useToast} from '@/components/toast';

export default function ForgotPassword(){
 const {showToast}=useToast();
 const[email,setEmail]=useState(''),[otp,setOtp]=useState(''),[password,setPassword]=useState(''),[confirm,setConfirm]=useState(''),[sent,setSent]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('');
 async function send(){try{setBusy(true);setError('');await sendResetPasswordOtp(email);setSent(true);const text='Jika email terdaftar, kode OTP telah dikirim dan berlaku 5 menit.';setMessage(text);showToast(text)}catch(e){const text=e instanceof Error?e.message:'OTP gagal dikirim';setError(text);showToast(text,'error')}finally{setBusy(false)}}
 async function save(){if(password!==confirm){const text='Konfirmasi password tidak sama.';setError(text);showToast(text,'error');return}try{setBusy(true);setError('');await resetPassword({email,otp,password});const text='Password berhasil diperbarui. Silakan login.';setMessage(text);showToast(text);setTimeout(()=>router.replace('/login'),900)}catch(e){const text=e instanceof Error?e.message:'Password gagal diperbarui';setError(text);showToast(text,'error')}finally{setBusy(false)}}
 return <SafeAreaView style={s.page}><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}><ScrollView contentContainerStyle={s.body} keyboardShouldPersistTaps="handled"><Text style={s.back} onPress={()=>router.back()}>‹ Kembali</Text><Text style={s.title}>Lupa password</Text><Text style={s.copy}>Masukkan email akun owner atau kasir. Kode OTP akan dikirim ke email tersebut.</Text><Card><Field label="Email akun" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address"/>{sent?<><Field label="Kode OTP" value={otp} onChangeText={setOtp} keyboardType="number-pad"/><Field label="Password baru" value={password} onChangeText={setPassword} secureTextEntry/><Field label="Konfirmasi password" value={confirm} onChangeText={setConfirm} secureTextEntry/></>:null}{error?<Text style={s.error}>{error}</Text>:null}{message?<Text style={s.success}>{message}</Text>:null}<View style={s.action}><Button title={busy?'Memproses...':sent?'Simpan password baru':'Kirim kode OTP'} disabled={busy||!email||(sent&&(!otp||password.length<8||!confirm))} onPress={sent?save:send}/></View>{sent?<Text style={s.link} onPress={()=>{setSent(false);setOtp('');setMessage('')}}>Kirim ulang kode OTP</Text>:null}</Card></ScrollView></KeyboardAvoidingView></SafeAreaView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.background},body:{padding:24,paddingTop:34},back:{color:colors.primary,fontWeight:'800',marginBottom:24},title:{fontSize:27,fontWeight:'900',color:colors.ink},copy:{color:colors.muted,lineHeight:20,marginTop:7,marginBottom:20},error:{color:colors.danger,marginTop:8},success:{color:colors.primary,fontWeight:'700',marginTop:8},action:{marginTop:16},link:{textAlign:'center',color:colors.primary,fontWeight:'800',marginTop:14}});
