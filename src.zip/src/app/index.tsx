import { Redirect } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';
import { useAuth } from '@/store/auth-context';
import { colors } from '@/theme';
export default function Index(){const {token,loading}=useAuth();if(loading)return <View style={{flex:1,alignItems:'center',justifyContent:'center'}}><ActivityIndicator color={colors.primary}/></View>;return <Redirect href={token?"/(tabs)":"/login"}/>;}
