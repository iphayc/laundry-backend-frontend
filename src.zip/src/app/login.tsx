import {useEffect,useState} from 'react';
import Constants from 'expo-constants';
import {Image,KeyboardAvoidingView,Platform,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {router,useLocalSearchParams} from 'expo-router';
import {SafeAreaView} from 'react-native-safe-area-context';
import {sendLoginOtp,requestDeviceTransferOtp,DeviceTransferDevice} from '@/api/auth';
import {Button,Card,Field} from '@/components/ui';
import {useAuth} from '@/store/auth-context';
import {colors} from '@/theme';
import {api,ApiError} from '@/api/client';
import {LegalModal} from '@/components/legal-modal';
import {useToast} from '@/components/toast';

export default function Login(){
 const{registered,registered_username}=useLocalSearchParams<{registered?:string;registered_username?:string}>();
 const{login,loginWithOtp,transferToThisDevice}=useAuth();
 const {showToast}=useToast();
 const[mode,setMode]=useState<'PASSWORD'|'OTP'>('PASSWORD');
 const[channel,setChannel]=useState<'EMAIL'|'WHATSAPP'>('WHATSAPP');
 const[identity,setIdentity]=useState('');const[username,setUsername]=useState(registered_username??'');const[secret,setSecret]=useState('');
 const[busy,setBusy]=useState(false);const[error,setError]=useState('');const[otpSent,setOtpSent]=useState(false);const[deviceConflict,setDeviceConflict]=useState(false);const[transferDevices,setTransferDevices]=useState<DeviceTransferDevice[]>([]);const[selectedReplaceDevice,setSelectedReplaceDevice]=useState<number|null>(null);const[transferOtp,setTransferOtp]=useState('');const[transferSent,setTransferSent]=useState(false);const[resendCooldown,setResendCooldown]=useState(0);
 useEffect(()=>{if(resendCooldown<=0)return;const t=setInterval(()=>setResendCooldown(v=>v>0?v-1:0),1000);return()=>clearInterval(t)},[resendCooldown>0]);
 const effectiveReplaceDeviceId=selectedReplaceDevice;
 const[terms,setTerms]=useState('');const[termsOpen,setTermsOpen]=useState(false);
 useEffect(()=>{api<Record<string,string>>('/config/app',{auth:false}).then(x=>setTerms(x.terms_and_conditions??'')).catch(()=>setTerms('Syarat dan ketentuan belum dapat dimuat. Pastikan koneksi ke server tersedia.'))},[]);
 async function getDevicePayload(){
  let deviceId=await import('@/services/token-storage').then(m=>m.tokenStorage.get('device_uuid'));
  if(!deviceId){
    deviceId=`${Platform.OS}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const {tokenStorage}=await import('@/services/token-storage');
    await tokenStorage.set('device_uuid',deviceId);
  }
  const Device=await import('expo-device');
  return {device_uuid:deviceId,device_name:Device.deviceName??'Perangkat mobile',platform:Platform.OS,app_version:Constants.expoConfig?.version??'1.0.0'};
 }
 async function submit(){if(busy)return;setBusy(true);setError('');setDeviceConflict(false);try{if(mode==='OTP'&&!otpSent){await sendLoginOtp({identity,username,channel});setOtpSent(true);showToast('Kode OTP berhasil dikirim.');}else{mode==='PASSWORD'?await login({identity,username,password:secret}):await loginWithOtp({identity,username,otp:secret});showToast('Login berhasil.');router.replace('/(tabs)');}}catch(e){
  const text=e instanceof Error?e.message:'Login gagal';
  const normalized=text.toLowerCase();
  const apiError=e instanceof ApiError?e:null;
  const isDeviceConflict=text.includes('DEVICE_LIMIT_REACHED') || text.includes('DEVICE_ALREADY_REGISTERED') ||
    (normalized.includes('batas perangkat') && normalized.includes('penuh')) ||
    (normalized.includes('terdaftar') && normalized.includes('perangkat'));
  if(isDeviceConflict){
    const devices=Array.isArray(apiError?.data?.devices)?apiError.data.devices:[];
    setTransferDevices(devices);
    setSelectedReplaceDevice(null);
    setTransferSent(false);setTransferOtp('');setDeviceConflict(true);
    setError(devices.length>0?'Batas perangkat pada paket Anda sudah penuh. Pilih perangkat lama yang hilang atau diganti, lalu pindahkan slot ke HP ini.':'Akun sudah terdaftar pada perangkat lain. Gunakan Pindah Perangkat untuk mengganti HP lama.');
  }else{setError(text);showToast(text,'error');}
 }finally{setBusy(false)}}
 async function requestTransfer(){
  if(busy||resendCooldown>0)return;
  try{
   setBusy(true);setError('');
   const d=await getDevicePayload();
   const result=await requestDeviceTransferOtp({
     identity,username,...d,
     replace_device_id:effectiveReplaceDeviceId??undefined
   });
   const devices=Array.isArray(result?.devices)?result.devices:[];
   if(devices.length){
     setTransferDevices(devices);
     
   }
   if(result?.requires_device_selection){
     setTransferSent(false);
     setError('Pilih perangkat lama yang akan diganti terlebih dahulu.');
     return;
   }
   setTransferSent(true);
   setResendCooldown(60);
   showToast('OTP pindah perangkat berhasil dikirim. Cek email terbaru — abaikan kode OTP sebelumnya jika ada.');
  }catch(e){const text=e instanceof Error?e.message:'OTP pindah perangkat gagal dikirim';setError(text);showToast(text,'error')}
  finally{setBusy(false)}
 }
 async function confirmTransfer(){
  if(busy)return;
  try{
   setBusy(true);setError('');
   const d=await getDevicePayload();
   await transferToThisDevice({identity,username,...d,otp:transferOtp,replace_device_id:effectiveReplaceDeviceId??undefined});
   showToast('Perangkat berhasil dipindahkan. Login berhasil.');
   router.replace('/(tabs)');
  }catch(e){const text=e instanceof Error?e.message:'Pindah perangkat gagal';setError(text);showToast(text,'error')}
  finally{setBusy(false)}
 }
 function switchMode(next:'PASSWORD'|'OTP'){setMode(next);setOtpSent(false);setSecret('');setError('')}
 return <SafeAreaView style={s.page}>
  <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
   <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <View style={s.brand}><Image source={require('@/assets/images/eksis-laundry-logo.png')} style={s.logo}/><Text style={s.brandName}>Eksis Laundry</Text><Text style={s.tagline}>Kelola laundry lebih mudah.</Text></View>
    {registered==='1'?<View style={s.successBox}><Text style={s.successTitle}>Registrasi berhasil</Text><Text style={s.successText}>Akun owner dan paket FREE sudah aktif. Username Anda: {registered_username??'-'}.</Text></View>:null}
    <Card>
     <Text style={s.heading}>Masuk ke akun</Text>
     <Text style={s.helper}>Gunakan identitas pemilik usaha dan username Anda. Sistem otomatis mengenali owner atau kasir.</Text>
     <View style={s.segment}>
      <Pressable onPress={()=>switchMode('PASSWORD')} style={[s.segmentButton,mode==='PASSWORD'&&s.segmentActive]}><Text style={[s.segmentText,mode==='PASSWORD'&&s.segmentTextActive]}>Password</Text></Pressable>
      <Pressable onPress={()=>switchMode('OTP')} style={[s.segmentButton,mode==='OTP'&&s.segmentActive]}><Text style={[s.segmentText,mode==='OTP'&&s.segmentTextActive]}>Kode OTP</Text></Pressable>
     </View>
     <Field label="No. HP atau email pemilik" value={identity} onChangeText={setIdentity} autoCapitalize="none" placeholder="0812... atau owner@email.com"/>
     <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" placeholder="owner atau kasir1"/>
     {mode==='OTP'&&!otpSent?<View><Text style={s.fieldLabel}>Kirim OTP melalui</Text><View style={s.channelRow}>{(['WHATSAPP','EMAIL'] as const).map(x=><Pressable key={x} onPress={()=>setChannel(x)} style={[s.channel,channel===x&&s.channelActive]}><Text style={{fontWeight:'700',color:channel===x?colors.primary:colors.muted}}>{x==='WHATSAPP'?'WhatsApp':'Email'}</Text></Pressable>)}</View></View>:null}
     {(mode==='PASSWORD'||otpSent)?<Field label={mode==='PASSWORD'?'Password':'Kode OTP'} value={secret} onChangeText={setSecret} secureTextEntry={mode==='PASSWORD'} keyboardType={mode==='OTP'?'number-pad':'default'} placeholder={mode==='PASSWORD'?'Masukkan password':'6 digit kode OTP'}/>:null}
     {mode==='PASSWORD'?<Pressable onPress={()=>router.push('/forgot-password')}><Text style={s.forgot}>Lupa password?</Text></Pressable>:null}
     {deviceConflict ? <View style={s.deviceBox}>
       <Text style={s.deviceTitle}>📱 Perangkat Aktif Sudah Penuh</Text>
       <Text style={s.deviceText}>Batas perangkat pada cabang ini sudah penuh. Jika salah satu HP hilang atau diganti, pilih perangkat lama yang akan digantikan dengan HP ini.</Text>
       {transferDevices.length===1 ? <Text style={s.deviceHint}>Pilih perangkat ini untuk mengirim OTP. Perangkat tidak dipilih otomatis.</Text> : <Text style={s.deviceHint}>Pilih salah satu perangkat lama yang akan diganti.</Text>}
       {transferDevices.length>0 ? <View style={s.deviceList}>
         {transferDevices.map(d=><Pressable
           key={d.id}
           onPress={()=>{
             const id=Number(d.id);
             setSelectedReplaceDevice(id);
             setError('');
             if(transferSent){
               setTransferSent(false);
               setTransferOtp('');
               showToast('Perangkat diganti. Kirim ulang OTP untuk perangkat yang dipilih.');
             }
           }}
           style={[s.deviceItem,effectiveReplaceDeviceId===Number(d.id)&&s.deviceItemActive]}
         >
           <View style={{flex:1}}>
             <Text style={s.deviceName}>{d.device_name||'Perangkat mobile'}</Text>
             <Text style={s.deviceMeta}>{d.branch_name?`${d.branch_name} · `:''}{d.platform||'-'}{d.last_login_at?` · terakhir ${d.last_login_at}`:''}</Text>
           </View>
           <Text style={s.deviceRadio}>{effectiveReplaceDeviceId===Number(d.id)?'✓':'○'}</Text>
         </Pressable>)}
       </View> : null}
       {!transferSent ? <Button title={busy ? "Mengirim OTP..." : "Pindah Perangkat ke HP Ini"} disabled={busy || !identity || !username || !effectiveReplaceDeviceId} onPress={requestTransfer}/> : <>
         <Field label="OTP Pindah Perangkat" value={transferOtp} onChangeText={setTransferOtp} keyboardType="number-pad" placeholder="Masukkan OTP"/>
         <Button title={busy ? "Memverifikasi..." : "Konfirmasi Pindah Perangkat"} disabled={busy} onPress={confirmTransfer}/>
         <Pressable disabled={busy||resendCooldown>0} onPress={requestTransfer}><Text style={[s.link,(busy||resendCooldown>0)&&{opacity:0.5}]}>{resendCooldown>0?`Kirim ulang OTP (${resendCooldown}s)`:'Kirim ulang OTP'}</Text></Pressable>
       </>}
     </View> : null}
     {error?<Text style={s.error}>{error}</Text>:null}
     <View style={s.submitSpacing}><Button disabled={busy||deviceConflict||!identity||!username||(mode==='PASSWORD'&&!secret)} onPress={submit} title={busy?'Memproses...':mode==='OTP'&&!otpSent?'Kirim Kode OTP':'Masuk'}/></View>
     {mode==='OTP'&&otpSent?<Pressable onPress={()=>setOtpSent(false)}><Text style={s.link}>Kirim ulang atau ganti metode</Text></Pressable>:null}
    </Card>
    <View style={s.registerBox}><Text style={s.registerTitle}>Baru menggunakan Eksis Laundry?</Text><Text style={s.registerText}>Daftar akun owner dan mulai dengan paket FREE.</Text><Pressable onPress={()=>router.push('/register')} style={s.registerButton}><Text style={s.registerButtonText}>Daftar Sekarang</Text></Pressable><Pressable onPress={()=>setTermsOpen(true)}><Text style={s.legalLink}>Syarat dan Ketentuan</Text></Pressable></View><LegalModal visible={termsOpen} html={terms} onClose={()=>setTermsOpen(false)}/>
   </ScrollView>
  </KeyboardAvoidingView>
 </SafeAreaView>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.background},content:{padding:24,paddingTop:36,paddingBottom:40,gap:20},brand:{alignItems:'center'},logo:{width:112,height:112,borderRadius:24,resizeMode:'contain'},brandName:{fontSize:25,fontWeight:'900',color:colors.ink,marginTop:10},tagline:{color:colors.muted,marginTop:3},successBox:{padding:16,borderRadius:16,backgroundColor:'#ECFDF5',borderWidth:1,borderColor:'#A7F3D0'},successTitle:{fontSize:16,fontWeight:'900',color:'#047857'},successText:{fontSize:13,lineHeight:19,color:'#065F46',marginTop:4},heading:{fontSize:22,fontWeight:'900',color:colors.ink},helper:{color:colors.muted,lineHeight:20,marginTop:7,marginBottom:17},segment:{flexDirection:'row',padding:4,borderRadius:14,backgroundColor:colors.background,marginBottom:16},segmentButton:{flex:1,padding:11,alignItems:'center',borderRadius:11},segmentActive:{backgroundColor:'#fff'},segmentText:{fontWeight:'700',color:colors.muted},segmentTextActive:{color:colors.primary},fieldLabel:{fontSize:13,fontWeight:'700',color:colors.ink,marginBottom:7},channelRow:{flexDirection:'row',gap:10},channel:{flex:1,padding:13,borderWidth:1,borderColor:colors.line,borderRadius:14,alignItems:'center'},channelActive:{backgroundColor:colors.primarySoft,borderColor:colors.primary},forgot:{textAlign:'right',color:colors.primary,fontWeight:'800',marginTop:8},error:{color:colors.danger,fontSize:13},submitSpacing:{marginTop:16},link:{textAlign:'center',color:colors.primary,fontWeight:'700',marginTop:13},deviceBox:{padding:14,borderRadius:14,borderWidth:1,borderColor:'#F59E0B',backgroundColor:'#FFFBEB',gap:10},deviceTitle:{fontWeight:'900',color:'#92400E'},deviceText:{fontSize:13,lineHeight:19,color:'#78350F'},deviceHint:{fontSize:12,color:'#92400E',fontWeight:'700'},deviceList:{gap:8},deviceItem:{flexDirection:'row',alignItems:'center',padding:11,borderRadius:12,borderWidth:1,borderColor:'#FDE68A',backgroundColor:'#fff'},deviceItemActive:{borderColor:'#D97706',backgroundColor:'#FEF3C7'},deviceName:{fontWeight:'800',color:'#451A03'},deviceMeta:{fontSize:11,color:'#92400E',marginTop:3},deviceRadio:{fontSize:20,fontWeight:'900',color:'#D97706',marginLeft:10},registerBox:{alignItems:'center',padding:18,borderRadius:20,borderWidth:1,borderColor:colors.line,backgroundColor:'#fff'},registerTitle:{fontWeight:'900',color:colors.ink},registerText:{fontSize:12,color:colors.muted,marginTop:4},registerButton:{marginTop:13,paddingHorizontal:22,paddingVertical:10,borderRadius:99,backgroundColor:colors.primarySoft},registerButtonText:{fontWeight:'900',color:colors.primary},legalLink:{color:colors.primary,textDecorationLine:'underline',fontWeight:'700',marginTop:14}});
