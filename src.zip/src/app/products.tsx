import { useEffect, useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  addProduct,
  getProductCategories,
  getProducts,
  Product,
  ProductCategory,
  updateProduct,
  disableProduct,
  getBranches,
  Branch,
} from "@/api/laundry";
import { Button, Card, Field } from "@/components/ui";
import { colors } from "@/theme";
import { exportProductsExcel } from "@/utils/product-excel";
export default function Products() {
  const [rows, setRows] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [branches,setBranches]=useState<Branch[]>([]);
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const [selected,setSelected]=useState(0),[editingId,setEditingId]=useState(0),[branchFilter,setBranchFilter]=useState(0);
  const [data, setData] = useState({ name: "", category_id: 0, price: "",branch_settings:[] as {branch_id:number;branch_name:string;price:string;is_active:boolean}[] });
  function load() {
    getProducts(true)
      .then(setRows)
      .catch((e) => setMessage(e.message));
    getBranches().then(setBranches).catch((e)=>setMessage(e.message));
    getProductCategories()
      .then((list) => {
        setCategories(Array.isArray(list) ? list : []);
        setData((x) => ({
          ...x,
          category_id: x.category_id || list[0]?.id || 0,
        }));
      })
      .catch((e) => setMessage(e.message));
  }
  useEffect(load, []);
  async function save() {
    try {
      setBusy(true);
      const payload={
        name: data.name,
        category_id: data.category_id,
        price: Number(data.price),
        branch_settings:data.branch_settings.map(x=>({branch_id:x.branch_id,price:Number(x.price||data.price),is_active:x.is_active})),
      };if(editingId)await updateProduct(editingId,payload);else await addProduct(payload);
      setShow(false);
      setData({ name: "", category_id: categories[0]?.id || 0, price: "",branch_settings:[] });
      setEditingId(0);setSelected(0);setMessage(editingId?"Produk berhasil diperbarui.":"Produk berhasil ditambahkan.");
      load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Produk gagal disimpan");
    } finally {
      setBusy(false);
    }
  }
  function edit(p:Product){setEditingId(p.id);setData({name:p.name,category_id:p.category_id,price:String(p.price),branch_settings:(p.branch_settings??branches.map(b=>({branch_id:b.id,branch_name:b.name,price:p.price,is_active:1}))).map(x=>({...x,price:String(x.price),is_active:!!x.is_active}))});setShow(true);setSelected(p.id)}
  function openNew(){setEditingId(0);setData({name:"",category_id:categories[0]?.id||0,price:"",branch_settings:branches.map(b=>({branch_id:b.id,branch_name:b.name,price:"",is_active:true}))});setShow(true)}
  function remove(p:Product){const run=async()=>{try{await disableProduct(p.id);setSelected(0);load();setMessage("Produk dinonaktifkan. Histori transaksi tetap tersimpan.")}catch(e){setMessage(e instanceof Error?e.message:"Produk gagal dinonaktifkan")}};const text=`Produk ${p.name} tidak akan muncul untuk pesanan baru.`;if(Platform.OS==='web'){if(window.confirm(text))run()}else Alert.alert('Hapus produk',text,[{text:'Batal',style:'cancel'},{text:'Hapus',style:'destructive',onPress:run}])}
  const filteredRows = rows.filter((p) => {
    if(branchFilter && !(p.branch_settings??[]).some(x=>x.branch_id===branchFilter&&x.is_active)) return false;
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return [
      p.name,
      p.category_name,
      p.category_code,
      p.unit,
      String(p.price),
    ].some((value) => String(value ?? "").toLowerCase().includes(q));
  });

  async function handleExportExcel() {
    try {
      setBusy(true);
      await exportProductsExcel(filteredRows);
      setMessage(`Export ${filteredRows.length} produk/layanan berhasil dibuat.`);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Export produk/layanan gagal.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <SafeAreaView style={s.page}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()}>
          <Text style={s.back}>‹</Text>
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={s.title}>Produk & Layanan</Text>
          <Text style={s.muted}>Kategori mengikuti master dari admin.</Text>
        </View>
        <Pressable onPress={() => show?setShow(false):openNew()} style={s.add}>
          <Text style={s.addText}>{show ? "Tutup" : "＋ Tambah"}</Text>
        </Pressable>
      </View>
      <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
      <ScrollView contentContainerStyle={s.body} keyboardShouldPersistTaps="handled" keyboardDismissMode={Platform.OS==='ios'?'interactive':'on-drag'} nestedScrollEnabled automaticallyAdjustKeyboardInsets={Platform.OS==='ios'}>
        <Button
          title="Kelola master diskon"
          variant="soft"
          onPress={() => router.push("/discounts")}
        />
        <View style={s.exportGap}>
          <Button
            title={busy ? "Membuat Excel..." : "Export Excel"}
            disabled={busy}
            variant="soft"
            onPress={handleExportExcel}
          />
        </View>
        <View style={s.searchBox}>
          <Field
            label="Cari produk / layanan"
            value={search}
            onChangeText={setSearch}
            placeholder="Nama, kategori, kode, atau satuan"
          />
        </View>
        <Card><Text style={s.branchTitle}>Filter cabang</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}><Pressable onPress={()=>setBranchFilter(0)} style={[s.chip,branchFilter===0&&s.chipOn]}><Text style={[s.chipText,branchFilter===0&&{color:'#fff'}]}>Semua cabang</Text></Pressable>{branches.map(branch=><Pressable key={branch.id} onPress={()=>setBranchFilter(branch.id)} style={[s.chip,branchFilter===branch.id&&s.chipOn]}><Text style={[s.chipText,branchFilter===branch.id&&{color:'#fff'}]}>{branch.name}</Text></Pressable>)}</ScrollView></Card>
        {message ? <Text style={s.message}>{message}</Text> : null}
        {show ? (
          <Card>
            <Text style={s.product}>{editingId?"Edit produk":"Produk baru"}</Text>
            <Field
              label="Nama produk/layanan"
              value={data.name}
              onChangeText={(name) => setData((x) => ({ ...x, name }))}
            />
            <Text style={s.label}>Kategori</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}>
              {categories.map((category) => (
                <Pressable
                  key={category.id}
                  onPress={() =>
                    setData((x) => ({ ...x, category_id: category.id }))
                  }
                  style={[s.chip, data.category_id === category.id && s.chipOn]}
                >
                  <Text
                    style={[
                      s.chipText,
                      data.category_id === category.id && { color: "#fff" },
                    ]}
                  >
                    {category.name} ({category.unit})
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
            {!categories.length ? (
              <Text style={s.muted}>Kategori belum diatur oleh admin.</Text>
            ) : null}
            <Field
              label="Harga"
              value={data.price}
              onChangeText={(price) => setData((x) => ({ ...x, price }))}
              keyboardType="numeric"
            />
            <Text style={s.branchTitle}>Harga & status per cabang</Text>
            <Text style={s.muted}>Harga kosong akan mengikuti harga master di atas.</Text>
            {data.branch_settings.map((setting,index)=><View key={setting.branch_id} style={s.branchCard}>
              <View style={s.row}><Text style={s.branchName}>{setting.branch_name}</Text><Pressable onPress={()=>setData(v=>({...v,branch_settings:v.branch_settings.map((x,i)=>i===index?{...x,is_active:!x.is_active}:x)}))} style={[s.toggle,setting.is_active?s.toggleOn:s.toggleOff]}><Text style={s.toggleText}>{setting.is_active?'ON':'OFF'}</Text></Pressable></View>
              <Field label={`Harga ${setting.branch_name}`} value={setting.price} onChangeText={price=>setData(v=>({...v,branch_settings:v.branch_settings.map((x,i)=>i===index?{...x,price}:x)}))} keyboardType="numeric"/>
            </View>)}
            <View style={s.buttonGap}><Button
              title={busy ? "Menyimpan..." : editingId?"Simpan perubahan":"Simpan produk"}
              disabled={busy || !data.name || !data.price || !data.category_id}
              onPress={save}
            /></View>
          </Card>
        ) : null}
        {filteredRows.map((p) => (
          <Card key={p.id}>
            <Pressable onPress={()=>setSelected(selected===p.id?0:p.id)} style={s.row}>
              <View>
                <Text style={s.product}>{p.name}</Text>
                <Text style={s.muted}>
                  {p.category_name || p.category_code} · per {p.unit}
                </Text>
              </View>
              <Text style={s.price}>
                Rp {Number(p.price).toLocaleString("id-ID")}
              </Text>
            </Pressable>
            {(p.branch_settings??[]).map(x=><View key={x.branch_id} style={s.branchSummary}><Text style={s.muted}>{x.branch_name}</Text><Text style={x.is_active?s.branchOn:s.branchOff}>{x.is_active?`ON · Rp ${Number(x.price).toLocaleString("id-ID")}/${p.unit}`:'OFF'}</Text></View>)}
            {selected===p.id?<View style={s.actionRow}><View style={{flex:1}}><Button title="Edit" variant="soft" onPress={()=>edit(p)}/></View><View style={{flex:1}}><Button title="Hapus" variant="danger" onPress={()=>remove(p)}/></View></View>:null}
          </Card>
        ))}
      </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  buttonGap:{marginTop:12},
  exportGap:{marginTop:-6},
  searchBox:{marginTop:-4},
  page: { flex: 1, backgroundColor: colors.background },
  header: {
    padding: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
  },
  back: { fontSize: 34, color: colors.ink },
  title: { fontSize: 20, fontWeight: "900", color: colors.ink },
  muted: { color: colors.muted, fontSize: 12 },
  add: { backgroundColor: colors.primary, padding: 10, borderRadius: 12 },
  addText: { color: "#fff", fontWeight: "800" },
  body: { padding: 18, gap: 14, paddingBottom: 220 },
  message: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    color: colors.primary,
    fontWeight: "700",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  product: { fontSize: 17, fontWeight: "900", color: colors.ink },
  price: { fontSize: 16, fontWeight: "900", color: colors.primary },
  label: { fontWeight: "800", color: colors.ink },
  chips: { flexDirection: "row", gap: 8, paddingVertical: 2, paddingRight: 8 },
  chip: { padding: 11, borderRadius: 10, backgroundColor: colors.primarySoft },
  chipOn: { backgroundColor: colors.primary },
  chipText: { fontWeight: "700", color: colors.ink },
  actionRow:{flexDirection:"row",gap:8,marginTop:10},
  branchTitle:{fontWeight:"900",color:colors.ink,marginTop:14},
  branchCard:{padding:12,borderWidth:1,borderColor:colors.line,borderRadius:12,gap:8},
  branchName:{fontWeight:"900",color:colors.ink},
  branchSummary:{flexDirection:"row",justifyContent:"space-between",paddingTop:7,marginTop:7,borderTopWidth:1,borderTopColor:colors.line},branchOn:{fontSize:12,fontWeight:"800",color:colors.primary},branchOff:{fontSize:12,fontWeight:"800",color:colors.danger},
  toggle:{paddingHorizontal:14,paddingVertical:8,borderRadius:10},toggleOn:{backgroundColor:colors.primary},toggleOff:{backgroundColor:"#E5E7EB"},toggleText:{fontWeight:"900",color:"#fff"},
});
