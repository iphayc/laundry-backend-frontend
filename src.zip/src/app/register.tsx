import {useEffect,useState} from 'react';
import * as Device from 'expo-device';
import {tokenStorage} from '@/services/token-storage';
import {KeyboardAvoidingView,Platform,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {router} from 'expo-router';
import {SafeAreaView} from 'react-native-safe-area-context';
import {registerOwner,sendRegistrationOtp} from '@/api/auth';
import {Button,Card,Field} from '@/components/ui';
import {colors} from '@/theme';
import {api} from '@/api/client';
import {LegalModal} from '@/components/legal-modal';
import {useToast} from '@/components/toast';

export default function Register(){
 const {showToast}=useToast();
 const[step,setStep]=useState<1|2>(1);
 const[busy,setBusy]=useState(false);
 const[error,setError]=useState('');
 const[terms,setTerms]=useState('');const[termsOpen,setTermsOpen]=useState(false);const[accepted,setAccepted]=useState(false);
 const[data,setData]=useState({fullname:'',username:'',company_name:'',email:'',phone:'',password:'',confirm:'',otp:''});
 useEffect(()=>{api<Record<string,string>>('/config/app',{auth:false}).then(x=>setTerms(x.terms_and_conditions??''))},[]);
 function set(key:keyof typeof data,value:string){setData(current=>({...current,[key]:value}))}
 async function sendOtp(){
  if(!data.fullname||!data.username||!data.company_name||!data.email||!data.phone||data.password.length<8){const text='Lengkapi data. Password minimal 8 karakter.';setError(text);showToast(text,'error');return}
  if(!/^[a-zA-Z0-9._-]{3,50}$/.test(data.username)){const text='Username minimal 3 karakter dan hanya boleh berisi huruf, angka, titik, garis bawah, atau strip.';setError(text);showToast(text,'error');return}
  if(data.password!==data.confirm){const text='Konfirmasi password tidak sama.';setError(text);showToast(text,'error');return}
  try{setBusy(true);setError('');await sendRegistrationOtp(data.email);setStep(2);showToast('Kode OTP berhasil dikirim ke email.')}catch(e){const text=e instanceof Error?e.message:'OTP gagal dikirim';setError(text);showToast(text,'error')}finally{setBusy(false)}
 }
 async function register(){
  if(data.otp.length!==6){const text='Masukkan 6 digit kode OTP.';setError(text);showToast(text,'error');return}
  try{
   setBusy(true);setError('');
   let deviceId=await tokenStorage.get('device_uuid');
   if(!deviceId){
    deviceId=`${Platform.OS}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    await tokenStorage.set('device_uuid',deviceId);
   }
   await registerOwner({
    ...data,
    terms_accepted:accepted,
    device_uuid:deviceId,
    device_name:Device.deviceName??'Perangkat mobile',
    platform:Platform.OS,
    app_version:'1.0.0',
   });
   showToast('Registrasi berhasil. Akun FREE telah aktif.');
   router.replace({pathname:'/login',params:{registered:'1',registered_username:data.username.toLowerCase()}});
  }catch(e){const text=e instanceof Error?e.message:'Registrasi gagal';setError(text);showToast(text,'error')}finally{setBusy(false)}
 }
 return <SafeAreaView style={s.page}>
  <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
   <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <Pressable onPress={()=>step===2?setStep(1):router.back()}><Text style={s.back}>‹</Text></Pressable>
    <View><Text style={s.eyebrow}>BUAT AKUN OWNER</Text><Text style={s.title}>{step===1?'Mulai kelola laundry Anda':'Verifikasi email'}</Text><Text style={s.subtitle}>{step===1?'Daftar kurang dari 5 menit dan mulai dengan paket FREE.':`Kode OTP telah dikirim ke ${data.email}`}</Text></View>
    <View style={s.steps}><View style={s.stepOn}/><View style={step===2?s.stepOn:s.stepOff}/></View>
    <Card>
     {step===1?<>
      <Field label="Nama lengkap pemilik" value={data.fullname} onChangeText={v=>set('fullname',v)} placeholder="Nama pemilik"/>
      <Field label="Username owner" value={data.username} onChangeText={v=>set('username',v.toLowerCase().replace(/[^a-z0-9._-]/g,''))} autoCapitalize="none" placeholder="Contoh: ipay"/>
      <Field label="Nama laundry" value={data.company_name} onChangeText={v=>set('company_name',v)} placeholder="Contoh: Laundry Bersih"/>
      <Field label="Email" value={data.email} onChangeText={v=>set('email',v)} autoCapitalize="none" keyboardType="email-address" placeholder="owner@email.com"/>
      <Field label="Nomor WhatsApp" value={data.phone} onChangeText={v=>set('phone',v)} keyboardType="phone-pad" placeholder="0812..."/>
      <Field label="Password" value={data.password} onChangeText={v=>set('password',v)} secureTextEntry placeholder="Minimal 8 karakter"/>
      <Field label="Konfirmasi password" value={data.confirm} onChangeText={v=>set('confirm',v)} secureTextEntry placeholder="Ulangi password"/>
      <Pressable onPress={()=>setAccepted(x=>!x)} style={s.consent}><View style={[s.checkbox,accepted&&s.checkboxOn]}><Text style={s.checkText}>{accepted?'✓':''}</Text></View><Text style={s.consentText}>Saya menyetujui <Text style={s.termsLink} onPress={()=>setTermsOpen(true)}>Syarat dan Ketentuan</Text>.</Text></Pressable>
     </>:<>
      <View style={s.otpIcon}><Text style={{fontSize:34}}>✉</Text></View>
      <Field label="Kode OTP" value={data.otp} onChangeText={v=>set('otp',v.replace(/\D/g,'').slice(0,6))} keyboardType="number-pad" maxLength={6} placeholder="6 digit kode"/>
      <Text style={s.note}>Setelah verifikasi, username pertama otomatis dibuat sebagai <Text style={{fontWeight:'900'}}>owner</Text>.</Text>
     </>}
     {error?<Text style={s.error}>{error}</Text>:null}
     <View style={s.submitSpacing}><Button title={busy?'Memproses...':step===1?'Kirim OTP Email':'Daftar & Aktifkan FREE'} disabled={busy||(step===1&&!accepted)} onPress={step===1?sendOtp:register}/></View>
     {step===2?<Pressable onPress={sendOtp}><Text style={s.link}>Kirim ulang OTP</Text></Pressable>:null}
    </Card>
    <Pressable onPress={()=>router.replace('/login')}><Text style={s.login}>Sudah punya akun? <Text style={{fontWeight:'900',color:colors.primary}}>Masuk</Text></Text></Pressable><LegalModal visible={termsOpen} html={terms} onClose={()=>setTermsOpen(false)}/>
   </ScrollView>
  </KeyboardAvoidingView>
 </SafeAreaView>
}

const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.background},content:{padding:22,paddingBottom:40,gap:18},back:{fontSize:38,color:colors.ink},eyebrow:{fontSize:12,fontWeight:'900',letterSpacing:1.5,color:colors.primary},title:{fontSize:28,fontWeight:'900',color:colors.ink,marginTop:5},subtitle:{color:colors.muted,lineHeight:20,marginTop:7},steps:{flexDirection:'row',gap:8},stepOn:{height:6,flex:1,borderRadius:6,backgroundColor:colors.primary},stepOff:{height:6,flex:1,borderRadius:6,backgroundColor:colors.line},otpIcon:{width:72,height:72,borderRadius:24,backgroundColor:colors.primarySoft,alignItems:'center',justifyContent:'center',alignSelf:'center',marginBottom:5},note:{fontSize:13,color:colors.muted,lineHeight:19},error:{color:colors.danger,fontSize:13},submitSpacing:{marginTop:16},consent:{flexDirection:'row',alignItems:'flex-start',gap:10,marginTop:8},checkbox:{width:22,height:22,borderRadius:6,borderWidth:1,borderColor:colors.line,alignItems:'center',justifyContent:'center'},checkboxOn:{backgroundColor:colors.primary,borderColor:colors.primary},checkText:{color:'#fff',fontWeight:'900'},consentText:{flex:1,color:colors.muted,lineHeight:21},termsLink:{color:colors.primary,fontWeight:'900'},link:{textAlign:'center',color:colors.primary,fontWeight:'800',marginTop:12},login:{textAlign:'center',color:colors.muted}});
