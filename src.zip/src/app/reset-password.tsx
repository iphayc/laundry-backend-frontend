import {useState} from "react";
import {Pressable,StyleSheet,Text,View} from "react-native";
import {router} from "expo-router";
import {Screen} from "@/components/screen";
import {Button,Card,Field,ScreenTitle} from "@/components/ui";
import {useToast} from "@/components/toast";
import {changeOwnPassword} from "@/api/auth";
import {colors} from "@/theme";

export default function ResetPassword(){
  const {showToast}=useToast();
  const [form,setForm]=useState({old_password:"",new_password:"",new_password_confirmation:""});
  const [busy,setBusy]=useState(false);

  async function save(){
    if(busy)return;
    if(!form.old_password){showToast("Password lama wajib diisi.","error");return}
    if(form.new_password.length<8){showToast("Password baru minimal 8 karakter.","error");return}
    if(form.new_password!==form.new_password_confirmation){showToast("Konfirmasi password baru tidak sama.","error");return}
    try{
      setBusy(true);
      await changeOwnPassword(form);
      setForm({old_password:"",new_password:"",new_password_confirmation:""});
      showToast("Password berhasil diperbarui.");
    }catch(e){
      showToast(e instanceof Error?e.message:"Password gagal diperbarui.","error");
    }finally{
      setBusy(false);
    }
  }

  return <Screen>
    <View style={s.header}>
      <Pressable onPress={()=>router.back()} style={s.back}><Text style={s.backText}>‹</Text></Pressable>
      <ScreenTitle title="Reset Password" subtitle="Perbarui password akun owner."/>
    </View>
    <Card style={s.form}>
      <Field label="Masukkan password lama" value={form.old_password} onChangeText={old_password=>setForm(v=>({...v,old_password}))} secureTextEntry autoCapitalize="none" autoCorrect={false}/>
      <Field label="Masukkan password baru" value={form.new_password} onChangeText={new_password=>setForm(v=>({...v,new_password}))} secureTextEntry autoCapitalize="none" autoCorrect={false}/>
      <Field label="Konfirmasi password baru" value={form.new_password_confirmation} onChangeText={new_password_confirmation=>setForm(v=>({...v,new_password_confirmation}))} secureTextEntry autoCapitalize="none" autoCorrect={false}/>
      <Button title={busy?"Menyimpan...":"Simpan Password"} disabled={busy} onPress={save}/>
      <Button title="Batal" variant="danger" disabled={busy} onPress={()=>router.back()}/>
    </Card>
  </Screen>
}

const s=StyleSheet.create({
  header:{flexDirection:"row",alignItems:"center",gap:12},
  back:{width:42,height:42,borderRadius:14,alignItems:"center",justifyContent:"center",backgroundColor:colors.card,borderWidth:1,borderColor:colors.line},
  backText:{fontSize:32,lineHeight:35,color:colors.ink},
  form:{gap:16},
});
