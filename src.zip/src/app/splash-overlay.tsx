import {Image,StyleSheet,View} from 'react-native';
export default function SplashOverlay(){return <View style={s.container}><Image source={require('@/assets/images/laundry-splash.png')} style={s.image} resizeMode="cover"/></View>}
const s=StyleSheet.create({container:{...StyleSheet.absoluteFillObject,backgroundColor:'#fff',zIndex:9999,elevation:9999},image:{width:'100%',height:'100%'}});
