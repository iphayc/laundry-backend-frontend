import {ReactNode} from 'react';
import {KeyboardAvoidingView,Platform,ScrollView,StyleSheet,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {colors} from '@/theme';

export function Screen({children,scroll=true,overlay}:{children:ReactNode;scroll?:boolean;overlay?:ReactNode}){
 const body=<View style={s.body}>{children}</View>;
 return <SafeAreaView edges={['top']} style={s.safe}>
  {scroll ? <KeyboardAvoidingView style={s.flex} behavior={Platform.OS==='ios'?'padding':undefined}>
    <ScrollView
      contentContainerStyle={s.scrollContent}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      keyboardDismissMode={Platform.OS==='ios'?'interactive':'on-drag'}
      nestedScrollEnabled
      automaticallyAdjustKeyboardInsets={Platform.OS==='ios'}
    >{body}</ScrollView>
  </KeyboardAvoidingView> : body}
  {overlay}
 </SafeAreaView>
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:colors.background},
 flex:{flex:1},
 scrollContent:{paddingBottom:180},
 body:{paddingHorizontal:18,paddingTop:16,gap:18},
});
