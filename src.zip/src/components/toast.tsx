import { createContext, ReactNode, useCallback, useContext, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

type ToastType = 'success' | 'error';
type ToastContextValue = { showToast: (message: string, type?: ToastType) => void };
const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = useCallback((message: string, type: ToastType = 'success') => {
    if (timer.current) clearTimeout(timer.current);
    setToast({ message, type });
    timer.current = setTimeout(() => setToast(null), 3500);
  }, []);
  return <ToastContext.Provider value={{ showToast }}>
    {children}
    {toast ? <View pointerEvents="none" style={[s.toast, toast.type === 'error' && s.error]}><Text style={s.text}>{toast.message}</Text></View> : null}
  </ToastContext.Provider>;
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('ToastProvider tidak tersedia');
  return context;
}

const s = StyleSheet.create({
  toast: { position: 'absolute', top: 52, right: 18, zIndex: 9999, maxWidth: 330, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 11, backgroundColor: '#047857', shadowColor: '#000', shadowOpacity: .2, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 9 },
  error: { backgroundColor: '#DC2626' },
  text: { color: '#fff', fontWeight: '700', fontSize: 13, lineHeight: 18 },
});
