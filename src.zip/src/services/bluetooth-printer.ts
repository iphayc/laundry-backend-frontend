import AsyncStorage from '@react-native-async-storage/async-storage';
import { Buffer } from 'buffer';
import { Linking, NativeModules, PermissionsAndroid, Platform } from 'react-native';
import { getCompany } from '../api/company';

export type BluetoothPrinter = { id: string; name: string; address?: string };
const KEY = 'selected_bluetooth_printer';

async function ensureBluetoothPermission(): Promise<void> {
  if (Platform.OS !== 'android') return;
  if (Platform.Version < 31) {
    const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
    if (granted !== PermissionsAndroid.RESULTS.GRANTED) throw new Error('Izin Lokasi diperlukan untuk membaca printer Bluetooth pada Android versi ini.');
    return;
  }
  const granted = await PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT, PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN]);
  if (Object.values(granted).some((value) => value !== PermissionsAndroid.RESULTS.GRANTED)) throw new Error('Izin Bluetooth (Connect & Scan) diperlukan. Aktifkan izin Bluetooth di pengaturan aplikasi.');
}

function assertNativeBuild() {
  if (Platform.OS === 'web') throw new Error('Printer Bluetooth hanya tersedia pada aplikasi Android/iOS.');
  if (!nativeBridge()) throw new Error('Modul Bluetooth belum tersedia. Gunakan development/production build, bukan Expo Go.');
}

function nativeBridge(): any { return NativeModules.RNBluetoothClassic; }

export async function pairedPrinters(): Promise<BluetoothPrinter[]> {
  assertNativeBuild();
  await ensureBluetoothPermission();
  try {
    const native = nativeBridge();
    if (!(await native.isBluetoothEnabled())) throw new Error('Bluetooth belum aktif.');
    const rows = await native.getBondedDevices();
    return rows.map((device: {address?:string;id?:string;name?:string}) => ({ id: device.address || device.id || '', name: device.name || 'Printer Bluetooth', address: device.address }));
  } catch (error) {
    if (error instanceof Error && error.message === 'Bluetooth belum aktif.') throw error;
    throw new Error(`Gagal memuat perangkat Bluetooth terpasang. ${error instanceof Error ? error.message : ''}`.trim());
  }
}

export async function selectedPrinter(): Promise<BluetoothPrinter | null> { const raw = await AsyncStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; }
export async function selectPrinter(printer: BluetoothPrinter) { await AsyncStorage.setItem(KEY, JSON.stringify(printer)); }
export async function forgetPrinter() { await AsyncStorage.removeItem(KEY); }
export async function openBluetoothSettings() {
  if (Platform.OS === 'android' && Linking.sendIntent) await Linking.sendIntent('android.settings.BLUETOOTH_SETTINGS');
  else await Linking.openSettings();
}

export async function testPrinter(printer: BluetoothPrinter, previewText?: string) {
  if (previewText) return printBluetoothText(printer, previewText);
  const company = await getCompany();
  const center = (value: string) => {
    const clean = value.trim().slice(0, 32);
    return ' '.repeat(Math.max(0, Math.floor((32 - clean.length) / 2))) + clean;
  };
  const designPreview = [
    center(company.company_name || 'NAMA LAUNDRY'),
    center(company.address || 'Alamat laundry'),
    company.phone ? center(company.phone) : '',
    company.receipt_header ? center(company.receipt_header) : '',
    '--------------------------------',
    'INV-XXXXXXXX',
    'TOTAL                 Rp 00.000',
    '--------------------------------',
    company.receipt_footer || 'Terima kasih',
  ].filter(Boolean).join('\n');
  await printBluetoothReceipt(printer, designPreview, company.logo_url);
}

async function connectPrinter(address: string): Promise<void> {
  const native = nativeBridge();
  if (await native.isDeviceConnected(address)) return;
  // RPP02N memakai Bluetooth Classic Serial Port Profile (SPP).
  await native.connectToDevice(address, { connectorType: 'rfcomm', delimiter: '\n', charset: 'ascii' });
}

export async function printBluetoothText(printer: BluetoothPrinter, text: string) {
  assertNativeBuild();
  await ensureBluetoothPermission();
  const address = printer.address || printer.id;
  if (!address) throw new Error('Alamat MAC printer tidak valid.');
  try {
    const native = nativeBridge();
    if (!(await native.isBluetoothEnabled())) throw new Error('Bluetooth belum aktif.');
    await connectPrinter(address);
    // ESC @ reset, ESC t 0 code page, teks CRLF, lalu feed empat baris.
    // Wrapper library mengubah Buffer menjadi Base64 yang diwajibkan native bridge.
    const payload = Buffer.concat([Buffer.from([0x1b, 0x40, 0x1b, 0x74, 0x00]), Buffer.from(text.replace(/\r?\n/g, '\r\n'), 'ascii'), Buffer.from([0x0d, 0x0a, 0x0d, 0x0a, 0x0d, 0x0a, 0x0d, 0x0a])]);
    // Method native menerima Base64, bukan string/Buffer mentah.
    if (!(await native.writeToDevice(address, payload.toString('base64')))) throw new Error('Printer menolak data cetak.');
  } catch (error) {
    throw new Error(`Gagal mencetak ke ${printer.name}. Pastikan printer menyala, sudah dipasangkan, kertas tersedia, dan tidak sedang terhubung ke perangkat lain. ${error instanceof Error ? `(${error.message})` : ''}`.trim());
  }
}

export async function printBluetoothReceipt(printer:BluetoothPrinter,text:string,logoUrl?:string|null){
  assertNativeBuild();
  await ensureBluetoothPermission();
  const address=printer.address||printer.id;
  if(!address)throw new Error('Alamat MAC printer tidak valid.');
  try{
    const native=nativeBridge();
    if(!(await native.isBluetoothEnabled()))throw new Error('Bluetooth belum aktif.');
    await connectPrinter(address);
    const parts:Buffer[]=[Buffer.from([0x1b,0x40,0x1b,0x74,0x00])];
    if(logoUrl&&Platform.OS==='android'&&NativeModules.EscPosImage){
      try{
        const imageBase64=await NativeModules.EscPosImage.rasterize(logoUrl,160);
        parts.push(Buffer.from(imageBase64,'base64'));
      }catch{
        // Logo yang tidak dapat dibaca tidak boleh menggagalkan pencetakan nota.
      }
    }
    parts.push(Buffer.from([0x1b,0x61,0x00]));
    parts.push(Buffer.from(text.replace(/\r?\n/g,'\r\n'),'ascii'));
    parts.push(Buffer.from([0x0d,0x0a,0x0d,0x0a,0x0d,0x0a,0x0d,0x0a]));
    if(!(await native.writeToDevice(address,Buffer.concat(parts).toString('base64'))))throw new Error('Printer menolak data cetak.');
  }catch(error){
    throw new Error(`Gagal mencetak ke ${printer.name}. Pastikan printer menyala, sudah dipasangkan, kertas tersedia, dan tidak sedang terhubung ke perangkat lain. ${error instanceof Error?`(${error.message})`:''}`.trim());
  }
}
