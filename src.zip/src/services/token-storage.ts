import * as SecureStore from 'expo-secure-store';
export const tokenStorage={get:(key:string)=>SecureStore.getItemAsync(key),set:(key:string,value:string)=>SecureStore.setItemAsync(key,value),remove:(key:string)=>SecureStore.deleteItemAsync(key)};
