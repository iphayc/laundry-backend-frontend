import * as Device from 'expo-device';
import {router} from 'expo-router';
import {Platform} from 'react-native';
import Constants from 'expo-constants';
import {createContext,useContext,useEffect,useMemo,useState} from 'react';
import {AuthResult,loginPassword,LoginPayload,loginOtp,confirmDeviceTransfer,DeviceTransferPayload} from '@/api/auth';
import {setSessionExpiredHandler,clearApiSessionExpired} from '@/api/client';
import {tokenStorage} from '@/services/token-storage';
import {api} from '@/api/client';


type User=AuthResult['user'];
type Auth={
  token:string|null;
  user:User|null;
  loading:boolean;
  sessionExpired:boolean;
  login:(p:Pick<LoginPayload,'identity'|'username'|'password'>)=>Promise<void>;
  loginWithOtp:(p:{identity:string;username:string;otp:string})=>Promise<void>;
  transferToThisDevice:(p:DeviceTransferPayload&{otp:string})=>Promise<void>;
  logout:()=>Promise<void>
};
const Context=createContext<Auth|null>(null);

async function deviceData(){
  let id=await tokenStorage.get('device_uuid');
  if(!id){
    id=`${Platform.OS}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    await tokenStorage.set('device_uuid',id);
  }
  return {
    device_uuid:id,
    device_name:Device.deviceName??'Perangkat mobile',
    platform:Platform.OS,
    app_version:Constants.expoConfig?.version??'1.0.0'
  };
}

export function AuthProvider({children}:{children:React.ReactNode}){
  const[token,setToken]=useState<string|null>(null);
  const[user,setUser]=useState<User|null>(null);
  const[loading,setLoading]=useState(true);
  const[sessionExpired,setSessionExpired]=useState(false);

  useEffect(()=>{
    const currentAppVersion=`${Constants.expoConfig?.version??'1.0.0'}:${Constants.nativeBuildVersion??''}`;
    Promise.all([
      tokenStorage.get('access_token'),
      tokenStorage.get('user'),
      tokenStorage.get('session_app_version')
    ]).then(async([savedToken,savedUser,savedVersion])=>{
      // Session lokal dipertahankan lintas hari. Login ulang hanya dipaksa saat
      // build aplikasi berubah atau device lama sudah digantikan/revoked.
      if(savedToken && savedVersion!==currentAppVersion){
        await Promise.all([tokenStorage.remove('access_token'),tokenStorage.remove('refresh_token'),tokenStorage.remove('user'),tokenStorage.remove('session_app_version')]);
        setToken(null);setUser(null);setSessionExpired(true);router.replace('/login');return;
      }
      if(savedToken){
        await tokenStorage.set('session_app_version',currentAppVersion);
        setToken(savedToken);setUser(savedUser?JSON.parse(savedUser):null);
        // Validasi paket setiap aplikasi dibuka. Filter backend akan
        // menurunkan lisensi berbayar yang kedaluwarsa ke FREE dan menolak
        // sesi lama; client kemudian membersihkan sesi dan membuka login.
        void api<unknown>('/license').catch(()=>{
          // Gangguan jaringan/server sementara tidak boleh menghapus sesi.
          // Logout hanya dijalankan oleh session-expired handler untuk 401
          // terminal yang sudah dikonfirmasi backend.
        });
      }else{
        setToken(null);setUser(null);
      }
    }).catch(()=>{setToken(null);setUser(null)}).finally(()=>setLoading(false));
  },[]);

  useEffect(()=>{
    setSessionExpiredHandler(()=>{
      // Refresh token ditolak jika akun/device dicabut atau paket berubah.
      // Pada kondisi tersebut user wajib melakukan login baru.
      void Promise.all([
        tokenStorage.remove('access_token'),
        tokenStorage.remove('refresh_token'),
        tokenStorage.remove('user')
      ]).finally(()=>{
        setSessionExpired(true);
        setToken(null);
        setUser(null);
        router.replace('/login');
      });
    });
    return()=>setSessionExpiredHandler(null);
  },[]);



  async function persist(result:AuthResult){
    clearApiSessionExpired();
    setSessionExpired(false);
    const currentAppVersion=`${Constants.expoConfig?.version??'1.0.0'}:${Constants.nativeBuildVersion??''}`;
    await Promise.all([
      tokenStorage.set('access_token',result.access_token),
      tokenStorage.set('refresh_token',result.refresh_token),
      tokenStorage.set('user',JSON.stringify(result.user)),
      tokenStorage.set('session_app_version',currentAppVersion)
    ]);

    setToken(result.access_token);
    setUser(result.user);
  }

  async function login(payload:Pick<LoginPayload,'identity'|'username'|'password'>){
    await persist(await loginPassword({...payload,...await deviceData()}));
  }

  async function withOtp(payload:{identity:string;username:string;otp:string}){
    await persist(await loginOtp({...payload,...await deviceData()}));
  }

  async function transferToThisDevice(payload:DeviceTransferPayload&{otp:string}){
    await persist(await confirmDeviceTransfer(payload));
  }

  async function logout(){
    await Promise.all([
      tokenStorage.remove('access_token'),
      tokenStorage.remove('refresh_token'),
      tokenStorage.remove('user'),
      tokenStorage.remove('session_app_version')
    ]);
    clearApiSessionExpired();
    setSessionExpired(false);
    setToken(null);
    setUser(null);
    router.replace('/login');
  }

  return <Context.Provider value={useMemo(
    ()=>({token,user,loading,sessionExpired,login,loginWithOtp:withOtp,transferToThisDevice,logout}),
    [token,user,loading,sessionExpired]
  )}>{children}</Context.Provider>;
}

export function useAuth(){
  const context=useContext(Context);
  if(!context) throw new Error('AuthProvider tidak tersedia');
  return context;
}
