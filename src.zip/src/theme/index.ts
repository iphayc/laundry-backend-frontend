export const colors={primary:'#168A72',primaryDark:'#0D5D4D',primarySoft:'#E8F6F2',ink:'#17332D',muted:'#71817D',background:'#F5F8F7',card:'#FFFFFF',line:'#E1EBE8',warning:'#F59E0B',danger:'#DC4C4C',blue:'#3B82F6'};
export const radius={sm:10,md:16,lg:24,pill:999};
export const shadow={shadowColor:'#123D33',shadowOpacity:.08,shadowRadius:18,shadowOffset:{width:0,height:8},elevation:3};
