import {Platform} from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import type {Employee} from "@/api/laundry";

function esc(v:unknown){return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function xml(rows:Employee[]){
  const header=["No","NIK","Nama","Jenis Kelamin","Tanggal Lahir","Status Perkawinan","Agama","Telepon","Email","Gaji","Tunjangan","Uang Makan","Transport","Kehadiran/Hari","Status"];
  const labels:Record<string,string>={MALE:"Laki-laki",FEMALE:"Perempuan",SINGLE:"Belum menikah",MARRIED:"Menikah",ISLAM:"Islam",CATHOLIC:"Katolik",PROTESTANT:"Protestan",HINDU:"Hindu",BUDDHIST:"Budha",CONFUCIAN:"Konghucu",BELIEF:"Kepercayaan"};
  const cell=(v:unknown)=>`<Cell><Data ss:Type="String">${esc(v)}</Data></Cell>`;
  const body=rows.map((r,i)=>`<Row>${[i+1,r.nik,r.name,labels[r.gender]??r.gender,r.birth_date??"",labels[r.marital_status]??r.marital_status,labels[r.religion]??r.religion,r.phone??"",r.email??"",r.salary,r.allowance,r.meal_allowance,r.transport_allowance,r.attendance_rate,Number(r.is_active)?"Aktif":"Inaktif"].map(cell).join("")}</Row>`).join("");
  return `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Pegawai"><Table><Row>${header.map(cell).join("")}</Row>${body}</Table></Worksheet></Workbook>`;
}
export async function downloadEmployees(rows:Employee[]){
 const filename="pegawai-eksis-laundry.xls";
 const content=xml(rows);
 if(Platform.OS==="web"){const blob=new Blob([content],{type:"application/vnd.ms-excel"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url);return;}
 const directory=FileSystem.cacheDirectory??FileSystem.documentDirectory;
 if(!directory)throw new Error("Penyimpanan aplikasi tidak tersedia.");
 const uri=`${directory}${filename}`;
 await FileSystem.writeAsStringAsync(uri,`\uFEFF${content}`,{encoding:FileSystem.EncodingType.UTF8});
 if(!await Sharing.isAvailableAsync())throw new Error("Fitur berbagi file tidak tersedia di perangkat ini.");
 await Sharing.shareAsync(uri,{mimeType:"application/vnd.ms-excel",dialogTitle:"Export Pegawai",UTI:"com.microsoft.excel.xls"});
}
