import { Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { API_URL } from "@/api/client";
import { tokenStorage } from "@/services/token-storage";

export async function downloadFinancialRecap(from: string, to: string, branchId = 0) {
  const token = await tokenStorage.get("access_token");
  const url = `${API_URL}/reports/financial-recap/excel?from=${from}&to=${to}&branch_id=${branchId}`;
  const filename = `rekap-laporan-keuangan-${from}-${to}.xlsx`;
  if (Platform.OS === "web") {
    const response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!response.ok) throw new Error("File laporan keuangan gagal diunduh.");
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(objectUrl);
    return;
  }
  const target = `${FileSystem.documentDirectory}${filename}`;
  const result = await FileSystem.downloadAsync(url, target, { headers: { Authorization: `Bearer ${token}` } });
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(result.uri, { mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", dialogTitle: "Ekspor Laporan Keuangan" });
}
