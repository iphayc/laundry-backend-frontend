import {Platform} from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import {API_URL} from '@/api/client';
import {tokenStorage} from '@/services/token-storage';

export async function downloadInventoryHistory(params:{from:string;to:string;branch_id:number;q:string}){
  const token=await tokenStorage.get('access_token');
  const query=`from=${encodeURIComponent(params.from)}&to=${encodeURIComponent(params.to)}&branch_id=${params.branch_id}&q=${encodeURIComponent(params.q)}`;
  const url=`${API_URL}/inventory/history/excel?${query}`;
  const filename=`history-inventory-${params.from}-${params.to}.xlsx`;
  if(Platform.OS==='web'){
    const response=await fetch(url,{headers:{Authorization:`Bearer ${token}`}});
    if(!response.ok)throw new Error('Export history inventory gagal.');
    const blob=await response.blob(),objectUrl=URL.createObjectURL(blob),anchor=document.createElement('a');
    anchor.href=objectUrl;anchor.download=filename;anchor.click();URL.revokeObjectURL(objectUrl);return;
  }
  const target=`${FileSystem.documentDirectory}${filename}`;
  const result=await FileSystem.downloadAsync(url,target,{headers:{Authorization:`Bearer ${token}`}});
  if(result.status<200||result.status>=300)throw new Error('Export history inventory gagal.');
  if(await Sharing.isAvailableAsync())await Sharing.shareAsync(result.uri,{mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',dialogTitle:'Export History Inventory'});
}
