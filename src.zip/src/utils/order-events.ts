type Listener = () => void;

const listeners = new Set<Listener>();

/** Beri tahu komponen di luar halaman Pesanan bahwa ringkasan order berubah. */
export function notifyOrdersChanged() {
  listeners.forEach((listener) => listener());
}

export function subscribeOrdersChanged(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
