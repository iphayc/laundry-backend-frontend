import { Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";

type ProductExportRow = {
  id: number;
  name: string;
  category_name?: string;
  category_code?: string;
  unit?: string;
  price: number;
};

function esc(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function xmlCell(value: unknown, type: "String" | "Number" = "String") {
  return `<Cell><Data ss:Type="${type}">${esc(value)}</Data></Cell>`;
}

export async function exportProductsExcel(rows: ProductExportRow[]) {
  const header = [
    xmlCell("No"),
    xmlCell("Nama Produk/Layanan"),
    xmlCell("Kategori"),
    xmlCell("Kode Kategori"),
    xmlCell("Satuan"),
    xmlCell("Harga", "Number"),
  ].join("");

  const body = rows.map((p, index) => [
    xmlCell(index + 1, "Number"),
    xmlCell(p.name),
    xmlCell(p.category_name ?? ""),
    xmlCell(p.category_code ?? ""),
    xmlCell(p.unit ?? ""),
    xmlCell(Number(p.price) || 0, "Number"),
  ].join("")).map(row => `<Row>${row}</Row>`).join("");

  const xml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="Produk &amp; Layanan">
  <Table>
   <Row>${header}</Row>
   ${body}
  </Table>
 </Worksheet>
</Workbook>`;

  const filename = `produk-layanan-eksis-laundry.xls`;

  if (Platform.OS === "web") {
    const blob = new Blob([xml], { type: "application/vnd.ms-excel" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
    return;
  }

  const directory = FileSystem.cacheDirectory ?? FileSystem.documentDirectory;
  if (!directory) throw new Error("Penyimpanan aplikasi tidak tersedia.");
  const uri = `${directory}${filename}`;
  await FileSystem.writeAsStringAsync(uri, `\uFEFF${xml}`, {encoding: FileSystem.EncodingType.UTF8});
  if (!await Sharing.isAvailableAsync()) throw new Error("Fitur berbagi file tidak tersedia di perangkat ini.");
  await Sharing.shareAsync(uri, {
    mimeType: "application/vnd.ms-excel",
    dialogTitle: "Export Produk & Layanan",
    UTI: "com.microsoft.excel.xls",
  });
}
