import * as Print from "expo-print";
import * as Linking from "expo-linking";
import { Platform } from "react-native";
import { Company } from "@/api/company";
import { Expense, getCustomerWhatsAppStatus, getWhatsAppDeliveryConfiguration, Order } from "@/api/laundry";
import { api } from "@/api/client";
import { printBluetoothReceipt, printBluetoothText, selectedPrinter } from "@/services/bluetooth-printer";

function esc(value:string){return value.replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]!))}
const money=(value:number)=>{const n=Number(value||0);const s=n.toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:2});return `Rp ${s}`};
const serviceStatus=(status:string)=>({RECEIVED:"Terima",PROCESSING:"Proses",READY:"Selesai",COMPLETED:"Diambil",CANCELLED:"Dihapus"} as Record<string,string>)[status]??status;
let nativePrintInProgress=false;
export function receiptHtml(company:Partial<Company>,paper:"A4"|"RECEIPT"="A4",order?:Order){const logo=company.logo_url?`<img src="${esc(company.logo_url)}" style="width:${paper==="A4"?72:48}px;height:${paper==="A4"?72:48}px;object-fit:contain;margin-right:14px">`:"";const number=order?.invoice_number??"INV-XXXXXXXX",customer=order?.customer_name??"Nama pelanggan",service=order?.service_name??"Layanan",subtotal=Number(order?.subtotal??0),discount=Number(order?.discount_amount??0),total=Number(order?.total??0);return `<html><head><style>@page{size:${paper==="A4"?"A4":"80mm auto"};margin:${paper==="A4"?"20mm":"5mm"}}body{font-family:Arial;color:#172b27;font-size:${paper==="A4"?"13px":"11px"}}.head{display:flex;align-items:center}.brand{font-size:20px;font-weight:800}.center{text-align:center}.line{border-top:1px dashed #555;margin:12px 0}.row{display:flex;justify-content:space-between;gap:12px;margin:6px 0}</style></head><body><div class="head">${logo}<div><div class="brand">${esc(company.company_name??"Eksis Laundry")}</div><div>${esc(company.address??"")}</div><div>${esc(company.phone??"")}</div></div></div><div class="line"></div><div class="center">${esc(company.receipt_header??"")}</div><div class="line"></div><div><b>${esc(number)}</b></div><div class="row"><span>Tanggal</span><span>${esc(order?.created_at??new Date().toLocaleString("id-ID"))}</span></div><div class="row"><span>Pelanggan</span><span>${esc(customer)}</span></div><div class="row"><span>Total barang</span><span>${Number(order?.item_count??0)}</span></div><div class="row"><span>Layanan</span><span>${esc(service)}</span></div><div class="line"></div><div class="row"><span>Harga</span><span>${money(subtotal)}</span></div>${discount?`<div class="row"><span>Diskon</span><span>-${money(discount)}</span></div>`:""}<div class="row"><b>TOTAL</b><b>${money(total)}</b></div><div class="row"><span>Pembayaran</span><span>${esc(order?.payment_method??"-")}</span></div><div class="row"><span>Estimasi</span><span>${Number(order?.estimated_days??0)} hari</span></div><div class="row"><span>Status layanan</span><span>${esc(serviceStatus(String(order?.status??"")))}</span></div>${order?.public_note_url?`<div class="row"><span>Nota online</span><span>${esc(order.public_note_url)}</span></div>`:""}<div class="line"></div><div class="center">${esc(company.receipt_footer??"")}</div></body></html>`}
export function orderPdfHtml(company:Partial<Company>,order:Order){const logo=company.logo_url?`<img src="${esc(company.logo_url)}" style="width:82px;height:82px;object-fit:contain">`:"";const status=({RECEIVED:"Diterima",PROCESSING:"Diproses",READY:"Selesai",COMPLETED:"Sudah diambil"} as Record<string,string>)[order.status]??order.status;return `<html><head><meta charset="utf-8"><style>@page{size:A4;margin:18mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#18332d;font-size:13px}.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #168a72;padding-bottom:18px}.brand{display:flex;gap:16px;align-items:center}.brand h1{font-size:23px;margin:0 0 6px}.muted{color:#64756f;line-height:1.5}.document{text-align:right}.document h2{margin:0;color:#168a72;font-size:25px}.number{font-weight:800;font-size:15px;margin-top:7px}.info{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:24px 0}.box{border:1px solid #d9e8e3;border-radius:10px;padding:15px}.box-title{font-size:11px;text-transform:uppercase;color:#168a72;font-weight:800;margin-bottom:9px}.info-row{display:flex;justify-content:space-between;gap:15px;margin:7px 0}.label{color:#64756f}.value{text-align:right;font-weight:700}.service{width:100%;border-collapse:collapse;margin-top:16px}.service th{background:#168a72;color:#fff;text-align:left;padding:11px}.service td{border-bottom:1px solid #d9e8e3;padding:12px}.service .right{text-align:right}.totals{width:330px;margin:18px 0 0 auto}.total-row{display:flex;justify-content:space-between;padding:8px 4px}.grand{font-size:18px;font-weight:900;color:#168a72;border-top:2px solid #168a72;margin-top:6px;padding-top:12px}.notes{margin-top:32px;border-top:1px dashed #9fb4ad;padding-top:18px}.footer{text-align:center;color:#64756f;margin-top:38px}</style></head><body><div class="header"><div class="brand">${logo}<div><h1>${esc(company.company_name??"Eksis Laundry")}</h1><div class="muted">${esc(company.address??"")}<br>${esc(company.phone??"")} · ${esc(company.email??"")}</div></div></div><div class="document"><h2>NOTA PESANAN</h2><div class="number">${esc(order.invoice_number)}</div><div class="muted">Status layanan: ${esc(status)}</div>${order.public_note_url?`<div class="muted" style="margin-top:5px;word-break:break-all">Nota online: ${esc(order.public_note_url)}</div>`:""}</div></div><div class="info"><div class="box"><div class="box-title">Informasi Pelanggan</div><div class="info-row"><span class="label">Nama</span><span class="value">${esc(order.customer_name??"-")}</span></div><div class="info-row"><span class="label">Telepon</span><span class="value">${esc(order.customer_phone??"-")}</span></div><div class="info-row"><span class="label">Email</span><span class="value">${esc(order.customer_email??"-")}</span></div></div><div class="box"><div class="box-title">Informasi Pesanan</div><div class="info-row"><span class="label">Tanggal</span><span class="value">${esc(order.created_at??"-")}</span></div><div class="info-row"><span class="label">Estimasi</span><span class="value">${Number(order.estimated_days??0)} hari</span></div><div class="info-row"><span class="label">Pembayaran</span><span class="value">${esc(order.payment_method??"-")}</span></div></div></div><table class="service"><thead><tr><th>Layanan / Produk</th><th class="right">Jumlah Barang</th><th class="right">Harga</th></tr></thead><tbody><tr><td>${esc(order.service_name??"-")}</td><td class="right">${Number(order.item_count??0)}</td><td class="right">${money(Number(order.subtotal??0))}</td></tr></tbody></table><div class="totals"><div class="total-row"><span>Subtotal</span><b>${money(Number(order.subtotal??0))}</b></div><div class="total-row"><span>Diskon</span><b>-${money(Number(order.discount_amount??0))}</b></div><div class="total-row grand"><span>Total</span><span>${money(Number(order.total??0))}</span></div></div>${order.notes?`<div class="notes"><b>Catatan:</b><br>${esc(order.notes)}</div>`:""}<div class="footer">${esc(company.receipt_footer??"Terima kasih telah menggunakan layanan kami.")}</div></body></html>`}
export async function printPdf(company:Partial<Company>,order?:Order){if(!order)throw new Error("Data pesanan belum dipilih.");const dp=Number(order.dp_amount??0),remaining=Math.max(0,Number(order.total??0)-Number(order.paid_amount??0)),status=order.payment_status==="UNPAID"?"Belum Bayar":order.payment_status==="PARTIAL"?"DP":"Lunas",method={CASH:"Cash",BANK_TRANSFER:"Transfer Bank",QRIS:"QRIS"}[order.payment_method]??order.payment_method,payment=`<div class="total-row"><span>DP</span><b>${money(dp)}</b></div><div class="total-row" style="color:#b45309;font-weight:900;border-top:1px dashed #9fb4ad"><span>Sisa pembayaran</span><b>${money(remaining)}</b></div><div class="total-row"><span>Status</span><b>${status}</b></div>${order.payment_status!=="UNPAID"?`<div class="total-row"><span>Metode bayar</span><b>${method}</b></div>`:""}${order.status==="COMPLETED"&&dp>0?`<div class="total-row"><span>Nilai bayar</span><b>${money(Math.max(0,Number(order.total)-dp))}</b></div>`:""}`;const html=orderPdfHtml(company,order).replace(/(<div class="total-row grand">[\s\S]*?<\/div>)(<\/div>)/,"$1"+payment+"$2");if(Platform.OS==="web"){const preview=window.open("","_blank");if(!preview)throw new Error("Popup pratinjau diblokir browser. Izinkan popup lalu coba kembali.");preview.document.write(html.replace("</body>","<script>window.onload=function(){setTimeout(function(){window.print()},250)}</script></body>"));preview.document.close();return}if(nativePrintInProgress)throw new Error("Dialog print sedang dibuka. Selesaikan atau tutup dialog sebelumnya.");nativePrintInProgress=true;try{await Print.printAsync({html})}finally{nativePrintInProgress=false}}
export function receiptText(company:Partial<Company>,order?:Order){
  const width=32,line="-".repeat(width);
  const center=(value:string)=>{const clean=value.trim().slice(0,width);return " ".repeat(Math.max(0,Math.floor((width-clean.length)/2)))+clean};
  const centerLines=(value:string)=>{const words=value.trim().split(/\s+/).filter(Boolean),lines:string[]=[];let current="";for(const word of words){const next=current?`${current} ${word}`:word;if(next.length<=width)current=next;else{if(current)lines.push(center(current));current=word}}if(current)lines.push(center(current));return lines};
  const amount=(value:number)=>Number(value||0).toLocaleString("id-ID",{minimumFractionDigits:0,maximumFractionDigits:0});
  const field=(label:string,value:string)=>`${label.padEnd(13).slice(0,13)}: ${value}`;
  const right=(left:string,value:string)=>left.length+value.length>=width?`${left}\n${value.padStart(width)}`:`${left}${" ".repeat(width-left.length-value.length)}${value}`;
  const receiptDate=(value?:string|null,withTime=false)=>{if(!value)return "-";const match=/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(value);if(!match)return value;const date=`${match[3]}-${match[2]}-${match[1]}`;return withTime&&match[4]?`${date} ${match[4]}:${match[5]}:${match[6]??"00"}`:date};
  const status=({RECEIVED:"Diterima",PROCESSING:"Diproses",READY:"Selesai",COMPLETED:"Diambil",DELETED:"Dihapus",CANCELLED:"Dihapus"} as Record<string,string>)[String(order?.status??"")]??String(order?.status??"-");
  const method=({CASH:"Cash",BANK_TRANSFER:"Transfer",QRIS:"QRIS"} as Record<string,string>)[String(order?.payment_method??"")]??String(order?.payment_method??"-");
  const subtotal=Number(order?.subtotal??0),discount=Number(order?.discount_amount??0),dp=Number(order?.dp_amount??0),totalAfterDp=Math.max(0,subtotal-discount-dp),paid=Number(order?.paid_amount??0),remaining=Math.max(0,Number(order?.outstanding_amount??(Number(order?.total??0)-paid)));
  const address=order?.branch_address||order?.main_branch_address||company.address||"";
  const phone=order?.branch_phone||order?.main_branch_phone||company.phone||"";
  const items=order?.items?.length?order.items:[{id:0,product_id:0,product_name:order?.service_name??"Layanan",unit:"",qty:1,price:subtotal,subtotal}];
  const rows=[...centerLines(company.company_name??"EKSIS LAUNDRY"),...centerLines(address),...centerLines(phone),...(company.receipt_header?centerLines(company.receipt_header):[]),line,order?.invoice_number??"INV-XXXXXXXX",field("Tanggal",receiptDate(order?.created_at,true)),field("Pelanggan",order?.customer_name??"-"),field("Telp",order?.customer_phone??"-"),field("Status",status),field("Estimasi",`${Number(order?.estimated_days??0).toLocaleString("id-ID")} hari/${receiptDate(order?.due_at)}`),field("Kasir",order?.cashier_name??"-"),field("Status Bayar",order?.payment_status==="UNPAID"?"Belum Bayar":"Bayar"),line,"Layanan"];
  for(const item of items){rows.push(item.product_name||"Layanan");rows.push(right(`${Number(item.qty).toFixed(2)} x ${amount(Number(item.price))}`,amount(Number(item.subtotal))));}
  rows.push(line,field("Jumlah Barang",Number(order?.item_count??0).toLocaleString("id-ID")),right("Sub Total",amount(subtotal)));
  if(discount>0)rows.push(right("Diskon",`-${amount(discount)}`));
  if(dp>0)rows.push(right("DP",`-${amount(dp)}`));
  rows.push(right("Total",amount(totalAfterDp)),line,"Metode Pembayaran",method,right("Jumlah Bayar",amount(paid)),right("Sisa Pembayaran",amount(remaining)));
  const body=rows.filter(value=>value!=="").join("\n");
  const footer=(company.receipt_footer??"Terima kasih").trim();
  // Dua newline menghasilkan tepat satu baris kosong sebelum footer di ESC/POS.
  return footer?`${body}\n\n${footer}`:body;
}
export async function printReceipt(company:Partial<Company>,order?:Order){if(!order)throw new Error("Data pesanan belum dipilih.");const printer=await selectedPrinter();if(!printer)throw new Error('Belum ada printer Bluetooth yang dipilih. Buka Pengaturan > Printer & Struk, hubungkan printer, lalu coba kembali.');await printBluetoothReceipt(printer,receiptText(company,order),company.logo_url)}
export async function emailReceipt(_company:Partial<Company>,order?:Order){if(!order)throw new Error("Data pesanan belum dipilih.");await api<{email:string}>(`/orders/${order.id}/email`,{method:"POST",body:JSON.stringify({})})}
export function whatsappReceiptText(company:Partial<Company>,order:Order){
  const line="----------------";
  const dp=Number(order.dp_amount??0);
  const total=Number(order.total??0);
  const paid=Number(order.paid_amount??0);
  const outstanding=Math.max(0,Number(order.outstanding_amount??(total-paid)));
  const status=order.payment_status==="UNPAID"?"Belum Bayar":order.payment_status==="PARTIAL"?"DP":"Lunas";

  return [
    `*${company.company_name??"Eksis Laundry"}*`,
    company.address??"",
    company.phone?`📞 ${company.phone}`:"",
    "",
    line,
    `🧾 *${order.invoice_number}*`,
    `👤 Pelanggan : ${order.customer_name}`,
    `📱 WhatsApp : ${order.customer_phone??"-"}`,
    `🧺 Layanan : ${order.service_name}`,
    `📦 Jumlah : ${Number(order.item_count??0)}`,
    `💰 Subtotal : ${money(Number(order.subtotal??0))}`,
    `🏷️ Diskon : -${money(Number(order.discount_amount??0))}`,
    `💵 Total : *${money(total)}*`,
    dp>0?`💳 DP : ${money(dp)}`:"",
    `💳 Sisa Pelunasan : ${money(outstanding)}`,
    `📌 Status layanan : ${serviceStatus(String(order.status??""))}`,
    `📅 Estimasi : ${Number(order.estimated_days??0)} hari`,
    line,
    order.notes?`📝 Catatan : ${order.notes}`:"",
    "",
    company.receipt_footer??"Terima kasih telah menggunakan layanan kami.",
    order.public_note_url?`\n🔗 Nota online : ${order.public_note_url}`:""
  ].filter(Boolean).join("\n");
}

function moveOnlineNoteToBottom(message:string,fallbackUrl?:string){
  let onlineNote="";
  const lines=message.split(/\r?\n/).filter(line=>{
    if(line.includes("Nota online")){onlineNote=line.trim();return false}
    return true;
  });
  while(lines.length&&!lines[lines.length-1].trim())lines.pop();
  if(!onlineNote&&fallbackUrl)onlineNote=`🔗 Nota online : ${fallbackUrl}`;
  return onlineNote?`${lines.join("\n")}\n\n${onlineNote}`:lines.join("\n");
}

export async function whatsappReceipt(company:Partial<Company>,order?:Order){
  if(!order) throw new Error("Data pesanan belum dipilih.");

  const config=await getWhatsAppDeliveryConfiguration();

  // Jika gateway WhatsApp Linked Device sedang TERHUBUNG, gunakan gateway
  // meskipun konfigurasi delivery lama masih tersimpan sebagai APP.
  // Ini mencegah struk kembali membuka aplikasi WhatsApp perangkat.
  let useLinked = config.method === "LINKED";
  if (!useLinked) {
    try {
      const waStatus = await getCustomerWhatsAppStatus();
      useLinked = !!waStatus.connected;
    } catch {
      // Jika status gateway tidak dapat dibaca, fallback ke konfigurasi.
    }
  }

  if(useLinked){
    // Format untuk Linked Device dikendalikan backend/gateway agar sama dengan
    // template WhatsApp pusat. Mobile tidak membuat format kedua untuk jalur ini.
    await api<{phone:string}>(`/orders/${order.id}/whatsapp`,{
      method:"POST",
      body:JSON.stringify({})
    });
    return;
  }

  const preview=await api<{phone:string;message:string}>(`/orders/${order.id}/whatsapp-preview`,{
    method:"GET",
  });

  const phone=(preview.phone??order.customer_phone??"").replace(/\D/g,"").replace(/^0/,"62");
  if(!phone) throw new Error("Pelanggan belum memiliki nomor WhatsApp.");

  const text=moveOnlineNoteToBottom(preview.message,order.public_note_url);
  if(!text) throw new Error("Format struk WhatsApp belum tersedia dari server.");

  await Linking.openURL(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`);
}

export function labelHtml(company:Partial<Company>,order:Order){
  return `<html><head><meta charset="utf-8"><style>@page{size:80mm auto;margin:5mm}body{font-family:Arial;font-size:12px;color:#111}.center{text-align:center}.line{border-top:1px dashed #555;margin:9px 0}.title{font-size:16px;font-weight:900}.row{display:flex;justify-content:space-between;gap:8px;margin:5px 0}</style></head><body>
  <div class="center"><div class="title">${esc(company.company_name??"EKSIS LAUNDRY")}</div><div>${esc(order.invoice_number)}</div></div>
  <div class="line"></div>
  <div class="row"><b>Tanggal</b><span>${esc(order.created_at??"-")}</span></div>
  <div class="row"><b>Pelanggan</b><span>${esc(order.customer_name??"-")}</span></div>
  <div class="row"><b>Layanan</b><span>${esc(order.service_name??"-")}</span></div>
  <div class="row"><b>Jumlah barang</b><span>${Number(order.item_count??0)}</span></div>
  <div class="row"><b>Total</b><b>${money(Number(order.total??0))}</b></div>
  <div class="line"></div>
  </body></html>`
}
export function labelText(company:Partial<Company>,order:Order){
  const width=32,line="-".repeat(width);
  const center=(value:string)=>{const clean=value.trim().slice(0,width);return " ".repeat(Math.max(0,Math.floor((width-clean.length)/2)))+clean};
  const centerLines=(value:string)=>{const words=value.trim().split(/\s+/).filter(Boolean),lines:string[]=[];let current="";for(const word of words){const next=current?`${current} ${word}`:word;if(next.length<=width)current=next;else{if(current)lines.push(center(current));current=word}}if(current)lines.push(center(current));return lines};
  const field=(label:string,value:string)=>`${label.padEnd(13).slice(0,13)}: ${value}`;
  const indo=(value?:string|null,withTime=false)=>{if(!value)return "-";const match=/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(value);if(!match)return value;const months=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agt","Sep","Okt","Nov","Des"];const date=`${Number(match[3])} ${months[Number(match[2])-1]} ${match[1]}`;return withTime&&match[4]?`${date} ${match[4]}:${match[5]}:${match[6]??"00"}`:date};
  const status=({RECEIVED:"Diterima",PROCESSING:"Diproses",READY:"Selesai",COMPLETED:"Diambil",DELETED:"Dihapus",CANCELLED:"Dihapus"} as Record<string,string>)[String(order.status??"")]??String(order.status??"-");
  const address=order.branch_address||order.main_branch_address||company.address||"";
  const phone=order.branch_phone||order.main_branch_phone||company.phone||"";
  const items=order.items?.length?order.items:[{id:0,product_id:0,product_name:order.service_name??"Layanan",unit:"",qty:1,price:0,subtotal:0}];
  const rows=[...centerLines(company.company_name??"EKSIS LAUNDRY"),...centerLines(address),...centerLines(phone),line,order.invoice_number,field("Tanggal",indo(order.created_at,true)),field("Pelanggan",order.customer_name??"-"),field("Telp",order.customer_phone??"-"),field("Status",status),field("Estimasi",`${Number(order.estimated_days??0).toLocaleString("id-ID")} hari - ${indo(order.due_at)}`),field("Kasir",order.cashier_name??"-"),line,"Layanan"];
  for(const item of items)rows.push(`${item.product_name||"Layanan"} (${Number(item.qty).toFixed(2)})`);
  rows.push(line,field("Jumlah Barang",Number(order.item_count??0).toLocaleString("id-ID")));
  return rows.join("\n")
}
export async function printLabel(company:Partial<Company>,order?:Order){
  if(!order)throw new Error("Data pesanan belum dipilih.");
  const printer=await selectedPrinter();
  if(!printer)throw new Error("Belum ada printer Bluetooth yang dipilih. Buka Pengaturan > Printer & Struk terlebih dahulu.");
  await printBluetoothReceipt(printer,labelText(company,order),company.logo_url);
}
export function salaryReceiptHtml(company:Partial<Company>,expense:Expense,paper:"A4"|"RECEIPT"="A4"){const logo=company.logo_url?`<img src="${esc(company.logo_url)}" style="width:${paper==="A4"?72:48}px;height:${paper==="A4"?72:48}px;object-fit:contain;margin-right:14px">`:"";const row=(label:string,value:number,minus=false)=>`<div class="row"><span>${label}</span><span>${minus?"-":""}${money(value)}</span></div>`;return `<html><head><meta charset="utf-8"><style>@page{size:${paper==="A4"?"A4":"80mm auto"};margin:${paper==="A4"?"18mm":"5mm"}}body{font-family:Arial;color:#172b27;font-size:${paper==="A4"?"13px":"11px"}}.head{display:flex;align-items:center;border-bottom:3px solid #168a72;padding-bottom:14px}.brand{font-size:20px;font-weight:900}.title{text-align:center;font-size:20px;font-weight:900;margin:22px 0 4px;color:#168a72}.center{text-align:center}.line{border-top:1px dashed #64756f;margin:12px 0}.row{display:flex;justify-content:space-between;gap:12px;margin:7px 0}.total{font-size:17px;font-weight:900;color:#168a72;border-top:2px solid #168a72;padding-top:11px}.muted{color:#64756f}</style></head><body><div class="head">${logo}<div><div class="brand">${esc(company.company_name??"Eksis Laundry")}</div><div>${esc(company.address??"")}</div><div>${esc(company.phone??"")}</div></div></div><div class="title">STRUK GAJI</div><div class="center muted">PAY-${String(expense.id).padStart(6,"0")}</div><div class="line"></div><div class="row"><span>Nama pegawai</span><b>${esc(expense.employee_name??"-")}</b></div><div class="row"><span>NIK</span><span>${esc(expense.employee_nik??"-")}</span></div><div class="row"><span>Periode</span><span>${esc(expense.payroll_period??"-")}</span></div><div class="row"><span>Tanggal proses</span><span>${esc(expense.expense_date)}</span></div><div class="line"></div>${row("Gaji pokok",Number(expense.base_salary??0))}${row("Tunjangan",Number(expense.allowance??0))}${row("Uang makan",Number(expense.meal_allowance??0))}${row("Transport",Number(expense.transport_allowance??0))}<div class="row"><span>Kehadiran (${Number(expense.attendance_days??0)} hari × ${money(Number(expense.attendance_rate??0))})</span><span>${money(Number(expense.attendance_allowance??0))}</span></div>${row("Potongan",Number(expense.deduction??0),true)}${row("Bonus",Number(expense.bonus??0))}${row("THR",Number(expense.thr??0))}<div class="row total"><span>GAJI DITERIMA</span><span>${money(Number(expense.total_amount))}</span></div>${expense.notes?`<div class="line"></div><div>Catatan: ${esc(expense.notes)}</div>`:""}<div class="line"></div><div class="center">${esc(company.receipt_footer??"Struk ini merupakan bukti pembayaran gaji.")}</div></body></html>`}
export async function printSalaryPdf(company:Partial<Company>,expense:Expense){await Print.printAsync({html:salaryReceiptHtml(company,expense,"A4")})}
export function salaryReceiptText(company:Partial<Company>,x:Expense){const line="-".repeat(32),m=(v:number)=>money(Number(v));return [company.company_name??"EKSIS LAUNDRY",company.address??"",line,"STRUK GAJI",`PAY-${String(x.id).padStart(6,"0")}`,line,`Pegawai : ${x.employee_name??"-"}`,`NIK     : ${x.employee_nik??"-"}`,`Periode : ${x.payroll_period??"-"}`,`Tanggal : ${x.expense_date}`,line,`Gaji    : ${m(x.base_salary??0)}`,`Tunjangan: ${m(x.allowance??0)}`,`Makan   : ${m(x.meal_allowance??0)}`,`Transport: ${m(x.transport_allowance??0)}`,`Hadir ${Number(x.attendance_days??0)} hari: ${m(x.attendance_allowance??0)}`,`Potongan: -${m(x.deduction??0)}`,`Bonus   : ${m(x.bonus??0)}`,`THR     : ${m(x.thr??0)}`,line,`DITERIMA: ${m(x.total_amount)}`,line,company.receipt_footer??"Bukti pembayaran gaji","",""].join("\n")}
export async function printSalaryReceipt(company:Partial<Company>,expense:Expense){const printer=await selectedPrinter();if(!printer)throw new Error("Belum ada printer Bluetooth yang dipilih. Buka Pengaturan > Printer & Struk terlebih dahulu.");await printBluetoothText(printer,salaryReceiptText(company,expense))}
export async function whatsappReminder(company:Partial<Company>,order:Order){
  const config=await getWhatsAppDeliveryConfiguration();
  let useLinked = config.method === "LINKED";
  if (!useLinked) {
    try {
      const waStatus = await getCustomerWhatsAppStatus();
      useLinked = !!waStatus.connected;
    } catch {}
  }
  if(useLinked){await api<{phone:string}>(`/orders/${order.id}/reminder`,{method:"POST",body:"{}"});return}const phone=(order.customer_phone??"").replace(/\D/g,"").replace(/^0/,"62");if(!phone)throw new Error("Pelanggan belum memiliki nomor WhatsApp.");const text=`Halo *${order.customer_name}* 👋\n\nLaundry Anda dengan nomor order *${order.invoice_number}* sudah selesai dan siap diambil. 🧺✨\n\n📦 *Detail Order*\n• No. Order: ${order.invoice_number}\n• Layanan: ${order.service_name}\n• Total: ${money(Number(order.total))}\n• Selesai: ${order.due_at}\n\nLaundry Anda masih tersimpan di outlet kami dan belum diambil.\n\nSilakan melakukan pengambilan pada jam operasional outlet.\n\n📍 *${company.company_name??"Eksis Laundry"}*\n${company.address??""}`;await Linking.openURL(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`)}
