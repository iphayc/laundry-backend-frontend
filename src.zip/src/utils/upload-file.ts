import { Platform } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import { File } from 'expo-file-system';

const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp'] as const;
const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
type ImageExtension = (typeof ALLOWED_EXTENSIONS)[number];

function extensionFromUri(uri: string): ImageExtension {
  const clean = decodeURIComponent(uri.split('?')[0]).toLowerCase();
  const matched = clean.match(/\.([a-z0-9]+)$/)?.[1];
  return ALLOWED_EXTENSIONS.includes(matched as ImageExtension)
    ? (matched as ImageExtension)
    : 'jpg';
}

function mimeFromExtension(extension: ImageExtension) {
  if (extension === 'png') return 'image/png';
  if (extension === 'webp') return 'image/webp';
  return 'image/jpeg';
}

export function imageMeta(uri: string, baseName: string) {
  const extension = extensionFromUri(uri);
  const sanitizedBaseName = baseName.replace(/[^a-zA-Z0-9_-]/g, '_');
  return {
    extension,
    name: `${sanitizedBaseName}_${Date.now()}.${extension}`,
    type: mimeFromExtension(extension),
  };
}

/** Salin URI Image Picker (content:// atau file://) ke cache aplikasi. */
export async function normalizeUri(
  uri: string,
  extension = extensionFromUri(uri)
): Promise<string> {
  if (Platform.OS === 'web') return uri;
  if (!uri) throw new Error('Lokasi file gambar tidak tersedia. Pilih gambar kembali.');
  if (!FileSystem.cacheDirectory) throw new Error('Direktori cache aplikasi tidak tersedia.');

  const destination = `${FileSystem.cacheDirectory}upload_${Date.now()}_${Math.random()
    .toString(36)
    .slice(2)}.${extension}`;

  try {
    await FileSystem.copyAsync({ from: uri, to: destination });
    const info = await FileSystem.getInfoAsync(destination);
    if (!info.exists || info.isDirectory) throw new Error('File hasil pilihan tidak dapat dibaca.');
    if (typeof info.size === 'number' && info.size > MAX_IMAGE_BYTES) {
      await FileSystem.deleteAsync(destination, { idempotent: true }).catch(() => undefined);
      throw new Error('Ukuran gambar melebihi 2 MB. Pilih atau kompres gambar yang lebih kecil.');
    }
    return destination;
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message.includes('2 MB') || error.message.includes('tidak dapat dibaca'))
    ) {
      throw error;
    }
    throw new Error(
      `Gambar tidak dapat dipersiapkan untuk upload di Android. Pilih gambar kembali.${
        error instanceof Error ? ` (${error.message})` : ''
      }`
    );
  }
}

export async function buildImageForm(
  fieldName: string,
  uri: string,
  baseName: string
): Promise<FormData> {
  const form = new FormData();
  const meta = imageMeta(uri, baseName);

  if (Platform.OS === 'web') {
    const response = await fetch(uri);
    if (!response.ok) throw new Error('Gambar yang dipilih tidak dapat dibaca.');
    const blob = await response.blob();
    if (blob.size > MAX_IMAGE_BYTES) throw new Error('Ukuran gambar melebihi 2 MB.');
    form.append(fieldName, blob, meta.name);
    return form;
  }

  const localUri = await normalizeUri(uri, meta.extension);
  // React Native 0.86 tidak lagi menerima object { uri, name, type }
  // sebagai FormDataPart. Ubah file lokal menjadi Blob standar agar request
  // multipart dapat diserialisasi sebelum dikirim ke server.
  const file = new File(localUri);
  if (!file.size) throw new Error('File gambar yang dipilih kosong atau tidak dapat dibaca.');
  if (file.size > MAX_IMAGE_BYTES) throw new Error('Ukuran gambar melebihi 2 MB.');
  form.append(fieldName, file, meta.name);
  return form;
}

/** Multipart file umum untuk bukti pembayaran/dokumen pada Android RN 0.86. */
export async function buildFileForm(
  fieldName: string,
  uri: string,
  originalName: string,
  mimeType: string,
  maxBytes = 5 * 1024 * 1024
): Promise<FormData> {
  const allowedMime = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
  const safeName = (originalName || `bukti_${Date.now()}`).replace(/[^a-zA-Z0-9._-]/g, '_');
  const namedExtension = safeName.toLowerCase().match(/\.([a-z0-9]+)$/)?.[1];
  const normalizedMime = allowedMime.includes(mimeType) ? mimeType
    : namedExtension === 'pdf' ? 'application/pdf'
    : namedExtension === 'png' ? 'image/png'
    : namedExtension === 'webp' ? 'image/webp'
    : namedExtension === 'jpg' || namedExtension === 'jpeg' ? 'image/jpeg'
    : mimeType;
  if (!allowedMime.includes(normalizedMime)) {
    throw new Error('Bukti harus JPG, PNG, WebP, atau PDF maksimal 5 MB.');
  }
  const form = new FormData();

  if (Platform.OS === 'web') {
    const response = await fetch(uri);
    if (!response.ok) throw new Error('File bukti pembayaran tidak dapat dibaca.');
    const blob = await response.blob();
    if (!blob.size) throw new Error('File bukti pembayaran kosong.');
    if (blob.size > maxBytes) throw new Error('Ukuran bukti pembayaran melebihi 5 MB.');
    form.append(fieldName, blob, safeName);
    return form;
  }

  if (!FileSystem.cacheDirectory) throw new Error('Direktori cache aplikasi tidak tersedia.');
  const extension = namedExtension
    ?? (normalizedMime === 'application/pdf' ? 'pdf' : normalizedMime === 'image/png' ? 'png' : normalizedMime === 'image/webp' ? 'webp' : 'jpg');
  const localUri = `${FileSystem.cacheDirectory}payment_${Date.now()}_${Math.random().toString(36).slice(2)}.${extension}`;
  try {
    await FileSystem.copyAsync({from:uri,to:localUri});
    const file = new File(localUri);
    if (!file.size) throw new Error('File bukti pembayaran kosong atau tidak dapat dibaca.');
    if (file.size > maxBytes) throw new Error('Ukuran bukti pembayaran melebihi 5 MB.');
    form.append(fieldName, file, safeName);
    return form;
  } catch (error) {
    if (error instanceof Error && (error.message.includes('5 MB') || error.message.includes('kosong'))) throw error;
    throw new Error(`Bukti pembayaran tidak dapat dipersiapkan untuk upload di Android.${error instanceof Error ? ` (${error.message})` : ''}`);
  }
}
